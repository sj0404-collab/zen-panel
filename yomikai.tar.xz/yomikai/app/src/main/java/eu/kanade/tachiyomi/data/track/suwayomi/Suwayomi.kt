package eu.kanade.tachiyomi.data.track.suwayomi

import dev.icerock.moko.resources.StringResource
import eu.kanade.tachiyomi.R
import eu.kanade.tachiyomi.data.database.models.Track
import eu.kanade.tachiyomi.data.track.BaseTracker
import eu.kanade.tachiyomi.data.track.EnhancedTracker
import eu.kanade.tachiyomi.data.track.model.TrackSearch
import eu.kanade.tachiyomi.source.Source
import logcat.LogPriority
import tachiyomi.core.common.util.system.logcat
import tachiyomi.i18n.MR
import tachiyomi.domain.manga.model.Manga as DomainManga
import tachiyomi.domain.track.model.Track as DomainTrack

class Suwayomi(id: Long) : BaseTracker(id, "Suwayomi"), EnhancedTracker {

    val api by lazy { SuwayomiApi(id) }

    override fun getLogo() = R.drawable.brand_suwayomi

    companion object {
        const val UNREAD = 1L
        const val READING = 2L
        const val COMPLETED = 3L

        private const val TRACKER_DELETE_KEY = "Tracker Delete"
        private const val TRACKER_DELETE_DEFAULT = false
        private const val SEARCH_LIMIT = 20
    }

    override fun getStatusList(): List<Long> = listOf(UNREAD, READING, COMPLETED)

    override fun getStatus(status: Long): StringResource? = when (status) {
        UNREAD -> MR.strings.unread
        READING -> MR.strings.reading
        COMPLETED -> MR.strings.completed
        else -> null
    }

    override fun getReadingStatus(): Long = READING

    override fun getRereadingStatus(): Long = -1

    override fun getCompletionStatus(): Long = COMPLETED

    override fun getScoreList(): List<String> = listOf()

    override fun displayScore(track: DomainTrack): String = ""

    override suspend fun update(track: Track, didReadChapter: Boolean): Track {
        if (track.status != COMPLETED) {
            if (didReadChapter) {
                if (track.last_chapter_read.toLong() == track.total_chapters && track.total_chapters > 0) {
                    track.status = COMPLETED
                } else {
                    track.status = READING
                }
            }
        }

        return api.updateProgress(track, getPrefTrackerDelete())
    }

    override suspend fun bind(track: Track, hasReadChapters: Boolean): Track {
        return track
    }

    /**
     * Продвинутый поиск в Suwayomi (Tachidesk/Suwayomi-Server).
     *
     * Раньше метод бросал `TODO`, теперь реализован через GraphQL:
     *  - Пустой запрос → пустой список без сетевого обращения.
     *  - Использует `POST /api/graphql` с фильтром
     *    `mangas(filter: {title: {includesInsensitive: $query}}, first: 20)`.
     *  - При недоступности сервера или отсутствии Tachidesk-источника
     *    возвращается пустой список с предупреждением, а не краш.
     *  - Результаты мапятся в [TrackSearch] с корректными полями
     *    (title, summary, cover, tracking_url, chapters, статус).
     */
    override suspend fun search(query: String): List<TrackSearch> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        return try {
            api.search(q, SEARCH_LIMIT)
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "Suwayomi search failed for query=$q" }
            emptyList()
        }
    }

    override suspend fun refresh(track: Track): Track {
        val remoteTrack = api.getTrackSearch(track.remote_id)
        track.copyPersonalFrom(remoteTrack)
        track.total_chapters = remoteTrack.total_chapters
        return track
    }

    override suspend fun login(username: String, password: String) {
        saveCredentials("user", "pass")
    }

    override fun loginNoop() {
        saveCredentials("user", "pass")
    }

    override fun getAcceptedSources(): List<String> = listOf("eu.kanade.tachiyomi.extension.all.tachidesk.Tachidesk")

    override suspend fun match(manga: DomainManga): TrackSearch? =
        try {
            api.getTrackSearch(manga.url.getMangaId())
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "Suwayomi match failed for url=${manga.url}" }
            null
        }

    override fun isTrackFrom(track: DomainTrack, manga: DomainManga, source: Source?): Boolean =
        track.remoteUrl == manga.url && source?.let { accept(it) } == true

    override fun migrateTrack(track: DomainTrack, manga: DomainManga, newSource: Source): DomainTrack? =
        if (accept(newSource)) {
            track.copy(remoteUrl = manga.url)
        } else {
            null
        }

    private fun String.getMangaId(): Long =
        this.substringAfterLast('/').toLong()

    private fun getPrefTrackerDelete(): Boolean {
        return try {
            val preferences = api.sourcePreferences()
            preferences.getBoolean(TRACKER_DELETE_KEY, TRACKER_DELETE_DEFAULT)
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "Suwayomi getPrefTrackerDelete failed" }
            TRACKER_DELETE_DEFAULT
        }
    }
}
