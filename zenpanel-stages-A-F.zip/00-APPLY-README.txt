Zen Panel — stages A..F (final file states, base: main@4967755)
===============================================================
28 files. Each goes over the same repo path. Order does not matter:
every file here is already the FINAL version (all stages layered).

Contents
--------
A. Per-OS slots .......... panel, publish_session.sh, agent/opencode/hub.yml, README
B. Panel quota ........... panel (ETag, hidden-skip, 403 auto-pause, desks loop), README
C. Hub gate token ........ panel, server.js, mobile/desktop-app.js, hub.yml, READMEs
D. Tests in repo ......... tests/* (6 files), tests.yml, CAPABILITIES, README
E. PC local bundles ...... 4 yml (runner_* inputs), panel, suite, pc-local/* (9 files), README
F. Lazy hub + unified reads  panel, hub.yml, suite, READMEs

Verified: panel jsdom 39/39, hub mobile 20/20, hub desktop 18/18,
live hub gate battery 8/8, YAML x5, bash -n x3.

How to apply
------------
Option 1 — PC with git (fastest, keeps history clean):
  git clone / git pull the repo, unzip this archive over it, then
  git add -A
  git add --chmod=+x pc-local/start.sh pc-local/stop.sh pc-local/runner/setup.sh
  git commit -m "..." && git push
  (git push uses the git protocol, not the REST API, so the API ban
  usually does not block it.)

Option 2 — GitHub web UI (works during a REST API ban):
  open each file in the repo -> Edit (pencil) -> Ctrl+A -> paste the
  matching file content -> Commit. For NEW files (tests/*, pc-local/*,
  tests.yml) use Add file -> Create new file / Upload files.
  NOTE: the web UI cannot set the +x bit on the three .sh files.
  Until that is fixed, run them explicitly:  bash pc-local/start.sh

Option 3 — wait for the ban to lift:
  the agent pushes the same content as 6 PRs (A..F) with proper modes
  and CI. Say "push".

After applying (any option)
----------------------------
- npm test in tests/ (CI does it too via tests.yml).
- Install the fresh APK (v1.72+) and desktop build; old panels hammer
  the API (~100 req/min idle) and re-trip the ban. Keep panels CLOSED
  until the ban lifts.
- Hub runs: preinstall defaults to false (lazy npx at first click).
