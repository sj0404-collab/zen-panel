#!/usr/bin/env bash
# syntax-check one or more C files of the ARM9 port
set -u
cd /home/runner/hub-work/elementia/code
docker run --rm -u "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD":/work -w /work devkitpro/devkitarm:latest \
  bash -c 'source /opt/devkitpro/devkitarm.sh >/dev/null 2>&1
    ARMINC=$(arm-none-eabi-gcc -print-file-name=include)
    for f in "$@"; do
      echo "--- $f"
      arm-none-eabi-gcc -fsyntax-only -Wall -Wextra -Wno-unused-parameter \
        -D__NDS__ -DARM9 -DNDS -march=armv5te \
        -iquote nds/include -I/opt/devkitpro/libnds/include \
        -I/opt/devkitpro/calico/include -I"$ARMINC" "$f" || true
    done' bash "$@"
