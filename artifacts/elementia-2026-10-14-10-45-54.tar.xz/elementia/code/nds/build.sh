#!/usr/bin/env bash
# Builds the Nintendo DS ROM (nds/elementia.nds) inside the official devkitPro
# container, so no local devkitARM install is required.
#
#   ./nds/build.sh            build the ROM
#   ./nds/build.sh clean      remove build output
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$HERE/.." && pwd)"
IMAGE="${DEVKITPRO_IMAGE:-devkitpro/devkitarm:latest}"
ARTIFACTS="${ELEMENTIA_ARTIFACTS:-/home/runner/hub-work/elementia/tmp}"

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
	echo ">> pulling $IMAGE"
	docker pull "$IMAGE"
fi

run() {
	docker run --rm \
		-u "$(id -u):$(id -g)" \
		-e HOME=/tmp \
		-e DEVKITPRO=/opt/devkitpro \
		-e DEVKITARM=/opt/devkitpro/devkitARM \
		-v "$REPO:/work" \
		-v "$ARTIFACTS:/out" \
		-w /work/nds \
		"$IMAGE" \
		bash -c 'source /opt/devkitpro/devkitarm.sh && exec "$@"' bash "$@"
}

case "${1:-all}" in
	clean)
		run make clean
		;;
	assets)
		run make -C gen
		;;
	*)
		shift 2>/dev/null || true
		run make "$@"
		cp -f "$HERE/elementia.nds" "$ARTIFACTS/elementia.nds"
		echo ">> $ARTIFACTS/elementia.nds"
		;;
esac
