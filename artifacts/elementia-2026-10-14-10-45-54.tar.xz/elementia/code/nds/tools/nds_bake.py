#!/usr/bin/env python3
"""Offline asset baker for the Nintendo DS port of Elementia.

Reads the LibGDX source assets

    core/src/main/resources/art/*.png
    core/src/main/resources/fonts/DejaVuSans.ttf

and writes the two blobs described in ``nds/FORMATS.md``:

    nds/gen/art.bin     ARTB  -- RGB555 colour plane + 1bpp coverage plane
    nds/gen/fonts.bin   FNTS  -- three baked 1bpp bitmap fonts

Both blobs are consumed by C code that this script must not have to know
about, so the layout is fixed here and never guessed at runtime.

Standard library only: no PIL, no numpy, no FreeType, no mkbcfnt.  PNG and
TrueType decoding are both implemented here from scratch, so the pipeline runs
under a plain ``python3`` on the host as well as inside the devkitPro
container.

Usage
-----
    nds_bake.py art    --src <dir> --out art.bin
    nds_bake.py fonts  --font <ttf> --charset charset.txt --out fonts.bin
                      [--sizes 12,20,32]
    nds_bake.py verify art.bin fonts.bin
    nds_bake.py summary art.bin fonts.bin

``verify`` re-parses both blobs, checks the magic, walks every entry/glyph,
asserts that every offset stays in bounds and prints the summary tables.
"""

import argparse
import os
import struct
import sys
import zlib

# ---------------------------------------------------------------------------
# Format constants (nds/FORMATS.md)
# ---------------------------------------------------------------------------

ART_MAGIC = 0x42525441        # 'ARTB'
ART_VERSION = 1
ART_ENTRY_SIZE = 28
ART_HEADER_SIZE = 12          # u32 magic, u16 version, u16 count, u32 entrySize

FONT_MAGIC = 0x53544E46       # 'FNTS'
FONT_HEADER_SIZE = 8          # u32 magic, u8 count, u8 reserved[3]
FONT_RECORD_SIZE = 20         # see bake_fonts() for the layout deviation
# FORMATS.md lists six fields for Glyph, which sum to 14 bytes but are declared
# 16.  x and y must be signed - the drawing rule places ink *above* the pen
# baseline - so the record is laid out as:
#   u32 codepoint, u16 advance, s16 x, s16 y, u16 w, u16 h, u16 reserved
GLYPH_SIZE = 16


def plane_stride(w):
    """Row stride of a 1bpp plane in bytes: whole 32-bit words, so the C side
    can walk the plane with a ``const u32 *``."""
    return ((w + 31) // 32) * 4


# Bit order inside a 1bpp plane.
#
# FORMATS.md says "LSB = leftmost pixel" and include/gfx.h repeats it
# (``const u32 *mask; // w*h bits, row major, LSB = leftmost pixel``), so pixel
# (x, y) lives in bit ``x`` of byte ``x >> 3`` of row ``y``.  The font atlas is
# written the same way; FORMATS.md does not state an order for it.
def plane_bit(x):
    return 1 << (x & 7)


# ---------------------------------------------------------------------------
# Canonical texture set.  Names and order are normative (FORMATS.md); the sizes
# are the rectangles the LibGDX build stretched each source texture into, which
# is exactly what the NDS blitter draws into.
# ---------------------------------------------------------------------------

TEXTURES = [
    ("grass", 32, 32),
    ("dirt", 32, 32),
    ("stone", 32, 32),
    ("ice", 32, 32),
    ("snow", 32, 32),
    ("brick", 32, 32),
    ("lavaA", 32, 32),
    ("lavaB", 32, 32),
    ("water", 32, 32),
    ("platform", 32, 14),
    ("crystal", 24, 30),
    ("tree", 32, 48),
    ("chest", 28, 24),
    ("hero", 56, 76),
    ("slime", 44, 38),
    ("wisp", 16, 14),
    ("golem", 56, 52),
    ("boss", 88, 76),
    ("waypoint", 40, 56),
]

FONT_SIZES = (12, 20, 32)     # FONT_SMALL, FONT_BODY, FONT_TITLE

# Alpha ramp for the coverage plane.
#
# The AI generated sprites have soft, antialiased edges.  A hard ``alpha >= 128``
# cut would chew holes in them, so coverage is remapped so that anything below
# ALPHA_FLOOR is fully transparent and anything above ALPHA_CEIL fully opaque,
# with a linear ramp between:
#
#     coverage = clamp((alpha - 40) * 255 / 168, 0, 255)
#
# i.e. fully transparent below alpha 40, fully opaque above alpha 208.  The
# plane is still a hard 1bpp mask; the ramp only decides where the cut falls.
ALPHA_FLOOR = 40
ALPHA_CEIL = 208


class BakeError(Exception):
    """Recoverable problem with one asset; the caller warns and continues."""


def warn(msg):
    sys.stderr.write("nds_bake: warning: %s\n" % msg)


def _floor(v):
    return int(v // 1)


def _ceil(v):
    return -int(-v // 1)


# ===========================================================================
# PNG decoder
# ===========================================================================

PNG_SIG = b"\x89PNG\r\n\x1a\n"

# Adam7: (x_start, y_start, x_step, y_step) per pass.
_ADAM7 = (
    (0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4),
    (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2),
)

_CHANNELS = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}


def _paeth(a, b, c):
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _unfilter(raw, height, stride, bpp):
    """Reverse the per-scanline PNG filters (None/Sub/Up/Average/Paeth)."""
    out = bytearray(stride * height)
    prev = bytearray(stride)
    pos = 0
    for y in range(height):
        if pos + 1 + stride > len(raw):
            raise BakeError("truncated image data (row %d of %d)" % (y, height))
        ft = raw[pos]
        pos += 1
        line = bytearray(raw[pos:pos + stride])
        pos += stride

        if ft == 0:
            pass
        elif ft == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 0xFF
        elif ft == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ft == 3:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 0xFF
        elif ft == 4:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                upleft = prev[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + _paeth(left, prev[i], upleft)) & 0xFF
        else:
            raise BakeError("unknown scanline filter %d" % ft)

        out[y * stride:(y + 1) * stride] = line
        prev = line
    return out


def _expand_samples(line, count, depth):
    """Turn unfiltered scanline bytes into a flat list of 0..255 samples."""
    if depth == 8:
        return list(line[:count])
    if depth == 16:
        return [line[i * 2] for i in range(count)]      # take the high byte
    maxval = (1 << depth) - 1
    per_byte = 8 // depth
    out = []
    for i in range(count):
        byte = line[i // per_byte]
        shift = 8 - depth * ((i % per_byte) + 1)
        out.append(((byte >> shift) & maxval) * 255 // maxval)
    return out


def decode_png(path):
    """Decode a PNG into ``(width, height, bytearray of RGBA8 rows)``.

    Handles colour types 0/2/3/4/6, bit depths 1/2/4/8/16, all five scanline
    filters and Adam7 interlacing.  Anything genuinely unsupported raises
    BakeError so the caller can skip the texture instead of crashing.
    """
    with open(path, "rb") as fh:
        data = fh.read()
    if data[:8] != PNG_SIG:
        raise BakeError("not a PNG file")

    pos = 8
    width = height = depth = ctype = None
    interlace = 0
    palette = None
    trns = None
    idat = []

    while pos + 8 <= len(data):
        (length,) = struct.unpack(">I", data[pos:pos + 4])
        ctag = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctag == b"IHDR":
            (width, height, depth, ctype, _comp, _filt,
             interlace) = struct.unpack(">IIBBBBB", body[:13])
        elif ctag == b"PLTE":
            palette = body
        elif ctag == b"tRNS":
            trns = body
        elif ctag == b"IDAT":
            idat.append(body)
        elif ctag == b"IEND":
            break

    if width is None or not idat:
        raise BakeError("missing IHDR or IDAT")
    if ctype not in _CHANNELS:
        raise BakeError("unsupported colour type %d" % ctype)
    if depth not in (1, 2, 4, 8, 16):
        raise BakeError("unsupported bit depth %d" % depth)
    if interlace not in (0, 1):
        raise BakeError("unsupported interlace method %d" % interlace)
    if ctype == 3 and palette is None:
        raise BakeError("palette image without PLTE")

    raw = zlib.decompress(b"".join(idat))
    channels = _CHANNELS[ctype]
    rgba = bytearray(width * height * 4)

    def emit(dx, dy, samples, count):
        """Write `count` consecutive pixels starting at column dx of row dy."""
        base = dy * width * 4 + dx * 4
        if ctype == 3:
            for i in range(count):
                idx = samples[i]
                o = base + i * 4
                p = idx * 3
                if p + 2 < len(palette):
                    rgba[o] = palette[p]
                    rgba[o + 1] = palette[p + 1]
                    rgba[o + 2] = palette[p + 2]
                if trns is not None and idx < len(trns):
                    rgba[o + 3] = trns[idx]
                else:
                    rgba[o + 3] = 255
            return
        step = channels
        for i in range(count):
            o = base + i * 4
            s = i * step
            if channels >= 3:
                rgba[o] = samples[s]
                rgba[o + 1] = samples[s + 1]
                rgba[o + 2] = samples[s + 2]
            else:
                rgba[o] = rgba[o + 1] = rgba[o + 2] = samples[s]
            rgba[o + 3] = samples[s + channels - 1] if channels >= 2 else 255

    if interlace == 0:
        stride = (width * channels * depth + 7) // 8
        bpp = max(1, channels * depth // 8)
        pixels = _unfilter(raw, height, stride, bpp)
        for y in range(height):
            line = pixels[y * stride:(y + 1) * stride]
            emit(0, y, _expand_samples(line, width * channels, depth), width)
    else:
        off = 0
        for (xs, ys, xstep, ystep) in _ADAM7:
            pw = (width - xs + xstep - 1) // xstep
            ph = (height - ys + ystep - 1) // ystep
            if pw <= 0 or ph <= 0:
                continue
            stride = (pw * channels * depth + 7) // 8
            bpp = max(1, channels * depth // 8)
            chunk = raw[off:off + (stride + 1) * ph]
            off += (stride + 1) * ph
            pixels = _unfilter(chunk, ph, stride, bpp)
            for py in range(ph):
                line = pixels[py * stride:(py + 1) * stride]
                samples = _expand_samples(line, pw * channels, depth)
                y = ys + py * ystep
                for px in range(pw):
                    x = xs + px * xstep
                    emit(x, y, samples[px * channels:(px + 1) * channels], 1)

    if width <= 0 or height <= 0:
        raise BakeError("degenerate image size")
    return width, height, rgba


# ===========================================================================
# Resampling
# ===========================================================================

def resample(sw, sh, src, dw, dh):
    """Area-average (box filter) resize of an RGBA8 buffer.

    LibGDX stretched the *whole* source texture into the target rectangle, so
    the NDS build downscales the whole image too - never a centre crop.  At a
    1:1 ratio (or when the source is smaller than the destination, where a box
    filter degenerates) it falls back to nearest neighbour.
    """
    if sw == dw and sh == dh:
        return bytearray(src)
    if sw <= dw or sh <= dh:
        return _resample_nearest(sw, sh, src, dw, dh)

    out = bytearray(dw * dh * 4)
    xr = sw / float(dw)
    yr = sh / float(dh)
    for dy in range(dh):
        sy0 = dy * yr
        sy1 = sy0 + yr
        iy0 = int(sy0)
        iy1 = min(sh, _ceil(sy1))
        ybase = dy * dw * 4
        for dx in range(dw):
            sx0 = dx * xr
            sx1 = sx0 + xr
            ix0 = int(sx0)
            ix1 = min(sw, _ceil(sx1))

            rsum = gsum = bsum = 0.0
            asum = 0.0      # sum(w * a)
            wsum = 0.0      # sum(w)
            war = wag = wab = 0.0
            for iy in range(iy0, iy1):
                lo = sy0 if iy < sy0 else iy
                hi = sy1 if iy + 1 > sy1 else iy + 1
                wy = hi - lo
                if wy <= 0.0:
                    continue
                row = (iy * sw) * 4
                for ix in range(ix0, ix1):
                    lo = sx0 if ix < sx0 else ix
                    hi = sx1 if ix + 1 > sx1 else ix + 1
                    wx = hi - lo
                    if wx <= 0.0:
                        continue
                    w = wx * wy
                    o = row + ix * 4
                    a = src[o + 3]
                    rsum += w * src[o]
                    gsum += w * src[o + 1]
                    bsum += w * src[o + 2]
                    asum += w * a
                    wsum += w
                    war += w * a * src[o]
                    wag += w * a * src[o + 1]
                    wab += w * a * src[o + 2]

            o = ybase + dx * 4
            if wsum <= 0.0:
                wsum = 1.0
            out[o + 3] = _clamp8(asum / wsum)
            if asum > 0.0:
                # Alpha-weighted average keeps antialiased edges from being
                # dragged towards the RGB of fully transparent neighbours.
                out[o] = _clamp8(war / asum)
                out[o + 1] = _clamp8(wag / asum)
                out[o + 2] = _clamp8(wab / asum)
            else:
                out[o] = _clamp8(rsum / wsum)
                out[o + 1] = _clamp8(gsum / wsum)
                out[o + 2] = _clamp8(bsum / wsum)
    return out


def _resample_nearest(sw, sh, src, dw, dh):
    out = bytearray(dw * dh * 4)
    for dy in range(dh):
        sy = min(sh - 1, (dy * sh) // dh)
        for dx in range(dw):
            sx = min(sw - 1, (dx * sw) // dw)
            o = (dy * dw + dx) * 4
            s = (sy * sw + sx) * 4
            out[o:o + 4] = src[s:s + 4]
    return out


def _clamp8(v):
    i = int(v)
    return 0 if i < 0 else (255 if i > 255 else i)


def coverage(alpha):
    """Smooth alpha -> coverage ramp; see ALPHA_FLOOR / ALPHA_CEIL."""
    c = (alpha - ALPHA_FLOOR) * 255 // (ALPHA_CEIL - ALPHA_FLOOR)
    return 0 if c < 0 else (255 if c > 255 else c)


def rgb555(r, g, b):
    """Mirror of the C side's rgb555(): R in bits 0-4, G in 5-9, B in 10-14."""
    return ((r >> 3) << 0) | ((g >> 3) << 5) | ((b >> 3) << 10)


# ===========================================================================
# art.bin
# ===========================================================================

def bake_art(src_dir, out_path):
    if not os.path.isdir(src_dir):
        raise BakeError("art source directory not found: %s" % src_dir)

    entries = []
    for name, tw, th in TEXTURES:
        path = _find_png(src_dir, name)
        if path is None:
            warn("%s: source PNG not found, skipping texture (the C side "
                 "falls back to a procedural one)" % name)
            continue
        try:
            sw, sh, rgba = decode_png(path)
        except BakeError as exc:
            warn("%s: %s, skipping texture" % (name, exc))
            continue
        except Exception as exc:                    # pragma: no cover
            warn("%s: cannot decode (%s), skipping texture" % (name, exc))
            continue

        small = resample(sw, sh, rgba, tw, th)
        stride = plane_stride(tw)
        pixels = bytearray(tw * th * 2)
        masks = bytearray(stride * th)
        for y in range(th):
            row = y * tw * 4
            for x in range(tw):
                o = row + x * 4
                r, g, b, a = small[o], small[o + 1], small[o + 2], small[o + 3]
                # The blitter indexes colour and mask independently, so the
                # colour of a transparent pixel must still be written out.
                struct.pack_into("<H", pixels, (y * tw + x) * 2,
                                 rgb555(r, g, b))
                if coverage(a) >= 128:
                    masks[y * stride + (x >> 3)] |= plane_bit(x)
        entries.append((name, tw, th, pixels, masks))

    if not entries:
        raise BakeError("no usable source art found in %s" % src_dir)

    pixel_bytes = sum(len(e[3]) for e in entries)
    # FORMATS.md declares the mask region as `u32 masks[pixelBytes*2/8]`, i.e.
    # exactly as many bytes as the colour plane.  Every texture row is already a
    # whole number of 32-bit words, so that is always >= the mask data actually
    # written; the tail is zero filled so the declared bound holds and the C
    # side can derive masksAt = tableEnd + pixelBytes without a stored field.
    mask_bytes = pixel_bytes
    if sum(len(e[4]) for e in entries) > mask_bytes:
        raise BakeError("internal error: mask region overflow")

    table_end = ART_HEADER_SIZE + ART_ENTRY_SIZE * len(entries)
    pixels_at = table_end
    masks_at = pixels_at + pixel_bytes

    out = bytearray(masks_at + mask_bytes)
    struct.pack_into("<IHHI", out, 0, ART_MAGIC, ART_VERSION,
                     len(entries), ART_ENTRY_SIZE)

    po = mo = 0
    for i, (name, tw, th, pixels, masks) in enumerate(entries):
        nm = name.encode("ascii")
        if len(nm) + 1 > ART_ENTRY_SIZE - 14:
            raise BakeError("texture name %r too long for Entry" % name)
        e = ART_HEADER_SIZE + i * ART_ENTRY_SIZE
        out[e] = len(nm)
        out[e + 1] = 0
        struct.pack_into("<HHII", out, e + 2, tw, th, po, mo)
        out[e + 14:e + 14 + len(nm)] = nm
        out[pixels_at + po:pixels_at + po + len(pixels)] = pixels
        out[masks_at + mo:masks_at + mo + len(masks)] = masks
        po += len(pixels)
        mo += len(masks)

    _write(out_path, bytes(out))
    return [_tex_stats(e) for e in entries], len(out)


def _find_png(src_dir, name):
    for cand in (name + ".png", name.lower() + ".png", name.upper() + ".png"):
        p = os.path.join(src_dir, cand)
        if os.path.isfile(p):
            return p
    want = (name + ".png").lower()
    for fn in sorted(os.listdir(src_dir)):
        if fn.lower() == want:
            return os.path.join(src_dir, fn)
    return None


def _tex_stats(entry):
    name, tw, th, _pixels, masks = entry
    stride = plane_stride(tw)
    opaque = 0
    for y in range(th):
        row = masks[y * stride:(y + 1) * stride]
        for x in range(tw):
            if row[x >> 3] & plane_bit(x):
                opaque += 1
    return (name, tw, th, opaque, tw * th)


# ===========================================================================
# TrueType
# ===========================================================================

_F2DOT14 = 1.0 / 16384.0

_CMP_ARGS_ARE_WORDS = 0x0001
_CMP_ARGS_ARE_XY = 0x0002
_CMP_WE_HAVE_A_SCALE = 0x0008
_CMP_MORE = 0x0020
_CMP_WE_HAVE_XY_SCALE = 0x0040
_CMP_WE_HAVE_2X2 = 0x0080
_CMP_UNSCALED_OFFSET = 0x1000


class TrueTypeFont(object):
    """Just enough of the spec to rasterise a bitmap font: head, maxp, hhea,
    hmtx, cmap, loca and glyf (including composite glyphs)."""

    def __init__(self, path):
        self.path = path
        self.advance = []
        self.lsb = []
        with open(path, "rb") as fh:
            self.data = fh.read()
        if len(self.data) < 12:
            raise BakeError("%s: truncated font file" % path)
        if self.data[:4] not in (b"\x00\x01\x00\x00", b"true", b"OTTO"):
            raise BakeError("%s: not a TrueType/OpenType font" % path)

        num = struct.unpack(">H", self.data[4:6])[0]
        self.tables = {}
        for i in range(num):
            o = 12 + 16 * i
            tag = self.data[o:o + 4].decode("latin-1")
            off, ln = struct.unpack(">II", self.data[o + 8:o + 16])
            self.tables[tag] = (off, ln)
        for req in ("head", "maxp", "hhea", "hmtx", "cmap", "loca", "glyf"):
            if req not in self.tables:
                raise BakeError("%s: missing '%s' table" % (path, req))

        h = self.tables["head"][0]
        (self.units_per_em,) = struct.unpack(">H", self.data[h + 18:h + 20])
        (self.x_min, self.y_min, self.x_max,
         self.y_max) = struct.unpack(">hhhh", self.data[h + 36:h + 44])
        (self.mac_style,) = struct.unpack(">H", self.data[h + 44:h + 46])
        (self.loc_fmt,) = struct.unpack(">h", self.data[h + 50:h + 52])
        if self.units_per_em <= 0:
            raise BakeError("%s: bad unitsPerEm" % path)
        if self.loc_fmt not in (0, 1):
            raise BakeError("%s: unsupported loca format %d" % (path, self.loc_fmt))

        mp = self.tables["maxp"][0]
        self.num_glyphs = struct.unpack(">H", self.data[mp + 4:mp + 6])[0]

        hh = self.tables["hhea"][0]
        (self.hhea_ascent, self.hhea_descent,
         self.line_gap) = struct.unpack(">hhh", self.data[hh + 4:hh + 10])
        self.num_h_metrics = struct.unpack(">H", self.data[hh + 34:hh + 36])[0]

        # USE_TYPO_METRICS (OS/2 fsSelection bit 7) wins over hhea.
        self.ascent_units = self.hhea_ascent
        self.descent_units = self.hhea_descent
        if "OS/2" in self.tables and self.tables["OS/2"][1] >= 74:
            oo = self.tables["OS/2"][0]
            if struct.unpack(">H", self.data[oo + 62:oo + 64])[0] & 0x0080:
                ta, td, _tg = struct.unpack(">hhh", self.data[oo + 68:oo + 74])
                self.ascent_units, self.descent_units = ta, td

        self._read_loca()
        self._read_hmtx()
        self.cmap = self._read_cmap()

    # -- tables ------------------------------------------------------------
    def _read_loca(self):
        off, ln = self.tables["loca"]
        n = min(self.num_glyphs + 1, ln // (4 if self.loc_fmt else 2))
        if self.loc_fmt == 0:
            raw = struct.unpack(">%dH" % n, self.data[off:off + 2 * n])
            self.loca = [v * 2 for v in raw]
        else:
            self.loca = list(struct.unpack(">%dI" % n, self.data[off:off + 4 * n]))
        self.glyf_off = self.tables["glyf"][0]

    def _read_hmtx(self):
        off, ln = self.tables["hmtx"]
        for i in range(self.num_h_metrics):
            o = off + i * 4
            if o + 4 > off + ln:
                break
            a, l = struct.unpack(">Hh", self.data[o:o + 4])
            self.advance.append(a)
            self.lsb.append(l)
        if not self.advance:
            raise BakeError("empty hmtx table")

    def _read_cmap(self):
        base = self.tables["cmap"][0]
        n = struct.unpack(">H", self.data[base + 2:base + 4])[0]
        subs = []
        for i in range(n):
            pid, eid, off = struct.unpack(">HHI", self.data[base + 4 + 8 * i:
                                                          base + 12 + 8 * i])
            fmt = struct.unpack(">H", self.data[base + off:base + off + 2])[0]
            if (pid, eid) in ((3, 10), (0, 4), (0, 6), (3, 1), (0, 3), (0, 0),
                              (3, 0)):
                subs.append((pid, eid, fmt, base + off))
        rank = {12: 0, 4: 1, 6: 2, 0: 3}
        subs.sort(key=lambda s: (rank.get(s[2], 9), 0 if s[0] == 3 else 1))

        table = {}
        for _pid, _eid, fmt, off in subs:
            table = self._parse_cmap_subtable(fmt, off)
            if table:
                break
        if not table:
            raise BakeError("%s: no usable cmap subtable" % self.path)
        return table

    def _parse_cmap_subtable(self, fmt, off):
        d = self.data
        table = {}
        if fmt == 12:
            ngroups = struct.unpack(">I", d[off + 12:off + 16])[0]
            for g in range(ngroups):
                o = off + 16 + 12 * g
                s, e, gid = struct.unpack(">III", d[o:o + 12])
                if e < s or e - s > 0x20000:
                    continue
                for c in range(s, e + 1):
                    table[c] = gid + (c - s)
        elif fmt == 4:
            segx2 = struct.unpack(">H", d[off + 6:off + 8])[0]
            seg = segx2 // 2
            ends = struct.unpack(">%dH" % seg, d[off + 14:off + 14 + segx2])
            so = off + 16 + segx2
            starts = struct.unpack(">%dH" % seg, d[so:so + segx2])
            do = so + segx2
            deltas = struct.unpack(">%dh" % seg, d[do:do + segx2])
            ro = do + segx2
            ranges = struct.unpack(">%dH" % seg, d[ro:ro + segx2])
            for i in range(seg):
                if ranges[i] == 0 or starts[i] > ends[i]:
                    continue
                for c in range(starts[i], min(ends[i], 0xFFFE) + 1):
                    gi = ro + i * 2 + ranges[i] + (c - starts[i]) * 2
                    if gi + 2 > len(d):
                        continue
                    gid = struct.unpack(">H", d[gi:gi + 2])[0]
                    if gid:
                        table[c] = (gid + deltas[i]) & 0xFFFF
        elif fmt == 6:
            first, cnt = struct.unpack(">HH", d[off + 6:off + 10])
            for i in range(cnt):
                gid = struct.unpack(">H", d[off + 10 + i * 2:off + 12 + i * 2])[0]
                if gid:
                    table[first + i] = gid
        elif fmt == 0:
            for c in range(256):
                gid = d[off + 6 + c]
                if gid:
                    table[c] = gid
        return table

    # -- outlines ----------------------------------------------------------
    def glyph_contours(self, gid, _depth=0):
        """List of contours, each a list of (x, y, on_curve) in font units."""
        if _depth > 5 or gid < 0 or gid + 1 >= len(self.loca):
            return []
        start, end = self.loca[gid], self.loca[gid + 1]
        if end <= start:
            return []
        o = self.glyf_off + start
        ncont = struct.unpack(">h", self.data[o:o + 2])[0]
        o += 10                                    # skip xMin/yMin/xMax/yMax
        if ncont >= 0:
            return self._simple_glyph(o, ncont)
        return self._composite_glyph(o + 2, _depth)

    def _simple_glyph(self, o, ncont):
        d = self.data
        if ncont <= 0:
            return []
        ends = struct.unpack(">%dH" % ncont, d[o:o + 2 * ncont])
        o += 2 * ncont
        ilen = struct.unpack(">H", d[o:o + 2])[0]
        o += 2 + ilen
        npts = ends[-1] + 1

        flags = []
        while len(flags) < npts:
            f = d[o]
            o += 1
            flags.append(f)
            if f & 0x08:
                flags.extend([f] * d[o])
                o += 1
        del flags[npts:]

        xs = []
        x = 0
        for f in flags:
            if f & 0x02:
                dx = d[o]
                o += 1
                x += dx if (f & 0x10) else -dx
            elif not (f & 0x10):
                x += struct.unpack(">h", d[o:o + 2])[0]
                o += 2
            xs.append(x)
        ys = []
        y = 0
        for f in flags:
            if f & 0x04:
                dy = d[o]
                o += 1
                y += dy if (f & 0x20) else -dy
            elif not (f & 0x20):
                y += struct.unpack(">h", d[o:o + 2])[0]
                o += 2
            ys.append(y)

        oncurve = [bool(f & 0x01) for f in flags]
        contours = []
        first = 0
        for last in ends:
            pts = [(xs[i], ys[i], oncurve[i]) for i in range(first, last + 1)]
            first = last + 1
            if pts:
                contours.append(pts)
        return contours

    def _composite_glyph(self, o, depth):
        d = self.data
        out = []
        while True:
            flags, gid = struct.unpack(">HH", d[o:o + 4])
            o += 4
            if flags & _CMP_ARGS_ARE_WORDS:
                a1, a2 = struct.unpack(">hh", d[o:o + 4])
                o += 4
            else:
                a1, a2 = struct.unpack(">bb", d[o:o + 2])
                o += 2
            if flags & _CMP_WE_HAVE_A_SCALE:
                a = b = struct.unpack(">h", d[o:o + 2])[0] * _F2DOT14
                c, e = 0.0, 1.0
                o += 2
            elif flags & _CMP_WE_HAVE_XY_SCALE:
                a, b = [v * _F2DOT14 for v in struct.unpack(">hh", d[o:o + 4])]
                c, e = 0.0, 1.0
                o += 4
            elif flags & _CMP_WE_HAVE_2X2:
                a, b, c, e = [v * _F2DOT14
                              for v in struct.unpack(">hhhh", d[o:o + 8])]
                o += 8
            else:
                a, b, c, e = 1.0, 0.0, 0.0, 1.0
            dx, dy = (a1, a2) if (flags & _CMP_ARGS_ARE_XY) else (0, 0)
            if not (flags & _CMP_UNSCALED_OFFSET):
                dx, dy = a * dx + c * dy, b * dx + e * dy
            for cont in self.glyph_contours(gid, depth + 1):
                out.append([(x * a + c * y + dx, b * x + e * y + dy, on)
                            for (x, y, on) in cont])
            if not (flags & _CMP_MORE):
                break
        return out


# ---------------------------------------------------------------------------
# Outline -> polygon -> coverage bitmap
# ---------------------------------------------------------------------------

def flatten_contour(pts, scale):
    """Convert a TrueType quadratic contour into a closed polygon in pixels
    (y up, baseline at y = 0).  Handles off-curve points and the implied
    on-curve midpoints between two consecutive off-curve points."""
    n = len(pts)
    if n == 0:
        return []

    start = -1
    for i in range(n):
        if pts[i][2]:
            start = i
            break
    if start < 0:
        # All points are off-curve: start halfway between the last and first.
        x0 = (pts[-1][0] + pts[0][0]) / 2.0
        y0 = (pts[-1][1] + pts[0][1]) / 2.0
        seq = [(x0, y0, True)] + list(pts)
    else:
        seq = list(pts[start:]) + list(pts[:start])

    poly = [(seq[0][0] * scale, seq[0][1] * scale)]
    m = len(seq)
    i = 1
    while i <= m:
        px, py, on = seq[i % m]
        if on:
            poly.append((px * scale, py * scale))
            i += 1
            continue
        nx, ny, non = seq[(i + 1) % m]
        ctl = (px * scale, py * scale)
        if non:
            end = (nx * scale, ny * scale)
            i += 2
        else:
            end = ((px + nx) / 2.0 * scale, (py + ny) / 2.0 * scale)
            i += 1
        poly.extend(_quad(poly[-1], ctl, end))
        poly[-1] = end
    return poly


def _quad(p0, p1, p2):
    """Flatten a quadratic bezier, stepping at most ~0.25px along the control
    polygon so even the sharpest serifs stay smooth at 32px."""
    lx = abs(p1[0] - p0[0]) + abs(p2[0] - p1[0])
    ly = abs(p1[1] - p0[1]) + abs(p2[1] - p1[1])
    n = int((lx + ly) / 0.25) + 1
    if n > 64:
        n = 64
    out = []
    for k in range(1, n + 1):
        t = k / float(n)
        u = 1.0 - t
        out.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0],
                    u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))
    return out


def rasterize(polys, left, top, w, h, ss=4):
    """Nonzero-winding scanline fill with ss x ss supersampling.

    ``left``/``top`` are the ink box origin in pixels with y measured *upwards*
    from the baseline, so pixel row r covers y in [top - r - 1, top - r].
    Returns h rows of w values, each 0 or 1.
    """
    if w <= 0 or h <= 0:
        return []

    edges = []
    for poly in polys:
        n = len(poly)
        if n < 3:
            continue
        for i in range(n):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % n]
            if y0 != y1:
                edges.append((y0, y1, x0, y0, x1, y1))

    inv = 1.0 / ss
    xs_pos = [left + c + (j + 0.5) * inv for c in range(w) for j in range(ss)]
    cov = [[0] * w for _ in range(h)]

    for r in range(h):
        row = cov[r]
        for j in range(ss):
            py = top - r - (j + 0.5) * inv
            xs = []
            for (y0, y1, ax, ay, bx, by) in edges:
                if y0 <= py < y1:
                    xs.append((ax + (py - ay) * (bx - ax) / (y1 - ay), 1))
                elif y1 <= py < y0:
                    xs.append((ax + (py - ay) * (bx - ax) / (y1 - ay), -1))
            if not xs:
                continue
            xs.sort()
            wind = 0
            span_start = 0.0
            for (xv, direction) in xs:
                if wind == 0:
                    span_start = xv
                wind += direction
                if wind != 0 or xv <= span_start:
                    continue
                c0 = max(0, _floor(span_start - left))
                c1 = min(w - 1, _floor(xv - left))
                for c in range(c0, c1 + 1):
                    base = c * ss
                    n_hit = 0
                    for i in range(ss):
                        if span_start <= xs_pos[base + i] < xv:
                            n_hit += 1
                    row[c] += n_hit

    return [[1 if v * 2 >= ss * ss else 0 for v in row] for row in cov]


# ---------------------------------------------------------------------------
# Atlas packing
# ---------------------------------------------------------------------------

def pack_shelves(items, max_w=4096, max_h=4096):
    """Shelf-pack (w, h, key) items; returns (atlas_w, atlas_h, {key: (x, y)}).

    Items are sorted tallest-first, which keeps shelf waste low.  Ties break on
    the key so the packing is deterministic.
    """
    order = sorted(items, key=lambda it: (-it[1], -it[0], it[2]))
    best = None
    for width in range(256, max_w + 1, 128):
        pos = {}
        x = y = shelf = 0
        ok = True
        for (w, h, key) in order:
            if x + w > width:
                x = 0
                y += shelf
                shelf = 0
            if y + h > max_h:
                ok = False
                break
            pos[key] = (x, y)
            x += w + 1
            if h > shelf:
                shelf = h
        if not ok:
            continue
        height = y + shelf
        cost = plane_stride(width) * height
        if best is None or cost < best[0]:
            best = (cost, width, height, pos)
    if best is None:
        raise BakeError("glyphs do not fit in a %dx%d atlas" % (max_w, max_h))
    return best[1], best[2], best[3]


# ---------------------------------------------------------------------------
# fonts.bin
# ---------------------------------------------------------------------------

def read_charset(path):
    """Whitespace separated codepoints (decimal or 0x hex), '#' comments."""
    with open(path, "r", encoding="utf-8") as fh:
        lines = fh.readlines()
    out = []
    for tok in "".join(ln.split("#", 1)[0] for ln in lines).split():
        try:
            if tok.lower().startswith("0x"):
                out.append(int(tok, 16))
            elif tok.isdigit():
                out.append(int(tok, 10))
            else:
                out.extend(ord(c) for c in tok)
        except ValueError:
            warn("charset: ignoring unparsable token %r" % tok)
    return sorted(set(out))


def build_font(font, codepoints, size):
    """Rasterise, trim and pack one font size."""
    scale = size / float(font.units_per_em)
    ascent = int(round(font.ascent_units * scale))
    descent = int(round(-font.descent_units * scale))
    line_height = ascent + descent
    box_top = line_height - ascent            # ink rows are offset by this

    glyphs = []                 # [cp, advance, x, y, w, h, bitmap|None]
    for cp in codepoints:
        gid = font.cmap.get(cp, 0)
        advance = 0
        if gid:
            aw = (font.advance[gid] if gid < len(font.advance)
                  else font.advance[-1])
            advance = int(round(aw * scale))
        if not gid:
            glyphs.append((cp, advance, 0, 0, 0, 0, None))
            continue

        polys = []
        lo_x = lo_y = 1e30
        hi_x = hi_y = -1e30
        for cont in font.glyph_contours(gid):
            poly = flatten_contour(cont, scale)
            if len(poly) < 3:
                continue
            polys.append(poly)
            for (px, py) in poly:
                lo_x = min(lo_x, px)
                hi_x = max(hi_x, px)
                lo_y = min(lo_y, py)
                hi_y = max(hi_y, py)
        if not polys:
            glyphs.append((cp, advance, 0, 0, 0, 0, None))
            continue

        left = _floor(lo_x)
        top = _ceil(hi_y)
        w = _ceil(hi_x) - left
        h = top - _floor(lo_y)
        if w <= 0 or h <= 0:
            glyphs.append((cp, advance, 0, 0, 0, 0, None))
            continue

        shifted = [[(px - left, py) for (px, py) in poly] for poly in polys]
        bitmap = rasterize(shifted, 0.0, float(top), w, h)
        # Drawing rule from FORMATS.md:
        #   ink top left = (x + g.x, y + lineHeight - ascent + g.y)
        # so g.y is the ink top measured from (baseline - box_top).
        glyphs.append((cp, advance, left, top - box_top, w, h, bitmap))

    nonempty = [(g[4], g[5], i) for i, g in enumerate(glyphs) if g[4] > 0]
    if nonempty:
        aw, ah, pos = pack_shelves(nonempty)
    else:
        aw, ah, pos = 32, 32, {}
    ah = (ah + 3) & ~3

    stride = plane_stride(aw)
    atlas = bytearray(stride * ah)
    for (w, h, i) in nonempty:
        g = glyphs[i]
        x, y = pos[i]
        for r in range(h):
            row = g[6][r]
            base = (y + r) * stride + (x >> 3)
            for c in range(w):
                if row[c]:
                    atlas[base + (c >> 3)] |= plane_bit(x + c)

    return {
        "glyphs": glyphs,
        "atlas": bytes(atlas),
        "stats": {
            "size": size,
            "glyphs": len(glyphs),
            "ink": len(nonempty),
            "atlas_w": aw,
            "atlas_h": ah,
            "atlas_bytes": stride * ah,
            "line_height": line_height,
            "ascent": ascent,
            "descent": descent,
            "blank": len(glyphs) - len(nonempty),
        },
    }


def bake_fonts(ttf_path, charset_path, out_path, sizes=FONT_SIZES,
               glyph_count_bits=32):
    codepoints = read_charset(charset_path)
    if not codepoints:
        raise BakeError("charset %s is empty" % charset_path)
    font = TrueTypeFont(ttf_path)
    built = [build_font(font, codepoints, size) for size in sizes]

    if glyph_count_bits == 8:
        for b in built:
            if len(b["glyphs"]) > 255:
                raise BakeError(
                    "font at %dpx needs %d glyphs but the format declares "
                    "u8 glyphCount; re-run with --glyph-count-bits 32"
                    % (b["stats"]["size"], len(b["glyphs"])))

    tables_at = FONT_HEADER_SIZE + FONT_RECORD_SIZE * len(built)
    data_at = tables_at + GLYPH_SIZE * sum(len(b["glyphs"]) for b in built)

    out = bytearray()
    out += struct.pack("<IB3s", FONT_MAGIC, len(built), b"\0\0\0")
    off = data_at
    for b in built:
        st = b["stats"]
        if glyph_count_bits == 8:
            rec = struct.pack("<BBBBIII", len(st["glyphs"]) & 0xFF,
                              st["line_height"], st["ascent"], 0,
                              off, st["atlas_w"], st["atlas_h"])
        else:
            # FORMATS.md declares `u8 glyphCount`, which caps a font at 255
            # glyphs.  The required charset (ASCII printable + U+0400..U+04FF +
            # the quotes and arrows) is 361, so the field is widened to u32 and
            # the record padded from 16 to 20 bytes; every other field keeps its
            # documented order and size.
            rec = struct.pack("<IBBBBIII", st["glyphs"], st["line_height"],
                              st["ascent"], 0, 0, off, st["atlas_w"],
                              st["atlas_h"])
        if len(rec) != FONT_RECORD_SIZE:
            raise BakeError("internal error: font record is %d bytes" % len(rec))
        out += rec
    out += b"\0" * (tables_at - len(out))
    for b in built:
        for (cp, advance, x, y, w, h, _bm) in b["glyphs"]:
            if not (-32768 <= x < 32768 and -32768 <= y < 32768):
                raise BakeError("glyph U+%04X offset (%d, %d) does not fit "
                                "in s16" % (cp, x, y))
            out += struct.pack("<IHhhHHH", cp, advance, x, y, w, h, 0)
    out += b"\0" * (data_at - len(out))
    for b in built:
        out += b["atlas"]

    _write(out_path, bytes(out))
    return [b["stats"] for b in built], len(out)


# ---------------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------------

def _write(path, blob):
    directory = os.path.dirname(os.path.abspath(path))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory, exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(blob)


# ===========================================================================
# Verification / summary
# ===========================================================================

def _check(cond, msg):
    if not cond:
        raise BakeError("verify: " + msg)


def verify_art(blob):
    _check(len(blob) >= ART_HEADER_SIZE, "art.bin shorter than its header")
    magic, version, count, entry_size = struct.unpack_from("<IHHI", blob, 0)
    _check(magic == ART_MAGIC,
           "art.bin magic is 0x%08X, want 0x%08X" % (magic, ART_MAGIC))
    _check(version == ART_VERSION, "art.bin version is %d" % version)
    _check(entry_size == ART_ENTRY_SIZE, "art.bin entrySize is %d" % entry_size)
    table_end = ART_HEADER_SIZE + ART_ENTRY_SIZE * count
    _check(len(blob) >= table_end, "art.bin table runs past end of file")

    raw = []
    for i in range(count):
        e = ART_HEADER_SIZE + i * ART_ENTRY_SIZE
        struct_end = ART_HEADER_SIZE + ART_ENTRY_SIZE * (i + 1)
        name_len = blob[e]
        _check(blob[e + 1] == 0, "entry %d has a non-zero reserved byte" % i)
        _check(14 + name_len <= ART_ENTRY_SIZE,
               "entry %d nameLen %d does not fit in the struct" % (i, name_len))
        _check(struct_end <= len(blob), "entry %d runs past end of file" % i)
        w, h, pixel_off, mask_off = struct.unpack_from("<HHII", blob, e + 2)
        name = blob[e + 14:e + 14 + name_len].decode("ascii", "replace")
        _check(blob[e + 14 + name_len] == 0,
               "entry %s name is not NUL terminated" % name)
        _check(0 < w <= 1024 and 0 < h <= 1024,
               "entry %s has size %dx%d" % (name, w, h))
        _check(14 + name_len + 1 <= ART_ENTRY_SIZE,
               "entry %s name overruns the struct" % name)
        _check(pixel_off % 2 == 0,
               "entry %s pixelOff %d is not 2-byte aligned" % (name, pixel_off))
        _check(mask_off % 4 == 0,
               "entry %s maskOff %d is not word aligned" % (name, mask_off))
        raw.append((name, w, h, pixel_off, mask_off))

    names = [r[0] for r in raw]
    _check(len(set(names)) == len(names), "duplicate texture names")

    # Colour planes are packed in table order with no padding, so the colour
    # region is exactly sum(w*h*2) bytes and the mask region starts right after.
    pixel_bytes = sum(w * h * 2 for (_, w, h, _, _) in raw)
    masks_at = table_end + pixel_bytes
    _check(masks_at + pixel_bytes == len(blob),
           "blob is %d bytes, expected %d (header+table, colour, mask)"
           % (len(blob), masks_at + pixel_bytes))

    prev_po = prev_mo = -1
    rows = []
    for (name, w, h, po, mo) in raw:
        _check(po >= prev_po,
               "entry %s colour planes are out of table order" % name)
        _check(mo >= prev_mo,
               "entry %s mask planes are out of table order" % name)
        prev_po, prev_mo = po, mo
        _check(table_end + po + w * h * 2 <= masks_at,
               "entry %s colour plane runs past the colour region" % name)
        stride = plane_stride(w)
        _check(mo + h * stride <= pixel_bytes,
               "entry %s mask plane runs past the mask region" % name)

        base = masks_at + mo
        opaque = 0
        for y in range(h):
            row = blob[base + y * stride:base + y * stride + stride]
            for x in range(w):
                if row[x >> 3] & plane_bit(x):
                    opaque += 1
        rows.append((name, w, h, opaque, w * h, po, mo))

    print("art.bin  OK   version=%d  textures=%d  entrySize=%d"
          % (version, count, entry_size))
    print("         header+table %dB, colour plane %dB, mask region %dB "
          "(%dB used), blob %dB"
          % (table_end, pixel_bytes, pixel_bytes,
             sum(h * plane_stride(w) for (_, w, h, _, _, _, _) in rows),
             len(blob)))
    print()
    print("  %-10s %5s %5s %9s   %-10s %-10s"
          % ("texture", "w", "h", "opaque", "pixelOff", "maskOff"))
    for (name, w, h, o, n, po, mo) in rows:
        print("  %-10s %5d %5d %8.1f%%   %-10d %-10d"
              % (name, w, h, 100.0 * o / n, po, mo))
    print()
    return rows


def verify_fonts(blob):
    _check(len(blob) >= FONT_HEADER_SIZE, "fonts.bin shorter than its header")
    magic, count = struct.unpack_from("<IB", blob, 0)
    _check(magic == FONT_MAGIC,
           "fonts.bin magic is 0x%08X, want 0x%08X" % (magic, FONT_MAGIC))
    _check(1 <= count <= 255, "fonts.bin declares %d fonts" % count)
    table_end = FONT_HEADER_SIZE + FONT_RECORD_SIZE * count
    _check(len(blob) >= table_end, "fonts.bin table runs past end of file")

    pos = table_end
    rows = []
    for i in range(count):
        r = FONT_HEADER_SIZE + FONT_RECORD_SIZE * i
        raw = blob[r:r + FONT_RECORD_SIZE]
        # FORMATS.md declares u8 glyphCount; this baker emits u32 because the
        # required charset is larger than 255.  Accept both on read.
        glyph_count = struct.unpack_from("<I", raw, 0)[0]
        if glyph_count * GLYPH_SIZE > len(blob) - pos:
            glyph_count = raw[0]
        line_height, ascent = raw[4], raw[5]
        atlas_off, atlas_w, atlas_h = struct.unpack_from("<III", raw, 8)
        _check(0 < glyph_count, "font %d has no glyphs" % i)
        _check(0 < ascent <= line_height <= 255,
               "font %d has lineHeight=%d ascent=%d" % (i, line_height, ascent))
        _check(atlas_off % 4 == 0,
               "font %d atlasOff %d is not word aligned" % (i, atlas_off))
        _check(atlas_w % 32 == 0,
               "font %d atlas width %d is not a multiple of 32" % (i, atlas_w))
        stride = plane_stride(atlas_w)
        _check(atlas_off + stride * atlas_h <= len(blob),
               "font %d atlas runs past the end of the blob" % i)
        _check(pos + glyph_count * GLYPH_SIZE <= len(blob),
               "font %d glyph table runs past the end of the blob" % i)

        prev_cp = -1
        inks = 0
        for g in range(glyph_count):
            cp, advance, x, y, w, h = struct.unpack_from(
                "<IHhhHH", blob, pos + g * GLYPH_SIZE)
            _check(cp > prev_cp,
                   "font %d glyph %d: codepoints are not sorted ascending" % (i, g))
            prev_cp = cp
            _check(advance < 4096,
                   "font %d glyph U+%04X advance %d is implausible" % (i, cp, advance))
            if w == 0 or h == 0:
                _check(w == 0 and h == 0,
                       "font %d glyph U+%04X has a half-empty box" % (i, cp))
                continue
            inks += 1
            _check(x + w <= atlas_w,
                   "font %d glyph U+%04X: x+w=%d exceeds atlas width %d"
                   % (i, cp, x + w, atlas_w))
            _check(y + h <= atlas_h,
                   "font %d glyph U+%04X: y+h=%d exceeds atlas height %d"
                   % (i, cp, y + h, atlas_h))
            _check((x + w + 7) // 8 <= stride,
                   "font %d glyph U+%04X crosses the row stride" % (i, cp))
            _check(-line_height <= y + line_height - ascent - h <= line_height,
                   "font %d glyph U+%04X box is implausibly far from the baseline"
                   % (i, cp))
            has_ink = False
            for row_i in range(h):
                base = atlas_off + (y + row_i) * stride
                for c in range(w):
                    if (blob[base + ((x + c) >> 3)] >> ((x + c) & 7)) & 1:
                        has_ink = True
                        break
                if has_ink:
                    break
            _check(has_ink,
                   "font %d glyph U+%04X has a %dx%d box containing no ink"
                   % (i, cp, w, h))
        pos += glyph_count * GLYPH_SIZE
        rows.append((i, glyph_count, inks, atlas_w, atlas_h, atlas_off,
                     stride * atlas_h, line_height, ascent))

    _check(pos <= len(blob), "font glyph tables overrun the blob")
    print("fonts.bin  OK   fonts=%d  record=%dB  glyph tables end at %d/%dB"
          % (count, FONT_RECORD_SIZE, pos, len(blob)))
    print()
    names = ["FONT_SMALL", "FONT_BODY", "FONT_TITLE"]
    print("  %-4s %-11s %7s %7s %-11s %7s %7s %7s %10s"
          % ("idx", "enum", "glyphs", "ink", "atlas", "lineH", "ascent",
             "atlasOff", "bytes"))
    for (i, gc, inks, aw, ah, ao, ab, lh, asc) in rows:
        print("  %-4d %-11s %7d %7d %4dx%-6d %7d %7d %7d %10d"
              % (i, names[i] if i < 3 else "?", gc, inks, aw, ah, lh, asc, ao, ab))
    print()
    return rows


# ===========================================================================
# CLI
# ===========================================================================

def cmd_art(args):
    rows, size = bake_art(args.src, args.out)
    print("art.bin   %d textures, %d bytes -> %s" % (len(rows), size, args.out))
    print()
    print("  %-10s %5s %5s %9s" % ("texture", "w", "h", "opaque"))
    for (name, w, h, o, t) in rows:
        print("  %-10s %5d %5d %8.1f%%" % (name, w, h, 100.0 * o / t))
    print()
    return 0


def cmd_fonts(args):
    sizes = tuple(int(s) for s in args.sizes.split(",") if s.strip())
    stats, size = bake_fonts(args.font, args.charset, args.out, sizes,
                             glyph_count_bits=args.glyph_count_bits)
    print("fonts.bin %d fonts, %d bytes -> %s" % (len(stats), size, args.out))
    print()
    print("  %-5s %7s %7s %-11s %8s %7s %7s"
          % ("size", "glyphs", "ink", "atlas", "bytes", "lineH", "ascent"))
    for st in stats:
        print("  %-5d %7d %7d %5dx%-5d %8d %7d %7d"
              % (st["size"], st["glyphs"], st["ink"], st["atlas_w"],
                 st["atlas_h"], st["atlas_bytes"], st["line_height"],
                 st["ascent"]))
    print()
    return 0


def cmd_verify(args):
    for path in args.files:
        with open(path, "rb") as fh:
            blob = fh.read()
        if blob[:4] == struct.pack("<I", ART_MAGIC):
            verify_art(blob)
        elif blob[:4] == struct.pack("<I", FONT_MAGIC):
            verify_fonts(blob)
        else:
            raise BakeError("verify: %s is neither an ARTB nor an FNTS blob"
                            % path)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="nds_bake.py",
        description="Bake gen/art.bin and gen/fonts.bin from the LibGDX assets.")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("art", help="bake the texture blob")
    p.add_argument("--src", required=True, help="directory holding the source PNGs")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_art)

    p = sub.add_parser("fonts", help="bake the bitmap font blob")
    p.add_argument("--font", required=True, help="source TTF")
    p.add_argument("--charset", required=True, help="codepoint whitelist file")
    p.add_argument("--out", required=True)
    p.add_argument("--sizes", default=",".join(str(s) for s in FONT_SIZES))
    p.add_argument("--glyph-count-bits", type=int, choices=(8, 32), default=32,
                   help="width of Font.glyphCount; FORMATS.md says u8 but the "
                        "required charset needs 32")
    p.set_defaults(func=cmd_fonts)

    p = sub.add_parser("verify", help="re-parse blobs and check every offset")
    p.add_argument("files", nargs="+")
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("summary", help="alias for verify")
    p.add_argument("files", nargs="+")
    p.set_defaults(func=cmd_verify)

    args = ap.parse_args(argv)
    if not getattr(args, "cmd", None):
        ap.print_help()
        return 2
    try:
        return args.func(args)
    except BakeError as exc:
        sys.stderr.write("nds_bake: error: %s\n" % exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())