// SPDX-License-Identifier: MIT
//
// Nintendo DS entry point.
//
//   ./nds/build.sh        -> nds/elementia.nds
//
#include <nds.h>
#include <stdio.h>

#include "assets.h"
#include "audio.h"
#include "font.h"
#include "game.h"
#include "gfx.h"
#include "input.h"
#include "world.h"

static InputState input;

int main(void) {
	powerOn(POWER_ALL_2D);

	gfxInit();
	assetsInit();
	fontInit();
	sfxInit();
	inputInit();

	lcdMainOnTop();

	titleScreenInit();

	float last = (float) (cpuGetTiming() / 1024) / (float) BUS_CLOCK;

	while (pmMainLoop()) {
		swiWaitForVBlank();
		scanKeys();

		// Simulation time is derived from the hardware timer so the game keeps
		// running at a constant rate even if a frame runs long.
		float now = (float) (cpuGetTiming() / 1024) / (float) BUS_CLOCK;
		float dt = now - last;
		last = now;
		if (dt > 0.05f) dt = 0.05f;
		if (dt < 0.0f) dt = 0.0f;

		gfxBeginFrame();
		inputPoll(&input);

		if (currentScreen == SCREEN_TITLE) {
			titleScreenUpdate(&input, dt);
			titleScreenRender(now);
		} else {
			gameScreenUpdate(&input, dt);
			gameScreenRender(dt);
		}

		inputResetEdges(&input);
		gfxFlip();
	}
	return 0;
}
