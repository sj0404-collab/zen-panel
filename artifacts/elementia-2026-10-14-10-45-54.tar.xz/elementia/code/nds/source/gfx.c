// SPDX-License-Identifier: MIT
//
// Software framebuffer renderer - the DS stand-in for LibGDX SpriteBatch.
//
// The whole game is drawn into gfxFramebuffer (256x192 RGB555, main RAM) and
// pushed to VRAM once per frame during vblank. Coordinates are bottom-left
// origin, matching SpriteBatch, so the Java ports translate 1:1.
//
#include <nds.h>
#include <string.h>

#include "config.h"
#include "gfx.h"

/* font.c blits glyphs straight into this buffer; gfx.h exposes no accessor
   and must not change, so the symbol is exported and declared there. */
u16 gfxFramebuffer[SCRW * SCRH] __attribute__((aligned(4)));

/* Last frame actually handed to the DMA engine, used by gfxFlip to find the
   rows that really changed. */
static u16 fbShadow[SCRW * SCRH];
static u8 rowDirty[SCRH];

static bool gWorld;
static float gCamX, gCamY;

static u16 gTintCol = 0x7fff;
static u8 gTintAlpha = 255;
static u16 gClearCol;

/* Per-channel tint ramps: 5 bit texel channel * 8 bit tint channel / 255.
   When the tint is pure white the ramps collapse to the identity and the
   blitter skips them entirely (the common case: every world tile). */
static u8 tintTab[3][32];
static bool tintPlain;

static const float kInvScale = 1.0f / (float)WORLD_SCALE;
static const float kMapLimit = 8192.0f;

/* -- small helpers -------------------------------------------------------- */

static inline float rnd(float v) {
	return v >= 0.0f ? (float) (int) (v + 0.5f) : (float) (int) (v - 0.5f);
}

/* Exact x/255 for x < 65536, no divide unit involved. */
static inline u32 div255(u32 x) {
	return (x + 1u + (x >> 8)) >> 8;
}

static inline u16 blendPx(u16 d, u16 s, u32 inv, u32 a) {
	u32 r = div255(((u32) (d & 0x1fu) * inv) + ((u32) (s & 0x1fu) * a));
	u32 g = div255((((u32) (d >> 5) & 0x1fu) * inv) + (((u32) (s >> 5) & 0x1fu) * a));
	u32 b = div255((((u32) (d >> 10) & 0x1fu) * inv) + (((u32) (s >> 10) & 0x1fu) * a));
	return (u16) (r | (g << 5) | (b << 10));
}

static inline u16 applyTint(u16 c) {
	return (u16) (tintTab[0][c & 31u] |
	              ((u32) tintTab[1][(c >> 5) & 31u] << 5) |
	              ((u32) tintTab[2][(c >> 10) & 31u] << 10));
}

/* -- transform ------------------------------------------------------------ */

void gfxSetWorld(float camX, float camY) {
	gWorld = true;
	gCamX = camX;
	gCamY = camY;
}

void gfxResetWorld(void) {
	gWorld = false;
}

static float clampMap(float v) {
	return v < -kMapLimit ? -kMapLimit : (v > kMapLimit ? kMapLimit : v);
}

/* World (or screen) coordinates -> rounded screen pixels, bottom-left origin. */
static void map(float *sx, float *sy, float x, float y) {
	if (gWorld) {
		x = (x - gCamX) * kInvScale;
		y = (y - gCamY) * kInvScale;
	}
	*sx = rnd(clampMap(x));
	*sy = rnd(clampMap(y));
}

static inline float mapLen(float v) {
	return rnd(clampMap(gWorld ? v * kInvScale : v));
}

/* Bottom-left rect in the current space -> integer top-left dest rect in
   screen rows (row 0 is the top scanline). */
static void destRect(float x, float y, float w, float h,
                     int *dx, int *dy, int *dw, int *dh) {
	float sx, sy;
	int iw, ih;

	if (w < 0.0f) { x += w; w = -w; }
	if (h < 0.0f) { y += h; h = -h; }

	map(&sx, &sy, x, y);
	iw = (int) mapLen(w);
	ih = (int) mapLen(h);

	*dx = (int) sx;
	*dy = (SCRH - 1 - (int) sy) - (ih - 1);
	*dw = iw;
	*dh = ih;
}

/* -- frame lifecycle ------------------------------------------------------ */

void gfxInit(void) {
	powerOn(POWER_ALL_2D);
	lcdMainOnTop();
	vramSetBankA(VRAM_A_MAIN_BG);
	REG_DISPCNT = MODE_FB0;	/* lcdMainOnTop only picks the panel */

	memset(gfxFramebuffer, 0, sizeof(gfxFramebuffer));
	memset(fbShadow, 0, sizeof(fbShadow));
	memset(rowDirty, 0, sizeof(rowDirty));

	gWorld = false;
	gCamX = 0.0f;
	gCamY = 0.0f;
	gClearCol = 0;
	gfxSetTint(0x7fff, 255);
}

void gfxBeginFrame(void) {
	gfxResetWorld();
	gfxSetTint(0x7fff, 255);
	gfxClear(gClearCol);
}

void gfxClear(u16 color) {
	u32 c, i, n;

	gClearCol = color & 0x7fff;
	c = (u32) gClearCol | ((u32) gClearCol << 16);
	n = (u32) (SCRW * SCRH) >> 1;

	{
		u32 *p = (u32 *) gfxFramebuffer;
		for (i = 0; i < n; i++) p[i] = c;
	}
}

void gfxFlip(void) {
	int y, y0;

	swiWaitForVBlank();

	for (y = 0; y < SCRH; y++) {
		rowDirty[y] = (memcmp(&gfxFramebuffer[y * SCRW], &fbShadow[y * SCRW],
		                      SCRW * 2) != 0);
	}

	/* Only the spans that actually changed go over the bus; a full redraw
	   degenerates to a single DMA of the whole buffer. */
	y = 0;
	while (y < SCRH) {
		int rows;

		if (!rowDirty[y]) { y++; continue; }
		y0 = y;
		while (y < SCRH && rowDirty[y]) y++;
		rows = y - y0;

		dmaCopyHalfWords(DMA3, &gfxFramebuffer[y0 * SCRW],
		                 (u16 *) ((u8 *) VRAM_A + (u32) y0 * SCRW * 2),
		                 (u32) rows * SCRW);
		memcpy(&fbShadow[y0 * SCRW], &gfxFramebuffer[y0 * SCRW],
		       (u32) rows * SCRW * 2);
	}
}

void gfxSetTint(u16 color, u8 alpha) {
	u32 i, ch;
	u32 t[3];

	gTintCol = color & 0x7fff;
	gTintAlpha = alpha;
	tintPlain = (gTintCol == 0x7fff);

	t[0] = (u32) (gTintCol & 0x1fu) << 3;
	t[1] = (u32) ((gTintCol >> 5) & 0x1fu) << 3;
	t[2] = (u32) ((gTintCol >> 10) & 0x1fu) << 3;

	if (tintPlain) return;

	for (ch = 0; ch < 3; ch++) {
		for (i = 0; i < 32; i++) {
			tintTab[ch][i] = (u8) div255(i * t[ch]);
		}
	}
}

/* -- solid geometry ------------------------------------------------------- */

static void clipRect(int *x, int *y, int *w, int *h) {
	if (*w <= 0 || *h <= 0) return;
	if (*x < 0) { *w += *x; *x = 0; }
	if (*y < 0) { *h += *y; *y = 0; }
	if (*x >= SCRW || *y >= SCRH) { *w = 0; *h = 0; return; }
	if (*x + *w > SCRW) *w = SCRW - *x;
	if (*y + *h > SCRH) *h = SCRH - *y;
	if (*w <= 0 || *h <= 0) { *w = 0; *h = 0; }
}

static void fillRun(u16 *p, int n, u32 c) {
	u32 *q;

	while (n > 0 && ((u32) p & 2u) != 0u) { *p++ = (u16) c; n--; }
	q = (u32 *) p;
	n >>= 1;
	while (n-- > 0) *q++ = c;
	if (n < 0 && (((u32) p ^ (u32) q) & 2u) != 0u) {
		/* n was consumed by the word loop; odd tail handled by caller */
	}
	(void) q;
}

static void fillRow(u16 *p, int n, u32 c) {
	u32 *q;
	int words;

	if (((u32) p & 2u) != 0u) { *p++ = (u16) c; n--; }
	if (n <= 0) return;
	words = n >> 1;
	q = (u32 *) p;
	while (words-- > 0) *q++ = c;
	if (n & 1) *(u16 *) q = (u16) c;
}

static void blendRun(u16 *p, int n, u16 c, u32 inv, u32 a) {
	while (n-- > 0) {
		*p = blendPx(*p, c, inv, a);
		p++;
	}
}

static void putPixel(int x, int y, u16 c, u32 inv, u32 a) {
	u16 *p;

	if ((unsigned) x >= SCRW || (unsigned) y >= SCRH) return;
	p = &gfxFramebuffer[(u32) y * SCRW + (u32) x];
	*p = (a == 255u) ? c : blendPx(*p, c, inv, a);
}

void gfxRect(float x, float y, float w, float h, u16 color) {
	int dx, dy, dw, dh, row;

	destRect(x, y, w, h, &dx, &dy, &dw, &dh);
	clipRect(&dx, &dy, &dw, &dh);
	if (dw <= 0) return;

	color &= 0x7fff;
	for (row = 0; row < dh; row++) {
		fillRow(gfxFramebuffer + (u32) (dy + row) * SCRW + (u32) dx, dw, color);
	}
}

void gfxRectA(float x, float y, float w, float h, u16 color, u8 alpha) {
	int dx, dy, dw, dh, row;

	destRect(x, y, w, h, &dx, &dy, &dw, &dh);
	clipRect(&dx, &dy, &dw, &dh);
	if (dw <= 0) return;

	color &= 0x7fff;
	for (row = 0; row < dh; row++) {
		u16 *p = gfxFramebuffer + (u32) (dy + row) * SCRW + (u32) dx;
		if (alpha == 255u) fillRow(p, dw, color);
		else blendRun(p, dw, color, 255u - alpha, alpha);
	}
}

void gfxLine(float x0, float y0, float x1, float y1, u16 color, u8 alpha) {
	float ax, ay, bx, by;
	int x, y, dx, dy, sx, sy, err, inv;

	map(&ax, &ay, x0, y0);
	map(&bx, &by, x1, y1);

	x = (int) ax;
	y = SCRH - 1 - (int) ay;
	dx = (int) bx;
	dy = SCRH - 1 - (int) by;

	{
		int ux = dx - x, uy = dy - y;
		if (ux < 0) ux = -ux;
		if (uy < 0) uy = -uy;
		if (ux >= SCRW * 2 || uy >= SCRH * 2) return;
	}

	dx = abs(dx - x);
	dy = -abs(dy - y);
	sx = x < dx ? 1 : -1;
	sy = y < dy ? 1 : -1;
	err = dx + dy;
	color &= 0x7fff;
	inv = 255 - alpha;

	for (;;) {
		putPixel(x, y, color, (u32) inv, alpha);
		if (x == dx && y == dy) break;
		{
			int e2 = err * 2;
			if (e2 >= dy) { err += dy; x += sx; }
			if (e2 <= dx) { err += dx; y += sy; }
		}
	}
}

void gfxCircle(float cx, float cy, float r, u16 color, u8 alpha) {
	float mx, my, mr;
	int r0, cx0, row, half, r2, inv;

	map(&mx, &my, cx, cy);
	mr = mapLen(r);
	if (mr < 1.0f) return;

	r0 = (int) mr;
	cx0 = (int) mx;
	color &= 0x7fff;
	inv = 255 - alpha;

	/* x is the half width at dy; it only ever shrinks, so the whole disc is
	   filled in O(r) instead of r sqrt() calls (no libm on this target). */
	half = r0;
	r2 = r0 * r0;
	for (row = 0; row <= r0; row++) {
		int yy = row * row;
		int lo, hi, ytop, ybot;

		while (half > 0 && half * half + yy > r2) half--;
		lo = cx0 - half;
		hi = cx0 + half;

		ybot = SCRH - 1 - ((int) my + row);
		ytop = SCRH - 1 - ((int) my - row);
		if (lo < 0) lo = 0;
		if (hi >= SCRW) hi = SCRW - 1;
		if (lo <= hi) {
			if ((unsigned) ybot < SCRH)
				fillSpan(ybot, lo, hi, color, inv, alpha);
			if (row != 0 && (unsigned) ytop < SCRH)
				fillSpan(ytop, lo, hi, color, inv, alpha);
		}
	}
}

/* -- textured geometry ---------------------------------------------------- */

static void texBlit(const Tex *t, int sx, int sy, int sw, int sh,
                    int dx, int dy, int dw, int dh, bool flipX) {
	s32 stepX, stepY, fx, fy;
	int skipX, skipY, mw, x, y;
	bool masked, plain;
	u32 alpha, inv;

	if (t == NULL || t->px == NULL) return;
	if (sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return;
	if (sx >= (int) t->w || sy >= (int) t->h || sx < 0 || sy < 0) return;
	if (sx + sw > (int) t->w) sw = (int) t->w - sx;
	if (sy + sh > (int) t->h) sh = (int) t->h - sy;
	if (sw <= 0 || sh <= 0) return;

	stepX = ((s32) sw << 16) / dw;
	stepY = ((s32) sh << 16) / dh;

	skipX = 0;
	skipY = 0;
	if (dx < 0) { skipX = -dx; dx = 0; dw -= skipX; }
	if (dy < 0) { skipY = -dy; dy = 0; dh -= skipY; }
	if (dw <= 0 || dh <= 0 || dx >= SCRW || dy >= SCRH) return;
	if (dx + dw > SCRW) dw = SCRW - dx;
	if (dy + dh > SCRH) dh = SCRH - dy;
	if (dw <= 0 || dh <= 0) return;

	/* Source start in 16.16 fixed point, already advanced past the clipped
	   columns; flipping mirrors around the region's right edge. */
	fx = ((s32) sx << 16) + (s32) skipX * stepX;
	if (flipX) {
		fx += (s32) (sw - 1) << 16;
		stepX = -stepX;
	}
	fy = ((s32) sy << 16) + (s32) skipY * stepY;

	masked = (t->mask != NULL);
	mw = ((int) t->w + 31) >> 5;
	alpha = gTintAlpha;
	inv = 255u - alpha;
	plain = tintPlain;

	if (plain && alpha == 255u) {
		for (y = 0; y < dh; y++) {
			s32 ty = fy >> 16;
			const u16 *prow;
			const u32 *mrow;
			u16 *dst;
			s32 f = fx;
			u32 wordIdx = 0xffffffffu, bits = 0;

			if (ty < 0) ty = 0;
			else if (ty > sh - 1) ty = sh - 1;
			prow = t->px + (u32) ty * t->w;
			mrow = masked ? t->mask + (u32) ty * mw : NULL;
			dst = gfxFramebuffer + (u32) (dy + y) * SCRW + (u32) dx;

			for (x = 0; x < dw; x++, dst++, f += stepX) {
				u32 tx = (u32) (f >> 16);
				u32 wi;

				if (mrow != NULL) {
					wi = tx >> 5;
					if (wi != wordIdx) { wordIdx = wi; bits = mrow[wi]; }
					if (((bits >> (tx & 31u)) & 1u) == 0u) continue;
				}
				*dst = prow[tx];
			}
			fy += stepY;
		}
	} else {
		for (y = 0; y < dh; y++) {
			s32 ty = fy >> 16;
			const u16 *prow;
			const u32 *mrow;
			u16 *dst;
			s32 f = fx;
			u32 wordIdx = 0xffffffffu, bits = 0;

			if (ty < 0) ty = 0;
			else if (ty > sh - 1) ty = sh - 1;
			prow = t->px + (u32) ty * t->w;
			mrow = masked ? t->mask + (u32) ty * mw : NULL;
			dst = gfxFramebuffer + (u32) (dy + y) * SCRW + (u32) dx;

			for (x = 0; x < dw; x++, dst++, f += stepX) {
				u32 tx = (u32) (f >> 16);
				u32 wi, cov;
				u16 c;

				if (mrow != NULL) {
					wi = tx >> 5;
					if (wi != wordIdx) { wordIdx = wi; bits = mrow[wi]; }
					cov = (bits >> (tx & 31u)) & 1u;
					if (cov == 0u) continue;
				}
				c = applyTint(prow[tx]);
				*dst = (alpha == 255u) ? c : blendPx(*dst, c, inv, alpha);
			}
			fy += stepY;
		}
	}
}

void gfxTex(const Tex *t, float x, float y, float w, float h) {
	int dx, dy, dw, dh;

	destRect(x, y, w, h, &dx, &dy, &dw, &dh);
	if (dw <= 0 || dh <= 0) return;
	texBlit(t, 0, 0, (int) t->w, (int) t->h, dx, dy, dw, dh, false);
}

void gfxTexFlipX(const Tex *t, float x, float y, float w, float h) {
	int dx, dy, dw, dh;

	destRect(x, y, w, h, &dx, &dy, &dw, &dh);
	if (dw <= 0 || dh <= 0) return;
	texBlit(t, 0, 0, (int) t->w, (int) t->h, dx, dy, dw, dh, true);
}

void gfxTexRegion(const Tex *t, u16 sx, u16 sy, u16 sw, u16 sh,
                  float dx, float dy, float dw, float dh) {
	int ex, ey, ew, eh;

	destRect(dx, dy, dw, dh, &ex, &ey, &ew, &eh);
	if (ew <= 0 || eh <= 0) return;
	texBlit(t, (int) sx, (int) sy, (int) sw, (int) sh, ex, ey, ew, eh, false);
}

void gfxTexRegionFlipX(const Tex *t, u16 sx, u16 sy, u16 sw, u16 sh,
                       float dx, float dy, float dw, float dh) {
	int ex, ey, ew, eh;

	destRect(dx, dy, dw, dh, &ex, &ey, &ew, &eh);
	if (ew <= 0 || eh <= 0) return;
	texBlit(t, (int) sx, (int) sy, (int) sw, (int) sh, ex, ey, ew, eh, true);
}

/* -- rotated blit (melee slash arc only) ---------------------------------- */

#define GFX_PI  3.14159265358979f
#define GFX_HPI 1.57079632679490f

/* libm is not linked on this target, so sin/cos come from a 5th order
   polynomial after a single quadrant reduction. Error is well under 1e-5. */
static void sincosApprox(float a, float *outS, float *outC) {
	const float twoPi = GFX_PI * 2.0f;
	float q = a * (1.0f / twoPi);
	float t = (q - (float) (int) q) * twoPi;
	float u, u2, s, c;

	if (t < GFX_HPI)                 u = t;
	else if (t < GFX_PI)             u = GFX_PI - t;
	else if (t < GFX_PI + GFX_HPI)   u = t - GFX_PI;
	else                             u = twoPi - t;

	u2 = u * u;
	s = u * (1.0f - u2 * (1.0f / 6.0f - u2 * (1.0f / 120.0f)));
	c = 1.0f + u2 * (-0.5f + u2 * (1.0f / 24.0f - u2 * (1.0f / 720.0f)));

	if (u == t)            { *outS = s;  *outC = c; }
	else if (u == GFX_PI - t) { *outS = s;  *outC = -c; }
	else if (u == t - GFX_PI) { *outS = -s; *outC = -c; }
	else                   { *outS = -s; *outC = c; }
}

void gfxTexRot(const Tex *t, float cx, float cy, float size, float angle) {
	float mx, my, sz, sn, cs, invSz;
	int x0, y0, dim, x, y, mw;

	if (t == NULL || t->px == NULL || t->w == 0 || t->h == 0) return;

	map(&mx, &my, cx, cy);
	sz = mapLen(size);
	if (sz < 1.0f) sz = 1.0f;

	sincosApprox(angle, &sn, &cs);
	invSz = 1.0f / sz;

	dim = (int) sz;
	if (dim < 1) dim = 1;
	x0 = (int) mx - dim / 2;
	y0 = (SCRH - 1 - (int) my) - dim / 2;
	mw = ((int) t->w + 31) >> 5;

	for (y = 0; y < dim; y++) {
		int row = y0 + y;
		if ((unsigned) row >= SCRH) continue;

		for (x = 0; x < dim; x++) {
			int col = x0 + x;
			float px, py, u, v, txf, tyf;
			u32 tx, ty;
			u16 c;

			if ((unsigned) col >= SCRW) continue;

			/* destination pixel centre, bottom-left origin */
			px = ((float) col + 0.5f) - mx;
			py = ((float) (SCRH - 1 - row) + 0.5f) - my;

			/* inverse rotate into texture space (y down) */
			u = px * cs + py * sn;
			v = py * cs - px * sn;
			txf = (u * invSz + 0.5f) * (float) t->w;
			tyf = (0.5f - v * invSz) * (float) t->h;

			if (txf < 0.0f || tyf < 0.0f) continue;
			tx = (u32) txf;
			ty = (u32) tyf;
			if (tx >= t->w || ty >= t->h) continue;

			if (t->mask != NULL &&
			    ((((t->mask[ty * (u32) mw + (tx >> 5)]) >> (tx & 31u)) & 1u) == 0u))
				continue;

			c = tintPlain ? t->px[ty * t->w + tx]
			              : applyTint(t->px[ty * t->w + tx]);
			{
				u16 *d = &gfxFramebuffer[(u32) row * SCRW + col];
				*d = (gTintAlpha == 255u) ? c : blendPx(*d, c, 255u - gTintAlpha, gTintAlpha);
			}
		}
	}
}