// SPDX-License-Identifier: MIT
//
// ARM7 (secondary CPU) entry point. All game logic lives on the ARM9; the ARM7
// only brings up the hardware servers (touch, sound, power management).
#include <calico.h>
#include <nds.h>
#include <maxmod7.h>

int main(void) {
	envReadNvramSettings();
	keypadStartExtServer();

	lcdSetIrqMask(DISPSTAT_IE_ALL, DISPSTAT_IE_VBLANK);
	irqEnable(IRQ_VBLANK);

	rtcInit();
	rtcSyncTime();

	pmInit();
	blkInit();

	touchInit();
	touchStartServer(80, MAIN_THREAD_PRIO);

	soundStartServer(MAIN_THREAD_PRIO - 0x10);
	micStartServer(MAIN_THREAD_PRIO - 0x18);

	wlmgrStartServer(MAIN_THREAD_PRIO - 8);

	mmInstall(MAIN_THREAD_PRIO + 1);

	while (pmMainLoop()) {
		threadWaitForVBlank();
	}
	return 0;
}
