# Binary asset formats

Two blobs are produced offline by `nds/tools/nds_bake.py` (run by
`nds/gen/Makefile`) and linked into the ARM9 image with `bin2o`:

* `gen/art.bin`   – sprites and tiles
* `gen/fonts.bin` – three baked bitmap fonts (Latin + Cyrillic)

Both are little-endian and addressed from the start of the blob.

---

## art.bin

```
u32  magic     = 'ARTB' (0x42525441)
u16  version   = 1
u16  count     number of textures
u32  entrySize = 28
Entry entries[count]        // no padding, tightly packed
u16  pixelBytes             // total, multiple of 4
u16  pad0
u8   nameLen
u8   reserved
Entry entry[count]
--- data follows the table, in table order ---
u16  pixels[pixelBytes/2]   // RGB555, row major, top-left origin
u32  masks[pixelBytes*2/8]  // 1bpp coverage, row major, LSB = leftmost pixel
```

`Entry` (28 bytes):

```
u8   nameLen    length of the NUL terminated ASCII name that follows
u8   reserved
u16  w
u16  h
u32  pixelOff   byte offset of the colour plane inside `pixels`
u32  maskOff    byte offset of the coverage plane inside `masks`
u8   name[nameLen] (padded so the struct is exactly 28 bytes)
```

Canonical names, in the order the baker emits them:

```
grass dirt stone ice snow brick lavaA lavaB water
platform crystal tree chest hero slime wisp golem boss waypoint
```

Anything missing from the PNG set is simply absent; the C side falls back to a
procedurally painted texture.

---

## fonts.bin

```
u32  magic    = 'FNTS' (0x53544e46)
u8   count    number of fonts (3)
u8   reserved[3]
Font fonts[count]
--- data follows the table, in table order ---
```

`Font` header:

```
u8   glyphCount
u8   lineHeight   pixels between baselines
u8   ascent       pixels above the baseline to the cap line
u8   reserved
u32  atlasOff     byte offset of the 1bpp atlas inside the blob
u32  atlasW
u32  atlasH
Glyph glyphs[glyphCount]   // sorted ascending by codepoint
```

`Glyph` (16 bytes):

```
u32  codepoint   UTF-8 decoded
u16  advance     pen movement in pixels (unsigned, 8.8 would be nicer but the
                 font is baked at one size so integers are enough)
u16  x           ink box inside the atlas
u16  y
u16  w
u16  h
```

The atlas is 1bpp, row stride `(atlasW + 31) / 32 * 4` bytes, 1 = ink.

Drawing rule (see `font.c`):

```
pen baseline = (x, y)              // same convention as LibGDX BitmapFont#draw
ink top left  = (x + g.x, y + lineHeight - ascent + g.y)
```

Fonts are emitted in this order and bound to the `FONT_*` enum:

| index | enum         | point size |
|-------|--------------|------------|
| 0     | `FONT_SMALL` | 12         |
| 1     | `FONT_BODY`  | 20         |
| 2     | `FONT_TITLE` | 32         |
