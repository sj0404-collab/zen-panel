// SPDX-License-Identifier: MIT
// Core tuning constants - a direct port of core/src/main/java/com/elementia/core/Config.java
#pragma once

#define VIEW_W   960.0f
#define VIEW_H   540.0f
#define GRAVITY  2100.0f
#define TILE     32.0f
#define MAX_FALL 1200.0f

#define PLAYER_W 22.0f
#define PLAYER_H 34.0f

#define MOVE_SPEED    260.0f
#define ACCEL         1800.0f
#define GROUND_DECEL  2600.0f
#define AIR_DECEL     900.0f

#define JUMP_VEL    700.0f
#define JUMP_CUT    0.45f
#define COYOTE_TIME 0.1f
#define JUMP_BUFFER 0.12f

#define DASH_SPEED 720.0f
#define DASH_TIME  0.16f
#define DASH_CD    0.5f

#define COMBO_WINDOW     0.5f
#define COMBAT_KNOCKBACK 220.0f
#define MAX_HP           100.0f
#define MAX_BURST        100.0f

#define SKILL_CD        1.4f
#define STATUS_DURATION 4.0f

#define CAM_LERP 4.5f

// Nintendo DS specifics
// The DS framebuffer is 256x192. The world is drawn through a 1/2 scale factor
// so a 32px world tile occupies 16 screen pixels - the classic DS tile size -
// while every gameplay constant above stays untouched (identical feel to the
// LibGDX build, which rendered a 960x540 world-space).
#define WORLD_SCALE 2  // divisor: screen = world / WORLD_SCALE
