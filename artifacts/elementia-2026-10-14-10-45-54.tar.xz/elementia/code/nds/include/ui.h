// SPDX-License-Identifier: MIT
// HUD / on-screen controls / dialogue box - ports of the ui package.
#pragma once

#include "gfx.h"
#include "world.h"

void hudRender(const World *w, float time);

/* -- touch controls -------------------------------------------------------- */
void touchInit(void);
void touchResize(int w, int h);
void touchUpdate(InputState *st);
void touchRender(void);
bool touchTapConsumed(void);
void touchResetTap(void);

/* -- dialogue -------------------------------------------------------------- */
void dlgShow(const char *speaker, const char *body, void (*onClose)(void));
void dlgUpdate(float dt);
/** Returns true when a tap/button advanced the dialogue this frame. */
bool dlgAdvance(void);
void dlgRender(float time);
bool dlgOpen(void);
