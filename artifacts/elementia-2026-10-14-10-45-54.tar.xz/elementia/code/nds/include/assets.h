// SPDX-License-Identifier: MIT
// Texture set - mirrors the fields of core/src/main/java/com/elementia/core/Assets.java
#pragma once

#include "gfx.h"
#include "element.h"

typedef struct {
	Tex grass, dirt, stone, ice, snow, brick, lavaA, lavaB, water;
	Tex platform;   // 32x14 one-way slab
	Tex crystal;    // 24x30 solid decor
	Tex tree;       // 32x48 background decoration
	Tex chest;      // 28x24
	Tex hero;       // 56x76
	Tex slime[4];   // 44x38 squash cycle
	Tex wisp;       // 16x14
	Tex golem;      // 56x52
	Tex boss;       // 88x76
	Tex slash;      // 96x96 crescent
	Tex waypoint;   // 40x56
	Tex icon[EL_COUNT]; // 24x24
	Tex glow;       // 32x32 radial falloff
} Assets;

extern Assets art;

void assetsInit(void);

/** Tile texture for a tile id, mirroring Assets#texForTile. */
const Tex *assetsTexForTile(int tileId);
/** Background parallax silhouette colour per zone, 0xRRGGBB. */
u32 assetsZoneColor(int zone, int layer);
