// SPDX-License-Identifier: MIT
// Procedural audio - a port of core/src/main/java/com/elementia/core/Sfx.java
#pragma once

#include <nds.h>

typedef enum {
	SFX_JUMP,
	SFX_DOUBLE_JUMP,
	SFX_DASH,
	SFX_SLASH,
	SFX_HIT,
	SFX_ENEMY_DIE,
	SFX_HURT,
	SFX_SKILL,
	SFX_BURST,
	SFX_WAYPOINT,
	SFX_TALK,
	SFX_BURN,
	SFX_MELT,
	SFX_ROAR,
	SFX_VICTORY,
	SFX_SPLASH,
	SFX_COUNT
} SfxId;

void sfxInit(void);
void sfxPlay(SfxId id, float volume, float pitch);
void sfxPlaySimple(SfxId id);
void musicStart(void);
void musicStop(void);
void musicSetVolume(float v);
void sfxSetVolume(float v);
