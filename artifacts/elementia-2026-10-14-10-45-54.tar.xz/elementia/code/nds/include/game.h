// SPDX-License-Identifier: MIT
// Top level application state machine (ElementiaGame / TitleScreen / GameScreen).
#pragma once

#include "world.h"

typedef enum { SCREEN_TITLE, SCREEN_GAME } Screen;

extern Screen currentScreen;

void titleScreenInit(void);
void titleScreenUpdate(InputState *in, float dt);
void titleScreenRender(float time);

void gameScreenInit(void);
void gameScreenUpdate(InputState *in, float dt);
void gameScreenRender(float dt);
