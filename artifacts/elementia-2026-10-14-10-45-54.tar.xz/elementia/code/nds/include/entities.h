// SPDX-License-Identifier: MIT
// Entities - ports of world/Entity.java, Player.java, Enemy.java, Boss.java,
// Projectile.java and Particles.java.
#pragma once

#include "config.h"
#include "element.h"

#define MAX_ENEMIES  32
#define MAX_PROJ     64
#define PARTICLE_N  160

typedef struct Entity {
	float x, y, w, h;
	float vx, vy;
	bool grounded;
	int facing;
	float hp, maxHp;
	bool alive;
	float hitFlash;
	float statusLife;
	Element status;
	float deadTimer;
} Entity;

typedef enum {
	PS_IDLE, PS_RUN, PS_JUMP, PS_FALL, PS_DASH, PS_ATTACK, PS_HURT, PS_DEAD
} PlayerState;

typedef struct {
	Entity e;
	u32 abilities;
	Element activeElement;   // -1 when no element unlocked yet
	float skillCd, burstGauge, burstPower;
	bool burstReady;
	int comboStep;
	float comboWindow, attackTimer;
	float atkCx, atkCy, atkRadius;
	bool atkHitApplied;
	float coyote, jumpBuffer;
	float dashTimer, dashCd;
	int jumpsUsed;
	float invuln;
	PlayerState state;
} Player;

typedef enum { EK_SLIME, EK_WISP, EK_GOLEM } EnemyKind;

typedef struct {
	Entity e;
	EnemyKind kind;
	Element element;
	float timer, hopTimer;
	float sx0, sx1;
	float homeX, homeY;
	float anim;
	bool angered;
	int contactDmg;
} Enemy;

typedef struct {
	Entity e;
	int phaseTimer, attackIdx;
	int intro;
	bool enraged, teleport, defeated, wobble;
	float volleyTimer;
} Boss;

typedef struct {
	float x, y, vx, vy, w, h, radius;
	float damage;
	Element element;
	bool fromEnemy;
	float life;
	bool alive;
} Projectile;

typedef struct {
	float x[PARTICLE_N], y[PARTICLE_N], vx[PARTICLE_N], vy[PARTICLE_N];
	float life[PARTICLE_N], maxLife[PARTICLE_N], size[PARTICLE_N];
	u32 color[PARTICLE_N];
	bool grav[PARTICLE_N];
	int head;
} Particles;

/* -- entity helpers -------------------------------------------------------- */
void entityTick(Entity *e, float dt);
void entityApplyDamage(Entity *e, float dmg, bool crit, float knockX, float knockY);
bool entityRectOverlap(const Entity *a, float x, float y, float w, float h);

void playerInit(Player *p, float x, float y);
void playerTickTimers(Player *p, float dt);
void playerUpdateState(Player *p);
bool playerHas(const Player *p, u32 ability);
bool playerCanDoubleJump(const Player *p);
void playerUnlock(Player *p, u32 ability);

void enemyInit(Enemy *e, EnemyKind kind, Element element, float x, float y);
void enemyTickTimers(Enemy *e, float dt);

void particlesInit(Particles *ps);
void particlesEmit(Particles *ps, float px, float py, float vx, float vy,
                   u32 color, float size, float life, bool grav);
void particlesBurst(Particles *ps, float px, float py, u32 color, int count,
                    float speed, float size, float life);
void particlesSparks(Particles *ps, float px, float py, u32 color);
void particlesUpdate(Particles *ps, float dt, float groundY);
void particlesClear(Particles *ps);
