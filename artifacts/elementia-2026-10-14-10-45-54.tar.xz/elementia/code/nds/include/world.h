// SPDX-License-Identifier: MIT
// World - port of core/src/main/java/com/elementia/world/World.java
#pragma once

#include "entities.h"
#include "input.h"

#define MW 150
#define MH 46

typedef enum { T_AIR = 0, T_GRASS, T_DIRT, T_STONE, T_ICE, T_SNOW,
               T_BRICK, T_PLAT, T_WATER, T_CRYST, T_LAVA } Tile;

typedef enum { GATE_VINE, GATE_FROST, GATE_MAGMA, GATE_FIRE, GATE_COUNT } GateType;

typedef struct { float x, y, w, h; GateType type; bool active; } Gate;
typedef struct { float x, y; int type; bool opened; } Chest;
typedef struct { float x, y; bool active; } Waypoint;
typedef struct { float x, y; int id; bool inRange, talked, repeat; } Npc;

typedef struct {
	u8 tiles[MH][MW];
	Player player;
	Enemy enemies[MAX_ENEMIES];
	int enemyCount;
	Boss boss;
	bool bossSpawned;
	Projectile proj[MAX_PROJ];
	Particles particles;
	Gate gates[GATE_COUNT];
	Chest chests[16];
	int chestCount;
	Waypoint waypoints[8];
	int waypointCount;
	Npc npcs[16];
	int npcCount;

	float time;
	float shakeTimer, shakeAmt;
	int respawnX, respawnY;

	bool vineBurned, frostMelted, fireDoused;
	bool bossStarted, bossDefeated, trophyClaimed, gameWon, introPending;
	bool saveDirty;

	// pending dialogue handed to the dialogue box
	int pendingNpc;
	const char *pendingSpeaker;
	const char *pendingBody;
} World;

extern World world;

void worldInit(void);
void worldUpdate(InputState *in, float dt);

/* -- tile helpers (world space, bottom-left origin) ------------------------- */
int worldTileAt(float wx, float wy);
bool worldSolidAt(float wx, float wy);
bool worldPlatformAt(float wx, float wy);
bool worldSupportAt(int col, int row);
float worldGroundTopAt(float wx, float wy);
int worldZoneAt(float camX, float camY);
float worldShakeX(void);
float worldShakeY(void);

/* -- player movement ------------------------------------------------------- */
void playerMoveAndCollide(Player *p, float dt);

/* -- dialogue -------------------------------------------------------------- */
/** Returns the NPC_TEXT entry for `id` into *speaker/*body (UTF-8). */
bool worldNpcText(int id, const char **speaker, const char **body);

void worldSave(void);
void worldLoad(const char *blob);
int worldSaveToBuffer(char *out, int cap);
void worldLoadFromBuffer(const char *blob);
