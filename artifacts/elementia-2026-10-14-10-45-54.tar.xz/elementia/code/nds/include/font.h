// SPDX-License-Identifier: MIT
// Bitmap font baked offline from DejaVuSans.ttf (see tools/nds_bake.py).
#pragma once

#include <nds.h>

enum {
	FONT_SMALL = 0, // HUD, hints, button labels
	FONT_BODY,      // dialogue, prompts
	FONT_TITLE,     // title / death / victory banners
	FONT_COUNT
};

void fontInit(void);
void fontSetTint(u16 color, u8 alpha);

/** Draws UTF-8 text, returns the x advance in screen pixels. */
float textDraw(float x, float y, int font, const char *utf8);
float textWidth(const char *utf8, int font);
int textHeight(int font);
