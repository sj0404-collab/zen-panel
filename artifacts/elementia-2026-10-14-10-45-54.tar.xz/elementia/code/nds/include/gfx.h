// SPDX-License-Identifier: MIT
// Software framebuffer renderer.
//
// The LibGDX build pushed ~2500 alpha-blended quads through a SpriteBatch. The
// DS has no equivalent (hardware sprites cap out at 128 affine objects), so the
// whole game is drawn into a 256x192 u16 buffer in main RAM which is DMA'd to
// VRAM once per frame.
//
// Coordinates use a bottom-left origin so the LibGDX sources port 1:1.
#pragma once

#include <nds.h>

#define SCRW 256
#define SCRH 192

/** Texture: 15bpp colour plane + 1bpp coverage mask (1 = opaque). */
typedef struct {
	u16 w, h;
	const u16 *px;
	const u32 *mask; // w*h bits, row major, LSB = leftmost pixel
} Tex;

void gfxInit(void);
/** Starts a new frame: clears the back buffer and resets the transform. */
void gfxBeginFrame(void);
/** Waits for vblank, DMAs the framebuffer to VRAM and flips it in. */
void gfxFlip(void);
void gfxClear(u16 color);

/**
 * Switch to world space: subsequent draws take world coordinates and are
 * rendered at 1/WORLD_SCALE size, shifted by the camera.
 */
void gfxSetWorld(float camX, float camY);
/** Switch back to raw screen pixels (HUD, dialogue, touch controls). */
void gfxResetWorld(void);

/** Global tint applied to every textured draw, like SpriteBatch#setColor. */
void gfxSetTint(u16 color, u8 alpha);

/* -- solid geometry -------------------------------------------------------- */
void gfxRect(float x, float y, float w, float h, u16 color);
void gfxRectA(float x, float y, float w, float h, u16 color, u8 alpha);
void gfxLine(float x0, float y0, float x1, float y1, u16 color, u8 alpha);
void gfxCircle(float cx, float cy, float r, u16 color, u8 alpha);

/* -- textured geometry ----------------------------------------------------- */
void gfxTex(const Tex *t, float x, float y, float w, float h);
void gfxTexFlipX(const Tex *t, float x, float y, float w, float h);
void gfxTexRegion(const Tex *t, u16 sx, u16 sy, u16 sw, u16 sh,
                  float dx, float dy, float dw, float dh);
void gfxTexRegionFlipX(const Tex *t, u16 sx, u16 sy, u16 sw, u16 sh,
                       float dx, float dy, float dw, float dh);
/** Rotated square blit around (cx,cy); angle in radians, counter clockwise. */
void gfxTexRot(const Tex *t, float cx, float cy, float size, float angle);
