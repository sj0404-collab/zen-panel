// SPDX-License-Identifier: MIT
// Input - port of InputState.java plus the DS button/touch sampling.
#pragma once

#include <nds.h>

typedef struct {
	bool left, right, up, down, jumpHeld;
	bool jumpPressed, attackPressed, skillPressed, dashPressed;
} InputState;

void inputInit(void);
/** Samples the DS pad, ORs the result into `st` (used by touch controls). */
void inputPoll(InputState *st);
/** Clears the edge triggered fields, like InputState#reset. */
void inputResetEdges(InputState *st);

/** Raw accessors for the touch control layer. */
bool inputTouchDown(void);
bool inputTouchPressed(void);
bool inputTouchReleased(void);
u16 inputTouchX(void);
u16 inputTouchY(void);
u16 inputKeysHeld(void);
u16 inputKeysDown(void);
