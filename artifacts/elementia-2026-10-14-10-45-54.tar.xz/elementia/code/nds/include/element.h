// SPDX-License-Identifier: MIT
// Elements + abilities - port of Element.java / Ability.java
#pragma once

#include <nds.h>

typedef enum {
	EL_ANEMO = 0,
	EL_PYRO,
	EL_CRYO,
	EL_HYDRO,
	EL_ELECTRO,
	EL_GEO,
	EL_DENDRO,
	EL_COUNT
} Element;

typedef enum {
	AB_DASH       = 1 << 0,
	AB_DOUBLE_JUMP = 1 << 1,
	AB_PYRO       = 1 << 2,
	AB_CRYO       = 1 << 3,
	AB_HYDRO      = 1 << 4,
	AB_BURST      = 1 << 5
} Ability;

/** bright/deep are 0xRRGGBB (8 bit per channel), exactly like Element.java. */
extern const u32 elementBright[EL_COUNT];
extern const u32 elementDeep[EL_COUNT];
extern const char *const elementName[EL_COUNT];

/** 0xRRGGBB -> RGB555 packed DS colour. */
static inline u16 rgb555(u32 rgb) {
	return (u16) (((((rgb >> 16) & 0xff) >> 3) << 0) |
	             ((((rgb >> 8) & 0xff) >> 3) << 5) |
	             (((rgb & 0xff) >> 3) << 10));
}

#define ELEM_BRIGHT(e) rgb555(elementBright[e])
#define ELEM_DEEP(e) rgb555(elementDeep[e])
