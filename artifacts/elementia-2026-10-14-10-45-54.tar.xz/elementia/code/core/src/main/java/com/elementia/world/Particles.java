package com.elementia.world;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Art;
import com.elementia.core.Assets;

/** Simple pooled particle system with additive-ish glow dots. */
public class Particles {
    public static final int N = 320;

    public float[] x = new float[N], y = new float[N], vx = new float[N], vy = new float[N];
    public float[] life = new float[N], maxLife = new float[N], size = new float[N];
    public int[] color = new int[N];
    public boolean[] gravity = new boolean[N];
    int head;

    World world;

    public Particles(World world) { this.world = world; }

    public void emit(float px, float py, float vx, float vy, int color, float size, float life, boolean gravity) {
        int i = head;
        head = (head + 1) % N;
        x[i] = px; y[i] = py; this.vx[i] = vx; this.vy[i] = vy;
        this.color[i] = color; this.size[i] = size; this.life[i] = life; this.maxLife[i] = life;
        this.gravity[i] = gravity;
    }

    public void emitBurst(float px, float py, int color, int count, float speed, float size, float life) {
        for (int i = 0; i < count; i++) {
            float a = (float) (Math.random() * Math.PI * 2);
            float sp = speed * (0.4f + (float) Math.random() * 0.6f);
            emit(px, py, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, color,
                    size * (0.7f + (float) Math.random() * 0.6f), life * (0.5f + (float) Math.random()), true);
        }
    }

    public void emitSparks(float px, float py, int color, int count, float speed) {
        emitBurst(px, py, color, count, speed, 4f, 0.4f);
    }

    public void update(float dt) {
        for (int i = 0; i < N; i++) {
            if (life[i] <= 0) continue;
            life[i] -= dt;
            if (gravity[i]) vy[i] -= 900f * dt;
            x[i] += vx[i] * dt;
            y[i] += vy[i] * dt;
            if (world != null) {
                // splash on ground
                if (gravity[i] && y[i] < world.tileToWorldY(0) + 2 && vy[i] < 0 && life[i] > 0 && life[i] < maxLife[i] * 0.3f) {
                    vy[i] *= -0.3f;
                }
            }
        }
    }

    public void render(SpriteBatch batch) {
        for (int i = 0; i < N; i++) {
            if (life[i] <= 0) continue;
            float t = life[i] / maxLife[i];
            int col = Art.mix(color[i] & 0x00ffffff, 0x00000000, (1f - t) * 0.6f);
            batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, t);
            float s = size[i] * 2f;
            batch.draw(Assets.glowDot, x[i] - s / 2, y[i] - s / 2, s, s);
        }
        batch.setColor(1, 1, 1, 1);
    }
}