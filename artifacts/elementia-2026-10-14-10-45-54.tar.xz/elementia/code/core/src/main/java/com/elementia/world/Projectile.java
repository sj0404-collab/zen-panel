package com.elementia.world;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;
import com.elementia.core.Element;

/** Homing/straight projectile for skills and enemy attacks. */
public class Projectile {
    public float x, y, vx, vy, w, h;
    public int damage;
    public Element element;
    public boolean fromEnemy;
    public float life = 3f;
    public boolean alive = true;
    public float radius;

    public Projectile(float x, float y, float vx, float vy, int dmg, Element e, boolean fromEnemy, float radius) {
        this.x = x; this.y = y; this.vx = vx; this.vy = vy;
        this.damage = dmg; this.element = e; this.fromEnemy = fromEnemy;
        this.radius = radius;
        this.w = this.h = radius * 2;
    }

    public void update(float dt) {
        life -= dt;
        if (life <= 0) alive = false;
        x += vx * dt;
        y += vy * dt;
    }

    public int texIndex() {
        if (element == null) return 0;
        switch (element) {
            case PYRO: return 0;
            case CRYO: return 1;
            case HYDRO: return 2;
            case ELECTRO: return 3;
            case ANEMO: return 4;
            default: return 5;
        }
    }

    public void render(SpriteBatch batch) {
        int col = element == null ? 0xffffffff : element.bright;
        batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, 0.85f);
        float s = radius * 2.6f;
        batch.draw(Assets.slashTex, x - s / 2, y - s / 2, s, s);
        batch.setColor(1, 1, 1, 1);
    }
}