package com.elementia.core;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;

/**
 * Pixel-painting primitives used to build every texture procedurally.
 * All drawings target a {@link Pixmap} in RGBA8888.
 */
public final class Art {
    private Art() {}

    public static Pixmap newPix(int w, int h) {
        return new Pixmap(w, h, Pixmap.Format.RGBA8888);
    }

    // ---------- color helpers ----------

    public static int rgb(int r, int g, int b) {
        return (0xff << 24) | (r << 16) | (g << 8) | b;
    }

    public static int rgba(float r, float g, float b, float a) {
        return ((int)(a * 255) << 24) | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

    public static int shade(int col, float f) {
        int a = (col >>> 24) & 0xff;
        int r = (int)(((col >>> 16) & 0xff) * f); r = Math.min(255, r);
        int g = (int)(((col >>> 8) & 0xff) * f);  g = Math.min(255, g);
        int b = (int)((col & 0xff) * f);          b = Math.min(255, b);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int mix(int c1, int c2, float t) {
        int a1 = (c1 >>> 24) & 0xff, r1 = (c1 >>> 16) & 0xff, g1 = (c1 >>> 8) & 0xff, b1 = c1 & 0xff;
        int a2 = (c2 >>> 24) & 0xff, r2 = (c2 >>> 16) & 0xff, g2 = (c2 >>> 8) & 0xff, b2 = c2 & 0xff;
        return ((int)(a1 + (a2 - a1) * t) << 24)
             | ((int)(r1 + (r2 - r1) * t) << 16)
             | ((int)(g1 + (g2 - g1) * t) << 8)
             | (int)(b1 + (b2 - b1) * t);
    }

    // ---------- fill primitives ----------

    public static void set(Pixmap p, int x, int y, int col) {
        if (x < 0 || y < 0 || x >= p.getWidth() || y >= p.getHeight()) return;
        p.drawPixel(x, y, col);
    }

    public static void fillRect(Pixmap p, int x, int y, int w, int h, int col) {
        for (int yy = y; yy < y + h; yy++)
            for (int xx = x; xx < x + w; xx++)
                set(p, xx, yy, col);
    }

    public static void outlineRect(Pixmap p, int x, int y, int w, int h, int col) {
        for (int i = 0; i < w; i++) {
            set(p, x + i, y, col);
            set(p, x + i, y + h - 1, col);
        }
        for (int j = 0; j < h; j++) {
            set(p, x, y + j, col);
            set(p, x + w - 1, y + j, col);
        }
    }

    public static void fillCircle(Pixmap p, int cx, int cy, int r, int col) {
        for (int y = -r; y <= r; y++)
            for (int x = -r; x <= r; x++)
                if (x * x + y * y <= r * r)
                    set(p, cx + x, cy + y, col);
    }

    public static void outlineCircle(Pixmap p, int cx, int cy, int r, int col) {
        for (int y = -r; y <= r; y++)
            for (int x = -r; x <= r; x++) {
                int d = x * x + y * y;
                int hi = r * r, lo = (r - 1) * (r - 1);
                if (d <= hi && d >= lo)
                    set(p, cx + x, cy + y, col);
            }
    }

    public static void fillEllipse(Pixmap p, int cx, int cy, int rx, int ry, int col) {
        for (int y = -ry; y <= ry; y++)
            for (int x = -rx; x <= rx; x++)
                if ((x * x * ry * ry) + (y * y * rx * rx) <= rx * rx * ry * ry)
                    set(p, cx + x, cy + y, col);
    }

    public static void outlineEllipse(Pixmap p, int cx, int cy, int rx, int ry, int col) {
        for (int y = -ry; y <= ry; y++)
            for (int x = -rx; x <= rx; x++) {
                double v = (x * x * ry * ry) + (y * y * rx * rx);
                double hi = rx * rx * ry * ry, lo = (rx - 1) * (rx - 1) * ry * ry;
                if (v <= hi && v >= lo)
                    set(p, cx + x, cy + y, col);
            }
    }

    public static void fillTriangle(Pixmap p, int x0, int y0, int x1, int y1, int x2, int y2, int col) {
        int minX = Math.max(0, Math.min(x0, Math.min(x1, x2)));
        int maxX = Math.min(p.getWidth() - 1, Math.max(x0, Math.max(x1, x2)));
        int minY = Math.max(0, Math.min(y0, Math.min(y1, y2)));
        int maxY = Math.min(p.getHeight() - 1, Math.max(y0, Math.max(y1, y2)));
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++)
                if (inTri(x, y, x0, y0, x1, y1, x2, y2))
                    set(p, x, y, col);
    }

    private static boolean inTri(int px, int py, int x0, int y0, int x1, int y1, int x2, int y2) {
        float d1 = sign(px, py, x0, y0, x1, y1);
        float d2 = sign(px, py, x1, y1, x2, y2);
        float d3 = sign(px, py, x2, y2, x0, y0);
        boolean neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
        boolean pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
        return !(neg && pos);
    }

    private static float sign(int px, int py, int x0, int y0, int x1, int y1) {
        return (px - x1) * (y0 - y1) - (x0 - x1) * (py - y1);
    }

    public static void fillPoly(Pixmap p, int[] xs, int[] ys, int col) {
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (int i = 0; i < xs.length; i++) {
            minX = Math.min(minX, xs[i]); maxX = Math.max(maxX, xs[i]);
            minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]);
        }
        minX = Math.max(0, minX); maxX = Math.min(p.getWidth() - 1, maxX);
        minY = Math.max(0, minY); maxY = Math.min(p.getHeight() - 1, maxY);
        int n = xs.length;
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++) {
                boolean inside = false;
                for (int i = 0, j = n - 1; i < n; j = i++) {
                    if ((ys[i] > y) != (ys[j] > y)
                        && x < (xs[j] - xs[i]) * (y - ys[i]) / (double)(ys[j] - ys[i]) + xs[i])
                        inside = !inside;
                }
                if (inside) set(p, x, y, col);
            }
    }

    /** Filled circular sector from angle0 to angle1 (degrees, 0 = +x, CCW). */
    public static void fillSector(Pixmap p, int cx, int cy, int radius, float a0, float a1, int col) {
        for (int y = -radius; y <= radius; y++)
            for (int x = -radius; x <= radius; x++) {
                if (x * x + y * y > radius * radius) continue;
                float ang = (float) Math.toDegrees(Math.atan2(y, x));
                if (ang < 0) ang += 360;
                float sweep = a1 - a0;
                if (sweep < 0) sweep += 360;
                float rel = ang - a0;
                if (rel < 0) rel += 360;
                if (rel <= sweep) set(p, cx + x, cy + y, col);
            }
    }

    /** Vertical gradient rect: top color -> bottom color. */
    public static void vGrad(Pixmap p, int x, int y, int w, int h, int cTop, int cBot) {
        for (int j = 0; j < h; j++) {
            int col = mix(cTop, cBot, j / (float) Math.max(1, h - 1));
            for (int i = 0; i < w; i++) set(p, x + i, y + j, col);
        }
    }

    /** Radial soft glow. */
    public static void glow(Pixmap p, int cx, int cy, int radius, int core) {
        for (int dy = -radius; dy <= radius; dy++)
            for (int dx = -radius; dx <= radius; dx++) {
                int d2 = dx * dx + dy * dy;
                if (d2 > radius * radius) continue;
                float t = (float) Math.sqrt(d2) / radius;
                int col = mix(core, (core & 0x00ffffff), t * t);
                // blend source-over with existing
                int ex = p.getPixel(cx + dx, cy + dy);
                float a = (1f - t) * 0.9f;
                set(p, cx + dx, cy + dy, blend(ex, col, a));
            }
    }

    public static int blend(int dst, int src, float a) {
        int sa = (int)(a * 255);
        int da = 255 - sa;
        int sr = (src >>> 16) & 0xff, sg = (src >>> 8) & 0xff, sb = src & 0xff;
        int dr = (dst >>> 16) & 0xff, dg = (dst >>> 8) & 0xff, db = dst & 0xff;
        int a2 = ((sa) * ((src >>> 24) & 0xff) + da * ((dst >>> 24) & 0xff)) / 255;
        return (a2 << 24) | (((sr * sa + dr * da) / 255) << 16) | (((sg * sa + dg * da) / 255) << 8) | ((sb * sa + db * da) / 255);
    }

    /** Simple value-noise for texture detail (deterministic). */
    public static float noise(int x, int y, int seed) {
        int h = x * 374761393 + y * 668265263 + seed * 1442695041;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xffff) / 65535f;
    }
}