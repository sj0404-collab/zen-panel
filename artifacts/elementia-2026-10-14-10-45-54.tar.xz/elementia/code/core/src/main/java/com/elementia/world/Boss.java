package com.elementia.world;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;
import com.elementia.core.Config;
import com.elementia.core.Element;

/**
 * The sanctuary guardian: an ice lion ("Frost Lich" / "Blizzard Lion").
 * Cycles leap > ice-shard volley > contact swipes, enrages under 50% HP.
 */
public class Boss extends Enemy {
    public float phaseTimer;
    public int attackIdx;
    public boolean intro;
    public boolean enraged;
    public float teleport;
    public float volleyTimer;
    public boolean defeated;
    float wobble;

    public Boss(float x, float y) {
        super(Enemy.Kind.GOLEM, x, y, 78f, 70f);
        maxHp = 620;
        hp = maxHp;
    }

    @Override
    public void update(World world, float dt) {
        if (!alive) { tick(dt); return; }
        super.tick(dt);
        wobble += dt;
        Player p = world.player;
        float dx = p.x - x;

        phaseTimer -= dt;
        if (hp <= maxHp / 2 && !enraged) {
            enraged = true;
            world.particles.emitBurst(x + w / 2, y + h / 2, 0xff7fd0ff, 40, 280, 4, 1.2f);
            world.screenShake(0.5f, 8f);
        }

        if (attackIdx == 0) {
            // leap at player
            facing = dx > 0 ? 1 : -1;
            if (phaseTimer <= 0) {
                vx = facing * 320f;
                vy = 560f;
                attackIdx = 1;
                phaseTimer = 0.5f;
                world.particles.emitSparks(x + w / 2, y, 0xff9fd8ff, 10, 120);
            }
        } else if (attackIdx == 1) {
            // airborne, small drift toward player
            vx *= 0.9f;
            if (phaseTimer <= 0 && y > p.y) {
                // mid-air slam
                vx = facing * -180f;
                vy = -900f;
                phaseTimer = 0.9f;
                attackIdx = 2;
            }
        } else if (attackIdx == 2) {
            // land shockwave
            if (grounded) {
                world.particles.emitBurst(x + w / 2, y, 0xffb8e6ff, 26, 260, 4, 0.7f);
                world.screenShake(0.3f, 6f);
                if (Math.abs(p.x - x) < 120f && p.y < y + h * 0.6f) {
                    p.applyDamage(14, false, Math.signum(p.x - x) * 260f, 400f);
                }
                attackIdx = 3;
                phaseTimer = 1.0f; // windup
            }
        } else if (attackIdx == 3) {
            // ice volley burst
            if (phaseTimer <= 0) {
                int n = enraged ? 6 : 4;
                for (int i = 0; i < n; i++) {
                    float a = -0.9f + i * (1.8f / (n - 1));
                    float spd = 260f + (enraged ? 60 : 0);
                    world.addProjectile(x + w / 2, y + h * 0.7f,
                            (float) Math.cos(a) * spd * 0.8f, (float) Math.sin(a) * spd * 0.6f,
                            12, Element.HYDRO, true, 10);
                }
                attackIdx = 0;
                phaseTimer = enraged ? 1.1f : 1.8f;
                world.particles.emitBurst(x + w / 2, y + h / 2, 0xff7fd0ff, 12, 180, 3, 0.5f);
            }
        }

        // gravity
        vy -= world.gravity() * dt * 0.9f;
        if (vy < -world.maxFall()) vy = -world.maxFall();
        float nx = x + vx * dt;
        if (!world.solidAt(nx + (facing > 0 ? 1 : -1) * 4, y + 4) || y > World.MH * Config.TILE) {
            x = nx;
        } else {
            vx = -vx * 0.5f;
        }
        y += vy * dt;
        grounded = false;
        if (world.solidAt(x + 2, y - 1) || world.solidAt(x + w - 2, y - 1)) {
            y -= -1; // snap
            grounded = true;
            vy = 0;
        } else if (y < 2) {
            y = 2;
            grounded = true;
            vy = 0;
        }
        updateRect();
    }

    public void contact(World world) {
        Player p = world.player;
        if (p.invuln <= 0 && p.x < x + w && p.x + p.w > x && p.y < y + h && p.y + p.h > y) {
            p.applyDamage(16, false, Math.signum(p.x - x) * 300f, 260f);
        }
    }

    @Override
    public void render(SpriteBatch batch) {
        // icy tint
        int col = 0xff9fd8ff;
        batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, 1f);
        float jitter = (attackIdx == 1) ? (float) Math.sin(wobble * 30f) * 2 : 0;
        if (hitFlash > 0) batch.setColor(2f, 2f, 2f, 1f);
        batch.draw(Assets.bossReg, x + w / 2 - 44f, y + jitter, 88, 76);
        batch.setColor(1, 1, 1, 1);
    }

    @Override
    public void onDie() {
        defeated = true;
    }
}