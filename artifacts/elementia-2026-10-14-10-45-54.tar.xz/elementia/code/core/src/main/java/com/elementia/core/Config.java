package com.elementia.core;

/** Global game constants and enums. */
public final class Config {
    private Config() {}

    // ---------- 2D viewport (world units) ----------
    public static final float VIEW_W = 960f;
    public static final float VIEW_H = 540f;

    // ---------- 2D physics ----------
    public static final float GRAVITY = 2100f;
    public static final float TILE = 32f;
    public static final float MAX_FALL = 1200f;
    public static final float PLAYER_W = 22f;
    public static final float PLAYER_H = 34f;
    public static final float MOVE_SPEED = 260f;
    public static final float ACCEL = 1800f;
    public static final float GROUND_DECEL = 2600f;
    public static final float AIR_DECEL = 900f;
    public static final float JUMP_VEL = 700f;
    public static final float JUMP_CUT = 0.45f;
    public static final float COYOTE_TIME = 0.1f;
    public static final float JUMP_BUFFER = 0.12f;
    public static final float DASH_SPEED = 720f;
    public static final float DASH_TIME = 0.16f;
    public static final float DASH_CD = 0.5f;

    // ---------- 2D combat ----------
    public static final float COMBO_WINDOW = 0.5f;
    public static final float COMBAT_KNOCKBACK = 220f;
    public static final float MAX_HP = 100f;
    public static final float MAX_BURST = 100f;
    public static final float SKILL_CD = 1.4f;
    public static final float STATUS_DURATION = 4f;

    // ---------- 2D camera ----------
    public static final float CAM_LERP = 4.5f;
    public static final float CAM_LOOKAHEAD = 60f;
}