package com.elementia.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;
import com.elementia.world.Player;

/**
 * Virtual touch controls: floating joystick on the left, four action buttons
 * on the right. Feeds the shared InputState.
 */
public class TouchControls extends InputAdapter {
    public com.elementia.core.InputState state;
    OrthographicCamera cam;
    SpriteBatch batch;

    /** On mobile the touch layer is authoritative; on desktop it only writes input while a touch is active. */
    public boolean mobile;

    int padPointer = -1, padId = -1;
    float padStartX, padStartY;
    float padCurX, padCurY;
    boolean padActive;

    public boolean tapConsumed;

    int jumpPointer = -1;
    int atkPointer = -1;
    int skillPointer = -1;
    int dashPointer = -1;
    boolean jumpHeld, atkHeld, skillHeld, dashHeld;
    boolean jumpPrev, atkPrev, skillPrev, dashPrev;

    float w, h;
    float uiScale = 1f;

    public TouchControls(com.elementia.core.InputState state) {
        this.state = state;
        cam = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.position.set(cam.viewportWidth / 2, cam.viewportHeight / 2, 0);
        cam.update();
    }

    public void resize(int w, int h) {
        this.w = w;
        this.h = h;
        uiScale = Math.max(0.9f, Math.min(2.4f, Math.min(w, h) / 540f));
        cam.viewportWidth = w;
        cam.viewportHeight = h;
        cam.position.set(w / 2f, h / 2f, 0);
        cam.update();
    }

    // button centers (in screen coords, y from bottom), scaled to screen size.
    // Medium size: ~38px radius for primary actions, ~34 for cooldown skills.
    float btnJumpX() { return w - 160 * uiScale; }
    float btnJumpY() { return 170 * uiScale; }
    float btnAtkX() { return w - 100 * uiScale; }
    float btnAtkY() { return 110 * uiScale; }
    float btnSkillX() { return w - 165 * uiScale; }
    float btnSkillY() { return 60 * uiScale; }
    float btnDashX() { return w - 60 * uiScale; }
    float btnDashY() { return 190 * uiScale; }
    static final float R_MAIN = 38f, R_SUB = 34f;

    public void update() {
        if (state != null) {
            boolean any = padActive || jumpHeld || atkHeld || skillHeld || dashHeld;
            if (mobile || any) {
                state.left = padActive && padCurX - padStartX < -22;
                state.right = padActive && padCurX - padStartX > 22;
                state.jumpHeld = jumpHeld;
                // pressed flags are edge-triggered so a held button fires once per press
                state.jumpPressed = jumpHeld && !jumpPrev;
                state.attackPressed = atkHeld && !atkPrev;
                state.skillPressed = skillHeld && !skillPrev;
                state.dashPressed = dashHeld && !dashPrev;
            }
            jumpPrev = jumpHeld;
            atkPrev = atkHeld;
            skillPrev = skillHeld;
            dashPrev = dashHeld;
        }
    }

    public void resetTap() { tapConsumed = false; }

    public boolean anyActiveTouch() {
        return padActive || atkHeld || jumpHeld || skillHeld || dashHeld;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        float y = h - screenY; // flip to bottom-origin
        // Left area = joystick
        if (screenX < w * 0.35f) {
            if (padPointer == -1) {
                padPointer = pointer;
                padStartX = screenX;
                padStartY = y;
                padCurX = screenX;
                padCurY = y;
                padActive = true;
            }
            return true;
        }
        // Buttons on the right
        boolean any = false;
        if (inCircle(screenX, y, btnAtkX(), btnAtkY(), R_MAIN * uiScale)) { atkPointer = pointer; atkHeld = true; any = true; }
        if (inCircle(screenX, y, btnJumpX(), btnJumpY(), R_MAIN * uiScale)) { jumpPointer = pointer; jumpHeld = true; any = true; }
        if (inCircle(screenX, y, btnSkillX(), btnSkillY(), R_SUB * uiScale)) { skillPointer = pointer; skillHeld = true; any = true; }
        if (inCircle(screenX, y, btnDashX(), btnDashY(), R_SUB * uiScale)) { dashPointer = pointer; dashHeld = true; any = true; }
        if (any) { tapConsumed = true; return true; }
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (pointer == padPointer) { padPointer = -1; padActive = false; }
        if (pointer == atkPointer) { atkPointer = -1; atkHeld = false; }
        if (pointer == jumpPointer) { jumpPointer = -1; jumpHeld = false; }
        if (pointer == skillPointer) { skillPointer = -1; skillHeld = false; }
        if (pointer == dashPointer) { dashPointer = -1; dashHeld = false; }
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        if (pointer == padPointer) {
            padCurX = screenX;
            padCurY = h - screenY;
        }
        return false;
    }

    boolean inCircle(float x, float y, float cx, float cy, float r) {
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy <= r * r;
    }

    public void render() {
        if (w <= 0) return;
        if (batch == null) {
            batch = new SpriteBatch();
        }
        batch.setProjectionMatrix(cam.combined);
        batch.begin();

        // joystick base
        float jx = 85 * uiScale, jy = 90 * uiScale, r = 52 * uiScale;
        batch.setColor(0.9f, 0.9f, 0.95f, 0.18f);
        batch.draw(Assets.glowDot, jx - r, jy - r, r * 2, r * 2);
        batch.setColor(0.9f, 0.9f, 0.95f, 0.25f);
        batch.draw(Assets.glowDot, jx - r * 0.7f, jy - r * 0.7f, r * 1.4f, r * 1.4f);
        float kx = jx, ky = jy;
        if (padActive) {
            float dx = padCurX - padStartX, dy = padCurY - padStartY;
            kx = jx + Math.max(-r * 0.5f, Math.min(r * 0.5f, dx));
            ky = jy + Math.max(-r * 0.5f, Math.min(r * 0.5f, dy));
        }
        batch.setColor(1f, 1f, 1f, 0.5f);
        batch.draw(Assets.glowDot, kx - 22 * uiScale, ky - 22 * uiScale, 44 * uiScale, 44 * uiScale);

        // action buttons (medium size)
        drawButton(btnJumpX(), btnJumpY(), "ПРЫЖОК", R_MAIN * uiScale, jumpPointer != -1, 0xff4dd0e1);
        drawButton(btnAtkX(), btnAtkY(), "АТАКА", R_MAIN * uiScale, atkPointer != -1, 0xffff8a65);
        drawButton(btnSkillX(), btnSkillY(), "НАВЫК", R_SUB * uiScale, skillPointer != -1, 0xffb39ddb);
        drawButton(btnDashX(), btnDashY(), "РЫВОК", R_SUB * uiScale, dashPointer != -1, 0xff66bb6a);

        batch.end();
    }

    void drawButton(float cx, float cy, String label, float r, boolean pressed, int col) {
        batch.setColor((col >>> 16) & 0xff, (col >>> 8) & 0xff, col & 0xff, pressed ? 0.6f : 0.3f);
        batch.draw(Assets.glowDot, cx - r, cy - r, r * 2, r * 2);
        batch.setColor(1, 1, 1, 0.5f);
        batch.draw(Assets.glowDot, cx - r * 0.78f, cy - r * 0.78f, r * 1.56f, r * 1.56f);
        Fonts.small.setColor(1f, 1f, 1f, 0.92f);
        com.badlogic.gdx.graphics.g2d.GlyphLayout gl = new com.badlogic.gdx.graphics.g2d.GlyphLayout(Fonts.small, label);
        Fonts.small.draw(batch, label, cx - gl.width / 2, cy + gl.height / 2);
    }

    public void dispose() {
        if (batch != null) batch.dispose();
    }
}