package com.elementia.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.ui.Fonts;

/** Anime-style title screen (Russian). */
public class TitleScreen extends ScreenAdapter {
    final ElementiaGame game;
    SpriteBatch batch;
    OrthographicCamera cam;
    GlyphLayout layout = new GlyphLayout();
    float t;

    public TitleScreen(ElementiaGame game) { this.game = game; }

    @Override
    public void show() {
        batch = new SpriteBatch();
        cam = new OrthographicCamera(Config.VIEW_W, Config.VIEW_H);
        cam.position.set(Config.VIEW_W / 2, Config.VIEW_H / 2, 0);
        cam.update();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.12f, 0.12f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        t += delta;
        boolean press = Gdx.input.isKeyJustPressed(Input.Keys.ENTER)
                || Gdx.input.isKeyJustPressed(Input.Keys.SPACE);
        boolean touchPress = Gdx.input.justTouched();
        if (press || touchPress) {
            game.setScreen(game.newGameScreen(game.mobile));
            return;
        }

        batch.setProjectionMatrix(cam.combined);
        batch.begin();

        // animated background: rotating elemental wheel
        float cx = Config.VIEW_W / 2, cy = Config.VIEW_H / 2 + 20;
        float pulse = (float) Math.sin(t * 1.5f) * 8f;
        for (int i = 0; i < Element.values().length; i++) {
            int col = Element.values()[i].bright;
            float a = (float) (t * 0.4f + i * Math.PI * 2 / Element.values().length);
            float x = cx + (float) Math.cos(a) * (120 + pulse);
            float y = cy + (float) Math.sin(a) * (120 + pulse);
            batch.setColor((col >>> 16) & 0xff, (col >>> 8) & 0xff, col & 0xff, 0.7f);
            batch.draw(Assets.glowDot, x - 14, y - 14, 28, 28);
        }

        // title text
        Fonts.title.setColor(1f, 0.95f, 0.8f, 1);
        layout.setText(Fonts.title, "ЭЛЕМЕНТИЯ");
        Fonts.title.draw(batch, "ЭЛЕМЕНТИЯ", cx - layout.width / 2, cy + 86);

        Fonts.titleSmall.setColor(0.85f, 0.9f, 1f, 1);
        layout.setText(Fonts.titleSmall, "Аниме-метроидвания о стихиях");
        Fonts.titleSmall.draw(batch, "Аниме-метроидвания о стихиях", cx - layout.width / 2, cy + 54);

        Fonts.dialogue.setColor(0.9f, 0.9f, 1f, 0.85f);
        layout.setText(Fonts.dialogue, game.mobile ? "Коснись экрана, чтобы начать" : "Нажми ENTER, чтобы начать");
        Fonts.dialogue.draw(batch, game.mobile ? "Коснись экрана, чтобы начать" : "Нажми ENTER, чтобы начать", cx - layout.width / 2, cy - 14);

        Fonts.small.setColor(0.7f, 0.75f, 0.9f, 0.8f);
        String controls = game.mobile
                ? "Слева — джойстик движения | Справа — Прыжок / Атака / Навык / Рывок"
                : "Движение: WASD/стрелки  Атака: J  Навык: K  Рывок: L  Прыжок: Пробел";
        layout.setText(Fonts.small, controls);
        Fonts.small.draw(batch, controls, cx - layout.width / 2, cy - 76);
        layout.setText(Fonts.small, "Исследуй шесть миров стихий и верни свет Кристаллу Судьбы!");
        Fonts.small.draw(batch, "Исследуй шесть миров стихий и верни свет Кристаллу Судьбы!", cx - layout.width / 2, cy - 98);

        // draw a hero silhouette bottom center
        float hx = cx, hy = 60;
        com.badlogic.gdx.graphics.g2d.TextureRegion r = Assets.heroIdle[(int) (t * 2) % 2];
        batch.draw(r, hx - 28, hy, 56, 76);

        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
    }
}