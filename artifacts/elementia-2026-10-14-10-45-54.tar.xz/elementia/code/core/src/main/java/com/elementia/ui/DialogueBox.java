package com.elementia.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;

/**
 * Typewriter dialogue box. Drives NPC dialogue from World.NPC_TEXT.
 * Show via {@link #show(String[], Runnable)}; call update(dt)/render every frame.
 */
public class DialogueBox {
    SpriteBatch batch;
    OrthographicCamera cam;
    BitmapFont font;
    GlyphLayout layout = new GlyphLayout();

    String[] lines;
    String speaker;
    int lineIdx;
    float typeTimer;
    boolean open;
    boolean doneTyping;
    Runnable onClose;
    float advanceCooldown;

    public DialogueBox() {
        cam = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.position.set(cam.viewportWidth / 2, cam.viewportHeight / 2, 0);
        cam.update();
    }

    public void resize(int w, int h) {
        cam.viewportWidth = w;
        cam.viewportHeight = h;
        cam.position.set(w / 2f, h / 2f, 0);
        cam.update();
    }

    public void show(String[] data, Runnable onClose) {
        this.speaker = data[0];
        this.lines = data[1].split("\n");
        this.onClose = onClose;
        lineIdx = 0;
        typeTimer = 0;
        open = true;
        doneTyping = false;
        advanceCooldown = 0.4f;
    }

    public boolean isOpen() { return open; }

    public void update(float dt) {
        if (!open) return;
        if (advanceCooldown > 0) advanceCooldown -= dt;
        if (!doneTyping) {
            typeTimer += dt * 34f;
            String line = lines[lineIdx];
            if (typeTimer >= line.length()) { typeTimer = line.length(); doneTyping = true; }
        }
    }

    /** Returns true if the dialogue was closed by this advance. */
    public boolean advance() {
        if (!open) return false;
        if (advanceCooldown > 0) return false;
        if (!doneTyping) {
            // skip typing
            typeTimer = lines[lineIdx].length();
            doneTyping = true;
            return false;
        }
        lineIdx++;
        if (lineIdx >= lines.length) {
            close();
            return true;
        }
        typeTimer = 0;
        doneTyping = false;
        return false;
    }

    void close() {
        open = false;
        if (onClose != null) onClose.run();
    }

    public void render(float time) {
        if (!open) return;
        if (batch == null) {
            cam.viewportWidth = Gdx.graphics.getWidth();
            cam.viewportHeight = Gdx.graphics.getHeight();
            cam.position.set(cam.viewportWidth / 2, cam.viewportHeight / 2, 0);
            cam.update();
            batch = new SpriteBatch();
        }
        batch.setProjectionMatrix(cam.combined);
        batch.begin();
        float w = cam.viewportWidth, h = cam.viewportHeight;

        // box
        float bw = w * 0.92f, bh = h * 0.26f, bx = w * 0.04f, by = h * 0.05f;
        batch.setColor(0, 0, 0, 0.75f);
        batch.draw(Assets.whiteDot, bx - 4, by - 4, bw + 8, bh + 8);
        batch.setColor(0.95f, 0.95f, 1f, 0.98f);
        batch.draw(Assets.whiteDot, bx, by, bw, bh);

        // speaker
        Fonts.dialogue.setColor(0.1f, 0.25f, 0.5f, 1f);
        Fonts.dialogue.draw(batch, speaker, bx + 14, by + bh - 20);

        // portrait (uses heroine frame)
        float ps = 52;
        batch.draw(Assets.heroIdle[0], bx + 16, by + 14, ps, ps * 76f / 56f);
        Fonts.dialogue.setColor(Color.BLACK);

        // typed text
        String line = lines[lineIdx];
        String shown = line.length() > (int) typeTimer ? line.substring(0, (int) typeTimer) : line;
        float tx = bx + 80, ty = by + bh - 52;
        drawWrapped(batch, Fonts.dialogue, shown, tx, ty, bw - 110, 24);

        // advance arrow
        if (doneTyping) {
            float blink = (float) Math.sin(time * 5) > 0 ? 1 : 0.2f;
            Fonts.dialogue.setColor(0.2f, 0.5f, 0.9f, blink);
            Fonts.dialogue.draw(batch, "▼", bx + bw - 26, by + 12);
        }
        batch.end();
    }

    void drawWrapped(SpriteBatch batch, BitmapFont f, String text, float x, float y, float maxW, float lineH) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            layout.setText(f, test);
            if (layout.width > maxW && line.length() > 0) {
                f.draw(batch, line.toString(), x, y);
                line.setLength(0);
                line.append(word);
                y -= lineH;
            } else {
                line.setLength(0);
                line.append(test);
            }
        }
        if (line.length() > 0) f.draw(batch, line.toString(), x, y);
    }

    public void dispose() { if (batch != null) batch.dispose(); }
}