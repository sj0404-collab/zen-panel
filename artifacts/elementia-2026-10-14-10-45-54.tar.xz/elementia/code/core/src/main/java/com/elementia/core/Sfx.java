package com.elementia.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;

import java.util.HashMap;
import java.util.Map;

/**
 * Procedurally generated, dependency-free audio. Sound effects and a looping
 * music track are synthesized as WAV streams at first launch, cached to the
 * local filesystem, and loaded through Gdx.audio. On headless backends
 * Gdx.audio is unavailable and every call becomes a no-op.
 */
public final class Sfx {
    private Sfx() {}

    static final int RATE = 22050;
    static volatile boolean available;
    static Music music;
    static final Map<String, Sound> sfx = new HashMap<>();
    public static float sfxVolume = 0.6f;
    public static float musicVolume = 0.35f;
    static boolean musicStarted;

    static final String[] NAMES = {
        "jump", "dash", "slash", "hit", "enemyDie", "hurt",
        "skill", "burst", "chest", "waypoint", "talk", "burn",
        "melt", "roar", "victory", "coin",
        "honk", "cash", "achieve", "interact", "portal", "crash", "splash"
    };

    public static void init() {
        try {
            if (Gdx.audio == null) { available = false; return; }
            FileHandle dir = Gdx.files.local("audio");
            dir.mkdirs();
            for (String n : NAMES) {
                FileHandle f = dir.child(n + ".wav");
                if (!f.exists()) f.writeBytes(wavPcm(sfxFor(n)), false);
                sfx.put(n, Gdx.audio.newSound(f));
            }
            FileHandle mf = dir.child("music.wav");
            if (!mf.exists()) mf.writeBytes(wavPcm(musicSamples()), false);
            music = Gdx.audio.newMusic(mf);
            music.setLooping(true);
            available = true;
        } catch (Throwable t) {
            available = false;
        }
    }

    public static void play(String name) { play(name, sfxVolume, 1f); }

    public static void play(String name, float vol, float pitch) {
        if (!available) return;
        Sound s = sfx.get(name);
        if (s == null) return;
        long id = s.play(Math.max(0, Math.min(1, vol)));
        if (pitch != 1f) s.setPitch(id, pitch);
    }

    public static void startMusic() {
        if (!available || music == null) return;
        musicStarted = true;
        music.setVolume(musicVolume);
        music.play();
    }

    public static void stopMusic() {
        if (!available || music == null) return;
        musicStarted = false;
        music.stop();
    }

    /** Pause the looping music when the app loses focus or is backgrounded. */
    public static void pauseMusic() {
        if (!available || music == null) return;
        if (music.isPlaying()) music.pause();
    }

    /** Resume the looping music when focus returns (only if it was playing). */
    public static void resumeMusic() {
        if (!available || music == null) return;
        if (musicStarted && !music.isPlaying()) music.play();
    }

    public static void dispose() {
        for (Sound s : sfx.values()) s.dispose();
        sfx.clear();
        if (music != null) music.dispose();
        music = null;
        available = false;
    }

    // ---------- synthesis helpers ----------

    static int rng = 987654321;

    static double rnd() {
        rng = rng * 1103515245 + 12345;
        return ((rng >>> 8) & 0xffffff) / (double) 0x1000000;
    }

    static float[] silent(int seconds) {
        return new float[seconds * RATE];
    }

    static void add(float[] a, float[] b, int at) {
        for (int i = 0; i < b.length; i++) {
            int j = at + i;
            if (j >= a.length) break;
            a[j] += b[i];
        }
    }

    static float[] tone(double len, double f, double amp) {
        int n = (int) (len * RATE);
        float[] a = new float[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            a[i] = (float) (amp * Math.sin(2 * Math.PI * f * t));
        }
        return a;
    }

    static float[] sweep(double len, double f0, double f1, double amp, double wave) {
        int n = (int) (len * RATE);
        float[] a = new float[n];
        double phi = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double f = f0 + (f1 - f0) * (i / (double) n);
            phi += 2 * Math.PI * f / RATE;
            double s;
            switch ((int) wave) {
                case 1: s = Math.signum(Math.sin(phi)); break;
                case 2: s = 2 * (phi / (2 * Math.PI) - Math.floor(0.5 + phi / (2 * Math.PI))); break;
                default: s = Math.sin(phi);
            }
            a[i] = (float) (amp * s * Math.min(1, Math.max(0, 1 - t * (1 / len) * (2 - 1))));
        }
        return a;
    }

    static float[] noise(double len, double amp) {
        int n = (int) (len * RATE);
        float[] a = new float[n];
        for (int i = 0; i < n; i++) a[i] = (float) ((rnd() * 2 - 1) * amp);
        return a;
    }

    static float[] envFade(float[] a, double in, double out) {
        int nIn = (int) (in * RATE), nOut = (int) (out * RATE);
        for (int i = 0; i < nIn && i < a.length; i++) a[i] *= i / (float) nIn;
        for (int j = 0; j < nOut && j < a.length; j++) a[a.length - 1 - j] *= j / (float) nOut;
        return a;
    }

    static void scale(float[] a, float k) {
        for (int i = 0; i < a.length; i++) a[i] *= k;
    }

    static float[] envSwell(float[] a, double swell) {
        int nS = (int) (swell * RATE);
        for (int i = 0; i < nS && i < a.length; i++) a[i] *= i / (float) nS;
        return a;
    }

    static byte[] wavPcm(float[] s) {
        int n = s.length;
        int dataSize = n * 2;
        byte[] b = new byte[44 + dataSize];
        putStr(b, 0, "RIFF");
        putLE(b, 4, 36 + dataSize);
        putStr(b, 8, "WAVE");
        putStr(b, 12, "fmt ");
        putLE(b, 16, 16);
        putLE16(b, 20, 1);
        putLE16(b, 22, 1);
        putLE(b, 24, RATE);
        putLE(b, 28, RATE * 2);
        putLE16(b, 32, 2);
        putLE16(b, 34, 16);
        putStr(b, 36, "data");
        putLE(b, 40, dataSize);
        for (int i = 0; i < n; i++) {
            float v = Math.max(-1f, Math.min(1f, s[i]));
            short pcm = (short) (v * 32767);
            b[44 + i * 2] = (byte) (pcm & 0xff);
            b[45 + i * 2] = (byte) ((pcm >>> 8) & 0xff);
        }
        return b;
    }

    static void putStr(byte[] b, int off, String s) {
        for (int i = 0; i < s.length(); i++) b[off + i] = (byte) s.charAt(i);
    }

    static void putLE(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xff);
        b[off + 1] = (byte) ((v >>> 8) & 0xff);
        b[off + 2] = (byte) ((v >>> 16) & 0xff);
        b[off + 3] = (byte) ((v >>> 24) & 0xff);
    }

    static void putLE16(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xff);
        b[off + 1] = (byte) ((v >>> 8) & 0xff);
    }

    // ---------- one-shot sounds ----------

    static float[] sfxFor(String name) {
        switch (name) {
            case "jump": {
                float[] a = sweep(0.18, 280, 680, 0.5, 0);
                return envFade(a, 0.02, 0.12);
            }
            case "dash": {
                float[] a = sweep(0.28, 500, 900, 0.3, 0);
                float[] nz = envSwell(noise(0.28, 0.35), 0.08);
                for (int i = 0; i < nz.length; i++) nz[i] *= (float) Math.min(1, (nz.length - i) / (double) RATE);
                add(a, nz, 0);
                return envFade(a, 0.01, 0.16);
            }
            case "slash": {
                float[] a = sweep(0.14, 700, 220, 0.4, 1);
                float[] nz = noise(0.1, 0.3);
                add(a, nz, 0);
                return envFade(a, 0.01, 0.1);
            }
            case "hit": {
                float[] a = sweep(0.1, 240, 110, 0.55, 1);
                return envFade(a, 0.005, 0.08);
            }
            case "enemyDie": {
                float[] a = sweep(0.3, 430, 70, 0.45, 2);
                return envFade(a, 0.01, 0.22);
            }
            case "hurt": {
                float[] a = sweep(0.26, 300, 90, 0.7, 2);
                return envFade(a, 0.01, 0.2);
            }
            case "skill": {
                float[] a = sweep(0.22, 500, 1200, 0.4, 1);
                float[] nz = noise(0.18, 0.25);
                add(a, nz, 0);
                return envFade(a, 0.01, 0.15);
            }
            case "burst": {
                float[] a = sweep(0.5, 150, 45, 0.8, 0);
                float[] nz = envFade(noise(0.4, 0.28), 0.01, 0.2);
                add(a, nz, 0);
                scale(a, 0.75f);
                return envFade(a, 0.01, 0.3);
            }
            case "chest": {
                float[] a = tone(0.12, 660, 0.5);
                float[] b = tone(0.3, 990, 0.5);
                add(a, b, (int) (0.1 * RATE));
                return envFade(a, 0.01, 0.28);
            }
            case "waypoint": {
                float[] a = new float[(int) (0.45 * RATE)];
                double[] f = { 660, 880, 1320 };
                for (int k = 0; k < 3; k++) {
                    add(a, envFade(tone(0.16, f[k], 0.4), 0.01, 0.12), (int) (k * 0.13 * RATE));
                }
                return a;
            }
            case "talk": {
                float[] a = tone(0.06, 780, 0.25);
                return envFade(a, 0.005, 0.05);
            }
            case "burn": {
                float[] a = noise(0.55, 0.5);
                for (int i = 0; i < a.length; i++) a[i] *= (float) (0.4 + 0.6 * rnd());
                float[] cr = sweep(0.55, 380, 160, 0.3, 2);
                add(a, cr, 0);
                return envFade(a, 0.02, 0.3);
            }
            case "melt": {
                float[] a = sweep(0.5, 900, 200, 0.35, 0);
                return envFade(a, 0.03, 0.35);
            }
            case "roar": {
                float[] a = sweep(0.7, 170, 60, 0.7, 2);
                float[] nz = envFade(noise(0.6, 0.3), 0.05, 0.25);
                add(a, nz, 0);
                return envFade(a, 0.03, 0.4);
            }
            case "victory": {
                float[] a = new float[(int) (1.1 * RATE)];
                double[] f = { 523, 659, 784, 1047 };
                for (int k = 0; k < 4; k++) {
                    add(a, envFade(tone(0.28, f[k], 0.4), 0.01, 0.2), (int) (k * 0.24 * RATE));
                }
                return a;
            }
            case "coin": {
                float[] a = sweep(0.14, 720, 1450, 0.4, 0);
                return envFade(a, 0.01, 0.1);
            }
            case "honk": {
                float[] a = new float[(int) (0.45 * RATE)];
                add(a, envFade(tone(0.16, 440, 0.4), 0.01, 0.12), 0);
                add(a, envFade(tone(0.16, 330, 0.4), 0.01, 0.12), (int) (0.18 * RATE));
                return a;
            }
            case "cash": {
                float[] a = new float[(int) (0.34 * RATE)];
                double[] seq = { 880, 1174, 1568 };
                for (int k = 0; k < 3; k++) {
                    add(a, envFade(tone(0.1, seq[k], 0.4), 0.01, 0.08), (int) (k * 0.09 * RATE));
                }
                return a;
            }
            case "achieve": {
                float[] a = new float[(int) (0.8 * RATE)];
                double[] f = { 659, 784, 1046, 1318 };
                for (int k = 0; k < 4; k++) {
                    add(a, envFade(tone(0.16, f[k], 0.4), 0.01, 0.12), (int) (k * 0.14 * RATE));
                }
                float[] sh = envFade(noise(0.7, 0.05), 0.02, 0.2);
                add(a, sh, 0);
                return a;
            }
            case "interact": {
                float[] a = sweep(0.16, 500, 820, 0.35, 0);
                return envFade(a, 0.01, 0.1);
            }
            case "portal": {
                float[] a = sweep(0.6, 220, 1400, 0.4, 0);
                float[] sh = envFade(noise(0.6, 0.12), 0.1, 0.3);
                add(a, sh, 0);
                return envFade(a, 0.1, 0.35);
            }
            case "crash": {
                float[] a = sweep(0.3, 160, 55, 0.7, 1);
                float[] nz = envFade(noise(0.25, 0.5), 0.005, 0.15);
                add(a, nz, 0);
                return envFade(a, 0.01, 0.25);
            }
            case "splash": {
                float[] a = sweep(0.35, 900, 220, 0.5, 1);
                float[] nz = envFade(noise(0.22, 0.35), 0.005, 0.18);
                add(a, nz, 0);
                return envFade(a, 0.01, 0.3);
            }
            default:
                return envFade(tone(0.1, 440, 0.3), 0.01, 0.08);
        }
    }

    // ---------- 8s ambient loop: soft pads, bass and arp, moody minor progression ----------

    static float[] musicSamples() {
        int total = RATE * 8;
        float[] out = new float[total];
        double[][] chords = {
            { 130.81, 155.56, 196.00 }, // Cm
            { 103.83, 207.65, 261.63 }, // Ab
            { 174.61, 207.65, 261.63 }, // Fm
            { 98.00, 233.08, 293.66 }   // G
        };
        // very low air noise bed
        float[] air = envFade(noise(8.0, 0.012), 0.5, 0.5);
        add(out, air, 0);

        for (int cIdx = 0; cIdx < chords.length; cIdx++) {
            int base = cIdx * RATE * 2;
            double[] chord = chords[cIdx];
            // pad: each chord tone
            for (double f : chord) {
                double fDet = f * (1 + (cIdx % 2 == 0 ? 0.001 : -0.001));
                float[] pad = tone(2.0, fDet, 0.05);
                for (int i = 0; i < pad.length; i++) {
                    double t = i / (double) RATE;
                    pad[i] *= (float) Math.min(1, t / 0.45) * (float) (0.5 + 0.5 * Math.sin(Math.PI * (t / 2.0)));
                }
                add(out, pad, base);
            }
            // bass: 4 quarter notes per chord
            double root = chord[0] / 2;
            for (int beat = 0; beat < 4; beat++) {
                float[] n = sweep(0.4, root, root, 0.16, 1);
                envFade(n, 0.02, 0.36);
                add(out, n, base + beat * (RATE / 2));
            }
            // arp: eighth-note broken chord up then down
            int[] seq = { 0, 1, 2, 1 };
            for (int e = 0; e < 8; e++) {
                double f = chord[seq[e % 4]];
                if (e < 4) f *= 2;
                float[] n = envFade(tone(0.2, f, 0.07), 0.01, 0.16);
                add(out, n, base + e * (RATE / 4));
            }
        }
        // normalize
        float max = 0;
        for (float v : out) max = Math.max(max, Math.abs(v));
        if (max > 0) for (int i = 0; i < out.length; i++) out[i] *= 0.85f / max;
        return out;
    }
}