package com.elementia.world;

import java.util.EnumSet;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.elementia.core.Ability;
import com.elementia.core.Config;
import com.elementia.core.Element;
import com.elementia.core.InputState;

/**
 * Heroine "Aria": arcade metroidvania movement (run/jump/double-jump/dash,
 * wall slide) with a 3-hit melee combo and elemental projectiles.
 */
public class Player extends Entity {
    public EnumSet<Ability> abilities = Ability.starting();
    public Element activeElement = null;
    public float skillCd, burstGauge;
    public boolean burstReady;
    public float burstPower;

    // state
    public enum State { IDLE, RUN, JUMP, FALL, DASH, ATTACK, HURT, DEAD }
    public State state = State.IDLE;
    float animTimer;

    // combat
    public int comboStep;            // 0,1,2
    public float comboWindow;
    public float attackTimer;
    float atkDuration;
    public final Vector2 atkCenter = new Vector2();
    public float atkRadius;
    public boolean atkHitApplied;
    public float summonTimer;

    // movement tech
    float coyote, jumpBuffer;
    public float dashTimer, dashCd;
    public int jumpsUsed;
    boolean holdDown;
    public float slideTimer;
    public float invuln;
    int prevFacing;

    public Player(float x, float y) {
        super(x, y, Config.PLAYER_W, Config.PLAYER_H);
        maxHp = (int) Config.MAX_HP;
        hp = maxHp;
        burstGauge = 0;
        burstPower = Config.MAX_BURST;
    }

    public void unlock(Ability a) {
        abilities.add(a);
        if (a == Ability.BURST) burstGauge = Config.MAX_BURST;
    }

    public boolean has(Ability a) { return abilities.contains(a); }

    public void setElement(Element e) {
        if (e == null) { activeElement = null; return; }
        // start with Anemo; others must be unlocked
        if (e == Element.ANEMO) { activeElement = e; return; }
        Ability map = null;
        switch (e) {
            case PYRO: map = Ability.PYRO; break;
            case CRYO: map = Ability.CRYO; break;
            case HYDRO: map = Ability.HYDRO; break;
            default: return;
        }
        if (has(map)) activeElement = e;
    }

    public boolean canDoubleJump() { return has(Ability.DOUBLE_JUMP) && jumpsUsed == 1; }

    public void moveAndCollide(World world, float dt) {
        final float sub = 4f;
        // horizontal (solid walls only)
        float tx = vx * dt;
        while (Math.abs(tx) > 0.01f) {
            float dx = MathUtils.clamp(tx, -sub, sub);
            x += dx;
            if (world.solidAt(x, y + 2) || world.solidAt(x + w - 1, y + 2)
             || world.solidAt(x, y + h - 2) || world.solidAt(x + w - 1, y + h - 2)) {
                x -= dx;
                vx = 0;
                break;
            }
            tx -= dx;
        }
        // vertical (solids + one-way platforms)
        float ty = vy * dt;
        while (Math.abs(ty) > 0.01f) {
            float dy = MathUtils.clamp(ty, -sub, sub);
            y += dy;
            boolean blocked;
            if (dy < 0) {
                blocked = world.solidAt(x + 2, y) || world.solidAt(x + w - 2, y)
                       || world.platformAt(x + 2, y) || world.platformAt(x + w - 2, y);
            } else {
                blocked = world.solidAt(x + 2, y + h) || world.solidAt(x + w - 2, y + h);
            }
            if (blocked) {
                y -= dy;
                if (dy < 0) {
                    float g = Math.max(world.groundTopAt(x + 2, y - 1), world.groundTopAt(x + w - 2, y - 1));
                    if (g > y) y = g;
                }
                vy = 0;
                break;
            }
            ty -= dy;
        }
        grounded = false;
        if (vy <= 0) {
            grounded = world.solidAt(x + 1, y - 2) || world.solidAt(x + w - 1, y - 2)
                    || world.platformAt(x + w / 2, y - 2);
        }
        updateRect();
        if (grounded) jumpsUsed = 0;
    }

    // ---------- animation helpers ----------
    public float animProgress(float dur) {
        return Math.min(1f, animTimer / dur);
    }

    public void updateState() {
        if (!alive || state == State.DEAD) return;
        if (state == State.ATTACK) { if (animTimer <= 0) state = State.IDLE; else return; }
        if (state == State.DASH) return;
        if (dashTimer > 0) return;
        state = State.IDLE;
        if (!grounded) state = (vy > 40) ? State.JUMP : State.FALL;
        else if (Math.abs(vx) > 40) state = State.RUN;
    }
}