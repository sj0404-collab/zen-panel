package com.elementia.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;
import com.elementia.core.Element;
import com.elementia.world.Player;
import com.elementia.world.World;

/** Renders the HUD: HP bar, element icon, burst bar, ability indicators, win banner. */
public class Hud {
    SpriteBatch batch;
    OrthographicCamera cam;
    BitmapFont font;
    GlyphLayout layout = new GlyphLayout();

    public Hud() {
        cam = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.position.set(cam.viewportWidth / 2, cam.viewportHeight / 2, 0);
        cam.update();
    }

    public void resize(int w, int h) {
        cam.viewportWidth = w;
        cam.viewportHeight = h;
        cam.position.set(w / 2f, h / 2f, 0);
        cam.update();
        if (batch == null) batch = new SpriteBatch();
        batch.setProjectionMatrix(cam.combined);
    }

    public void render(World world, float time) {
        render(world, time, false);
    }

    public void render(World world, float time, boolean mobile) {
        Player p = world.player;
        if (batch == null) {
            cam.viewportWidth = Gdx.graphics.getWidth();
            cam.viewportHeight = Gdx.graphics.getHeight();
            cam.position.set(cam.viewportWidth / 2, cam.viewportHeight / 2, 0);
            cam.update();
            batch = new SpriteBatch();
        }
        batch.setProjectionMatrix(cam.combined);
        batch.begin();
        float sw = cam.viewportWidth, sh = cam.viewportHeight;

        // HP bar (top-left)
        float barW = 130, barH = 11, bx = 14, by = sh - 22;
        batch.setColor(0, 0, 0, 0.55f);
        batch.draw(Assets.whiteDot, bx - 1, by - 1, barW + 2, barH + 2);
        float hpFrac = Math.max(0, p.hp / (float) p.maxHp);
        batch.setColor(0.8f, 0.2f, 0.2f, 1);
        batch.draw(Assets.whiteDot, bx, by, barW * hpFrac, barH);
        Fonts.hud.setColor(Color.WHITE);
        Fonts.hud.draw(batch, "ЗДОР", bx + 5, by + barH - 1);
        layout.setText(Fonts.hud, p.hp + "/" + p.maxHp);
        Fonts.hud.draw(batch, p.hp + "/" + p.maxHp, bx + barW / 2 - layout.width / 2, by + barH - 1);

        // Element icon (next to HP)
        if (p.activeElement != null) {
            int ei = p.activeElement.ordinal();
            if (ei < Assets.elementIcons.length)
                batch.draw(Assets.elementIcons[ei], bx + barW + 10, by - 3, 18, 18);
        }
        if (p.activeElement != null && p.activeElement != Element.ANEMO) {
            Fonts.small.setColor(new Color(p.activeElement.bright));
            Fonts.small.draw(batch, p.activeElement.name, bx + barW + 32, by + 9);
        }

        // Burst bar
        float bw = 100, bh = 8, bxx = bx + barW + 36, byy = by + 1;
        batch.setColor(0, 0, 0, 0.55f);
        batch.draw(Assets.whiteDot, bxx - 1, byy - 1, bw + 2, bh + 2);
        float burstFrac = Math.min(1f, p.burstGauge / p.burstPower);
        batch.setColor(1f, 0.85f, 0.2f, 1);
        batch.draw(Assets.whiteDot, bxx, byy, bw * burstFrac, bh);
        if (p.burstReady) {
            float pulse = (float) Math.sin(time * 6) * 0.3f + 0.7f;
            batch.setColor(1f, 1f, 0.5f, pulse);
            batch.draw(Assets.whiteDot, bxx - 2, byy - 2, bw + 4, bh + 4);
        }
        Fonts.hud.setColor(Color.WHITE);
        Fonts.hud.draw(batch, "ВЗРЫВ", bxx + 4, byy + bh - 1);

        // Ability indicators (bottom-left)
        int ax = 14, ay = 40;
        Fonts.small.setColor(Color.LIGHT_GRAY);
        Fonts.small.draw(batch, "Стихии:", ax, ay + 14);
        int offset = 0;
        for (Element e : Element.values()) {
            boolean unlocked = hasElement(p, e);
            if (e == Element.ANEMO || unlocked) {
                int col = unlocked ? e.bright : 0x40808080;
                batch.setColor((col >>> 16) & 0xff, (col >>> 8) & 0xff, col & 0xff, 0.85f);
                batch.draw(Assets.whiteDot, ax + offset, ay - 6, 12, 12);
                Fonts.small.setColor(unlocked ? Color.WHITE : Color.DARK_GRAY);
                Fonts.small.draw(batch, e.name.substring(0, 1), ax + offset + 3, ay + 2);
                offset += 18;
            }
        }

        // Status text for pickups
        if (world.bossDefeated && !world.trophyClaimed) {
            Fonts.hud.setColor(Color.CYAN);
            layout.setText(Fonts.hud, "ДВОЙНОЙ ПРЫЖОК ОТКРЫТ!");
            Fonts.hud.draw(batch, "ДВОЙНОЙ ПРЫЖОК ОТКРЫТ!", sw / 2 - layout.width / 2, sh - 56);
        }
        if (world.gameWon) {
            Fonts.title.setColor(Color.GOLD);
            layout.setText(Fonts.title, "ПОБЕДА!");
            Fonts.title.draw(batch, "ПОБЕДА!", sw / 2 - layout.width / 2, sh / 2 + 30);
            Fonts.dialogue.setColor(Color.WHITE);
            layout.setText(Fonts.dialogue, "Стихии вновь в равновесии. Кристалл судьбы засиял.");
            Fonts.dialogue.draw(batch, "Стихии вновь в равновесии. Кристалл судьбы засиял.", sw / 2 - layout.width / 2, sh / 2 - 10);
            Fonts.small.setColor(0.8f, 0.8f, 0.8f, 1);
            String again = mobile ? "Коснись, чтобы играть заново" : "Нажми ENTER, чтобы играть заново";
            layout.setText(Fonts.small, again);
            Fonts.small.draw(batch, again, sw / 2 - layout.width / 2, sh / 2 - 44);
        }

        // hints
        if (world.time < 12 && world.time > 2) {
            Fonts.small.setColor(1f, 1f, 0.8f, 0.7f);
            String hint = mobile
                    ? "Слева — джойстик  |  Справа — ПРЫЖОК / АТАКА / НАВЫК / РЫВОК"
                    : "WASD/стрелки — движение | Пробел — прыжок | J — атака | K — навык | L — рывок";
            Fonts.small.draw(batch, hint, 14, 20);
            layout.setText(Fonts.small, hint);
            if (layout.width > sw - 28) {
                Fonts.small.draw(batch, hint.substring(0, Math.min(hint.length(), 55)), 14, 20);
            }
        }

        batch.end();
    }

    boolean hasElement(Player p, Element e) {
        switch (e) {
            case PYRO: return p.abilities.contains(com.elementia.core.Ability.PYRO);
            case CRYO: return p.abilities.contains(com.elementia.core.Ability.CRYO);
            case HYDRO: return p.abilities.contains(com.elementia.core.Ability.HYDRO);
            default: return true;
        }
    }

    public void dispose() { if (batch != null) batch.dispose(); }
}