package com.elementia.world;

import com.badlogic.gdx.math.Rectangle;
import com.elementia.core.Element;

/** Base entity: AABB body, velocity, health, elemental status, hit flash. */
public class Entity {
    public float x, y, w, h;     // AABB (x,y = bottom-left)
    public float vx, vy;
    public boolean grounded;
    public int facing = 1;       // 1 right, -1 left
    public int hp, maxHp;
    public boolean alive = true;
    public float hitFlash;       // 1..0 white flash timer
    public float statusLife;     // seconds remaining for current status
    public Element status;       // elemental aura currently applied
    public float deadTimer;

    public final Rectangle rect = new Rectangle();

    public Entity(float x, float y, float w, float h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        rect.set(x, y, w, h);
    }

    public void setPos(float x, float y) {
        this.x = x;
        this.y = y;
        updateRect();
    }

    public void updateRect() {
        rect.set(x, y, w, h);
    }

    /** Apply a damage number, returns actual damage dealt. */
    public int applyDamage(int dmg, boolean crit, float knockX, float knockY) {
        if (!alive) return 0;
        float mult = 1f;
        if (crit) mult = 1.8f;
        int dmgOut = Math.round(dmg * mult);
        hitFlash = 0.16f;
        hp = Math.max(0, hp - dmgOut);
        if (knockX != 0 || knockY != 0) {
            vx = knockX;
            vy = knockY;
        }
        if (hp <= 0) { alive = false; deadTimer = 0.4f; onDie(); }
        return dmgOut;
    }

    public void heal(int amount) {
        hp = Math.min(maxHp, hp + amount);
    }

    public void onDie() {}

    public boolean isPlayer() { return false; }

    public void tick(float dt) {
        if (hitFlash > 0) hitFlash -= dt;
        if (statusLife > 0) statusLife -= dt;
        else status = null;
        if (deadTimer > 0) deadTimer -= dt;
    }

    /** Full elemental cleanse. */
    public void clearStatus() {
        status = null;
        statusLife = 0;
    }
}