package com.elementia.core;

import java.util.EnumSet;

/** Metroidvania progression gates the player can unlock. */
public enum Ability {
    DASH,
    DOUBLE_JUMP,
    PYRO,   // unlock: burn vines, melt frost
    CRYO,   // freeze water to walk
    HYDRO,  // quench fire doors
    BURST;  // elemental burst ultimate

    public static EnumSet<Ability> starting() {
        EnumSet<Ability> s = EnumSet.noneOf(Ability.class);
        s.add(DASH);
        return s;
    }
}