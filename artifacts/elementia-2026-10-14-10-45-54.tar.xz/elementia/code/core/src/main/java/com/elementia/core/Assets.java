package com.elementia.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;

import java.util.function.Supplier;

/**
 * Builds every texture of the game. Art generated with Pollinations AI is
 * loaded from "art/" when present (see tools/refresh_assets.py); otherwise a
 * procedurally painted fallback is used so the game never depends on the
 * files being generated.
 */
public final class Assets {
    private Assets() {}

    public static Texture whiteDot;
    public static Texture glowDot;
    public static Texture sparkDot;

    // Tiles
    public static Texture t_grass, t_dirt, t_stone, t_ice, t_snow, t_platform, t_brick;
    public static Texture t_lavaA, t_lavaB, t_water, t_crystal, t_bgGrass, t_bgChest;

    // Character frames (anime chibi "Aria")
    public static Texture charFrames;
    public static TextureRegion[] heroIdle = new TextureRegion[2];
    public static TextureRegion[] heroRun = new TextureRegion[4];
    public static TextureRegion heroJump, heroFall, heroAtk1, heroAtk2, heroAtk3, heroSlide, heroHurt;

    // Slime per element (4 frames squash)
    public static Texture slimeTex;
    public static TextureRegion[] slimeFrames = new TextureRegion[4];

    // Wisp flyer
    public static Texture wispTex;
    public static TextureRegion wispReg;

    // Crystal golem miniboss
    public static Texture golemTex;
    public static TextureRegion golemReg;

    // Boss (ember king)
    public static Texture bossTex;
    public static TextureRegion bossReg;

    // Effects
    public static Texture slashTex;
    public static TextureRegion slashReg;
    public static Texture projTex;   // projectiles strip: 0 fire,1 ice,2 water,3 electro,4 wind,5 geo
    public static TextureRegion[] proj = new TextureRegion[6];

    // 3D city tiles & facades
    public static Texture t_road, t_sidewalk, t_grass3, t_plaza, t_park, t_roof;
    public static Texture[] facDay = new Texture[6];
    public static Texture[] facNight = new Texture[6];

    // Waypoint (save statue)
    public static Texture waypointTex;
    public static TextureRegion wpReg;

    // Element icons (7)
    public static Texture iconTex;
    public static TextureRegion[] elementIcons = new TextureRegion[7];

    public static void init() {
        whiteDot = makeTex(2, 2, p -> { Art.fillRect(p, 0, 0, 2, 2, 0xffffffff); });
        glowDot = makeTex(32, 32, p -> Art.glow(p, 16, 16, 15, 0xffffffff));
        sparkDot = makeTex(16, 16, p -> gradientDot(p, 8, 8, 7, 0xffffffff));

        buildTiles();
        buildHero();
        buildSlimes();
        buildWisps();
        buildGolem();
        buildBoss();
        buildEffects();
        buildWaypoint();
        buildIcons();
        buildCityTex();
    }

    // ================= low level =================

    public interface PixPainter { void paint(Pixmap p); }

    /**
     * Load a Pollinations-generated asset from "art/&lt;name&gt;.png", or null
     * when it is not bundled. Textures are linearly filtered so the high-res
     * art scales down cleanly at render time.
     */
    static Texture aiTex(String name) {
        try {
            if (!Gdx.files.internal("art/" + name + ".png").exists()) return null;
            Texture t = new Texture(Gdx.files.internal("art/" + name + ".png"));
            t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return t;
        } catch (Throwable e) {
            Gdx.app.error("Assets", "Failed to load art/" + name, e);
            return null;
        }
    }

    /** Pick the AI texture when available, otherwise run the procedural fallback. */
    private static Texture or(Texture ai, Supplier<Texture> fallback) {
        return ai != null ? ai : fallback.get();
    }

    public static Texture makeTex(int w, int h, PixPainter painter) {
        Pixmap p = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        painter.paint(p);
        Texture t = new Texture(p);
        t.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        p.dispose();
        return t;
    }

    /** Soft radial gradient dot (core white -> transparent). */
    public static void gradientDot(Pixmap p, int cx, int cy, int r, int core) {
        for (int dy = -r; dy <= r; dy++)
            for (int dx = -r; dx <= r; dx++) {
                int d2 = dx * dx + dy * dy;
                if (d2 > r * r) continue;
                float t = (float) Math.sqrt(d2) / r;
                int col = Art.rgba(1f, 1f, 1f, 1f - t);
                setAlpha(p, cx + dx, cy + dy, col);
            }
    }

    private static void setAlpha(Pixmap p, int x, int y, int col) {
        if (x < 0 || y < 0 || x >= p.getWidth() || y >= p.getHeight()) return;
        int ex = p.getPixel(x, y);
        int blended = Art.blend(ex, col, ((col >>> 24) & 0xff) / 255f);
        p.drawPixel(x, y, blended);
    }

    // ================= tiles =================

    private static void buildTiles() {
        // AI-overridable: each tile falls back to procedural painting below.
        t_grass = or(aiTex("grass"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xff7cb342, 0xff4e6a24);
            // grass top layer
            Art.fillRect(p, 0, 0, 32, 10, 0xff66bb6a);
            Art.fillRect(p, 0, 0, 32, 2, 0xff8bc34a);
            Art.fillRect(p, 0, 10, 32, 2, 0x9e5e7c2f);
            speckle(p, 0, 12, 32, 20, 0x20, 0xff3e5320, 3);
            // grass fringe
            for (int i = 0; i < 32; i++) if ((i & 3) == 0) Art.set(p, i, 3 + (i % 3), 0xffaed581);
        }));

        // ---- dirt ----
        t_dirt = or(aiTex("dirt"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xff8d6e63, 0xff6d4c41);
            speckle(p, 0, 0, 32, 32, 0x30, 0xff5d4037, 4);
            speckle(p, 0, 0, 32, 32, 0x14, 0xffa1887f, 4);
            Art.outlineRect(p, 0, 0, 32, 32, 0x40000000);
        }));

        // ---- stone (cave) ----
        t_stone = or(aiTex("stone"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xff546e7a, 0xff37474f);
            speckle(p, 0, 0, 32, 32, 0x28, 0xff263238, 4);
            Art.outlineRect(p, 0, 0, 32, 32, 0x40000000);
        }));

        // ---- ice ----
        t_ice = or(aiTex("ice"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xffb3e5fc, 0xff7cc8ea);
            Art.glow(p, 16, 16, 18, 0x66ffffff);
            Art.outlineRect(p, 0, 0, 32, 32, 0x5effffff);
            // cracks
            Art.fillTriangle(p, 4, 4, 12, 10, 6, 16, 0x44ffffff);
        }));

        // ---- snow ----
        t_snow = or(aiTex("snow"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xffeceff1, 0xffb0bec5);
            speckle(p, 0, 0, 32, 32, 0x2a, 0xffffffff, 3);
            Art.outlineRect(p, 0, 0, 32, 32, 0x30000000);
        }));

        // ---- platform (wooden one-way) ----
        t_platform = or(aiTex("platform"), () -> makeTex(32, 14, p -> {
            Art.vGrad(p, 0, 0, 32, 14, 0xffa1887f, 0xff6d4c41);
            Art.fillRect(p, 0, 0, 32, 4, 0xffbcaaa4);
            for (int i = 0; i < 32; i += 8) Art.set(p, i, 6, 0x406d4c41);
            Art.fillRect(p, 0, 11, 32, 1, 0x60000000);
        }));

        // ---- brick (boss arena) ----
        t_brick = or(aiTex("brick"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xff795548, 0xff4e342e);
            for (int row = 0; row < 32; row += 8) {
                for (int x = 0; x < 32; x += 16) {
                    int off = (row / 8) % 2 == 0 ? 0 : 8;
                    Art.fillRect(p, x + off, row, 16, 8, Art.shade(0xff6d4c41, 0.85f));
                }
            }
            Art.outlineRect(p, 0, 0, 32, 32, 0x50000000);
        }));

        // ---- lava ----
        t_lavaA = or(aiTex("lavaA"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xffff7043, 0xffd32f2f);
            Art.fillRect(p, 0, 0, 32, 6, 0xffffb34d);
            speckle(p, 8, 6, 32, 26, 0x60, 0xffffd046, 3);
        }));
        t_lavaB = or(aiTex("lavaB"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0xffff6d33, 0xffe53935);
            Art.fillRect(p, 0, 0, 32, 9, 0xffffb74d);
            speckle(p, 0, 9, 32, 23, 0x60, 0xffff8a3c, 3);
        }));

        // ---- water ----
        t_water = or(aiTex("water"), () -> makeTex(32, 32, p -> {
            Art.vGrad(p, 0, 0, 32, 32, 0x804dd0e1, 0xaa26abcd);
            Art.fillRect(p, 0, 0, 32, 3, 0x66ffffff);
        }));

        // ---- geo crystal (blockable decor) ----
        t_crystal = or(aiTex("crystal"), () -> makeTex(24, 30, p -> {
            int col = 0xffffd54f;
            Art.fillPoly(p, new int[]{12, 4, 12, 20}, new int[]{0, 12, 28, 16}, Art.shade(col, 0.7f));
            Art.fillPoly(p, new int[]{12, 20, 12, 4}, new int[]{0, 12, 30, 14}, Art.mix(col, 0xffffffff, 0.35f));
            Art.fillPoly(p, new int[]{4, 12, 12}, new int[]{12, 4, 28}, 0xffffe082);
            Art.glow(p, 12, 12, 14, 0x55);
        }));

        // ---- background decorations ----
        t_bgGrass = or(aiTex("tree"), () -> makeTex(32, 48, p -> buildTree(p, 0xff388e3c, 0xff2e7d32)));
        t_bgChest = or(aiTex("chest"), () -> makeTex(28, 24, p -> {
            Art.fillRect(p, 2, 2, 24, 20, 0xff8d6e63);
            Art.fillRect(p, 2, 2, 24, 8, 0xffa1887f);
            Art.fillRect(p, 9, 10, 10, 12, 0xffffd54f);
            Art.fillRect(p, 12, 6, 4, 16, 0xffb8860b);
            Art.outlineRect(p, 2, 2, 24, 20, 0x30000000);
        }));
    }

    private static void buildTree(Pixmap p, int leaf, int leafDark) {
        // trunk
        Art.fillTriangle(p, 13, 30, 19, 30, 17, 48, 0xff6d4c41);
        Art.fillTriangle(p, 14, 30, 18, 30, 16, 20, 0xff5d4037);
        // canopy circles
        Art.fillCircle(p, 16, 12, 13, leafDark);
        Art.fillCircle(p, 6, 20, 10, leafDark);
        Art.fillCircle(p, 26, 20, 10, leafDark);
        Art.fillCircle(p, 16, 18, 12, leaf);
        Art.fillCircle(p, 8, 24, 8, leaf);
        Art.fillCircle(p, 24, 24, 8, leaf);
        Art.fillCircle(p, 16, 8, 9, Art.mix(leaf, 0xffffffff, 0.25f));
    }

    private static void speckle(Pixmap p, int x, int y, int w, int h, int alpha, int col, int step) {
        for (int j = y; j < y + h; j += 2)
            for (int i = x; i < x + w; i += 2) {
                if (Art.noise(i, j, 7) > 0.55f) {
                    int c = col;
                    Art.set(p, i, j, c & 0xffffff | (alpha << 24));
                }
            }
    }

    // ================= hero =================

    private static final int HF = 0xffc9a985; // hero skin
    private static final int HSK = 0xffeeeee6; // hero outfit light
    private static final int HACC = 0xff4ea3e0; // accent blue
    private static final int HOUT = 0xff2b2b35; // outline
    private static final int HSNOW = 0xffffffff; // snow-white hair base

    private static void buildHero() {
        Texture heroAI = aiTex("hero");
        if (heroAI != null) {
            // single AI portrait fills every animation slot so the game logic,
            // flipping and drawing sizes keep working unchanged.
            charFrames = heroAI;
            TextureRegion r = new TextureRegion(heroAI);
            for (int i = 0; i < 2; i++) heroIdle[i] = r;
            for (int i = 0; i < 4; i++) heroRun[i] = r;
            heroJump = heroFall = heroAtk1 = heroAtk2 = heroAtk3 = heroSlide = heroHurt = r;
            return;
        }
        // 6 wide frames of 56x76 each: idle(2) run(4) jump fall atk1 atk2 atk3 slide hurt
        // Layout: idle[0,1], run[2..5], then single columns 6..12 => jump fall atk1 atk2 atk3 slide hurt
        int cols = 13, w = 56, h = 76;
        Pixmap p = new Pixmap(w * cols, h, Pixmap.Format.RGBA8888);
        drawChar(p, 0, 1, 0, 0, 0);      // idle 0
        drawChar(p, 1, 0, 0, 0, 0);      // idle 1 bobbing
        for (int i = 0; i < 4; i++) drawChar(p, 2 + i, 1, i == 1 ? 1 : (i == 3 ? -1 : 0), 0, 0); // run
        drawChar(p, 6, 1, 0, 2, 0);      // jump
        drawChar(p, 7, 1, 0, 3, 0);      // fall
        drawChar(p, 8, 1, 0, 0, 1);      // atk1
        drawChar(p, 9, 1, 0, 0, 2);      // atk2
        drawChar(p, 10, 1, 0, 0, 3);     // atk3
        drawChar(p, 11, 1, 0, 0, 0);     // slide (squashed) - special
        drawChar(p, 12, 1, 0, 4, 0);     // hurt
        charFrames = new Texture(p);
        charFrames.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        // slide squashed variant drawn atop col 11? handled in drawChar via mode; keep simple: draw jump frame squashed
        p.dispose();

        for (int i = 0; i < 2; i++) heroIdle[i] = new TextureRegion(charFrames, w * i, 0, w, h);
        for (int i = 0; i < 4; i++) heroRun[i] = new TextureRegion(charFrames, w * (2 + i), 0, w, h);
        heroJump = new TextureRegion(charFrames, w * 6, 0, w, h);
        heroFall = new TextureRegion(charFrames, w * 7, 0, w, h);
        heroAtk1 = new TextureRegion(charFrames, w * 8, 0, w, h);
        heroAtk2 = new TextureRegion(charFrames, w * 9, 0, w, h);
        heroAtk3 = new TextureRegion(charFrames, w * 10, 0, w, h);
        heroSlide = new TextureRegion(charFrames, w * 11, 0, w, h);
        heroHurt = new TextureRegion(charFrames, w * 12, 0, w, h);
    }

    /**
     * Draw anime chibi heroine "Aria" into column frame.
     * legSwing: -1..1 run cycle; pose: 0 idle,1 run,2 jump,3 fall,4 hurt; atkCombo: 0 none,1/2/3.
     */
    private static void drawChar(Pixmap p, int frame, int legSwing, int pose, int atkCombo, int dummy) {
        int ox = frame * 56, oy = 0;
        int cy = 8;                  // feet baseline
        float bob = (pose == 1) ? (legSwing != 0 ? 2 : 0) : (pose == 2 ? 4 : 0);
        if (pose == 4) bob = 0;
        float rotLean = (pose == 1 && legSwing != 0) ? 3 : 0;

        // --- body geometry ---
        float hipX = 28, hipY = cy + 30;
        float headCx = 28 + (rotLean * 0.2f), headCy = cy + 56 - bob;

        // 1) back hair (dark under, long flowing strands)
        drawBackHair(p, ox, (int) headCx, (int) headCy, (int) hipY);

        // 2) legs
        if (pose == 2) drawLeg(p, ox, hipX - 5, hipY, hipX - 9, cy + 10);       // tucked jump
        else if (pose == 3) drawLeg(p, ox, hipX - 4, hipY, hipX - 7, cy + 6);   // fall spread
        else if (pose == 1) {
            drawLeg(p, ox, hipX - 4, hipY, hipX - 8 - legSwing * 5, cy + 2 + Math.abs(legSwing) * 2);
            drawLeg(p, ox, hipX + 4, hipY, hipX + 8 + legSwing * 5, cy + 2 + Math.abs(legSwing) * 2);
        } else {
            drawLeg(p, ox, hipX - 4, hipY, hipX - 6, cy + 2);
            drawLeg(p, ox, hipX + 4, hipY, hipX + 6, cy + 2);
        }

        // 3) dress/body (A-line kimono)
        int shY = cy + 46;
        drawTorso(p, ox, (int) headCx, shY, (int) hipY, (int) hipX);

        // 4) arms
        float shoulderX = headCx - 9, shoulderY = shY + 2;
        if (atkCombo == 1) {                                     // sword slash low-forward
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 14, shoulderY - 4, 6);
            drawSword(p, ox, (int) shoulderX - 14, (int) shoulderY - 4, -20, 6);
        } else if (atkCombo == 2) {
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 2, shoulderY + 10, 6);
            drawSword(p, ox, (int) shoulderX - 2, (int) shoulderY + 10, 4, 18);
        } else if (atkCombo == 3) {
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 12, shoulderY - 12, 6);
            drawSword(p, ox, (int) shoulderX - 12, (int) shoulderY - 12, 34, -2);
        } else if (pose == 1) {
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 6 - legSwing * 3, shoulderY - 6 + Math.abs(legSwing) * 4, 5);
            drawArm(p, ox, headCx + 9, shoulderY, headCx + 12, shoulderY - 7, 5);
        } else if (pose == 3) {
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 8, shoulderY + 4, 5);
        } else {
            drawArm(p, ox, shoulderX, shoulderY, shoulderX - 7, shoulderY - 8, 5);
            drawArm(p, ox, headCx + 9, shoulderY, headCx + 12, shoulderY - 8, 5);
        }

        // 5) head
        drawHead(p, ox, (int) headCx, (int) headCy);

        // 6) front hair
        drawFrontHair(p, ox, (int) headCx, (int) headCy);

        // 7) face
        drawFace(p, ox, (int) headCx, (int) headCy, pose);

        // 8) ribbon
        int rx = (int) headCx + 4;
        Art.fillTriangle(p, ox + rx - 4, (int) headCy - 6, ox + rx + 6, (int) headCy + 4, ox + rx - 10, (int) headCy + 6, HACC);
        Art.fillTriangle(p, ox + rx - 4, (int) headCy - 6, ox + rx + 6, (int) headCy + 4, ox + rx + 12, (int) headCy + 10, Art.shade(HACC, 0.8f));
    }

    private static void drawLeg(Pixmap p, int ox, float x0, float y0, float x1, float y1) {
        thickLine(p, ox + (int) x0, (int) y0, ox + (int) x1, (int) y1, 6, HOUT);
        thickLine(p, ox + (int) x0, (int) y0, ox + (int) x1, (int) y1, 4, 0xfff4ece2);
        // foot
        Art.fillEllipse(p, ox + (int) x1, (int) y1 + 1, 4, 2, HOUT);
        Art.fillEllipse(p, ox + (int) x1 - 1, (int) y1 + 1, 3, 1, 0xff4a3b6e);
    }

    private static void drawTorso(Pixmap p, int ox, int cx, int shY, int hipY, int hipX) {
        int wTop = 15, wBot = 12;
        // floofy bottom
        Art.fillCircle(p, ox + hipX, hipY + 4, wBot + 2, HOUT);
        Art.fillCircle(p, ox + hipX, hipY + 5, wBot, 0xff7e6ba6);
        Art.fillCircle(p, ox + hipX, hipY + 4, wBot - 3, Art.mix(0xff7e6ba6, 0xffffffff, 0.2f));
        // dress body
        drawPoly(p, ox + cx - wTop, shY, ox + cx + wTop, shY, ox + hipX + wBot, hipY + 2, ox + hipX - wBot, hipY + 2, HOUT);
        drawPoly(p, ox + cx - wTop + 2, shY + 2, ox + cx + wTop - 2, shY + 2, ox + hipX + wBot - 2, hipY + 1, ox + hipX - wBot + 2, hipY + 1, HSK);
        // gold belt
        Art.fillRect(p, ox + cx - wTop + 1, shY + 4, (wTop - 1) * 2 - 1, 4, 0xfff0c27a);
        // center stripe
        Art.fillRect(p, ox + cx - 2, shY + 8, 4, 14, HACC);
        // collar
        Art.fillEllipse(p, ox + cx, shY, wTop - 4, 4, 0xffc9a985);
        // shoulder fluff
        Art.fillCircle(p, ox + cx - wTop, shY + 2, 4, HSK);
        Art.fillCircle(p, ox + cx + wTop, shY + 2, 4, HSK);
    }

    private static void drawArm(Pixmap p, int ox, float x0, float y0, float x1, float y1, int w) {
        thickLine(p, ox + (int) x0, (int) y0, ox + (int) x1, (int) y1, w + 2, HOUT);
        thickLine(p, ox + (int) x0, (int) y0, ox + (int) x1, (int) y1, w - 2, 0xfff4ece2);
        // hand
        Art.fillCircle(p, ox + (int) x1, (int) y1, w / 2 + 1, HOUT);
        Art.fillCircle(p, ox + (int) x1, (int) y1, w / 2, HF);
    }

    private static void drawSword(Pixmap p, int ox, int hx, int hy, float dx, float dy) {
        int len = (int) Math.sqrt(dx * dx + dy * dy);
        float ux = dx / len, uy = dy / len;
        int px = (int) (uy), py = (int) (-ux);
        // blade from hx,hy = tip
        int tx = hx + (int) (dx * 0.9f), ty = hy + (int) (dy * 0.9f);
        int bx = hx + (int) (dx * 1.8f), by = hy + (int) (dy * 1.8f);
        drawPoly(p, ox + tx + px * 2, ty + py * 2, ox + bx + px * 2, by + py * 2,
                     ox + bx - px * 2, by - py * 2, ox + tx - px * 2, ty - py * 2, HOUT);
        drawPoly(p, ox + tx + px, ty + py, ox + bx + px, by + py - py * 2 + py,
                     ox + bx - px, by - py - py * 2 + py, ox + tx - px, ty - py, 0xffdce6f5);
        // crossguard
        Art.fillRect(p, ox + bx + (int) (px * 4), by - 3, 2, 6, 0xfff0c27a);
        // grip
        Art.fillRect(p, ox + bx + 1, by - 2, 7, 4, 0xff8d5524);
    }

    private static void drawHead(Pixmap p, int ox, int cx, int cy) {
        Art.fillCircle(p, ox + cx, cy, 12, HOUT);
        Art.fillCircle(p, ox + cx, cy, 11, HF);
        // hair cap behind
        Art.fillCircle(p, ox + cx, cy + 2, 12, HOUT);
        Art.fillCircle(p, ox + cx, cy + 2, 11, Art.mix(0xffe8ecf8, 0xffcfe0f5, 0.5f));
        // ears/head base
        Art.fillCircle(p, ox + cx, cy + 4, 10, HF);
        // neck
        Art.fillRect(p, ox + cx - 3, cy - 9, 6, 6, HF);
    }

    private static void drawBackHair(Pixmap p, int ox, int cx, int cy, int hipY) {
        // long strands flowing down behind
        int colDeep = 0xffb8c6e8; // silver-blue back hair
        Art.fillCircle(p, ox + cx, cy + 4, 13, colDeep);
        // tail strands (triangles)
        for (int i = -1; i <= 1; i += 2) {
            Art.fillTriangle(p, ox + cx + i * 8, cy - 2, ox + cx + i * 15, hipY + 2, ox + cx + i * 3, hipY + 2, colDeep);
            Art.fillTriangle(p, ox + cx + i * 8, cy - 2, ox + cx + i * 12, hipY - 4, ox + cx + i * 5, hipY - 6, 0xffdce6f5);
        }
        Art.fillTriangle(p, ox + cx - 6, cy - 6, ox + cx, hipY - 4, ox + cx + 6, cy - 6, Art.shade(colDeep, 0.7f));
        Art.fillTriangle(p, ox + cx - 5, cy - 6, ox + cx, hipY - 1, ox + cx - 2, cy - 3, 0xffb8c6e8);
    }

    private static void drawFrontHair(Pixmap p, int ox, int cx, int cy) {
        int hair = 0xfff0f4ff; // light silver-white
        // fringe: overlap top of head
        Art.fillCircle(p, ox + cx, cy - 2, 12, HOUT);
        Art.fillCircle(p, ox + cx, cy - 2, 11, hair);
        // bangs spikes around forehead
        int[] xs = { cx - 12, cx - 7, cx - 3, cx + 0, cx + 4, cx + 8, cx + 13 };
        int[] ys = { cy + 2, cy - 4, cy - 7, cy + 6, cy - 8, cy + 1, cy + 7 };
        for (int i = 0; i < xs.length; i++) {
            int px = ox + xs[i], py = cy + (ys[i] - cy) + 4;
            int cur = Math.min(xs.length - 1, i);
            int next = Math.min(xs.length - 1, i + 1);
            int base = cur == i ? 10 : 10;
            int pyy = (cur + next) / 2;
            Art.fillPoly(p, new int[]{px, ox + cx, px + 4}, new int[]{py, cy + 8, py + 1}, Art.shade(hair, 0.94f));
        }
        // two pronounced side strands framing face
        Art.fillEllipse(p, ox + cx - 12, cy + 1, 5, 9, hair);
        Art.fillEllipse(p, ox + cx + 12, cy + 1, 5, 9, hair);
        Art.fillEllipse(p, ox + cx - 11, cy + 2, 4, 8, Art.shade(hair, 0.82f));
        Art.fillEllipse(p, ox + cx + 11, cy + 2, 4, 8, Art.shade(hair, 0.82f));
        // long twin strand in front of shoulders
        Art.fillTriangle(p, ox + cx - 13, cy + 6, ox + cx - 18, cy + 20, ox + cx - 9, cy + 18, hair);
        Art.fillTriangle(p, ox + cx + 13, cy + 6, ox + cx + 18, cy + 20, ox + cx + 9, cy + 18, hair);
    }

    private static void drawFace(Pixmap p, int ox, int cx, int cy, int pose) {
        int eyeY = cy + 2;
        // eye white
        for (int e = 0; e < 2; e++) {
            int ex = cx + (e == 0 ? -5 : 5);
            Art.fillEllipse(p, ox + ex, eyeY, 4, 5, HOUT);
            Art.fillEllipse(p, ox + ex, eyeY, 3, 4, 0xffffffff);
            Art.fillEllipse(p, ox + ex, eyeY, 3, 4, 0xff8be0ff); // aqua iris
            // iris gradient bottom dark
            Art.fillEllipse(p, ox + ex, eyeY + 1, 3, 2, 0xff2c9fce);
            Art.fillEllipse(p, ox + ex, eyeY - 2, 2, 2, 0xffc7f2ff); // highlight
            Art.fillRect(p, ox + ex - 1, eyeY - 1, 2, 1, 0xffffffff); // shine
            // upper lash line
            Art.fillRect(p, ox + ex - 4, eyeY - 3, 8, 2, HOUT);
            // lashes corners
            Art.set(p, ox + ex - 4, eyeY - 4, HOUT);
            Art.set(p, ox + ex + 4, eyeY - 4, HOUT);
        }
        // brows
        Art.fillRect(p, ox + cx - 8, cy - 2, 7, 2, Art.shade(hair(0xfff0f4ff), 0.6f));
        Art.fillRect(p, ox + cx + 1, cy - 2, 7, 2, Art.shade(0xfff0f4ff, 0.6f));

        // mouth
        if (pose == 4) { // hurt: wavy mouth
            Art.fillEllipse(p, ox + cx, eyeY + 4, 2, 2, 0xffb04552);
        } else {
            Art.fillRect(p, ox + cx - 1, eyeY + 7, 2, 2, 0xffb04552);
            Art.fillRect(p, ox + cx - 2, eyeY + 8, 4, 1, 0xffd07a8a);
        }
        // blush
        Art.glow(p, ox + cx - 9, eyeY + 4, 4, 0x4433a2d9);
        Art.glow(p, ox + cx + 9, eyeY + 4, 4, 0x4433a2d9);
        // nose dot
        Art.set(p, ox + cx, eyeY - 1, 0x55c79a89);
    }

    private static int hair(int c) { return c; }

    private static void drawPoly(Pixmap p, int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3, int col) {
        Art.fillPoly(p, new int[]{x0, x1, x2, x3}, new int[]{y0, y1, y2, y3}, col);
    }

    private static void thickLine(Pixmap p, int x0, int y0, int x1, int y1, int w, int col) {
        int dx = x1 - x0, dy = y1 - y0;
        int steps = Math.max(Math.abs(dx), Math.abs(dy)) * 2;
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            int x = x0 + (int) (dx * t), y = y0 + (int) (dy * t);
            Art.fillCircle(p, x, y, w / 2, col);
        }
    }

    // ================= slimes =================

    private static void buildSlimes() {
        Texture slimeAI = aiTex("slime");
        if (slimeAI != null) {
            slimeTex = slimeAI;
            TextureRegion r = new TextureRegion(slimeAI);
            for (int i = 0; i < 4; i++) slimeFrames[i] = r;
            return;
        }
        int cols = 4, w = 44, h = 38;
        Pixmap p = new Pixmap(w * cols, h, Pixmap.Format.RGBA8888);
        for (int i = 0; i < 4; i++) {
            float sq = 1f - 0.08f * (i % 2 == 0 ? i : -i); // squash B A B A
            drawSlime(p, i, sq);
        }
        slimeTex = new Texture(p);
        slimeTex.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        p.dispose();
        for (int i = 0; i < 4; i++) slimeFrames[i] = new TextureRegion(slimeTex, w * i, 0, w, h);
    }

    /** Slime with element tint; colored in-place via renderer (tint = white), so base is neutral. */
    private static void drawSlime(Pixmap p, int frame, float squash) {
        int ox = frame * 44;
        int w = 44, h = 38;
        int cx = w / 2, base = h - 4;
        int radX = 18, radY = (int) (16 / (squash > 1 ? 1 : squash));
        // drop shadow
        Art.fillEllipse(p, ox + cx, base + 1, 20, 4, 0x40000000);
        // body back fill (solid white so tint colors it)
        Art.fillEllipse(p, ox + cx, base - radY, radX, radY, 0xffffffff);
        // bottom darker band (fixed dark in shader-less tint: use pure white anyway in base; tint outlets)
        Art.fillEllipse(p, ox + cx, base - radY, radX, radY, 0xfff2f2f2);
        // glossy highlight
        Art.fillEllipse(p, ox + cx - 6, base - radY - 5, 7, 4, 0xffffffff);
        // outline
        Art.outlineEllipse(p, ox + cx, base - radY, radX, radY, 0x90000000);
        // face
        Art.fillEllipse(p, ox + cx - 7, base - radY - 1, 3, 4, 0x66000000);
        Art.fillEllipse(p, ox + cx + 7, base - radY - 1, 3, 4, 0x66000000);
        Art.fillRect(p, ox + cx - 5, base - radY + 6, 3, 2, 0x40000000);
        Art.fillEllipse(p, ox + cx - 6, base - radY, 2, 3, 0xffffffff); // eye shine
    }

    // ================= wisps =================

    private static void buildWisps() {
        Texture wAI = aiTex("wisp");
        if (wAI != null) {
            wispTex = wAI;
            wispReg = new TextureRegion(wAI);
            return;
        }
        int w = 48, h = 40;
        Pixmap p = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        Art.glow(p, 24, 22, 18, 0xffffffff);       // aura
        Art.glow(p, 18, 14, 6, 0xffffffff);
        Art.glow(p, 30, 14, 6, 0xffffffff);
        // little flame wings
        Art.fillEllipse(p, 12, 28, 8, 3, 0x80ffffff);
        Art.fillEllipse(p, 36, 28, 8, 3, 0x80ffffff);
        Art.fillSector(p, 8, 18, 8, -30, 90, 0xaa);
        wispTex = makeTexP(p);
        wispReg = new TextureRegion(wispTex);
        p.dispose();
    }

    private static Texture makeTexP(Pixmap p) {
        Texture t = new Texture(p);
        t.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        return t;
    }

    // ================= golem (geo miniboss) =================

    private static void buildGolem() {
        Texture gAI = aiTex("golem");
        if (gAI != null) {
            golemTex = gAI;
            golemReg = new TextureRegion(gAI);
            return;
        }
        int w = 56, h = 52;
        Pixmap p = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        drawGolem(p);
        golemTex = makeTexP(p);
        golemReg = new TextureRegion(golemTex);
        p.dispose();
    }

    private static void drawGolem(Pixmap p) {
        int cx = 28, base = 4;
        int col = 0xffffcc66, colD = 0xffc88a28;
        // legs
        Art.fillRect(p, cx - 16, base, 12, 14, colD);
        Art.fillRect(p, cx + 4, base, 12, 14, colD);
        // body
        drawPoly(p, cx - 20, base + 14, cx + 20, base + 14, cx + 16, base + 38, cx - 16, base + 38, 0xffcc9c3c);
        drawPoly(p, cx - 17, base + 16, cx + 17, base + 16, cx + 14, base + 36, cx - 14, base + 36, col);
        // head
        Art.fillRect(p, cx - 14, base + 38, 28, 12, 0xff2b2b35);
        Art.fillRect(p, cx - 12, base + 40, 24, 10, col);
        Art.fillRect(p, cx - 9, base + 42, 7, 5, 0xff5b3a12);
        Art.fillRect(p, cx + 2, base + 42, 7, 5, 0xff5b3a12);
        // arms
        Art.fillRect(p, cx - 24, base + 22, 8, 14, colD);
        Art.fillRect(p, cx + 16, base + 22, 8, 14, colD);
        // core gem
        Art.glow(p, cx, base + 28, 10, 0xaa);
        Art.fillEllipse(p, cx, base + 28, 5, 6, 0xffffffff);
        Art.fillEllipse(p, cx, base + 28, 4, 5, 0xc8ffee58);
        // sparkles
        for (int i = 0; i < 6; i++) {
            int sx = 4 + (i * 9) % 48, sy = 6 + (i * 7) % 40;
            Art.set(p, sx, sy, 0xffffe066);
        }
    }

    // ================= boss (ember king) =================

    private static void buildBoss() {
        Texture bAI = aiTex("boss");
        if (bAI != null) {
            bossTex = bAI;
            bossReg = new TextureRegion(bAI);
            return;
        }
        int w = 88, h = 76;
        Pixmap p = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        drawBoss(p);
        bossTex = makeTexP(p);
        bossReg = new TextureRegion(bossTex);
        p.dispose();
    }

    private static void drawBoss(Pixmap p) {
        int cx = 44, base = 6;
        int fur = 0xffa33b20, furD = 0xff6b1f12, man = 0xffff5a26;
        // mane (flame droplets around neck)
        for (int a = 0; a < 360; a += 15) {
            float rad = (float) Math.toRadians(a);
            int mx = cx + (int) (Math.cos(rad) * 26), my = base + 40 + (int) (Math.sin(rad) * 20);
            if (my < base + 40) Art.fillTriangle(p, cx, base + 40, mx, my + 6, mx + (int) (Math.cos(rad) * 10), my, man);
            if (my < base + 42) Art.fillTriangle(p, cx, base + 40 - 2, mx, my - 4, mx - 4, my, 0xffff7a42);
        }
        // body
        drawPoly(p, cx - 30, base + 24, cx + 30, base + 24, cx + 20, base + 48, cx - 20, base + 48, HOUT);
        drawPoly(p, cx - 28, base + 26, cx + 28, base + 26, cx + 18, base + 46, cx - 18, base + 46, fur);
        // chest flame
        Art.glow(p, cx, base + 36, 12, 0x88);
        Art.fillSector(p, cx, base + 36, 9, -40, 40, 0xcc);
        Art.fillTriangle(p, cx, base + 33, cx - 5, base + 40, cx + 5, base + 40, 0xffffd054);
        // legs
        Art.fillRect(p, cx - 20, base, 12, 26, furD);
        Art.fillRect(p, cx + 8, base, 12, 26, furD);
        Art.fillRect(p, cx - 22, base - 2, 16, 5, 0xffff8a3c);
        Art.fillRect(p, cx + 6, base - 2, 16, 5, 0xffff8a3c);
        // head
        Art.fillCircle(p, cx, base + 58, 15, HOUT);
        Art.fillCircle(p, cx, base + 58, 13, fur);
        // ears/horns
        Art.fillTriangle(p, cx - 14, base + 64, cx - 24, base + 78, cx - 8, base + 70, 0xffffd054);
        Art.fillTriangle(p, cx + 14, base + 64, cx + 24, base + 78, cx + 8, base + 70, 0xffffd054);
        // eyes
        Art.fillEllipse(p, cx - 7, base + 60, 4, 2, 0xffffd054);
        Art.fillEllipse(p, cx + 7, base + 60, 4, 2, 0xffffd054);
        Art.fillRect(p, cx - 6, base + 59, 3, 1, 0xffffffff);
        Art.fillRect(p, cx + 6, base + 59, 3, 1, 0xffffffff);
        Art.fillRect(p, cx - 3, base + 54, 3, 4, 0x661a1a1a);
        Art.fillRect(p, cx + 0, base + 54, 3, 4, 0x661a1a1a);
        // snout
        Art.fillEllipse(p, cx, base + 48, 5, 3, 0x804a1a0e);
        // tail flame
        Art.fillTriangle(p, cx - 30, base + 30, cx - 46, base + 16, cx - 30, base + 20, man);
        Art.fillTriangle(p, cx - 46, base + 16, cx - 56, base + 26, cx - 40, base + 20, 0xffff7a42);
    }

    // ================= effects =================

    private static void buildEffects() {
        // slash arc (elemental crescent) - 96x96
        slashTex = makeTex(96, 96, p -> {
            for (int r = 30; r > 6; r--) {
                float t = (r - 6) / 24f;
                int col = Art.mix(0xffffffff, 0xc8a0c8ff, t);
                Art.fillSector(p, 48, 48, r, -55, 55, col);
            }
            Art.fillSector(p, 48, 48, 22, -50, 50, 0xccffffff);
        });
        slashReg = new TextureRegion(slashTex);

        // projectiles strip: 0 fire 1 ice 2 water 3 electro 4 wind 5 geo
        Pixmap p = new Pixmap(96, 40, Pixmap.Format.RGBA8888);
        drawFireball(p, 0);
        drawIceShard(p, 1);
        drawWaterLance(p, 2);
        drawElectro(p, 3);
        drawWind(p, 4);
        drawGeo(p, 5);
        projTex = makeTexP(p);
        p.dispose();
        for (int i = 0; i < 6; i++) proj[i] = new TextureRegion(projTex, i * 16, 0, 16, 40);
    }

    private static void drawFireball(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        Art.glow(p, ox, cy, 15, 0x88);
        Art.fillCircle(p, ox - 1, cy, 7, 0xffff9822);
        Art.fillCircle(p, ox, cy, 5, 0xffffcf4d);
        Art.fillCircle(p, ox, cy + 1, 2, 0xffffffff);
        Art.fillTriangle(p, ox - 4, cy + 2, ox + 4, cy + 2, ox, cy + 9, 0xffff7043);
    }

    private static void drawIceShard(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        int col = 0xff9fe8ff, colD = 0xff4db6e8;
        drawPoly(p, ox - 3, cy - 8, ox + 3, cy - 8, ox + 6, cy, ox - 6, cy, 0xff2b6ea0);
        drawPoly(p, ox - 2, cy - 8, ox + 2, cy - 8, ox + 4, cy, ox - 4, cy, col);
        drawPoly(p, ox - 6, cy, ox + 6, cy, ox + 3, cy + 8, ox - 3, cy + 8, 0xff2b6ea0);
        drawPoly(p, ox - 4, cy, ox + 4, cy, ox + 2, cy + 7, ox - 2, cy + 7, colD);
        Art.fillRect(p, ox - 1, cy - 7, 2, 14, 0xccffffff);
        Art.set(p, ox - 1, cy - 8, 0xffffffff);
    }

    private static void drawWaterLance(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        int col = 0xff5ce0ee, colD = 0xff1f9fbb;
        Art.glow(p, ox, cy, 10, 0x66);
        drawPoly(p, ox - 3, cy - 10, ox + 3, cy - 10, ox, cy - 14, ox, cy - 14, colD);
        drawPoly(p, ox - 5, cy - 10, ox + 5, cy - 10, ox + 4, cy, ox - 4, cy, colD);
        drawPoly(p, ox - 4, cy - 9, ox + 4, cy - 9, ox + 3, cy - 1, ox - 3, cy - 1, col);
        drawPoly(p, ox - 4, cy, ox + 4, cy, ox + 2, cy + 8, ox - 2, cy + 8, colD);
        drawPoly(p, ox - 3, cy + 1, ox + 3, cy + 1, ox + 2, cy + 7, ox - 2, cy + 7, col);
        Art.fillRect(p, ox - 1, cy - 8, 2, 12, 0xccffffff);
    }

    private static void drawElectro(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        Art.glow(p, ox, cy, 12, 0x99);
        Art.fillCircle(p, ox, cy, 5, 0xffffeb7a);
        for (int a = 0; a < 360; a += 45) {
            float rad = (float) Math.toRadians(a);
            int x1 = ox + (int) (Math.cos(rad) * 6), y1 = cy + (int) (Math.sin(rad) * 6);
            int x2 = ox + (int) (Math.cos(rad + 0.35f) * 10), y2 = cy + (int) (Math.sin(rad + 0.35f) * 10);
            thickLine(p, x1, y1, x2, y2, 2, 0xffffffcc);
        }
    }

    private static void drawWind(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        Art.glow(p, ox, cy, 11, 0x77);
        for (int i = 0; i < 3; i++) {
            int yy = cy - 4 + i * 4;
            Art.fillEllipse(p, ox, yy, 8 - i, 2, 0xccd6faff);
            Art.fillEllipse(p, ox + 2, yy, 5 - i, 1, 0xfff6fbff);
        }
    }

    private static void drawGeo(Pixmap p, int f) {
        int ox = f * 16 + 8, cy = 20;
        Art.glow(p, ox, cy, 10, 0x77);
        Art.fillRect(p, ox - 4, cy - 4, 8, 8, 0xffd9a322);
        Art.fillRect(p, ox - 2, cy - 2, 4, 4, 0xffffe082);
        Art.set(p, ox - 1, cy - 1, 0xffffffff);
    }

    // ================= waypoint statue =================

    private static void buildWaypoint() {
        Texture wpAI = aiTex("waypoint");
        if (wpAI != null) {
            waypointTex = wpAI;
            wpReg = new TextureRegion(wpAI);
            return;
        }
        int w = 40, h = 56;
        Pixmap p = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        int base = h;
        // shadow
        Art.fillEllipse(p, 20, base - 2, 18, 4, 0x50000000);
        // pedestal
        Art.fillRect(p, 10, base - 28, 20, 6, 0xff5d4037);
        Art.fillRect(p, 7, base - 34, 26, 6, 0xff795548);
        Art.fillRect(p, 11, base - 34, 8, 6, 0xff8d6e63);
        // pillar
        Art.fillRect(p, 17, base - 46, 6, 12, 0xff6d4c41);
        Art.fillRect(p, 18, base - 48, 4, 2, 0xffa1887f);
        // floating orb
        Art.glow(p, 20, base - 14, 14, 0x88);
        Art.fillCircle(p, 20, base - 14, 7, 0xfffff7d0);
        Art.fillCircle(p, 20, base - 14, 5, 0xffffe58a);
        Art.fillCircle(p, 20, base - 14, 2, 0xffffffff);
        // ring halo
        Art.outlineEllipse(p, 20, base - 15, 11, 4, 0x66ffffff);
        waypointTex = makeTexP(p);
        wpReg = new TextureRegion(waypointTex);
        p.dispose();
    }

    // ================= element icons =================

    private static void buildIcons() {
        int w = 24, h = 24;
        Pixmap p = new Pixmap(w * Element.values().length, h, Pixmap.Format.RGBA8888);
        Element[] es = Element.values();
        for (int i = 0; i < es.length; i++) {
            int ox = i * w;
            Art.fillCircle(p, ox + 12, 12, 12, 0x80000000);
            Art.fillCircle(p, ox + 12, 12, 11, 0xee + (es[i].bright & 0xff));
            Art.glow(p, ox + 12, 12, 11, es[i].bright);
            Art.outlineCircle(p, ox + 12, 12, 11, 0xcc000000);
            // little symbol: cross/star
            int c = (es[i].bright & 0x00ffffff);
            Art.fillCircle(p, ox + 12, 12, 5, 0xffffffff & 0x00ffffff | 0xcc000000);
            Art.fillCircle(p, ox + 12, 12, 4, es[i].bright);
            Art.fillEllipse(p, ox + 12, 12, 2, 3, 0xffffffff);
        }
        iconTex = makeTexP(p);
        p.dispose();
        for (int i = 0; i < es.length; i++) elementIcons[i] = new TextureRegion(iconTex, i * w, 0, w, h);
    }

    // ================= 3D city surfaces & facades =================

    private static void buildCityTex() {
        t_road = makeTex(64, 64, p -> {
            Art.fillRect(p, 0, 0, 64, 64, 0xff3b3f46);
            for (int i = 0; i < 64; i += 2) speckle(p, i % 3, 0, 3, 64, 0x14, 0xff2b2e33, 3);
            // dashed center line
            for (int y = 0; y < 64; y += 4) {
                if ((y / 4) % 2 == 0) Art.fillRect(p, 30, y, 4, 2, 0xffd8d475);
            }
            Art.fillRect(p, 0, 0, 64, 2, 0xff55525c);
            Art.fillRect(p, 0, 62, 64, 2, 0xff55525c);
        });
        t_sidewalk = makeTex(64, 64, p -> {
            Art.fillRect(p, 0, 0, 64, 64, 0xffb9b2a6);
            speckle(p, 0, 0, 64, 64, 0x18, 0xffa09a8e, 4);
            Art.fillRect(p, 0, 0, 64, 2, 0xffcfc9bd);
            Art.fillRect(p, 0, 20, 64, 1, 0xff99917f);
            Art.fillRect(p, 0, 40, 64, 1, 0xff99917f);
        });
        t_grass3 = makeTex(64, 64, p -> {
            Art.fillRect(p, 0, 0, 64, 64, 0xff5b8c3a);
            speckle(p, 0, 0, 64, 64, 0x2a, 0xff6f9f47, 3);
            speckle(p, 0, 0, 64, 64, 0x18, 0xff41742b, 3);
        });
        t_park = makeTex(64, 64, p -> {
            Art.fillRect(p, 0, 0, 64, 64, 0xff69a63f);
            speckle(p, 0, 0, 64, 64, 0x30, 0xff7fbf52, 2);
            speckle(p, 0, 0, 64, 64, 0x22, 0xffd45d8c, 5);
            speckle(p, 0, 0, 64, 64, 0x22, 0xffffd740, 6);
        });
        t_plaza = makeTex(64, 64, p -> {
            Art.fillRect(p, 0, 0, 64, 64, 0xffcfc4ae);
            for (int i = 0; i < 64; i += 16) {
                Art.fillRect(p, i, 0, 1, 64, 0xffb3a78e);
                Art.fillRect(p, 0, i, 64, 1, 0xffb3a78e);
            }
            Art.fillRect(p, 0, 0, 64, 2, 0xffe2d9c4);
        });
        t_roof = makeTex(32, 32, p -> {
            Art.fillRect(p, 0, 0, 32, 32, 0xff6e6e74);
            speckle(p, 0, 0, 32, 32, 0x2c, 0xff56565c, 3);
            Art.fillRect(p, 0, 0, 32, 2, 0xff83838a);
        });

        // facade styles: base wall, frame, day glass, night glass, big windows?
        facade(0xff8a9bb0, 0xff5c6b80, 0xffdbe8f5, 0xffffe08a, false); // office blue
        facade(0xffc8b08a, 0xff9d8459, 0xffcfeaf2, 0xffffcf6e, false); // beige residential
        facade(0xffa05c48, 0xff7a4030, 0xfff4d8c8, 0xffffb45e, false); // brick
        facade(0xff7ba58c, 0xff4e7a61, 0xffeafff0, 0xffc9f09a, true);  // glass green
        facade(0xffcfc6b8, 0xffa89c8a, 0xffe6f2f7, 0xffffd984, false); // marble
        facade(0xff98546a, 0xff713a4d, 0xfff5dbe4, 0xffffb3c1, false); // rose
    }

    private static void facade(int base, int frame, int glassDay, int glassNight, boolean big) {
        int w = 64, h = 64;
        Pixmap d = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        Pixmap n = new Pixmap(w, h, Pixmap.Format.RGBA8888);
        int rows = big ? 5 : 6;
        int cols = big ? 2 : 4;
        int m = 3;
        float cw = (w - m * 2f) / cols, ch = (h - m * 2f) / rows;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                int x0 = (int) (m + col * cw), y0 = (int) (m + row * ch);
                int cw2 = (int) cw - 2, ch2 = (int) ch - 2;
                // frame
                Art.fillRect(d, x0, y0, cw2, ch2, frame);
                Art.fillRect(n, x0, y0, cw2, ch2, frame);
                // glass
                int gx = x0 + 2, gy = y0 + 2, gw = cw2 - 4, gh = ch2 - 4;
                Art.fillRect(d, gx, gy, gw, gh, glassDay);
                Art.fillRect(n, gx, gy, gw, gh, glassNight);
                // divider on big glass
                if (big) {
                    Art.fillRect(d, gx + gw / 2, gy, 2, gh, frame);
                    Art.fillRect(n, gx + gw / 2, gy, 2, gh, frame);
                }
            }
        }
        // base wall margin + subtle roofline
        Art.fillRect(d, 0, 0, w, m, 0x90000000);
        Art.fillRect(n, 0, 0, w, m, 0x90000000);
        // store two textures per style via shared slot
        facDay[stringIdx] = makeTexP(d);
        facNight[stringIdx] = makeTexP(n);
        stringIdx++;
        d.dispose();
        n.dispose();
    }

    // facade style index shared between facade() calls
    private static int stringIdx;
}