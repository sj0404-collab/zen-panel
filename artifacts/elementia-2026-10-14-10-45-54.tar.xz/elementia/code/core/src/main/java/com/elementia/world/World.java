package com.elementia.world;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.elementia.core.*;

/**
 * The entire metroidvania world: tilemap, gates, pickups, enemies, physics,
 * combat reactions, rendering, save/load.
 */
public class World {
    // tile codes
    static final int AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, ICE_T = 4, SNOW = 5, BRICK = 6, PLAT = 7, WATER_T = 8, CRYST = 9, LAVA_T = 10;
    public static final int MW = 150, MH = 46;
    static final float T = Config.TILE;

    int[][] tiles = new int[MH][MW];
    public Player player;
    public ArrayList<Enemy> enemies = new ArrayList<>();
    public ArrayList<Projectile> projs = new ArrayList<>();
    public Particles particles;
    public ArrayList<Gate> gates = new ArrayList<>();
    public ArrayList<Chest> chests = new ArrayList<>();
    public ArrayList<Waypoint> waypoints = new ArrayList<>();
    public ArrayList<Npc> npcs = new ArrayList<>();

    // background positions for trees, crystals, columns
    static final List<float[]> MEADOW_TREES = Arrays.asList(
        new float[]{6,22,0.6f}, new float[]{12,20,1.1f}, new float[]{22,25,0.9f}, new float[]{30,21,0.7f});
    static final List<float[]> CAVE_CRYSTALS = Arrays.asList(
        new float[]{45,24,1.0f}, new float[]{53,22,0.8f}, new float[]{61,25,1.1f});

    public boolean vineBurned, frostMelted, fireDoused, bossStarted, bossDefeated, trophyClaimed, gameWon;
    public String pendingNpc;
    public boolean introPending = true;
    public float respawnX = 12 * T, respawnY = (MH - 1 - 28) * T;
    float shakeTimer, shakeAmt;
    public float time;

    enum GateType { VINE, FROST, BOSS, MAGMA, FIRE }
    public static class Gate { float x,y,w,h; GateType type; boolean active;
        Gate(float x, float y, float w, float h, GateType t, boolean active) {
            this.x=x;this.y=y;this.w=w;this.h=h;type=t;this.active=active;
        }
    }
    public static class Chest { float x,y; String type; boolean opened;
        Chest(float x,float y,String t){this.x=x;this.y=y;type=t;}
    }
    public static class Waypoint { float x,y; boolean active;
        Waypoint(float x,float y){this.x=x;this.y=y;}
    }
    public static class Npc { float x,y; String id; boolean inRange; boolean talked; boolean repeat;
        Npc(float x,float y,String id,boolean repeat){this.x=x;this.y=y;this.id=id;this.repeat=repeat;}
    }

    public static final Map<String, String[]> NPC_TEXT = new HashMap<>();
    static {
        NPC_TEXT.put("intro", new String[]{
            "Пролог", "Я — Элемиса, странница пути… Пять стихий вновь схлестнулись, а Кристалл, что их связывал, раскололся.\nСоберу осколки силы. Впереди — Пепельное Жерло, где спит последний Страж."
        });
        NPC_TEXT.put("elder", new String[]{
            "Старейшина Ваша", "Добро пожаловать, странница! Земли под нами полны древней силы.\nНа востоке пещеры ждут. Отыщи Огненный Камень и сожги лианы-завесу, что закрыли путь."
        });
        NPC_TEXT.put("keeper", new String[]{
            "Хранитель моста", "За постом каменного голема спит Ледяная Святыня.\nЕё морозная сила раскроет двери в святилище Стражей."
        });
        NPC_TEXT.put("sage", new String[]{
            "Кристальная Мудрец", "За ледяной вратою дремлет древний Страж — Владыка Пепелища.\nБудь готова, дитя. Одержишь верх — и путь в самое сердце вулкана откроется."
        });
        NPC_TEXT.put("witch", new String[]{
            "Ведьма Пепелища", "А ты дерзкая… Под нашими ногами — живое сердце вулкана — Ядро Пламени.\nЗабери его — и равновесие стихий вернётся. Но берегись: огонь тут желает пить.\nГидро усмиряет пламя, а Страж падёт лишь от клинка."
        });
        NPC_TEXT.put("s_dash", new String[]{
            "Знак", "Рывок — твой верный спутник. Коснись кнопки рывка и пронесись сквозь врага."
        });
        NPC_TEXT.put("s_vine", new String[]{
            "Знак", "Лианы не рвутся. Но струя Пиро обратит их в пепел."
        });
        NPC_TEXT.put("s_frost", new String[]{
            "Знак", "Морозная врата жаждет Крио. Белый кристалл лежит на ледяной полке."
        });
        NPC_TEXT.put("s_boss", new String[]{
            "Знак", "Стражи Элемисуса не дремлют вечно. Переступи последний порог… если осмелишься."
        });
        NPC_TEXT.put("s_lava", new String[]{
            "Знак", "Лава обжигает. Ищи камни, что выше огня."
        });
        NPC_TEXT.put("s_hydro", new String[]{
            "Знак", "Огненные стены гасятся Гидро. Ключ-родник спрятан на верхней полке Ледяной Святыни."
        });
        NPC_TEXT.put("s_win", new String[]{
            "Знак", "Ядро Пламени ждёт. Верни его свет в Кристалл Стихий."
        });
    }

    public World() { build(); }

    private void build() {
        particles = new Particles(this);
        buildTerrain();
        addGates();
        addWaypoints();
        addNpcs();
        addChests();
        addEnemies();
        player = new Player(respawnX, respawnY);
    }

    private void buildTerrain() {
        // Meadow ground rows 28-33 cols 0-39
        box(0, 28, 39, 33, DIRT);
        box(0, 28, 39, 28, GRASS);
        // some sky ledge
        platformRow(8, 24, 6);
        platformRow(18, 20, 5);
        platformRow(27, 22, 4);
        // Sky tower (far left, climbable with double-jump later)
        box(2, 7, 7, 11, BRICK);
        platformRow(1, 12, 8);
        platformRow(3, 15, 4);
        platformRow(0, 18, 5);
        platformRow(2, 21, 4);

        // Cave entrance shaft
        platformRow(35, 26, 5);
        platformRow(36, 23, 4);
        platformRow(34, 20, 4);

        // Cavern: cols 40-70, floor 28-33, ceiling 4-5
        box(40, 28, 70, 33, STONE);
        box(40, 4, 97, 5, STONE);
        // platforms inside cavern
        platformRow(44, 23, 5);
        platformRow(52, 20, 5);
        platformRow(58, 17, 4);
        platformRow(46, 14, 4);
        // Water pool in cavern
        for (int c = 57; c <= 62; c++) tiles[29][c] = WATER_T;

        // Frost shrine: cols 71-97, floor 28-33
        box(71, 28, 97, 33, SNOW);
        box(71, 28, 97, 28, ICE_T);
        // low pedestal for the cryo key (reachable with a single jump + dash)
        box(81, 27, 83, 27, SNOW);
        platformRow(74, 23, 5);
        platformRow(80, 19, 5);
        platformRow(86, 15, 4);
        platformRow(78, 11, 3);
        platformRow(94, 8, 3);

        // Sanctum: cols 98-117 enclosed
        box(98, 28, 117, 33, BRICK);
        box(98, 5, 117, 6, BRICK);
        box(98, 6, 98, 33, BRICK);
        box(117, 6, 117, 33, BRICK);
        platformRow(100, 22, 4);
        platformRow(106, 17, 4);
        platformRow(112, 12, 4);

        // Boss arena floor drop: shaft down into the volcano heart
        for (int r = 28; r <= 33; r++) { tiles[r][111] = AIR; tiles[r][112] = AIR; }

        // ================= Volcano (deep under cols 98-149, rows 34-45) =================
        // east chamber floor (extended to the forge step so no deadly gap)
        box(100, 43, 132, 44, STONE);
        box(133, 40, 148, 44, STONE);
        // lava pools
        for (int c = 106; c <= 109; c++) tiles[43][c] = LAVA_T;
        for (int c = 118; c <= 120; c++) tiles[43][c] = LAVA_T;
        for (int c = 137; c <= 139; c++) tiles[43][c] = LAVA_T;
        // glowing lava wall columns (non-solid decor)
        tiles[40][105] = LAVA_T; tiles[39][105] = LAVA_T;
        tiles[36][129] = LAVA_T; tiles[35][129] = LAVA_T;
        tiles[41][132] = LAVA_T; tiles[40][132] = LAVA_T; tiles[39][132] = LAVA_T;
        // hop-stones rising eastward
        platformRow(104, 37, 4);
        platformRow(110, 34, 3);   // landing right under the sanctum shaft
        platformRow(116, 36, 3);
        platformRow(122, 34, 4);
        platformRow(128, 37, 3);
        platformRow(134, 34, 4);
        platformRow(138, 30, 3);
        platformRow(142, 27, 3);
        platformRow(146, 30, 4);
        // side chamber (behind fire wall) with a heart relic
        box(119, 43, 124, 44, STONE);
        box(119, 37, 119, 42, STONE);
        box(124, 37, 124, 42, STONE);
        // secret high alcove under the boss arena (reachable with double jump)
        platformRow(100, 35, 3);

        // place crystals (decor block, solid)
        tiles[24][48] = CRYST;
        tiles[22][54] = CRYST;
        tiles[23][82] = CRYST;
        tiles[35][144] = CRYST;
        tiles[37][146] = CRYST;
    }

    private void addGates() {
        // Vine wall blocking cave path, cols 50-51, rows 17-27 (world y 224..576)
        gates.add(new Gate(50 * T, tileToWorldY(27), 2 * T, 11 * T, GateType.VINE, true));
        // Frost gate to sanctum entrance: col 97, rows 6-27 (world y 224..928)
        gates.add(new Gate(97 * T, tileToWorldY(27), 1 * T, 22 * T, GateType.FROST, true));
        // Magma seal across the boss-arena shaft (col 111-112, rows 29-33); molten open after the Guardian falls
        gates.add(new Gate(111 * T, tileToWorldY(33), 2 * T, 5 * T, GateType.MAGMA, true));
        // Fire wall to the volcano side chamber (col 118, rows 37-43); doused only by Hydro
        gates.add(new Gate(118 * T, tileToWorldY(43), 1 * T, 7 * T, GateType.FIRE, true));
    }

    private void addWaypoints() {
        float g = tileToWorldY(28);
        waypoints.add(new Waypoint(16 * T, g));  // meadow
        waypoints.add(new Waypoint(43 * T, g));  // cave entrance
        waypoints.add(new Waypoint(84 * T, g));  // frost shrine
        waypoints.add(new Waypoint(127 * T, tileToWorldY(43)));  // volcano forge
    }

    private void addNpcs() {
        float g = tileToWorldY(28);
        npcs.add(new Npc(14 * T, g, "elder", false));
        npcs.add(new Npc(44 * T, g, "keeper", false));
        npcs.add(new Npc(83 * T, g, "sage", false));
        npcs.add(new Npc(112 * T, tileToWorldY(34), "witch", false));
        // re-readable lore / hint signs
        npcs.add(new Npc(9 * T, g, "s_dash", true));
        npcs.add(new Npc(46 * T, tileToWorldY(28), "s_vine", true));
        npcs.add(new Npc(72 * T, tileToWorldY(28), "s_frost", true));
        npcs.add(new Npc(99 * T, tileToWorldY(28), "s_boss", true));
        npcs.add(new Npc(110 * T, tileToWorldY(34), "s_lava", true));
        npcs.add(new Npc(79 * T, tileToWorldY(11), "s_hydro", true));
        npcs.add(new Npc(147 * T, tileToWorldY(30), "s_win", true));
    }

    private void addChests() {
        // pyro chest sits before the vine wall (col < 50) so it is reachable
        chests.add(new Chest(47 * T, tileToWorldY(28), "pyro"));
        // cryo chest sits on the one-tile pedestal in the frost shrine (single jump reachable)
        chests.add(new Chest(82 * T, tileToWorldY(27), "cryo"));
        // heart relic on the sky tower (row 12 top)
        chests.add(new Chest(4 * T, tileToWorldY(12), "heart"));
        // hydro key hidden high in the Frost Shrine (row 8 top, needs double jump)
        chests.add(new Chest(95 * T, tileToWorldY(8), "hydro"));
        // heart relic behind the fire wall in the volcano
        chests.add(new Chest(121 * T, tileToWorldY(43), "heart"));
        // fire-warded bonus heart in the secret alcove under the boss arena
        chests.add(new Chest(101 * T, tileToWorldY(35), "heart"));
        // the Flame Core: restore the Crystal and win
        chests.add(new Chest(143 * T, tileToWorldY(27), "flame"));
    }

    private void addEnemies() {
        spawnEnemy(Enemy.Kind.SLIME, 22, 28, Element.ANEMO);
        spawnEnemy(Enemy.Kind.SLIME, 26, 28, Element.ANEMO);
        spawnEnemy(Enemy.Kind.SLIME, 30, 28, Element.ANEMO);
        spawnEnemy(Enemy.Kind.WISP, 28, 19, Element.ANEMO);
        // Cavern enemies (guarding pyro chest area)
        spawnEnemy(Enemy.Kind.SLIME, 49, 28, Element.PYRO);
        spawnEnemy(Enemy.Kind.SLIME, 56, 28, Element.PYRO);
        spawnEnemy(Enemy.Kind.WISP, 55, 19, Element.PYRO);
        spawnEnemy(Enemy.Kind.WISP, 63, 15, Element.PYRO);
        // golem guards frost entrance
        Enemy g = new Enemy(Enemy.Kind.GOLEM, 69 * T, tileToWorldY(28));
        g.element = Element.GEO;
        g.setBounds(66 * T, 72 * T);
        enemies.add(g);
        // Frost enemies
        spawnEnemy(Enemy.Kind.SLIME, 76, 28, Element.CRYO);
        spawnEnemy(Enemy.Kind.SLIME, 82, 28, Element.CRYO);
        spawnEnemy(Enemy.Kind.WISP, 85, 14, Element.CRYO);
        spawnEnemy(Enemy.Kind.WISP, 92, 18, Element.HYDRO);
        // Volcano (deep): fire slimes, ember wisps, a magma golem
        spawnEnemy(Enemy.Kind.SLIME, 106, 44, Element.PYRO);
        spawnEnemy(Enemy.Kind.SLIME, 116, 34, Element.PYRO);
        spawnEnemy(Enemy.Kind.WISP, 121, 38, Element.PYRO);
        spawnEnemy(Enemy.Kind.WISP, 126, 33, Element.PYRO);
        Enemy mg = new Enemy(Enemy.Kind.GOLEM, 135 * T, tileToWorldY(40));
        mg.element = Element.PYRO;
        mg.setBounds(128 * T, 143 * T);
        enemies.add(mg);
        spawnEnemy(Enemy.Kind.SLIME, 137, 40, Element.PYRO);
        spawnEnemy(Enemy.Kind.WISP, 141, 33, Element.PYRO);
        spawnEnemy(Enemy.Kind.SLIME, 146, 30, Element.PYRO);
        // Boss
        Boss b = new Boss(108 * T, tileToWorldY(28));
        b.setBounds(99 * T, 116 * T);
        enemies.add(b);
    }

    void spawnEnemy(Enemy.Kind kind, int col, int row, Element e) {
        float y = tileToWorldY(row) - (kind == Enemy.Kind.WISP ? 16 : 0);
        Enemy en = new Enemy(kind, col * T, y);
        en.element = e;
        en.setBounds((col - 6) * T, (col + 6) * T);
        enemies.add(en);
    }

    // ---------- tile helpers ----------

    void box(int c0, int r0, int c1, int r1, int tile) {
        for (int r = r0; r <= r1; r++)
            for (int c = c0; c <= c1; c++)
                if (r >= 0 && r < MH && c >= 0 && c < MW) tiles[r][c] = tile;
    }

    void platformRow(int c0, int row, int len) {
        for (int c = c0; c < c0 + len; c++)
            if (row >= 0 && row < MH && c >= 0 && c < MW) tiles[row][c] = PLAT;
    }

    /** World y -> tile row. A point exactly on a tile's top face belongs to the air cell above it. */
    private int rowAt(float wy) {
        return (int) Math.ceil(MH - 2 - wy / T);
    }

    public int tileAt(float wx, float wy) {
        int c = (int) (wx / T);
        int r = rowAt(wy);
        if (c < 0 || c >= MW || r < 0 || r >= MH) return -1;
        return tiles[r][c];
    }

    public boolean solidAt(float wx, float wy) {
        int c = (int) (wx / T);
        int r = rowAt(wy);
        if (c < 0 || c >= MW) return true;
        if (r < 0) return false;
        if (r >= MH) return true;
        int t = tiles[r][c];
        if (t == GRASS || t == DIRT || t == STONE || t == ICE_T || t == SNOW || t == BRICK || t == CRYST) {
            for (Gate g : gates) if (g.active && wx >= g.x && wx <= g.x + g.w && wy >= g.y && wy <= g.y + g.h) return true;
            return true;
        }
        // gates overlap any tile
        for (Gate g : gates) if (g.active && wx >= g.x && wx <= g.x + g.w && wy >= g.y && wy <= g.y + g.h) return true;
        return false;
    }

    public boolean platformAt(float wx, float wy) {
        int c = (int) (wx / T);
        int r = rowAt(wy);
        if (c < 0 || c >= MW || r < 0 || r >= MH) return false;
        return tiles[r][c] == PLAT;
    }

    /** Highest support surface (top face) at column wx at/below wy; -1 if none. */
    public float groundTopAt(float wx, float wy) {
        int c = (int) (wx / T);
        if (c < 0 || c >= MW) return -1;
        int r = Math.max(0, Math.min(MH - 1, rowAt(wy)));
        for (int rr = r; rr < MH; rr++) {
            if (supportAt(c, rr)) return tileToWorldY(rr);
        }
        return -1;
    }

    private boolean supportAt(int c, int r) {
        int t = tiles[r][c];
        if (t == GRASS || t == DIRT || t == STONE || t == ICE_T || t == SNOW || t == BRICK || t == CRYST) return true;
        if (t == PLAT) return true;
        float top = tileToWorldY(r), bot = top - T;
        float c0 = c * T, c1 = c0 + T;
        for (Gate g : gates) {
            if (!g.active) continue;
            if (g.x + g.w <= c0 || g.x >= c1) continue;
            if (g.y < top && g.y + g.h > bot) return true;
        }
        return false;
    }

    public float gravity() { return Config.GRAVITY; }
    public float maxFall() { return Config.MAX_FALL; }

    public float tileToWorldX(int col) { return col * T; }
    public float tileToWorldY(int row) { return (MH - 1 - row) * T; }

    public void screenShake(float duration, float amount) {
        shakeTimer = Math.max(shakeTimer, duration);
        shakeAmt = Math.max(shakeAmt, amount);
    }

    public void addProjectile(float x, float y, float vx, float vy, int dmg, Element e, boolean fromEnemy, float radius) {
        projs.add(new Projectile(x, y, vx, vy, dmg, e, fromEnemy, radius));
    }

    // ---------- update ----------

    public void update(InputState in, float dt) {
        time += dt;
        if (shakeTimer > 0) shakeTimer -= dt;

        boolean wasGrounded = player.grounded;
        float vyBefore = player.vy;
        boolean wasInWater = tileAt(player.x + player.w / 2, player.y + player.h / 2 - 4) == WATER_T;

        handlePlayerInput(in, dt);
        player.moveAndCollide(this, dt);
        player.updateState();
        player.invuln = Math.max(0, player.invuln - dt);
        updateAttack(dt);
        updatePlayerSkill(in, dt);
        updateEnemies(dt);
        updateProjectiles(dt);
        checkInteractions(dt);
        emitAmbient();
        cleanup();

        // animation polish: landing dust, water splash, dash wind-trail
        if (player.alive && player.state == Player.State.DASH && time % 0.06f < dt) {
            particles.emit(player.x + player.w / 2 - player.facing * 14, player.y + player.h / 2, -player.facing * 160, 0, 0x60c8c8ff, 2, 0.22f, true);
        }
        if (!wasGrounded && player.grounded) {
            float impact = Math.abs(Math.min(0, vyBefore));
            particles.emitBurst(player.x + player.w / 2, player.y, 0xddffffff, 5, 90, 2, 0.35f);
            if (impact > 700) screenShake(0.2f, 4f);
            else if (impact > 420) screenShake(0.12f, 2f);
        }
        boolean nowInWater = tileAt(player.x + player.w / 2, player.y + player.h / 2 - 4) == WATER_T;
        if (nowInWater && !wasInWater) {
            particles.emitBurst(player.x + player.w / 2, player.y + player.h / 2, 0xff4dd0e1, 8, 140, 3, 0.4f);
            Sfx.play("splash", 0.6f, 1f);
        }
        if (player.grounded && Math.abs(player.vx) > 120 && time % (0.22f) < dt) {
            particles.emit(player.x + player.w / 2 - player.facing * 12, player.y + 2, -player.facing * 40, 30, 0x60ffffff, 1, 0.3f, true);
        }
    }

    private void handlePlayerInput(InputState in, float dt) {
        if (!player.alive) return;
        if (player.state == Player.State.DASH) { player.dashTimer -= dt; if (player.dashTimer <= 0) { player.state = Player.State.IDLE; player.vx = 0; } return; }
        if (player.dashTimer > 0) player.dashTimer -= dt;
        // movement
        float targetVx = 0;
        if (in.left) { targetVx = -Config.MOVE_SPEED; player.facing = -1; }
        if (in.right) { targetVx = Config.MOVE_SPEED; player.facing = 1; }
        float accel = player.grounded ? Config.ACCEL : Config.AIR_DECEL;
        if (Math.abs(targetVx) < 1) accel = player.grounded ? Config.GROUND_DECEL : Config.AIR_DECEL;
        player.vx = MathUtils.lerp(player.vx, targetVx, Math.min(1, dt * accel / 400f));
        if (Math.abs(player.vx) < 5 && Math.abs(targetVx) < 1) player.vx = 0;
        // gravity
        player.vy -= Config.GRAVITY * dt;
        if (player.vy < -Config.MAX_FALL) player.vy = -Config.MAX_FALL;
        // jump
        if (player.grounded) { player.coyote = Config.COYOTE_TIME; player.jumpsUsed = 0; } else player.coyote -= dt;
        if (in.jumpPressed) player.jumpBuffer = Config.JUMP_BUFFER;
        if (player.jumpBuffer > 0) player.jumpBuffer -= dt;
        if (player.jumpBuffer > 0 && player.coyote > 0 && player.jumpsUsed == 0) {
            player.vy = Config.JUMP_VEL;
            player.jumpBuffer = 0;
            player.coyote = 0;
            player.jumpsUsed = 1;
            Sfx.play("jump", 0.7f, 0.9f);
        } else if (in.jumpPressed && player.canDoubleJump()) {
            player.vy = Config.JUMP_VEL * 0.88f;
            player.jumpsUsed = 2;
            player.jumpBuffer = 0;
            Sfx.play("jump", 0.6f, 1.3f);
            particles.emitBurst(player.x + player.w / 2, player.y, 0xffc8e0ff, 10, 120, 3, 0.35f);
        }
        // jump cut
        if (!in.jumpHeld && player.vy > 0 && player.jumpsUsed > 0) player.vy *= Config.JUMP_CUT;
        // dash
        if (in.dashPressed && player.dashTimer <= 0 && player.has(Ability.DASH) && player.dashCd <= 0) {
            player.state = Player.State.DASH;
            player.dashTimer = Config.DASH_TIME;
            player.dashCd = Config.DASH_CD;
            player.vy = 0;
            player.vx = player.facing * Config.DASH_SPEED;
            player.invuln = Config.DASH_TIME + 0.05f;
            Sfx.play("dash", 0.5f, 1f);
            particles.emitBurst(player.x + player.w / 2, player.y + player.h / 2, 0xffc8c8ff, 8, 180, 3, 0.25f);
        }
        if (player.dashCd > 0) player.dashCd -= dt;
        // attack
        if (in.attackPressed && player.state != Player.State.ATTACK && player.comboWindow <= 0) {
            startAttack();
        }
        // pause
        // handled in screen
    }

    private void startAttack() {
        player.state = Player.State.ATTACK;
        player.comboStep = (player.comboStep + 1) % 3;
        player.attackTimer = 0.2f;
        player.atkHitApplied = false;
        player.atkCenter.set(player.x + player.w / 2 + player.facing * 20, player.y + player.h * 0.6f);
        player.atkRadius = 18f;
        // slash particles
        Sfx.play("slash", 0.7f, 0.9f + player.comboStep * 0.15f);
        particles.emitSparks(player.atkCenter.x, player.atkCenter.y, 0xffffffff, 5, 100);
    }

    private void updateAttack(float dt) {
        if (player.state == Player.State.ATTACK) {
            player.attackTimer -= dt;
            if (player.attackTimer <= 0) { player.comboWindow = Config.COMBO_WINDOW; player.state = Player.State.IDLE; }
            if (!player.atkHitApplied) applyMeleeHits();
        }
        if (player.comboWindow > 0) player.comboWindow -= dt;
    }

    private void applyMeleeHits() {
        int dmg = 8 + player.comboStep * 4;
        for (Enemy e : enemies) {
            if (!e.alive) continue;
            if (e.rect.contains(player.atkCenter.x, player.atkCenter.y)
                || dist(e.x + e.w / 2, e.y + e.h / 2, player.atkCenter.x, player.atkCenter.y) < e.w / 2 + player.atkRadius) {
                float kx = Math.signum(e.x - player.x) * Config.COMBAT_KNOCKBACK;
                int actual = e.applyDamage(dmg, false, kx, 120f);
                player.atkHitApplied = true;
                Sfx.play("hit", 0.6f, 0.9f + player.comboStep * 0.1f);
                particles.emitBurst(e.x + e.w / 2, e.y + e.h / 2, 0xffffffff, 6, 130, 3, 0.25f);
                applyElementToEnemy(e);
                // melee gives slight burst
                player.burstGauge = Math.min(player.burstPower, player.burstGauge + 5f);
            }
        }
    }

    private void updatePlayerSkill(InputState in, float dt) {
        player.skillCd = Math.max(0, player.skillCd - dt);
        if (in.skillPressed && player.skillCd <= 0 && player.activeElement != null) {
            player.skillCd = Config.SKILL_CD;
            float sx = player.x + player.w / 2 + player.facing * 18;
            float sy = player.y + player.h * 0.65f;
            float spd = 380f;
            float vx = player.facing * spd;
            float vy = 0;
            if (player.state == Player.State.JUMP) vy = -spd * 0.3f;
            projs.add(new Projectile(sx, sy, vx, vy, 14, player.activeElement, false, 6));
            Sfx.play("skill", 0.6f, 0.95f);
            particles.emitBurst(sx, sy, player.activeElement.bright, 8, 160, 3, 0.3f);
        }
        if (in.attackPressed && player.burstReady && player.has(Ability.BURST)) {
            applyBurstNova();
            player.burstGauge = 0;
            player.burstReady = false;
        }
        player.burstReady = player.burstGauge >= player.burstPower;
    }

    private void applyBurstNova() {
        float cx = player.x + player.w / 2, cy = player.y + player.h / 2;
        int col = player.activeElement == null ? 0xffffffff : player.activeElement.bright;
        particles.emitBurst(cx, cy, col, 40, 300, 5, 0.8f);
        Sfx.play("burst", 0.8f, 0.8f);
        screenShake(0.5f, 8f);
        for (Enemy e : enemies) {
            if (!e.alive) continue;
            if (dist(e.x + e.w / 2, e.y + e.h / 2, cx, cy) < 180f) {
                e.applyDamage(40, false, Math.signum(e.x - cx) * 200f, 180f);
                applyElementToEnemy(e);
            }
        }
    }

    // ---------- elemental reactions ----------

    void applyElementToEnemy(Enemy e) {
        if (player.activeElement == null) return;
        Element newEl = player.activeElement;
        Element prev = e.status;
        if (prev != null && prev != newEl) {
            float mult = 1f;
            if ((prev == Element.PYRO && newEl == Element.HYDRO) || (prev == Element.HYDRO && newEl == Element.PYRO)) mult = 1.6f; // vaporize
            if ((prev == Element.PYRO && newEl == Element.CRYO) || (prev == Element.CRYO && newEl == Element.PYRO)) mult = 2f; // melt
            if (prev == Element.ANEMO || newEl == Element.ANEMO) mult = 1.3f; // swirl
            e.hp = Math.max(0, e.hp - (int) (20 * mult));
            particles.emitBurst(e.x + e.w / 2, e.y + e.h / 2, newEl.bright, 14, 200, 4, 0.45f);
            if (mult >= 1.5f) screenShake(0.2f, 4f);
            if (e.hp <= 0) { e.alive = false; e.deadTimer = 0.4f; }
            e.status = null;
            e.statusLife = 0;
        } else {
            e.status = newEl;
            e.statusLife = Config.STATUS_DURATION;
        }
    }

    // ---------- enemy, projectile updates ----------

    private void updateEnemies(float dt) {
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            e.update(this, dt);
            if (!e.alive && e.deadTimer <= 0) {
                drop(e);
                enemies.remove(i);
            }
        }
    }

    void drop(Enemy e) {
        particles.emitBurst(e.x + e.w / 2, e.y + e.h / 2, 0xffaaffaa, 8, 120, 3, 0.3f);
        Sfx.play("enemyDie", 0.6f, 0.9f);
        player.heal(8);
        player.burstGauge = Math.min(player.burstPower, player.burstGauge + 12f);
    }

    void updateProjectiles(float dt) {
        for (int i = projs.size() - 1; i >= 0; i--) {
            Projectile p = projs.get(i);
            p.update(dt);
            if (p.life <= 0 || p.x < -50 || p.x > MW * T + 50 || p.y < -50 || p.y > MH * T + 50) { projs.remove(i); continue; }
            if (p.fromEnemy) {
                if (player.invuln <= 0 && rectsOverlap(p.x, p.y, p.w, p.h, player.x, player.y, player.w, player.h)) {
                    player.applyDamage(p.damage, false, p.vx * 0.15f, 120f);
                    Sfx.play("hurt", 0.8f, 1f);
                    projs.remove(i);
                }
            } else {
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    if (rectsOverlap(p.x, p.y, p.w, p.h, e.x, e.y, e.w, e.h)) {
                        e.applyDamage(p.damage, false, p.vx * 0.12f, 100f);
                        applyElementToEnemy(e);
                        Sfx.play("hit", 0.5f, 1.3f);
                        particles.emitBurst(p.x, p.y, e.status != null ? e.status.bright : 0xffffff, 6, 100, 2, 0.2f);
                        projs.remove(i);
                        break;
                    }
                }
            }
            // gate collision
            if (projs.contains(p)) {
                for (Gate g : gates) {
                    if (g.active && rectsOverlap(p.x, p.y, p.w, p.h, g.x, g.y, g.w, g.h)) {
                        if (g.type == GateType.VINE && p.element == Element.PYRO) {
                            burnVine();
                            particles.emitBurst(g.x + g.w / 2, g.y + g.h / 2, 0xffff6040, 30, 200, 5, 0.7f);
                        } else if (g.type == GateType.FROST && p.element == Element.CRYO) {
                            meltFrost();
                        } else if (g.type == GateType.FIRE && p.element == Element.HYDRO) {
                            douseFire();
                        }
                        projs.remove(i);
                        break;
                    }
                }
            }
        }
    }

    void burnVine() {
        vineBurned = true;
        Sfx.play("burn", 0.7f, 1f);
        for (Gate g : gates) if (g.type == GateType.VINE) g.active = false;
        saveDirty = true;
    }

    void meltFrost() {
        frostMelted = true;
        Sfx.play("melt", 0.7f, 1f);
        for (Gate g : gates) if (g.type == GateType.FROST) g.active = false;
        saveDirty = true;
    }

    void douseFire() {
        fireDoused = true;
        Sfx.play("burn", 0.8f, 1.4f);
        particles.emitBurst(118 * T, tileToWorldY(40), 0xff4dd0e1, 30, 220, 5, 0.8f);
        for (Gate g : gates) if (g.type == GateType.FIRE) g.active = false;
        saveDirty = true;
    }

    void openMagmaGates() {
        Sfx.play("burn", 0.7f, 0.7f);
        for (Gate g : gates) if (g.type == GateType.MAGMA) g.active = false;
    }

    // ---------- interactions ----------

    void checkInteractions(float dt) {
        // damage from contact with enemies
        if (player.invuln <= 0) {
            for (Enemy e : enemies) {
                if (!e.alive) continue;
                if (rectsOverlap(player.x, player.y, player.w, player.h, e.x, e.y, e.w, e.h)) {
                    player.applyDamage((int) e.contactDmg, false, Math.signum(player.x - e.x) * 200f, 260f);
                    Sfx.play("hurt", 0.7f, 0.9f);
                    break;
                }
            }
        }
        // water damage (standing in water cells = slow but no damage? let's make it minor hazard)
        int tileBelow = tileAt(player.x + player.w / 2, player.y + player.h / 2 - 4);
        if (tileBelow == WATER_T) {
            player.vy = Math.min(player.vy, 80);
            if (player.grounded && time % 0.8f < dt) player.heal(1);
        }
        // lava hazard: burns on contact, small knock upwards + ember burst
        if (tileBelow == LAVA_T) {
            player.vy = Math.max(player.vy, 300f);
            if (time % 0.5f < dt && player.invuln <= 0) {
                player.applyDamage(12, false, 0, 0);
                Sfx.play("hurt", 0.7f, 0.6f);
                particles.emitBurst(player.x + player.w / 2, player.y, 0xffff7043, 12, 220, 4, 0.5f);
            }
        }
        // death zone
        if (player.y < -40) {
            Sfx.play("hurt", 0.7f, 0.6f);
            player.applyDamage(player.hp, false, 0, 0);
            respawn();
        }
        // chests
        for (Chest ch : chests) {
            if (ch.opened) continue;
            if (rectsOverlap(player.x, player.y, player.w, player.h, ch.x, ch.y, 24, 24)) {
                openChest(ch);
            }
        }
        // waypoints
        for (Waypoint w : waypoints) {
            float dx = player.x + player.w / 2 - w.x;
            if (Math.abs(dx) < 28 && Math.abs(player.y + 4 - w.y) < 20) {
                if (!w.active) {
                    w.active = true;
                    respawnX = w.x;
                    respawnY = w.y + 1;
                    player.heal(player.maxHp);
                    Sfx.play("waypoint", 0.6f, 1f);
                    particles.emitBurst(w.x, w.y + 8, 0xfffff7d0, 16, 120, 4, 0.5f);
                    saveDirty = true;
                }
            } else {
                w.active = false;
            }
        }
        // NPC talk (edge-triggered: only when the player enters range; signs are re-readable)
        for (Npc n : npcs) {
            boolean inRange = Math.abs(player.x + player.w / 2 - n.x) < 26 && Math.abs(player.y - n.y) < 18;
            if (inRange && !n.inRange && !n.talked) {
                pendingNpc = n.id;
                n.talked = true;
                Sfx.play("talk", 0.5f, 1f);
            }
            if (!inRange && n.repeat) n.talked = false;
            n.inRange = inRange;
        }
        // boss interactions
        for (Enemy e : enemies) {
            if (e instanceof Boss) {
                Boss b = (Boss) e;
                if (!b.defeated) {
                    if (!bossStarted && Math.abs(player.x - b.x) < 140) {
                        bossStarted = true;
                        Sfx.play("roar", 0.9f, 0.9f);
                    }
                    if (bossStarted) b.contact(this);
                } else {
                    if (!bossDefeated) {
                        bossDefeated = true;
                        player.unlock(Ability.DOUBLE_JUMP);
                        player.unlock(Ability.BURST);
                        openMagmaGates();
                        Sfx.play("victory", 0.9f, 1f);
                        particles.emitBurst(b.x + b.w / 2, b.y + b.h / 2, 0xffc8ffff, 60, 280, 6, 1.6f);
                        screenShake(1f, 10f);
                        saveDirty = true;
                    }
                }
            }
        }
    }

    void openChest(Chest ch) {
        ch.opened = true;
        particles.emitBurst(ch.x + 12, ch.y + 12, 0xffffd54f, 20, 160, 4, 0.6f);
        saveDirty = true;
        switch (ch.type) {
            case "pyro":
                player.unlock(Ability.PYRO);
                player.setElement(Element.PYRO);
                player.setElement(Element.ANEMO);
                Sfx.play("skill", 0.8f, 0.8f);
                break;
            case "cryo":
                player.unlock(Ability.CRYO);
                player.setElement(Element.CRYO);
                player.setElement(Element.ANEMO);
                Sfx.play("skill", 0.8f, 1.1f);
                break;
            case "hydro":
                player.unlock(Ability.HYDRO);
                player.setElement(Element.HYDRO);
                Sfx.play("skill", 0.8f, 1.25f);
                break;
            case "heart":
                player.maxHp = Math.min(200, player.maxHp + 20);
                player.hp = player.maxHp;
                Sfx.play("waypoint", 0.7f, 1f);
                screenShake(0.4f, 6f);
                break;
            case "flame":
                trophyClaimed = true;
                gameWon = true;
                Sfx.play("victory", 1f, 1f);
                break;
        }
    }

    void respawn() {
        player.setPos(respawnX, respawnY);
        player.hp = player.maxHp;
        player.vx = 0;
        player.vy = 0;
        player.invuln = 1f;
        player.state = Player.State.IDLE;
        player.alive = true;
        player.hitFlash = 0;
    }

    void cleanup() {
        enemies.removeIf(e -> !e.alive && e.deadTimer <= 0);
        projs.removeIf(p -> !p.alive);
    }

    // ---------- ambient ----------

    void emitAmbient() {
        if (time % 0.4f < 0.02f) {
            int col = (int) (player.x / T);
            int zone = col < 40 ? 0 : col < 71 ? 1 : col < 98 ? 2 : 3;
            boolean deep = player.y < 400;
            float px = player.x + (float) (Math.random() - 0.5) * 900;
            float py = player.y + 260 + (float) Math.random() * 120;
            if (py > 10 * T && py < 28 * T) {
                if (zone == 2) particles.emit(px, py, 0, -40, 0xc0ffffff, 3, 3f, true);
                else if (zone == 1) particles.emit(px, py, 0, 10, 0x30ffffff, 2, 4f, false);
                else if (zone == 0) particles.emit(px, py, 15, 5, 0x20ffffff, 2, 5f, false);
            }
            // volcano: rising embers + drifting sparks
            if (zone >= 3 || deep) {
                particles.emit(px, py, 0, 70 + (float) Math.random() * 40, 0xffff7043, 2, 2.5f, true);
                if (deep) particles.emit(px, py - 40, 25, 15, 0x20ffb74d, 1, 3f, false);
            }
        }
    }

    // ---------- parallax ----------

    // Static screen-space silhouette layers (far to near). Each ridge column is
    // derived only from the screen X, so the backdrop never moves with the
    // camera and cannot shimmer. {baseYfrac of VIEW_H, ampPx, wavelength}
    static final float[][] P_LAYERS = {
        {0.58f, 18f, 0.011f},
        {0.50f, 26f, 0.008f},
        {0.42f, 34f, 0.006f}
    };

    static Color[] parallaxCol(int zone) {
        switch (zone) {
            case 0: return new Color[]{
                new Color(0.28f, 0.42f, 0.28f, 0.35f),
                new Color(0.35f, 0.50f, 0.35f, 0.42f),
                new Color(0.45f, 0.58f, 0.40f, 0.52f)};
            case 1: return new Color[]{
                new Color(0.15f, 0.13f, 0.25f, 0.35f),
                new Color(0.20f, 0.18f, 0.30f, 0.42f),
                new Color(0.28f, 0.24f, 0.38f, 0.52f)};
            case 2: return new Color[]{
                new Color(0.30f, 0.45f, 0.55f, 0.35f),
                new Color(0.38f, 0.55f, 0.65f, 0.42f),
                new Color(0.50f, 0.65f, 0.75f, 0.52f)};
            case 3: return new Color[]{
                new Color(0.35f, 0.15f, 0.20f, 0.35f),
                new Color(0.42f, 0.20f, 0.28f, 0.42f),
                new Color(0.50f, 0.28f, 0.30f, 0.52f)};
            case 4: return new Color[]{
                new Color(0.42f, 0.10f, 0.04f, 0.35f),
                new Color(0.55f, 0.16f, 0.05f, 0.42f),
                new Color(0.70f, 0.28f, 0.08f, 0.52f)};
            default: return new Color[]{
                new Color(0.30f, 0.40f, 0.30f, 0.35f),
                new Color(0.40f, 0.50f, 0.40f, 0.42f),
                new Color(0.50f, 0.60f, 0.50f, 0.52f)};
        }
    }

    /** Static backdrop: identical silhouette from any camera position, no jitter. */
    void renderParallax(SpriteBatch batch, int zone) {
        Color[] cols = parallaxCol(zone);
        float vw = Config.VIEW_W;
        float step = 16f;
        for (int i = 0; i < P_LAYERS.length; i++) {
            float baseY = Config.VIEW_H * P_LAYERS[i][0];
            float amp = P_LAYERS[i][1];
            float k = P_LAYERS[i][2];
            float seed = i * 4.7f;
            Color c = cols[i];
            batch.setColor(c);
            for (float sx = 0; sx <= vw + step; sx += step) {
                float y = baseY + amp * (float) Math.sin(sx * k + seed)
                                  + amp * 0.5f * (float) Math.sin(sx * k * 2.2f + seed * 1.7f);
                if (y <= 0) continue;
                batch.draw(Assets.whiteDot, sx, 0, step, y);
            }
        }
        batch.setColor(1, 1, 1, 1);
    }

    /** Screen-space atmosphere: zone tint and a cinematic vignette. */
    void drawImmersion(SpriteBatch batch, int zone) {
        float w = Config.VIEW_W, h = Config.VIEW_H;

        // zone color grade overlay
        Color tint = zoneTint(zone);
        batch.setColor(tint.r, tint.g, tint.b, 0.08f);
        batch.draw(Assets.whiteDot, 0, 0, w, h);

        // cinematic vignette
        int vm = 14;
        batch.setColor(0, 0, 0, 0.26f);
        batch.draw(Assets.whiteDot, 0, h - vm, w, vm);
        batch.draw(Assets.whiteDot, 0, 0, w, vm);
        batch.draw(Assets.whiteDot, 0, 0, vm, h);
        batch.draw(Assets.whiteDot, w - vm, 0, vm, h);
        batch.setColor(1, 1, 1, 1);
    }

    // ---------- render ----------

    public void render(SpriteBatch batch, float camX, float camY) {
        int zone = viewZone(camX, camY);

        // static sky backdrop + fixed parallax silhouettes (never scroll with the camera)
        batch.setColor(zoneTint(zone));
        batch.draw(Assets.whiteDot, 0, 0, Config.VIEW_W, Config.VIEW_H);
        batch.setColor(1, 1, 1, 1);
        renderParallax(batch, zone);

        // tiles visible range
        int cMin = Math.max(0, (int) ((camX - T) / T));
        int cMax = Math.min(MW - 1, (int) ((camX + Config.VIEW_W + T) / T));
        int rMin = Math.max(0, MH - 1 - (int) ((camY + Config.VIEW_H + T) / T));
        int rMax = Math.min(MH - 1, MH - 1 - (int) ((camY - T) / T));

        for (int r = rMin; r <= rMax; r++) {
            for (int c = cMin; c <= cMax; c++) {
                int t = tiles[r][c];
                if (t == AIR) continue;
                float wx = c * T;
                float wy = (MH - 1 - r) * T;
                int zx = tileZone(c, r);
                batch.setColor(zoneColor(zx, 0.95f));
                Texture tex = texForTile(t);
                batch.draw(tex, wx - camX, wy - camY, T, T);
            }
        }

        // platforms (drawn differently: 14px tall)
        for (int r = rMin; r <= rMax; r++) {
            for (int c = cMin; c <= cMax; c++) {
                if (tiles[r][c] == PLAT) {
                    float wx = c * T;
                    float wy = (MH - 1 - r) * T;
                    int zx = tileZone(c, r);
                    batch.setColor(zoneColor(zx, 1f));
                    batch.draw(Assets.t_platform, wx - camX, wy + T - 14 - camY, T, 14);
                }
            }
        }

        batch.setColor(1, 1, 1, 1);

        // water overlay
        for (int r = rMin; r <= rMax; r++) {
            for (int c = cMin; c <= cMax; c++) {
                if (tiles[r][c] == WATER_T) {
                    float wx = c * T;
                    float wy = (MH - 1 - r) * T;
                    float yoff = (float) Math.sin(time * 3 + c) * 2;
                    batch.setColor(0.7f, 0.88f, 0.96f, 0.55f);
                    batch.draw(Assets.whiteDot, wx - camX, wy + T - 20 + yoff - camY, T, 20);
                    batch.setColor(1, 1, 1, 1);
                }
            }
        }

        // lava overlay: flickering glow + hot surface
        for (int r = rMin; r <= rMax; r++) {
            for (int c = cMin; c <= cMax; c++) {
                if (tiles[r][c] == LAVA_T) {
                    float wx = c * T;
                    float wy = (MH - 1 - r) * T;
                    float pulse = 0.7f + 0.3f * (float) Math.sin(time * 6 + c * 1.7f);
                    batch.setColor(1f, 0.5f, 0.2f, 0.28f * pulse);
                    batch.draw(Assets.whiteDot, wx - camX, wy + T - 6 - camY, T, 6);
                    batch.setColor(1, 1, 1, 1);
                    if ((int) (time * 2 + c) % 2 == 0) {
                        batch.setColor(1, 0.7f, 0.3f, 0.4f);
                        batch.draw(Assets.whiteDot, wx - camX, wy - camY, T, T);
                        batch.setColor(1, 1, 1, 1);
                    }
                }
            }
        }

        // gates
        for (Gate g : gates) {
            if (!g.active) continue;
            int col;
            switch (g.type) {
                case VINE: col = 0xff2e7d32; break;
                case FROST: col = 0xff90caf9; break;
                case MAGMA: col = 0xffb71c1c; break;
                case FIRE: col = 0xffff6f00; break;
                default: col = 0xffb71c1c; break;
            }
            batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, 0.85f);
            batch.draw(Assets.whiteDot, g.x - camX, g.y - camY, g.w, g.h);
            batch.setColor(1, 1, 1, 1);
            if (g.type == GateType.FIRE) {
                // dancing flames on the hazard wall
                for (int j = 0; j < g.h; j += 10) {
                    float fl = (float) Math.sin(time * 8 + j * 1.3f) * 3f;
                    batch.setColor(1, (float) Math.sin(time * 5 + j) * 0.3f + 0.5f, 0.2f, 0.8f);
                    batch.draw(Assets.glowDot, g.x + g.w / 2 + fl - 8 - camX, g.y + j - camY, 16, 16 + 6 * (float) Math.sin(time * 7 + j));
                }
                batch.setColor(1, 1, 1, 1);
            }
            // gate overlay pattern
            for (int i = 0; i < g.w; i += 6) {
                for (int j = 0; j < g.h; j += 6) {
                    batch.setColor(1, 1, 1, 0.15f);
                    batch.draw(Assets.whiteDot, g.x + i - camX, g.y + j - camY, 2, 2);
                }
            }
            batch.setColor(1, 1, 1, 1);
        }

        // waypoint statues
        for (Waypoint w : waypoints) {
            float pulse = (float) Math.sin(time * 3) * 0.15f + 0.85f;
            batch.draw(Assets.wpReg, w.x - 20 - camX, w.y - 42 - camY, 40, 56);
            if (w.active) {
                batch.setColor(pulse, pulse, 1f, 0.5f);
                batch.draw(Assets.glowDot, w.x - 16 - camX, w.y - 8 - camY, 32, 32);
                batch.setColor(1, 1, 1, 1);
            }
        }

        // NPC bubbles
        for (Npc n : npcs) {
            batch.setColor(1f, 1f, 0.85f, 0.8f);
            batch.draw(Assets.whiteDot, n.x - 3 - camX, n.y + 34 - camY, 6, 6);
            batch.setColor(1, 1, 1, 1);
        }

        // chests
        for (Chest ch : chests) {
            if (ch.opened) {
                batch.draw(Assets.t_bgChest, ch.x - 2 - camX, ch.y - 2 - camY, 28, 24);
                batch.setColor(1, 1, 1, 0.6f);
            } else {
                batch.draw(Assets.t_bgChest, ch.x - 2 - camX, ch.y - 2 - camY, 28, 24);
            }
            batch.setColor(1, 1, 1, 1);
        }

        // background trees/crystals (behind enemies)
        for (float[] d : MEADOW_TREES) {
            if (d[0] > cMin && d[0] < cMax) {
                float wx = d[0] * T, wy = (MH - 1 - (int) d[1]) * T;
                float s = d[2];
                batch.draw(Assets.t_bgGrass, wx - camX, wy - camY, 32 * s, 48 * s);
            }
        }

        // enemies
        for (Enemy e : enemies) {
            float sx = e.x - camX, sy = e.y - camY;
            if (sx > -100 && sx < Config.VIEW_W + 100) e.render(batch);
        }

        // player
        if (player.alive) {
            drawPlayer(batch, camX, camY);
        }

        // projectiles
        for (Projectile p : projs) {
            p.render(batch);
        }

        // particles (on top)
        particles.render(batch);

        // boss HP bar (top center)
        for (Enemy e : enemies) {
            if (e instanceof Boss && bossStarted) {
                Boss b = (Boss) e;
                float bw = 220, bh = 8, bx = Config.VIEW_W / 2 - bw / 2, by = Config.VIEW_H - 36;
                batch.setColor(0, 0, 0, 0.6f);
                batch.draw(Assets.whiteDot, bx, by, bw, bh);
                float hpFrac = Math.max(0, b.hp / (float) b.maxHp);
                batch.setColor(0.76f, 0.3f, 0.3f, 1);
                batch.draw(Assets.whiteDot, bx, by, bw * hpFrac, bh);
                batch.setColor(1, 1, 1, 1);
            }
        }

        // atmosphere: zone tint + vignette
        drawImmersion(batch, zone);
    }

    void drawPlayer(SpriteBatch batch, float camX, float camY) {
        float sx = player.x - camX, sy = player.y - camY;
        com.badlogic.gdx.graphics.g2d.TextureRegion region = heroFrame();
        float drawW = 56, drawH = 76;
        if (player.state == Player.State.DASH) {
            batch.setColor(0.7f, 0.7f, 1f, 0.6f);
        } else if (player.invuln > 0) {
            float flash = (float) Math.sin(time * 30f);
            if (flash > 0) batch.setColor(1, 1, 1, 0.5f); else batch.setColor(0.8f, 0.8f, 1f, 0.6f);
        } else if (player.hitFlash > 0) {
            batch.setColor(2f, 2f, 2f, 1);
        } else {
            batch.setColor(1, 1, 1, 1);
        }
        // Mirror by drawing with a negative width around the left edge so the
        // sprite footprint stays on the player body on both facings.
        if (player.facing < 0 && drawW > 0) {
            batch.draw(region, sx + drawW, sy - 8, -drawW, drawH);
        } else {
            batch.draw(region, sx, sy - 8, drawW, drawH);
        }
        batch.setColor(1, 1, 1, 1);

        // melee slash crescent sweeping across the attack center
        if (player.state == Player.State.ATTACK) {
            float dur = 0.2f;
            float prog = player.attackTimer / dur;
            float alpha = (float) Math.sin(prog * (float) Math.PI) * 0.95f;
            if (alpha > 0.02f) {
                float scale = 0.55f + (1f - prog) * 0.75f;
                float reach = 6f + (1f - prog) * 34f;
                float cx = player.atkCenter.x - camX + player.facing * reach;
                float cy = player.atkCenter.y - camY + 6;
                float rot = (1f - prog) * 130f;
                if (player.facing < 0) rot = -rot;
                batch.setColor(0.9f, 0.95f, 1f, alpha);
                batch.draw(Assets.slashReg, cx - 48 * scale, cy - 48 * scale, 48 * scale, 48 * scale,
                        96 * scale, 96 * scale, 1, 1, rot);
                batch.setColor(1, 1, 1, 1);
            }
        }
    }

    com.badlogic.gdx.graphics.g2d.TextureRegion heroFrame() {
        switch (player.state) {
            case JUMP: return Assets.heroJump;
            case FALL: return Assets.heroFall;
            case ATTACK:
                if (player.comboStep == 0) return Assets.heroAtk1;
                if (player.comboStep == 1) return Assets.heroAtk2;
                return Assets.heroAtk3;
            case HURT: return Assets.heroHurt;
            case DASH: return Assets.heroJump;
            case RUN: {
                int f = (int) ((time * 8f) % 4);
                return Assets.heroRun[f];
            }
            default: {
                int f = (int) ((time * 2.5f) % 2);
                return Assets.heroIdle[f];
            }
        }
    }

    Texture texForTile(int t) {
        switch (t) {
            case GRASS: return Assets.t_grass;
            case DIRT: return Assets.t_dirt;
            case STONE: return Assets.t_stone;
            case ICE_T: return Assets.t_ice;
            case SNOW: return Assets.t_snow;
            case BRICK: return Assets.t_brick;
            case CRYST: return Assets.t_crystal;
            case LAVA_T: return (int) (time * 4 + t) % 2 == 0 ? Assets.t_lavaA : Assets.t_lavaB;
            default: return Assets.whiteDot;
        }
    }

    /** Column-based zone (used for ambient, waypoints etc.). */
    int zoneAt(float wx) {
        int c = (int) (wx / T);
        if (c < 40) return 0;
        if (c < 71) return 1;
        if (c < 98) return 2;
        return 3;
    }

    /** View zone: drops to the volcanic underworld when the camera dives deep. */
    int viewZone(float camX, float camY) {
        int z = zoneAt(camX + Config.VIEW_W / 2);
        if (z >= 3 && camY < 200) return 4;
        return z;
    }

    /** Tile zone: below the sanctum/forge floor the whole region becomes the volcano. */
    int tileZone(int col, int row) {
        int z = zoneAt(col * T);
        if (col >= 98 && row >= 34) return 4;
        return z;
    }

    Color zoneColor(int zone, float alpha) {
        switch (zone) {
            case 0: return new Color(1f, 1f, 0.97f, alpha);
            case 1: return new Color(0.58f, 0.62f, 0.82f, alpha);
            case 2: return new Color(0.82f, 0.93f, 1f, alpha);
            case 3: return new Color(1f, 0.74f, 0.82f, alpha);
            case 4: return new Color(0.62f, 0.42f, 0.36f, alpha);
            default: return new Color(1, 1, 1, alpha);
        }
    }

    Color zoneTint(int zone) {
        switch (zone) {
            case 0: return new Color(0.32f, 0.53f, 0.82f, 1);
            case 1: return new Color(0.12f, 0.12f, 0.2f, 1);
            case 2: return new Color(0.48f, 0.62f, 0.78f, 1);
            case 3: return new Color(0.22f, 0.12f, 0.28f, 1);
            case 4: return new Color(0.15f, 0.04f, 0.03f, 1);
            default: return new Color(0.3f, 0.5f, 0.8f, 1);
        }
    }

    // ---------- save/load (via Gdx Preferences) ----------

    public boolean saveDirty;

    public String save() {
        StringBuilder sb = new StringBuilder();
        sb.append("{x:").append(player.x);
        sb.append(";y:").append(player.y);
        sb.append(";hp:").append(player.hp);
        sb.append(";mx:").append(player.maxHp);
        sb.append(";ab:");
        for (Ability a : player.abilities) {
            if (sb.charAt(sb.length() - 1) != ':') sb.append(',');
            sb.append(a.name());
        }
        sb.append(";vine:").append(vineBurned);
        sb.append(";frost:").append(frostMelted);
        sb.append(";fire:").append(fireDoused);
        sb.append(";bd:").append(bossDefeated);
        sb.append(";tr:").append(trophyClaimed);
        sb.append(";won:").append(gameWon);
        sb.append(";rx:").append(respawnX);
        sb.append(";ry:").append(respawnY);
        sb.append(";ch:");
        for (Chest c : chests) sb.append(c.opened ? "1" : "0");
        sb.append("}");
        return sb.toString();
    }

    /** Restore a previously saved state; silently ignores a corrupt save. */
    public void load(String data) {
        if (data == null || data.isEmpty()) return;
        try {
            Map<String, String> kv = new HashMap<>();
            String inner = data.replace("{", "").replace("}", "");
            for (String pair : inner.split(";")) {
                int i = pair.indexOf(':');
                if (i <= 0) continue;
                kv.put(pair.substring(0, i), pair.substring(i + 1));
            }
            player.setPos(parseF(kv, "x", player.x), parseF(kv, "y", player.y));
            player.maxHp = (int) Math.min(200, parseF(kv, "mx", player.maxHp));
            player.hp = (int) Math.min(player.maxHp, parseF(kv, "hp", player.hp));
            player.abilities = Ability.starting();
            String ab = kv.getOrDefault("ab", "");
            if (!ab.isEmpty()) for (String a : ab.split(",")) {
                try { player.abilities.add(Ability.valueOf(a.trim())); } catch (Exception ignored) {}
            }
            vineBurned = parseB(kv, "vine");
            frostMelted = parseB(kv, "frost");
            fireDoused = parseB(kv, "fire");
            bossDefeated = parseB(kv, "bd");
            trophyClaimed = parseB(kv, "tr");
            gameWon = parseB(kv, "won");
            // parse and validate respawn (rx, ry) - player position (x,y) can be mid-air
            respawnX = parseF(kv, "rx", respawnX);
            respawnY = parseF(kv, "ry", respawnY);
            if (respawnY < 0 || tileAt(respawnX, respawnY - 2) == AIR) {
                respawnX = 12 * T;
                respawnY = (MH - 1 - 28) * T;
            }
            player.setPos(parseF(kv, "x", player.x), parseF(kv, "y", player.y));
            player.maxHp = (int) Math.min(200, parseF(kv, "mx", player.maxHp));
            player.hp = (int) Math.min(player.maxHp, parseF(kv, "hp", player.hp));
            String chs = kv.getOrDefault("ch", "");
            for (int i = 0; i < chests.size() && i < chs.length(); i++)
                chests.get(i).opened = chs.charAt(i) == '1';
            for (Gate g : gates) {
                if (g.type == GateType.VINE && vineBurned) g.active = false;
                if (g.type == GateType.FROST && frostMelted) g.active = false;
                if (g.type == GateType.MAGMA && bossDefeated) g.active = false;
                if (g.type == GateType.FIRE && fireDoused) g.active = false;
            }
            if (bossDefeated) {
                player.unlock(Ability.DOUBLE_JUMP);
                player.unlock(Ability.BURST);
            }
            player.setElement(Element.ANEMO);
            player.updateRect();
            saveDirty = false;
            introPending = false;
        } catch (Exception e) {
            System.err.println("Elementia: failed to load save (" + e + "); starting fresh");
            saveDirty = true; // rewrite a fresh save next frame
        }
    }

    private static float parseF(Map<String, String> kv, String key, float def) {
        String s = kv.get(key);
        if (s == null || s.isEmpty()) return def;
        try { return Float.parseFloat(s); } catch (Exception e) { return def; }
    }

    private static boolean parseB(Map<String, String> kv, String key) {
        String s = kv.get(key);
        return s != null && s.equals("true");
    }

    // ---------- math helpers ----------

    static float dist(float x1, float y1, float x2, float y2) {
        return (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }

    static boolean rectsOverlap(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2) {
        return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
    }

    public float getShakeX() { return shakeTimer > 0 ? (float) Math.random() * shakeAmt * 2 - shakeAmt : 0; }
    public float getShakeY() { return shakeTimer > 0 ? (float) Math.random() * shakeAmt * 2 - shakeAmt : 0; }
}