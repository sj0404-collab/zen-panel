package com.elementia.core;

import com.badlogic.gdx.Game;
import com.elementia.ui.Fonts;

/** Elementia - anime Metroidvania. Boots assets and routes screens. */
public class ElementiaGame extends Game {
    public boolean mobile;

    public ElementiaGame() {}
    public ElementiaGame(boolean mobile) { this.mobile = mobile; }

    @Override
    public void create() {
        Assets.init();
        Fonts.init();
        Sfx.init();
        setScreen(new TitleScreen(this));
    }

    public GameScreen newGameScreen(boolean m) { return new GameScreen(this, m); }

    @Override
    public void pause() {
        super.pause();
        Sfx.pauseMusic();
    }

    @Override
    public void resume() {
        super.resume();
        Sfx.resumeMusic();
    }

    @Override
    public void dispose() {
        super.dispose();
        Sfx.dispose();
        Fonts.dispose();
    }
}