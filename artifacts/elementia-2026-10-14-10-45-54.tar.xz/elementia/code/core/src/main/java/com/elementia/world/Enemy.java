package com.elementia.world;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.elementia.core.Assets;
import com.elementia.core.Element;

/**
 * Enemy AI. Variants: floating-slime (bounce toward player), wisp (float), golem (tanky walker).
 */
public class Enemy extends Entity {
    public enum Kind { SLIME, WISP, GOLEM }

    public Kind kind;
    public Element element = Element.ANEMO;
    public float timer;
    float hopTimer;
    float sx0;                // patrol bounds
    float sx1;
    public float homeX, homeY;
    public float anim;
    public boolean angered;
    public float contactDmg = 10f;
    public int scoreGems = 1;

    public Enemy(Kind kind, float x, float y) {
        this(kind, x, y, defaultWidth(kind), defaultHeight(kind));
    }

    public Enemy(Kind kind, float x, float y, float w, float h) {
        super(x, y, w, h);
        this.kind = kind;
        homeX = x;
        homeY = y;
        sx0 = x - 90;
        sx1 = x + 90;
        switch (kind) {
            case SLIME:
                maxHp = 26; hp = 26; contactDmg = 12; scoreGems = 1;
                break;
            case WISP:
                maxHp = 12; hp = 12; contactDmg = 10; scoreGems = 1;
                break;
            case GOLEM:
                maxHp = 160; hp = 160; contactDmg = 20; scoreGems = 3;
                break;
        }
    }

    private static float defaultWidth(Kind kind) {
        switch (kind) {
            case SLIME: return 44f;
            case WISP: return 16f;
            default: return 48f;
        }
    }

    private static float defaultHeight(Kind kind) {
        switch (kind) {
            case SLIME: return 38f;
            case WISP: return 14f;
            default: return 44f;
        }
    }

    public void setBounds(float a, float b) {
        sx0 = Math.min(a, b);
        sx1 = Math.max(a, b);
    }

    public void update(World world, float dt) {
        if (!alive) { tick(dt); return; }
        super.tick(dt);
        anim += dt;
        Player p = world.player;

        switch (kind) {
            case SLIME: updateSlime(world, p, dt); break;
            case WISP: updateWisp(world, p, dt); break;
            case GOLEM: updateGolem(world, p, dt); break;
        }
        updateRect();
    }

    void updateSlime(World world, Player p, float dt) {
        float dx = p.x - x;
        timer -= dt;
        if (Math.abs(dx) < 220f && Math.abs(p.y - y) < 120f) {
            if (timer <= 0) {
                timer = 1.4f;
                facing = dx > 0 ? 1 : -1;
                vx = facing * (110 + (float) Math.random() * 60);
                vy = 260f + (float) Math.random() * 130;
            }
        } else {
            vx *= 0.6f;
        }
        gravityMove(world, dt);
        if (grounded) vy = 0;
    }

    void updateWisp(World world, Player p, float dt) {
        float dx = p.x - x, dy = p.y - y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d < 260f) {
            float sp = 70f;
            vx = dx / Math.max(1, d) * sp;
            vy = dy / Math.max(1, d) * sp + (float) Math.sin(anim * 5f) * 20f;
        } else {
            vx *= 0.9f;
            vy = (float) Math.sin(anim * 2f) * 15f;
        }
        x += vx * dt;
        y += vy * dt;
        facing = dx > 0 ? 1 : -1;
        clampBounds();
    }

    void updateGolem(World world, Player p, float dt) {
        float dx = p.x - x;
        timer -= dt;
        if (Math.abs(p.y - y) < 90f && Math.abs(dx) < 260f) angered = true;
        if (angered) {
            facing = dx > 0 ? 1 : -1;
            if (Math.abs(dx) > 40f) vx = facing * 55f; else vx = 0;
            if (timer <= 0 && Math.abs(dx) < 200f && grounded) {
                timer = 2.2f;
                vy = 620f;
                vx = facing * 230f;
            }
            if (grounded && vy == 0 && timer > 1.9f && timer < 2.0f) {
                world.particles.emitBurst(x + w / 2, y, 0xffc8a04a, 6, 120, 3, 0.4f);
                if (Math.abs(p.x - x) < 70f && p.y - y < 34f) p.applyDamage(18, false, facing * 260f, 260f);
            }
        } else {
            if (Math.abs(x - homeX) > 4) vx = Math.signum(homeX - x) * 30f; else vx = 0;
        }
        gravityMove(world, dt);
        clampBounds();
    }

    void clampBounds() {
        if (x < sx0) { x = sx0; vx = Math.max(0, vx); }
        if (x > sx1) { x = sx1; vx = Math.min(0, vx); }
    }

    void gravityMove(World world, float dt) {
        vy -= world.gravity() * dt;
        if (vy < -world.maxFall()) vy = -world.maxFall();
        x += vx * dt;
        y += vy * dt;
        // horizontal collide
        if (world.solidAt(x + 2, y + 2) || world.solidAt(x + w - 2, y + 2)
         || world.solidAt(x + 2, y + h - 2) || world.solidAt(x + w - 2, y + h - 2)) {
            x -= vx * dt;
            vx *= -0.3f;
        }
        grounded = false;
        float fall = Math.abs(vx) * dt;
        y -= Math.min(fall, 0);
        y += Math.max(0, fall);
        updateRect();
        grounded = world.solidAt(x + 1, y - 2) || world.solidAt(x + w - 1, y - 2)
                || world.platformAt(x + w / 2, y - 2);
    }

    public void render(SpriteBatch batch) {
        switch (kind) {
            case SLIME: renderSlime(batch); break;
            case WISP: renderWisp(batch); break;
            case GOLEM: renderGolem(batch); break;
        }
    }

    void renderSlime(SpriteBatch batch) {
        if (hitFlash > 0) batch.setColor(1.8f, 1.8f, 1.8f, 1);
        else {
            int col = element.bright;
            batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, 1f);
        }
        int idx = (int) ((anim * 2f) % 4);
        float sx = w / 44f * 2f;
        batch.draw(Assets.slimeFrames[idx], x + w / 2 - 22 * sx / 2f, y + (grounded ? 0 : 2), 22 * sx, 22 * sx * (38f / 44f));
        batch.setColor(1, 1, 1, 1);
    }

    void renderWisp(SpriteBatch batch) {
        float kick = (float) Math.sin(anim * 4f) * 2f;
        int col = element.bright;
        batch.setColor(((col >> 16) & 0xff) / 255f, ((col >> 8) & 0xff) / 255f, (col & 0xff) / 255f, 0.95f);
        batch.draw(Assets.wispReg, x - 8, y + kick, 16, 14);
        batch.setColor(1, 1, 1, 1);
    }

    void renderGolem(SpriteBatch batch) {
        float kick = 0;
        batch.setColor(1, 1, 1, 1);
        batch.draw(Assets.golemReg, x + w / 2 - 24, y + kick, 48, 44);
        // amber eyes glow on anger
        if (angeredFlash(batch)) { }
    }

    boolean angeredFlash(SpriteBatch batch) {
        if (angered && anim % 0.5f < 0.25f) {
            batch.setColor(1.4f, 0.9f, 0.8f, 1);
            batch.draw(Assets.golemReg, x + w / 2 - 24, y, 48, 44);
            batch.setColor(1, 1, 1, 1);
            return true;
        }
        return false;
    }

    @Override
    public void onDie() {
        // handled by world for drops
    }
}