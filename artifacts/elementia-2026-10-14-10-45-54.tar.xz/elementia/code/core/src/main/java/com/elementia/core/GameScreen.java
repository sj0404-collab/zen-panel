package com.elementia.core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.elementia.ui.DialogueBox;
import com.elementia.ui.Fonts;
import com.elementia.ui.Hud;
import com.elementia.ui.TouchControls;
import com.elementia.world.Player;
import com.elementia.world.World;

public class GameScreen extends ScreenAdapter {
    final ElementiaGame game;
    public World world;
    SpriteBatch batch;
    OrthographicCamera cam;
    Hud hud;
    DialogueBox dlg;
    TouchControls touch;
    InputState state = new InputState();
    boolean onMobile;
    float dieMsg;
    boolean dialogOpen;
    float camX, camY;
    Preferences prefs;
    boolean inited;

    public GameScreen(ElementiaGame game, boolean mobile) {
        this.game = game;
        this.onMobile = mobile;
    }

    @Override
    public void show() {
        prefs = Gdx.app.getPreferences("elementia-save");
        if (inited) {
            // re-entering from the title screen: re-attach input + music, keep the world
            Gdx.input.setInputProcessor(touch);
            Sfx.startMusic();
            return;
        }
        inited = true;
        if (world == null) {
            world = new World();
            String saved = prefs.getString("save01", "");
            if (!saved.isEmpty()) world.load(saved);
        }
        batch = new SpriteBatch();
        cam = new OrthographicCamera(Config.VIEW_W, Config.VIEW_H);
        cam.position.set(Config.VIEW_W / 2, Config.VIEW_H / 2, 0);
        hud = new Hud();
        dlg = new DialogueBox();
        touch = new TouchControls(state);
        touch.mobile = onMobile;
        Gdx.input.setInputProcessor(touch);
        state.reset();
        Sfx.startMusic();
    }

    @Override
    public void hide() {
        Sfx.stopMusic();
    }

    @Override
    public void render(float dt) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if (world.gameWon && ((!onMobile && Gdx.input.isKeyJustPressed(Input.Keys.ENTER))
                || (onMobile && Gdx.input.justTouched()) || touch.tapConsumed)) {
            game.setScreen(game.newGameScreen(onMobile));
            return;
        }
        dt = Math.min(dt, 0.05f);

        // reflect input into the shared InputState (keyboard and/or touch layer)
        if (!onMobile) updateKbd();
        touch.update();

        if (!dialogOpen) {
            // story intro dialogue on a brand-new game
            if (world.introPending && !dlg.isOpen()) {
                String[] data = World.NPC_TEXT.get("intro");
                if (data != null) dlg.show(data, null);
                world.introPending = false;
                state.reset();
            }
        }

        if (!dialogOpen) {
            world.update(state, dt);
            updateCamera(dt);
        } else {
            dlg.update(dt);
        }
        if (world.saveDirty) {
            prefs.putString("save01", world.save());
            prefs.flush();
            world.saveDirty = false;
        }
        if (dlg.isOpen() && !dialogOpen) { dialogOpen = true; }
        if (!dlg.isOpen() && dialogOpen) {
            dialogOpen = false;
            world.pendingNpc = null;
        }

        if (world.pendingNpc != null && !dlg.isOpen()) {
            String[] data = World.NPC_TEXT.get(world.pendingNpc);
            if (data != null) dlg.show(data, null);
            world.pendingNpc = null;
            state.reset();
        }

        // handle dialogue advance (Z / Enter key or touch anywhere)
        if (dlg.isOpen() && !onMobile && (Gdx.input.isKeyJustPressed(Input.Keys.Z)
                || Gdx.input.isKeyJustPressed(Input.Keys.ENTER))) {
            dlg.advance();
        }
        if (dlg.isOpen() && onMobile && (Gdx.input.justTouched() || touch.tapConsumed)) {
            dlg.advance();
        }
        touch.resetTap();

        if (world.player != null && !world.player.alive) {
            dieMsg = 1.2f;
        }
        if (dieMsg > 0) dieMsg -= dt;

        // transient pressed flags are consumed by the world; clear them once per frame
        state.reset();

        // camera
        cam.update();

        // render world
        batch.setProjectionMatrix(cam.combined);
        float shX = world.getShakeX() + camX;
        float shY = world.getShakeY() + camY;
        batch.begin();
        world.render(batch, shX, shY);
        batch.end();

        // HUD
        hud.render(world, world.time, onMobile);

        // touch controls (visible and mouse-clickable on all platforms)
        if (!dlg.isOpen()) touch.render();

        // dialogue
        dlg.render(world.time);

        if (dieMsg > 0) {
            batch.begin();
            hudDrawDeath();
            batch.end();
        }
    }

    void updateCamera(float dt) {
        Player p = world.player;
        float vx = p.vx;
        // look-ahead scaled by speed so the camera stays tight but leads during dashes
        float look = MathUtils.clamp(vx * 0.14f, -80f, 80f);
        float tx = p.x + p.w / 2 + look - Config.VIEW_W / 2;
        float ty = p.y + p.h / 2 - Config.VIEW_H / 2;
        float t = Math.min(1, dt * Config.CAM_LERP);
        camX = MathUtils.lerp(camX, tx, t);
        camY = MathUtils.lerp(camY, ty, t);
        camX = MathUtils.clamp(camX, 0, World.MW * Config.TILE - Config.VIEW_W);
        camY = MathUtils.clamp(camY, 0, Math.max(0, World.MH * Config.TILE - Config.VIEW_H));
        // camera stays at screen center; the world is offset manually in render()
        cam.position.set(Config.VIEW_W / 2, Config.VIEW_H / 2, 0);
    }

    void updateKbd() {
        state.left = Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT);
        state.right = Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.RIGHT);
        state.jumpHeld = Gdx.input.isKeyPressed(Input.Keys.SPACE);
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) state.jumpPressed = true;
        if (Gdx.input.isKeyJustPressed(Input.Keys.J)) state.attackPressed = true;
        if (Gdx.input.isKeyJustPressed(Input.Keys.K)) state.skillPressed = true;
        if (Gdx.input.isKeyJustPressed(Input.Keys.L)) state.dashPressed = true;
    }

    void hudDrawDeath() {
        batch.setProjectionMatrix(cam.combined);
        Fonts.title.setColor(1f, 0.3f, 0.3f, 1);
        com.badlogic.gdx.graphics.g2d.GlyphLayout gl = new com.badlogic.gdx.graphics.g2d.GlyphLayout(Fonts.title, "ТЫ ПАЛА!");
        Fonts.title.draw(batch, "ТЫ ПАЛА!", Config.VIEW_W / 2 - gl.width / 2, Config.VIEW_H / 2 + 26);
        if (dieMsg < 0.4f) {
            Fonts.dialogue.setColor(1f, 1f, 1f, 1);
            gl.setText(Fonts.dialogue, "Возвращение к точке сохранения...");
            Fonts.dialogue.draw(batch, "Возвращение к точке сохранения...", Config.VIEW_W / 2 - gl.width / 2, Config.VIEW_H / 2 - 14);
        }
    }

    @Override
    public void resize(int width, int height) {
        cam.viewportWidth = Config.VIEW_W;
        cam.viewportHeight = Config.VIEW_H;
        hud.resize(width, height);
        touch.resize(width, height);
        dlg.resize(width, height);
    }

    @Override
    public void dispose() {
        batch.dispose();
        touch.dispose();
        hud.dispose();
        dlg.dispose();
    }
}