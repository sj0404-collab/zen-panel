package com.elementia.core;

/** Frame-by-frame input state shared by keyboard and touch controls. */
public class InputState {
    // continuous
    public boolean left, right, up, down;
    public boolean jumpHeld;

    // edge-triggered (cleared by reset() every frame)
    public boolean jumpPressed;
    public boolean attackPressed;
    public boolean skillPressed;
    public boolean dashPressed;

    public void reset() {
        jumpPressed = false;
        attackPressed = false;
        skillPressed = false;
        dashPressed = false;
    }
}