package com.elementia.core;

/** The seven elements, Genshin-style. Russian names drive the localized UI. */
public enum Element {
    ANEMO(0xff81d4fa, 0xff4fc3f7, "Анемо"),
    PYRO(0xffff8a65, 0xffff7043, "Пиро"),
    CRYO(0xffb3e5fc, 0xff69c0f0, "Крио"),
    HYDRO(0xff4dd0e1, 0xff26abd0, "Гидро"),
    ELECTRO(0xffb39ddb, 0xff9575cd, "Электро"),
    GEO(0xffffd54f, 0xfff0b429, "Гео"),
    DENDRO(0xff66bb6a, 0xff43a047, "Дендро");

    public final int bright;
    public final int deep;
    public final String name;

    Element(int bright, int deep, String name) {
        this.bright = bright;
        this.deep = deep;
        this.name = name;
    }
}