package com.elementia.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;

/**
 * Cyrillic-capable bitmap fonts generated at startup from the bundled
 * DejaVuSans.ttf. libGDX's default BitmapFont only carries Latin glyphs,
 * so all Russian text goes through these.
 */
public final class Fonts {
    private Fonts() {}

    private static FreeTypeFontGenerator gen;

    public static BitmapFont hud;         // HUD labels ~ 24px
    public static BitmapFont small;       // hints ~ 18px
    public static BitmapFont dialogue;    // dialogue box ~ 26px
    public static BitmapFont controls;    // touch button labels ~ 20px
    public static BitmapFont title;       // title screen ~ 54px
    public static BitmapFont titleSmall;  // subtitle ~ 28px

    /** Letters used across all Russian text in the game. */
    private static final String RU =
        "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
      + "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
      + "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
      + "0123456789.,!?:;«»—()+-%/=…“”'\"";

    public static void init() {
        gen = new FreeTypeFontGenerator(Gdx.files.internal("fonts/DejaVuSans.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter p;

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 24;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU;
        hud = gen.generateFont(p);

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 18;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU;
        small = gen.generateFont(p);

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 26;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU + "▼►";
        dialogue = gen.generateFont(p);

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 20;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU;
        controls = gen.generateFont(p);

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 54;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU;
        title = gen.generateFont(p);

        p = new FreeTypeFontGenerator.FreeTypeFontParameter();
        p.size = 28;
        p.characters = FreeTypeFontGenerator.DEFAULT_CHARS + RU;
        titleSmall = gen.generateFont(p);
    }

    public static void dispose() {
        if (gen != null) gen.dispose();
        gen = null;
        hud = small = dialogue = controls = title = titleSmall = null;
    }
}