package com.elementia.desktop;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Window;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3WindowListener;
import com.elementia.core.ElementiaGame;
import com.elementia.core.Sfx;

public class DesktopLauncher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration cfg = new Lwjgl3ApplicationConfiguration();
        cfg.setTitle("Elementia");
        cfg.setWindowedMode(1280, 720);
        cfg.setResizable(true);
        cfg.useVsync(true);
        cfg.setForegroundFPS(60);
        cfg.setWindowListener(new Lwjgl3WindowListener() {
            @Override
            public void created(Lwjgl3Window window) {}
            @Override
            public void iconified(boolean iconified) {}
            @Override
            public void maximized(boolean maximized) {}
            @Override
            public void focusLost() { Sfx.pauseMusic(); }
            @Override
            public void focusGained() { Sfx.resumeMusic(); }
            @Override
            public boolean closeRequested() { return true; }
            @Override
            public void filesDropped(String[] files) {}
            @Override
            public void refreshRequested() {}
        });
        new Lwjgl3Application(new ElementiaGame(false), cfg);
    }
}