package com.elementia.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.headless.HeadlessApplication;
import com.badlogic.gdx.backends.headless.HeadlessApplicationConfiguration;
import com.elementia.core.InputState;
import com.elementia.ui.TouchControls;
import com.elementia.world.Player;
import com.elementia.world.World;

/**
 * Headless smoke test: boots the world, simulates a few seconds,
 * verifies basic integrity without GL rendering.
 */
public class HeadlessTest {
    static volatile boolean done;
    static volatile boolean pass;

    public static void main(String[] args) throws Exception {
        System.out.println("=== Elementia Headless Test ===");
        HeadlessApplicationConfiguration cfg = new HeadlessApplicationConfiguration();
        cfg.updatesPerSecond = 60;

        done = false;
        pass = false;

        new HeadlessApplication(new com.badlogic.gdx.ApplicationAdapter() {
            @Override
            public void create() {
                try {
                    // skip texture init (no real GL)
                    System.out.println("Building world...");
                    World w = new World();
                    System.out.println("  World: " + World.MW + "x" + World.MH + " tiles");

                    Player p = w.player;
                    assert p != null : "Player is null";
                    assert p.hp > 0 : "Player HP=" + p.hp;
                    assert p.alive : "Player dead at start";
                    System.out.println("  Player: pos=(" + String.format("%.0f,%.0f", p.x, p.y)
                            + ") hp=" + p.hp + " abilities=" + p.abilities);

                    // simulate 2 seconds with right arrow held
                    InputState in = new InputState();
                    in.right = true;
                    float simTime = 2f;
                    for (int i = 0; i < (int) (simTime * 60); i++) {
                        w.update(in, 1 / 60f);
                        in.reset();
                        in.right = true; // hold right
                        if (i % 30 == 0) System.out.println("  t=" + String.format("%.1f", i / 60f)
                                + " pos=(" + String.format("%.0f,%.0f", p.x, p.y)
                                + ") grounded=" + p.grounded + " vy=" + String.format("%.0f", p.vy)
                                + " tileBelow=" + w.tileAt(p.x + p.w / 2, p.y - 2));
                    }
                    System.out.println("  After " + simTime + "s: pos=(" + String.format("%.0f,%.0f", p.x, p.y) + ")");
                    assert p.x > 12 * 32 : "Player didn't move right";
                    assert p.alive : "Player died during simulation";
                    assert w.enemies.size() > 0 : "No enemies spawned";
                    assert w.gates.size() > 0 : "No gates";
                    assert w.waypoints.size() > 0 : "No waypoints";

                    // test jump
                    InputState jumpIn = new InputState();
                    jumpIn.jumpPressed = true;
                    jumpIn.jumpHeld = true;
                    jumpIn.right = false;
                    w.update(jumpIn, 1 / 60f);
                    for (int i = 0; i < 30; i++) {
                        w.update(jumpIn, 1 / 60f);
                        jumpIn.reset();
                        jumpIn.jumpHeld = true;
                    }
                    System.out.println("  After jump: pos=(" + String.format("%.0f,%.0f", p.x, p.y) + ")");

                    // save/load round-trip
                    String data = w.save();
                    assert data != null && !data.isEmpty() && data.contains(";ab:") : "save() format broken";
                    float sx = p.x, sy = p.y, shp = p.hp;
                    p.setPos(100, 100);
                    w.load(data);
                    assert Math.abs(p.x - sx) < 1 : "save/load x mismatch (" + p.x + " vs " + sx + ")";
                    assert Math.abs(p.y - sy) < 1 : "save/load y mismatch (" + p.y + " vs " + sy + ")";
                    assert Math.abs(p.hp - shp) < 1 : "save/load hp mismatch";
                    System.out.println("  Save/load round-trip OK");

                    // NPC dialogue should fire once per approach, not every frame
                    {
                        World wn = new World();
                        Player pn = wn.player;
                        pn.setPos(14 * com.elementia.core.Config.TILE, wn.tileToWorldY(28));
                        InputState idle = new InputState();
                        wn.update(idle, 1 / 60f);
                        assert "elder".equals(wn.pendingNpc) : "pendingNpc not set near elder NPC, got=" + wn.pendingNpc;
                        wn.pendingNpc = null; // dialogue shown & closed
                        for (int i = 0; i < 120; i++) {
                            wn.update(idle, 1 / 60f);
                        }
                        assert wn.pendingNpc == null : "NPC dialogue re-triggered while standing in range";
                        System.out.println("  NPC dialogue is one-shot: OK");
                    }

                    // Touch controls: pressed flags must be edge-triggered, jump must produce jumpPressed
                    {
                        InputState t = new InputState();
                        TouchControls tc = new TouchControls(t);
                        tc.mobile = true;
                        tc.resize(1280, 720); // uiScale = min(1280,720)/540 = 1.333
                        tc.update();
                        assert !t.jumpPressed && !t.attackPressed : "baseline pressed flags not clear";

                        // scaled button centers (screen coords, y from bottom) for the medium buttons:
                        // jump (w-160*1.333, 170*1.333) = (1066.7, 226.7) -> screen (1067, 493)
                        tc.touchDown(1067, 493, 0, 0);
                        tc.update();
                        assert t.jumpHeld : "touch jumpHeld not set";
                        assert t.jumpPressed : "touch jumpPressed not set on press";
                        tc.update(); // still held: must NOT re-fire
                        assert !t.jumpPressed : "touch jumpPressed re-fires while held";
                        tc.touchUp(1067, 493, 0, 0);
                        tc.update();
                        assert !t.jumpHeld : "touch jumpHeld stuck after release";

                        // attack (w-100*1.333, 110*1.333) = (1146.7, 146.7) -> screen (1147, 573)
                        tc.touchDown(1147, 573, 1, 0);
                        tc.update();
                        assert t.attackPressed : "touch attackPressed not set on press";
                        tc.update();
                        assert !t.attackPressed : "touch attackPressed re-fires while held";
                        tc.touchUp(1147, 573, 1, 0);
                        tc.update();
                        assert !t.attackPressed : "touch attackPressed stuck after release";

                        // dash (w-60*1.333, 190*1.333) = (1200, 253.3) -> screen (1200, 467)
                        tc.touchDown(1200, 467, 2, 0);
                        tc.update();
                        assert t.dashPressed : "touch dashPressed not set on press";
                        tc.touchUp(1200, 467, 2, 0);
                        tc.update();
                        System.out.println("  Touch controls edge-triggering: OK");
                    }

                    // Audio must not crash on the headless backend (Gdx.audio == null)
                    {
                        com.elementia.core.Sfx.init();
                        com.elementia.core.Sfx.play("jump");
                        com.elementia.core.Sfx.startMusic();
                        System.out.println("  Sfx safely no-ops headless: OK");
                    }

                    System.out.println("  All assertions passed: TEST PASSED");
                    pass = true;
                } catch (Throwable t) {
                    System.err.println("TEST FAILED: " + t.getMessage());
                    t.printStackTrace();
                } finally {
                    done = true;
                    try { Gdx.app.exit(); } catch (Exception ignored) {}
                }
            }

            @Override
            public void render() {}
        }, cfg);

        for (int i = 0; i < 15000 && !done; i++) Thread.sleep(10);
        if (!done) { System.err.println("TEST TIMED OUT"); }
        System.exit(pass ? 0 : 1);
    }
}