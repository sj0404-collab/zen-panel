#!/usr/bin/env bash
#
# Build a tagged Elementia release APK.
#
# Usage:
#   tools/release.sh                # bump minor version (x.y -> x.(y+1))
#   tools/release.sh 1.6.0          # explicit version name
#
# Bumps versionCode/versionName in android/build.gradle, commits them,
# tags v<version>, builds the signed release APK and pushes tag + branch.
# Release signing uses android/keystore.properties (gitignored); CI restores
# the same keys from GitHub secrets. On tag push, .github/workflows/release.yml
# rebuilds the APK and publishes a GitHub Release.

set -euo pipefail
cd "$(dirname "$0")/.."

if [ -z "$(git config user.email)" ]; then
    git config user.name "elementia dev"
    git config user.email "dev@elementia.local"
fi

BG="android/build.gradle"

vc=$(sed -nE "s/.*versionCode ([0-9]+).*/\1/p" "$BG")
vn=$(sed -nE "s/.*versionName '([^']+)'.*/\1/p" "$BG")
new_vc=$((vc + 1))

if [ "$#" -ge 1 ]; then
    new_vn="$1"
else
    if [[ "$vn" =~ ^[0-9]+\.[0-9]+$ ]]; then
        new_vn="${vn%.*}.$(( ${vn##*.} + 1 ))"
    else
        new_vn="${vn%.*.*}.$(( ${vn##*.} + 1 ))"
    fi
fi
tag="v$new_vn"

echo "Release: $vn (code $vc) -> $new_vn (code $new_vc), tag $tag"

if ! git diff --quiet -- android/build.gradle; then
    echo "error: android/build.gradle has uncommitted changes; commit them first" >&2
    exit 1
fi

sed -i "s/versionCode $vc/versionCode $new_vc/; s/versionName '$vn'/versionName '$new_vn'/" "$BG"

git add "$BG"
git commit -m "release: $new_vn" >/dev/null
git tag "$tag"

./gradlew :android:assembleRelease

echo ""
echo "Tag: $tag"
echo "APK: android/build/outputs/apk/release/android-release.apk"
echo "Pushing branch + tag..."
git push origin HEAD
git push origin "$tag"