#!/usr/bin/env python3
"""
Regenerate Elementia's art assets through the Pollinations AI image API.

Each asset is drawn from a text prompt, then post-processed:

  * "tile"  -> opaque 256x256 seamless square tile
  * "green" -> sprite on a green(ish) background, keyed by colour distance,
               biggest-connected-component clean-up, then fitted to the canvas
               the game actually draws (so no runtime stretching)
  * "white" -> same pipeline but keyed on a pure-white background (models obey
               "white background" more reliably, good for props)

The game loads these files from "art/" and falls back to the procedural art
when a file is missing or the background turned out untrustworthy, so nothing
ever breaks if this script can not be re-run.

Usage:
    python3 tools/refresh_assets.py            # regenerate everything
    python3 tools/refresh_assets.py hero boss  # only specific assets
"""

import io
import os
import sys
import time
import urllib.parse
import urllib.request

import numpy as np
from PIL import Image

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "core", "src", "main", "resources", "art")
BASE_URL = "https://image.pollinations.ai/prompt/"

STYLE = "2D game asset, anime cel-shaded style, flat clean colors, crisp outlines, no text, no watermark"

# name -> (prompt, mode, bg)
# mode: "tile" | "sprite" | "wide"
# bg:   "tile" | "green" | "white"   (only for sprite/wide)
ASSETS = {
    # ---- environment tiles (opaque, seamless) ----
    "grass": (
        "seamless tileable top-down grass tile texture for a 2D platformer, "
        "lush green meadow grass with tiny flowers, gentle light and shade, " + STYLE,
        "tile", "tile"),
    "dirt": (
        "seamless tileable top-down dirt tile texture for a 2D platformer underground, "
        "brown crumbly earth with pebbles and small roots, " + STYLE,
        "tile", "tile"),
    "stone": (
        "seamless tileable top-down cave stone tile texture for a 2D platformer, "
        "grey blue slate flagstones with moss in the cracks, " + STYLE,
        "tile", "tile"),
    "ice": (
        "seamless tileable top-down ice tile texture for a 2D platformer frost shrine, "
        "pale blue translucide ice with white frost cracks and sparkles, " + STYLE,
        "tile", "tile"),
    "snow": (
        "seamless tileable top-down snow tile texture for a 2D platformer, "
        "soft white snow with gentle blue shaded undulations, " + STYLE,
        "tile", "tile"),
    "brick": (
        "seamless tileable top-down red brick floor tile texture for a 2D platformer "
        "castle boss arena, dark mortar joints, " + STYLE,
        "tile", "tile"),
    "lavaA": (
        "seamless tileable top-down molten lava tile texture for a 2D platformer volcano, "
        "glowing orange lava with dark cracked crust floating on top, " + STYLE,
        "tile", "tile"),
    "lavaB": (
        "seamless tileable top-down molten lava tile texture for a 2D platformer volcano, "
        "bright bubbling lava with red hot channels, second frame, " + STYLE,
        "tile", "tile"),
    "water": (
        "seamless tileable top-down water tile texture for a 2D platformer lake, "
        "clear blue water with soft ripples and reflections, " + STYLE,
        "tile", "tile"),
    "crystal": (
        "seamless tileable crystal gemstone block tile texture for a 2D platformer, "
        "glowing amber yellow crystal cluster with dark stone gaps, " + STYLE,
        "tile", "tile"),
    # ---- one-way wooden platform (keyed wide slab) ----
    "platform": (
        "single horizontal wooden plank platform prop for a 2D platformer, "
        "woven brown planks with rope and nails, side view slab, " + STYLE,
        "wide", "green"),

    # ---- background props (keyed sprites) ----
    "tree": (
        "single flat cartoon green tree sticker with round fluffy canopy and brown "
        "trunk, plain icon, " + STYLE,
        "sprite", "green"),
    "chest": (
        "single game prop sprite of a small wooden treasure chest, gold trim, glowing "
        "open lid, centered, " + STYLE,
        "sprite", "white"),

    # ---- characters / monsters (keyed sprites) ----
    "hero": (
        "full body anime chibi heroine game character, silver-white bob haircut, "
        "light blue dress, golden belt, big aqua eyes, short sword in hand, "
        "standing centered, " + STYLE,
        "sprite", "green"),
    "slime": (
        "cute white translucent slime blob enemy with glossy highlight and simple "
        "cute face, soft squishy gel body, " + STYLE,
        "sprite", "green"),
    "wisp": (
        "luminous white wisp spirit orb with wavy flame wings and soft glow, "
        "2D game enemy, floating, " + STYLE,
        "sprite", "green"),
    "golem": (
        "chunky golden crystal rock golem monster with glowing amber core gem and "
        "stone fists, 2D game miniboss, " + STYLE,
        "sprite", "green"),
    "boss": (
        "huge fire lion monster boss with orange flame mane and curved horns, "
        "fierce roaring, 2D game boss sprite, " + STYLE,
        "sprite", "white"),
    "waypoint": (
        "single game prop sticker of a grey stone save statue pedestal with floating "
        "glowing golden orb, centered, " + STYLE,
        "sprite", "green"),
}

KEY_GREEN = " the subject fills most of the frame, uniform solid lime green "
KEY_GREEN += "background #00FF00, no scenery, no ground, no shadow, no text"
KEY_WHITE = " the subject fills most of the frame, isolated on a flat pure white "
KEY_WHITE += "background, no scenery, no ground, no shadow, no text, no watermark"

TILE_DONE = "tile"


def fetch(prompt, tries=6):
    url = BASE_URL + urllib.parse.quote(prompt)
    for attempt in range(1, tries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "elementia-assets/1.0"})
            with urllib.request.urlopen(req, timeout=180) as r:
                data = r.read()
            if data[:3] == b"\xff\xd8\xff":
                return data
            txt = data[:200].decode("utf-8", "replace")
            print(f"    bad response ({len(data)}B): {txt}", flush=True)
        except Exception as e:
            print(f"    try {attempt}/{tries}: {e}", flush=True)
        time.sleep(6 * attempt)
    return None


def load_rgb(data):
    return Image.open(io.BytesIO(data)).convert("RGB")


def largest_component(mask):
    """Return only the biggest 8-connected component of a boolean mask."""
    idx = np.argwhere(mask)
    if idx.size == 0:
        return mask
    h, w = mask.shape
    parent = list(np.arange(h * w))
    size = [1] * (h * w)

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return
        if size[ra] < size[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        size[ra] += size[rb]

    px, py = idx[:, 0], idx[:, 1]
    for k in range(len(px)):
        x, y = int(px[k]), int(py[k])
        base = x * w + y
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < h and 0 <= ny < w and mask[nx, ny]:
                    union(base, nx * w + ny)

    root_sizes = {}
    for k in range(len(px)):
        r = find(int(px[k]) * w + int(py[k]))
        root_sizes[r] = root_sizes.get(r, 0) + 1
    best = max(root_sizes, key=root_sizes.get)
    best_mask = np.zeros((h, w), dtype=bool)
    for k in range(len(px)):
        if find(int(px[k]) * w + int(py[k])) == best:
            best_mask[int(px[k]), int(py[k])] = True
    return best_mask


def key_bg(img):
    """
    Turn a near-uniform background (whatever hue the model produced) into
    transparency by colour distance to the border colour. Returns an RGBA
    image, or None when the background does not look uniform enough to key
    reliably (caller then keeps the procedural asset).
    """
    arr = np.asarray(img).astype(np.int16)
    h, w = arr.shape[:2]
    m = max(6, h // 16)
    border = np.concatenate([arr[:m].reshape(-1, 3),
                             arr[-m:].reshape(-1, 3),
                             arr[:, :max(2, w // 24)].reshape(-1, 3),
                             arr[:, -max(2, w // 24):].reshape(-1, 3)])
    ref = np.median(border, axis=0)
    std = border.std(axis=0).mean()
    if std > 26:
        return None

    dist = np.linalg.norm(arr - ref, axis=2)
    threshold = max(54, std * 5 + 22)
    alpha = np.clip((dist - threshold) / 26.0, 0.0, 1.0) * 255
    alpha = alpha.astype(np.uint8)

    subject = largest_component(alpha > 60)
    if subject.mean() < 0.008 or subject.mean() > 0.92:
        return None
    alpha = np.where(subject, alpha, 0).astype(np.uint8)

    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    spill = (dist < threshold + 60) & (alpha > 0)
    avg = ((r + b) / 2).astype(np.int16)
    return Image.fromarray(np.dstack([
        np.where(spill, (r * 0.5 + avg * 0.5).astype(np.int16), r).clip(0, 255),
        np.where(spill, (g * 0.5 + avg * 0.5).astype(np.int16), g).clip(0, 255),
        np.where(spill, (b * 0.5 + avg * 0.5).astype(np.int16), b).clip(0, 255),
        alpha]).astype(np.uint8), "RGBA")


def key_white(img):
    """
    Key a pure-white (or near-white) background out. White = high luminance,
    low saturation, so the subject's own saturation keeps it intact.
    """
    arr = np.asarray(img).astype(np.int16)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    lo = np.minimum(np.minimum(r, g), b)
    hi = np.maximum(np.maximum(r, g), b)
    sat = hi - lo
    # alpha ramps 0 (distinctly white) -> 255 (subject) across the range lo 220..180
    alpha = np.clip((220 - lo) / 40.0, 0.0, 1.0)
    alpha = np.where(sat > 55, 1.0, alpha)  # colourful pixels are never background
    alpha = (alpha * 255).astype(np.uint8)

    subject = largest_component(alpha > 80)
    if subject.mean() < 0.008 or subject.mean() > 0.92:
        return None
    alpha = np.where(subject, alpha, 0).astype(np.uint8)
    return Image.fromarray(np.dstack([r.clip(0, 255), g.clip(0, 255), b.clip(0, 255), alpha]).astype(np.uint8), "RGBA")


def crop_to_alpha(img, margin=8):
    a = np.asarray(img)[..., 3]
    ys, xs = np.where(a > 40)
    if ys.size == 0:
        return None
    x0, x1 = xs.min(), xs.max()
    y0, y1 = ys.min(), ys.max()
    x0 = max(0, x0 - margin)
    y0 = max(0, y0 - margin)
    x1 = min(img.width, x1 + margin)
    y1 = min(img.height, y1 + margin)
    return img.crop((x0, y0, x1, y1))


# in-game drawing size per sprite -> aspect ratio width/height
DRAW_ASPECT = {
    "hero": 56 / 76.0,
    "boss": 88 / 76.0,
    "golem": 48 / 44.0,
    "slime": 44 / 38.0,
    "wisp": 48 / 40.0,
    "waypoint": 40 / 56.0,
    "tree": 32 / 48.0,
    "chest": 28 / 24.0,
}


def fit_ratio(img, ratio, size=512):
    """
    Resize keeping aspect, then pad transparent so the canvas has the same
    width:height `ratio` the game draws this sprite with.
    """
    w, h = img.size
    scale = min(size / w, (size / ratio) / h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    cw = max(1, round(size)) if ratio >= 1 else max(1, round(size * ratio))
    ch = max(1, round(size / ratio)) if ratio >= 1 else max(1, round(size))
    canvas = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    canvas.paste(img, ((cw - nw) // 2, (ch - nh) // 2), img)
    return canvas


def process(name, mode, bg, data):
    img = load_rgb(data)
    if mode == TILE_DONE:
        return img.convert("RGB").resize((256, 256), Image.LANCZOS).convert("RGBA")

    rgba = key_white(img) if bg == "white" else key_bg(img)
    if rgba is None:
        print("    background not uniform - keeping procedural fallback", flush=True)
        return None
    subject = crop_to_alpha(rgba)
    if subject is None:
        return None

    if mode == "wide":
        w, h = subject.size
        target = 16 / 7.0
        if w / h > target:
            band_h = int(w / target)
            y0 = max(0, (h - band_h) // 2)
            subject = subject.crop((0, y0, w, min(h, y0 + band_h)))
        else:
            need_w = int(h * target)
            canvas = Image.new("RGBA", (need_w, h), (0, 0, 0, 0))
            canvas.paste(subject, ((need_w - w) // 2, 0), subject)
            subject = canvas
        return subject.resize((512, 224), Image.LANCZOS)

    ratio = DRAW_ASPECT.get(name, 1.0)
    return fit_ratio(subject, ratio, 512)


def main():
    only = set(sys.argv[1:])
    jobs = [(n, ASSETS[n]) for n in ASSETS if not only or n in only]
    os.makedirs(OUT_DIR, exist_ok=True)

    ok, failed = [], []
    for name, (prompt, mode, bg) in jobs:
        suffix = TILE_DONE if mode == "tile" else (KEY_WHITE if bg == "white" else KEY_GREEN)
        print(f"[{name}] fetching...", flush=True)
        data = fetch(prompt + suffix)
        if data is None:
            print("  FAILED fetch - keeping procedural fallback", flush=True)
            failed.append(name)
            continue
        out = process(name, mode, bg, data)
        if out is None:
            print("  FAILED post-process - keeping procedural fallback", flush=True)
            failed.append(name)
            continue
        path = os.path.join(OUT_DIR, name + ".png")
        out.save(path)
        print(f"  saved {os.path.relpath(path, os.path.dirname(OUT_DIR))} "
              f"({out.size[0]}x{out.size[1]} mode={mode}/bg={bg})", flush=True)
        ok.append(name)
        time.sleep(2)

    print(f"\nDone: {len(ok)} ok, {len(failed)} failed.")
    for f in failed:
        print(f"  missing (procedural fallback used): {f}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())