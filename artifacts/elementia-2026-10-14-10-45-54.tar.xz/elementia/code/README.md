# Elementia

A compact anime-style Metroidvania for Android, built with [LibGDX](https://libgdx.com/).
Play as the heroine **Aria**, explore four elemental zones, unlock abilities and
defeat the Ice Lion.

## Zones & progression

| Area       | Theme    | Gating ability            |
|------------|----------|---------------------------|
| Meadow      | grass/sky | DASH (start)             |
| Cavern      | stone     | PYRO (chest) → burns vine |
| Frost Shrine| ice/snow  | CRYO (chest) → melts frost |
| Sanctum     | boss arena| DOUBLE_JUMP + BURST (boss)|

Combos, dash, elemental skill shots and reactions (vaporize ×1.6, melt ×2,
swirl ×1.3) are all in. One-way platforms, checkpoints (waypoint statues),
dialogue NPCs and auto-save included.

## Modules

- `core`    – game logic + art (Pollinations AI sprites/tiles optional,
  procedural fallback, see `tools/refresh_assets.py`)
- `desktop` – desktop backend for local testing
- `android` – Android application module
- `test`    – headless smoke tests

## Requirements

- JDK 17
- Android SDK (compileSdk 34, build-tools 35.0.0, minSdk 24)

## Build

```bash
# compile + headless test
./gradlew core:compileJava :test:run

# desktop launcher
./gradlew :desktop:run

# Android debug APK
./gradlew :android:assembleDebug
# output: android/build/outputs/apk/debug/android-debug.apk
```

> If the project ships `local.properties` it already contains your SDK path;
> otherwise create it with `sdk.dir=/path/to/android-sdk`.

## Controls

| Desktop                     | Touch (Android)             |
|-----------------------------|-----------------------------|
| WASD/arrows move            | Left/right on-screen pad    |
| SPACE jump (×2)             | Jump/skill buttons          |
| J attack (3-hit)            | Attack button               |
| K elemental skill           | Element switch via HUD      |
| L dash                      | Dash button                 |

The on-screen pad and buttons are visible on every platform (mouse-clickable on
desktop), and the in-game hints adjust to the platform automatically.

## Art assets

Environment tiles, characters and props are drawn by Pollinations AI
(`tools/refresh_assets.py` regenerates them into `core/src/main/resources/art/`)
and smoothed at render time. Any asset that is missing or failed to generate
cleanly falls back to the built-in procedural cel-shaded art, so the game
always runs offline.

## Render modes & audio

- **Visual modes** — cycle with `P` or the round **MODE** button (top right):
  `2D` (flat, no parallax) → `2.5D` (default: parallax ridges + zone fog +
  vignette) → `3D` (deeper parallax, zoomed-out pseudoperspective, handheld sway).
  The active mode is shown in the top-center HUD badge.
- **Sound & music** — all audio is synthesized at first launch (no asset files):
  music loops in the game screen, and one-shot effects cover jump, double-jump,
  dash, slash, melee/projectile hits, enemy death, skill shots, burst nova,
  chests, waypoints, burning/melting gates, NPC chatter, boss roar and victory.
  WAV files are cached under `audio/` in the local storage. On headless runs all
  audio calls are no-ops.