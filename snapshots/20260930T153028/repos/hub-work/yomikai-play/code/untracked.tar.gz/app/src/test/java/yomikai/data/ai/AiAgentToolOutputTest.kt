package yomikai.data.ai

import io.kotest.matchers.shouldBe
import io.kotest.matchers.string.shouldContain
import org.junit.jupiter.api.Test

/**
 * Что агент показывает модели и что от неё прячет.
 *
 * Три правила, которые вытащили из реальных поломок:
 *  • результат любого инструмента резался до 700 символов МОЛЧА — модель
 *    считала, что файл прочитан целиком, и либо выдумывала вторую половину,
 *    либо звала инструмент заново;
 *  • `providers/*.json` читались агентом дословно, а `plugin_create` с
 *    `kind=http` умеет отправить что угодно на любой хост — вместе это давало
 *    утечку ключа по цепочке из прочитанной страницы;
 *  • блок знаний о книге уходил в каждый вызов целиком.
 */
class AiAgentToolOutputTest {

    @Test
    fun `a short result is passed through untouched`() {
        AiAgent.toolOutputFor("read_file", "Город сегодня") shouldBe "read_file: Город сегодня"
    }

    @Test
    fun `a long result is cut and says so`() {
        val long = "я".repeat(50_000)
        val shown = AiAgent.toolOutputFor("read_file", long)

        shown.contains("обрезано") shouldBe true
        shown.contains("из 50000 символов") shouldBe true
        // Обрезка не должна раздувать вывод: бюджет 8000 плюс объявление.
        (shown.length < 9_000) shouldBe true
        shown.contains(long.take(7_900)) shouldBe true
    }

    @Test
    fun `web results get a smaller budget than file reads`() {
        val text = "я".repeat(50_000)
        (AiAgent.toolOutputFor("web_fetch", text).length <
            AiAgent.toolOutputFor("read_file", text).length) shouldBe true
    }

    @Test
    fun `unknown tools still get a budget instead of a silent cut`() {
        AiAgent.toolOutputFor("some_new_tool", "я".repeat(9_000)).contains("обрезано") shouldBe true
    }

    @Test
    fun `provider files are closed for the agent`() {
        AiAgent.secretGuard("providers/openrouter.json") shouldContain "ОТКАЗ"
        AiAgent.secretGuard("./providers/x.json") shouldContain "ОТКАЗ"
        AiAgent.secretGuard("books/providers.json") shouldContain "ОТКАЗ"
    }

    @Test
    fun `ordinary workspace files stay readable`() {
        AiAgent.secretGuard("books/1.json") shouldBe null
        AiAgent.secretGuard("notes.md") shouldBe null
        // Похожее имя, но не папка ключей.
        AiAgent.secretGuard("providers.md") shouldBe null
    }

    @Test
    fun `api keys are redacted from any text shown to the model`() {
        val json = """{"id":"openrouter","baseUrl":"https://x","apiKey":"sk-or-v1-abcdef123456"}"""
        val shown = AiAgent.redactSecrets(json)

        shown.contains("sk-or-v1-abcdef123456") shouldBe false
        shown.contains("скрыто агентом") shouldBe true
        shown.contains("openrouter") shouldBe true
    }

    @Test
    fun `redaction leaves ordinary json alone`() {
        val json = """{"title":"Город","count":3}"""
        AiAgent.redactSecrets(json) shouldBe json
    }

    @Test
    fun `the book knowledge budget is bounded`() {
        // Правило книги — до 6000 символов, правил бывает 120: без потолка блок
        // знаний уезжал на десятки тысяч токенов в КАЖДЫЙ вызов модели.
        BookKnowledge.MAX_RENDER_CHARS shouldBe 4_000
        (BookKnowledge.MAX_RENDER_CHARS < 6_000) shouldBe true
    }
}
