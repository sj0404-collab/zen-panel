package yomikai.data.ai

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/**
 * Разбор вызовов инструментов.
 *
 * Скрин: модель писала канонический однострочный `@tool web_search {"query":"x"}`
 * и получала в ответ «НЕ ВЫПОЛНЕНО: тот же вызов уже выполнялся в этом ходе».
 * Причина была не в модели: каноническую строку находили ДВА парсера (по
 * маркеру `@tool` и построчный), она попадала в список вызовов дважды, а цикл
 * хода отдавал модели второй как повтор — про вызов, который как раз
 * выполнился.
 *
 * Здесь проверяется чистое правило: одинаковые вызовы схлопываются по
 * подписи, а порядок аргументов в JSON на подпись не влияет.
 */
class AiAgentToolCallParsingTest {

    private val known = listOf("web_search", "web_fetch", "read_file", "turn_page")

    private fun parse(text: String) = AiAgent.parseToolCallsIn(known, text)

    @Test
    fun `a canonical one-line call is parsed once`() {
        val calls = parse("""@tool web_search {"query":"свалка"}""")
        assertEquals(1, calls.size)
        assertEquals("web_search", calls[0].name)
        assertEquals("свалка", calls[0].args.optString("query"))
    }

    @Test
    fun `a call without the tool keyword and without at is still parsed`() {
        assertEquals(1, parse("""@web_fetch {"url":"https://example.com"}""").size)
        assertEquals(1, parse("""read_file {"path":"a.txt"}""").size)
    }

    @Test
    fun `a call in backticks is parsed`() {
        val calls = parse("""сделаю так: `@tool turn_page {"to":"next"}`""")
        assertEquals(1, calls.size)
        assertEquals("turn_page", calls[0].name)
    }

    @Test
    fun `a multiline call is parsed`() {
        val calls = parse(
            """
            @tool web_fetch {
              "url": "https://example.com/a",
              "chars": 12000
            }
            """.trimIndent(),
        )
        assertEquals(1, calls.size)
        assertEquals("https://example.com/a", calls[0].args.optString("url"))
        assertEquals(12000, calls[0].args.optInt("chars"))
    }

    @Test
    fun `an xml-style call is parsed`() {
        val calls = parse(
            "<tool_call>web_search<arg_key>query</arg_key><arg_value>сакура</arg_value></tool_call>",
        )
        assertEquals(1, calls.size)
        assertEquals("web_search", calls[0].name)
        assertEquals("сакура", calls[0].args.optString("query"))
    }

    @Test
    fun `a call without arguments is parsed as an empty object`() {
        val calls = parse("@tool turn_page")
        assertEquals(1, calls.size)
        assertTrue(calls[0].args.length() == 0)
    }

    @Test
    fun `an unknown tool name is ignored`() {
        assertTrue(parse("""@tool rm_rf_slash {}""").isEmpty())
        // Имя известно, но аргументы не разобрались — вызова нет.
        assertTrue(parse("""@tool web_search {это не json}""").isEmpty())
    }

    @Test
    fun `different calls in one answer are all kept in order`() {
        val calls = parse(
            """
            @tool web_search {"query":"раз"}
            @tool web_search {"query":"два"}
            """.trimIndent(),
        )
        assertEquals(listOf("раз", "два"), calls.map { it.args.optString("query") })
    }

    @Test
    fun `the same call written twice is parsed once`() {
        // Ровно тот случай из бага: два парсера нашли одну и ту же строку.
        val calls = parse(
            """
            @tool web_search {"query":"раз"}
            @tool web_search {"query":"раз"}
            """.trimIndent(),
        )
        assertEquals(1, calls.size)
    }

    @Test
    fun `argument order does not change the call identity`() {
        val first = AiAgent.ToolCall(
            "web_fetch",
            org.json.JSONObject("""{"url":"https://a","chars":10}"""),
        )
        val second = AiAgent.ToolCall(
            "web_fetch",
            org.json.JSONObject("""{"chars":10,"url":"https://a"}"""),
        )
        assertEquals(AiAgent.callSignature(first), AiAgent.callSignature(second))
    }
}
