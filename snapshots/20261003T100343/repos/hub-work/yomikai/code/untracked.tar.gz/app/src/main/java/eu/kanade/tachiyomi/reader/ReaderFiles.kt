package eu.kanade.tachiyomi.reader

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Доступ к файлам приложения для приложения читалки.
 *
 * Отдельное приложение не видит приватные файлы Yomikai, а передать можно
 * только ссылку, на которую у Yomikai есть разрешение. Поэтому для файлов из
 * собственных каталогов заводится провайдер: он отдаёт ссылку
 * `content://<authority>/file/<корень>/<путь>`, а раздать её другому
 * приложению можно одним флагом FLAG_GRANT_READ_URI_PERMISSION.
 *
 * Провайдер отдаёт только то, что лежит внутри каталогов самого приложения.
 * Никаких «абсолютных путей от корня»: путь проверяется по префиксу корня, и
 * всё, что выходит за него, считается отсутствующим.
 */
object ReaderFiles {

    private const val AUTHORITY_SUFFIX = ".reader.files"

    private const val SEGMENT_FILE = "file"
    private const val SEGMENT_TREE = "tree"

    /** Своя колонка: ссылка на child, собранная провайдером, а не угаданная читалкой. */
    const val COLUMN_CHILD_URI = "reader_child_uri"

    /** Имена корней в ссылке — короткие и постоянные, чтобы их нельзя было перепутать. */
    const val ROOT_FILES = "files"
    const val ROOT_CACHE = "cache"
    const val ROOT_EXTERNAL_FILES = "external-files"
    const val ROOT_EXTERNAL_CACHE = "external-cache"

    fun authority(context: Context): String = context.packageName + AUTHORITY_SUFFIX

    fun isReaderFiles(uri: Uri?): Boolean = uri?.authority?.endsWith(AUTHORITY_SUFFIX) == true

    /** Ссылка на файл, либо null, если файл лежит вне каталогов приложения. */
    fun fileUri(context: Context, file: File): Uri? {
        val relative = relativePathOf(context, file) ?: return null
        return Uri.Builder()
            .scheme("content")
            .authority(authority(context))
            .appendPath(SEGMENT_FILE)
            .appendEncodedPath(relative)
            .build()
    }

    /** Ссылка на каталог: по ней провайдер отдаёт список содержимого. */
    fun treeUri(context: Context, directory: File): Uri? {
        val relative = relativePathOf(context, directory) ?: return null
        return Uri.Builder()
            .scheme("content")
            .authority(authority(context))
            .appendPath(SEGMENT_TREE)
            .appendEncodedPath(relative)
            .build()
    }

    fun isTree(uri: Uri): Boolean = uri.pathSegments.firstOrNull() == SEGMENT_TREE

    /**
     * Путь относительно корня, внутри которого лежит файл: `files/LocalSource/…`.
     * Возвращает null, если файл не внутри ни одного корня.
     */
    private fun relativePathOf(context: Context, file: File): String? {
        val canonical = runCatching { file.canonicalFile }.getOrNull() ?: return null
        for ((name, root) in roots(context)) {
            val rootPath = runCatching { root.canonicalPath }.getOrNull() ?: continue
            val prefix = if (rootPath.endsWith(File.separator)) rootPath else rootPath + File.separator
            if (canonical.path.startsWith(prefix)) {
                return "$name/${canonical.path.removePrefix(prefix)}"
            }
        }
        return null
    }

    /** Каталоги приложения, которые разрешено отдавать наружу. */
    fun roots(context: Context): List<Pair<String, File>> = listOf(
        ROOT_FILES to context.filesDir,
        ROOT_CACHE to context.cacheDir,
        ROOT_EXTERNAL_FILES to context.externalFilesDir,
        ROOT_EXTERNAL_CACHE to context.externalCacheDir,
    ).mapNotNull { (name, dir) -> dir?.let { name to it } }

    /**
     * Разбирает путь из ссылки в настоящий файл. Имя корня отбрасывается, а
     * остаток проверяется на то, что он не вылезает выше корня.
     */
    fun resolve(context: Context, uri: Uri): File? {
        val segments = uri.pathSegments
        if (segments.size < 2) return null
        val rootName = segments[0]
        val relative = segments.drop(1).joinToString("/")
        if (relative.isEmpty() || relative.contains("..")) return null

        val root = roots(context).firstOrNull { it.first == rootName }?.second ?: return null
        val rootPath = runCatching { root.canonicalPath }.getOrNull() ?: return null
        val candidate = runCatching { File(root, relative).canonicalFile }.getOrNull() ?: return null
        val prefix = if (rootPath.endsWith(File.separator)) rootPath else rootPath + File.separator
        return candidate.takeIf { it.path.startsWith(prefix) }
    }
}
