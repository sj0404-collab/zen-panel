package eu.kanade.tachiyomi.ui.reader

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import eu.kanade.tachiyomi.reader.ReaderFiles

/**
 * Запуск читалки.
 *
 * Если приложение читалки установлено и ссылку на главу удалось получить —
 * открывается оно, потому что у него свои настройки. Если нет — встроенная
 * читалка, и пользователь этого не замечает.
 *
 * Ссылка получается не всегда, и это ожидаемо: сетевые главы лежат в
 * источнике, а не на диске, и отдать их может только встроенная читалка.
 */
object ReaderLauncher {

    private const val ACTION_READ = "com.yomikai.reader.action.READ"
    private const val READER_PACKAGE = "com.yomikai.reader"

    private const val EXTRA_MANGA = "manga"
    private const val EXTRA_CHAPTER = "chapter"
    private const val EXTRA_AUTO_READ = "autoread_start"

    /**
     * @param uri ссылка на папку или архив главы; null, если глава не на диске.
     * @return true, если открылось приложение читалки.
     */
    fun open(
        context: Context,
        uri: Uri?,
        mangaId: Long?,
        chapterId: Long?,
        autoRead: Boolean = false,
    ): Boolean {
        val external = uri?.let { externalIntent(context, it, mangaId, chapterId, autoRead) }
        if (external != null) {
            try {
                context.startActivity(external)
                return true
            } catch (_: ActivityNotFoundException) {
                // Приложение читалки не установлено или не собрано с этим
                // действием: молча читаем встроенной, без сообщения.
            }
        }
        context.startActivity(
            if (autoRead) {
                ReaderActivity.newAutoReadIntent(context, mangaId, chapterId)
            } else {
                ReaderActivity.newIntent(context, mangaId, chapterId)
            },
        )
        return false
    }

    /** Ссылка на файл приложения превращается в ссылку провайдера: приватный файл иначе не отдать. */
    fun shareableUri(context: Context, uri: Uri?): Uri? = when {
        uri == null -> null
        ReaderFiles.isReaderFiles(uri) -> uri
        uri.scheme == "file" -> ReaderFiles.fileUri(context, uri.path?.let { java.io.File(it) } ?: return null)
        else -> uri
    }

    fun directoryUri(context: Context, uri: Uri?): Uri? = when {
        uri == null -> null
        ReaderFiles.isReaderFiles(uri) -> uri
        uri.scheme == "file" -> ReaderFiles.treeUri(context, uri.path?.let { java.io.File(it) } ?: return null)
        else -> uri
    }

    private fun externalIntent(
        context: Context,
        uri: Uri,
        mangaId: Long?,
        chapterId: Long?,
        autoRead: Boolean,
    ): Intent? {
        val source = shareableUri(context, uri) ?: return null
        return Intent(ACTION_READ).apply {
            setPackage(READER_PACKAGE)
            data = source
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            mangaId?.let { putExtra(EXTRA_MANGA, it) }
            chapterId?.let { putExtra(EXTRA_CHAPTER, it) }
            if (autoRead) putExtra(EXTRA_AUTO_READ, true)
        }
    }
}
