package eu.kanade.tachiyomi.reader

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import java.io.File

/**
 * Провайдер файлов приложения для приложения читалки.
 *
 * Отдаёт ровно две вещи: поток файла и список содержимого каталога. Никакой
 * записи, никаких прав — читательскому приложению нужно только прочитать
 * главу, которую Yomikai сам открыл.
 *
 * Ссылка передаётся другому приложению флагом FLAG_GRANT_READ_URI_PERMISSION
 * в намерении, поэтому провайдер и не должен быть открытым всему подряд: путь
 * проверяется по корню (см. [ReaderFiles]), а Authority уникален для пакета.
 */
class ReaderFileProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun getType(uri: Uri): String? {
        val context = context ?: return null
        val file = ReaderFiles.resolve(context, uri) ?: return null
        if (file.isDirectory) return DocumentsContract.Document.MIME_TYPE_DIR
        return mimeOf(file.name)
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val context = context ?: return null
        require(mode == "r") { "ReaderFileProvider открыт только на чтение, а не «$mode»" }
        val file = ReaderFiles.resolve(context, uri) ?: return null
        if (file.isDirectory) throw java.io.FileNotFoundException("$uri — это каталог")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    /**
     * Для каталога отдаём список детей: имя плюс их собственная ссылка, иначе
     * читалке пришлось бы угадывать путь и угадывать неверно.
     */
    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?,
    ): Cursor? {
        val context = context ?: return null
        val file = ReaderFiles.resolve(context, uri) ?: return null

        val columns = projection ?: arrayOf(
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            ReaderFiles.COLUMN_CHILD_URI,
        )
        val cursor = MatrixCursor(columns)
        val children = if (file.isDirectory) {
            file.listFiles().orEmpty().sortedBy { it.name }
        } else {
            listOf(file)
        }

        for (child in children) {
            val values = columns.associateWith { column ->
                when (column) {
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME -> child.name
                    DocumentsContract.Document.COLUMN_MIME_TYPE -> if (child.isDirectory) {
                        DocumentsContract.Document.MIME_TYPE_DIR
                    } else {
                        mimeOf(child.name)
                    }
                    ReaderFiles.COLUMN_CHILD_URI -> childUri(context, uri, child)?.toString()
                    else -> null
                }
            }
            cursor.addRow(columns.map { values[it] }.toTypedArray())
        }
        return cursor
    }

    private fun childUri(context: android.content.Context, parent: Uri, child: File): Uri? =
        if (child.isDirectory) {
            ReaderFiles.treeUri(context, child)
        } else {
            ReaderFiles.fileUri(context, child)
        }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    private fun mimeOf(name: String): String {
        val extension = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            ?: if (extension in IMAGE_EXTENSIONS) "image/*" else "application/octet-stream"
    }

    private companion object {
        val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif")
    }
}
