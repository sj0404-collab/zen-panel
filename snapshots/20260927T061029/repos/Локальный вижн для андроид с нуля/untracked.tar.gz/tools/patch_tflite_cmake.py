"""Guard the unconditional target_compile_options on xnnpack-delegate.

TFLite's own CMakeLists sets compile options on xnnpack-delegate even when the
delegate is disabled, so TFLITE_ENABLE_XNNPACK_DELEGATE=OFF fails to configure.
We only need MMAPAllocation and the classic Interpreter, so disabling the
delegates is worth the one-line patch.
"""

import sys

OLD = """target_compile_options(xnnpack-delegate
  PUBLIC ${TFLITE_TARGET_PUBLIC_OPTIONS}
  PRIVATE ${TFLITE_TARGET_PRIVATE_OPTIONS}
)"""

NEW = "if(TARGET xnnpack-delegate)\n" + OLD + "\nendif()\n"


def main(path):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    if "if(TARGET xnnpack-delegate)" in src:
        print("already patched")
        return 0
    if OLD not in src:
        print("pattern not found")
        return 1
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src.replace(OLD, NEW))
    print("patched")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
