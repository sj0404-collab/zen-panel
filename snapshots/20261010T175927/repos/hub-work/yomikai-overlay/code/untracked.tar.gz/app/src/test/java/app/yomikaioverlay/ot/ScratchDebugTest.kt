package app.yomikaioverlay.ot

import org.junit.Test

class ScratchDebugTest {
    @Test
    fun dumpBytes() {
        val bytes = ProtoWriter().apply {
            writeMessage(1) {
                it.writeString(1, "ru")
                it.writeMessage(2) { i2 -> i2.writeInt32(1, 42) }
            }
            writeUInt64(2, 987_654_321L)
            writeBytes(3, byteArrayOf(0, 1, 2, 3))
        }.toByteArray()
        println("BYTES=" + bytes.joinToString(" ") { "%02X".format(it) })
        println("SIZE=" + bytes.size)
        val r = ProtoReader(bytes)
        val t1 = r.readTag()!!
        println("t1=${t1} field=${t1 ushr 3} wire=${t1 and 7}")
        val msg = ProtoReader(r.readBytes())
        val s1 = msg.readTag()!!
        println("s1 field=${s1 ushr 3}")
        println("str=" + msg.readString())
        val s2 = msg.readTag()!!
        println("s2 field=${s2 ushr 3}")
        val inner = ProtoReader(msg.readBytes())
        val s3 = inner.readTag()!!
        println("s3 field=${s3 ushr 3} val=${inner.readVarint32()}")
        val t2 = r.readTag()!!
        println("t2 field=${t2 ushr 3} val=${r.readVarint32()}")
        val t3 = r.readTag()!!
        println("t3 field=${t3 ushr 3}")
        println("tail=" + r.readBytes().joinToString(" ") { "%02X".format(it) })
    }
}
