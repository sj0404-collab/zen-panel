package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThrottleTest {

    @Test
    fun firstCallAllowed() {
        assertTrue(Throttle(1000).allow(0))
    }

    @Test
    fun immediateSecondCallBlocked() {
        val t = Throttle(1000)
        assertTrue(t.allow(0))
        assertFalse(t.allow(0))
        assertFalse(t.allow(999))
    }

    @Test
    fun allowedAfterInterval() {
        val t = Throttle(1000)
        t.allow(0)
        assertFalse(t.allow(999))
        assertTrue(t.allow(1000))
    }

    @Test
    fun countsFromLastAllowedNotFromLastAttempt() {
        val t = Throttle(1000)
        t.allow(0)
        t.allow(500)  // отклонено — не двигает окно
        assertFalse(t.allow(900))
        assertTrue(t.allow(1000))
    }

    @Test
    fun resetAllowsImmediately() {
        val t = Throttle(1000)
        t.allow(0)
        t.reset()
        assertTrue(t.allow(1))
    }

    @Test
    fun remainingCountsDown() {
        val t = Throttle(1000)
        assertEquals(0L, t.remaining(0))
        t.allow(0)
        assertEquals(1000L, t.remaining(0))
        assertEquals(400L, t.remaining(600))
        assertEquals(0L, t.remaining(1200))
    }
}