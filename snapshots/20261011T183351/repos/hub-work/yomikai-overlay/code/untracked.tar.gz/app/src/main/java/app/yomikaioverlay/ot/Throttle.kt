package app.yomikaioverlay.ot

/**
 * Ограничитель частоты: «не чаще, чем раз в N мс».
 *
 * Нужен, чтобы цикл авточтения/автонажатий не превращался в поток запросов
 * в систему: каждый захват кадра — это работа композитора, каждое обновление
 * уведомления и жест — это binder-вызовы system_server. При перегрузке
 * system_server не отвечает и его убивает watchdog, после чего система
 * перезапускается — телефон выглядит «зависшим».
 *
 * Чистая логика на переданном времени (без Android) — покрыта юнит-тестами.
 */
class Throttle(private val intervalMs: Long) {

    private var last = Long.MIN_VALUE

    /** Прошло ли достаточно времени. Отмечает момент — повторный вызов сразу вернёт false. */
    fun allow(now: Long): Boolean {
        if (last != Long.MIN_VALUE && now - last < intervalMs) return false
        last = now
        return true
    }

    /** Сбросить (новый сеанс чтения). */
    fun reset() {
        last = Long.MIN_VALUE
    }

    /** Сколько ещё ждать до разрешения, мс. */
    fun remaining(now: Long): Long {
        if (last == Long.MIN_VALUE) return 0L
        val left = intervalMs - (now - last)
        return if (left > 0) left else 0L
    }
}