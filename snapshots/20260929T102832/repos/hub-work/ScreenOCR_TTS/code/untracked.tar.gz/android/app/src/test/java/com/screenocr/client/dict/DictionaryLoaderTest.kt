package com.screenocr.client.dict

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DictionaryLoaderTest {

    private val dicts = TestDictionaries.dicts

    @Test
    fun `json dictionaries extend the literal ones`() {
        val wordsFromJson = 68155
        val phrasesFromJson = 510 + 686
        assertTrue(
            "ожидалось от 512 до ${512 + wordsFromJson} слов, получено ${dicts.words.size}",
            dicts.words.size in (wordsFromJson + 1)..(512 + wordsFromJson),
        )
        assertTrue(
            "ожидалось от 258 до ${258 + phrasesFromJson} фраз, получено ${dicts.phrases.size}",
            dicts.phrases.size in (258 + 1)..(258 + phrasesFromJson),
        )
    }

    @Test
    fun `literal dictionaries win over json duplicates`() {
        val fromLiteral = DictData.PHRASES["hello"]
        assertEquals("привет", fromLiteral)
        assertEquals("привет", dicts.phrases["hello"])
    }

    @Test
    fun `cities and game names land in the phrase table`() {
        assertTrue(dicts.phrases.containsKey("new york"))
        assertTrue(dicts.phrases.size > DictData.PHRASES.size)
    }

    @Test
    fun `known entries translate end to end`() {
        val translator = OfflineTranslator(dicts.words, dicts.phrases)
        assertEquals("привет мир", translator.translate("hello world"))
        assertTrue(translator.translate("teleport to the arena").isNotEmpty())
    }

    @Test
    fun `missing dictionary file is reported`() {
        try {
            DictionaryLoader.loadFromDir(java.io.File("/nonexistent-dict-dir"))
            throw AssertionError("ожидалось исключение об отсутствии файла")
        } catch (expected: java.io.FileNotFoundException) {
            assertTrue(expected.message!!.contains("en_rus_full.json"))
        }
    }
}
