#!/usr/bin/env python3
"""Score OCR transcripts against the hand-cleaned reference.

Both the reference (``results/hand-cleaned.txt``) and the engine transcripts use
one entry per page:

    reference:  ``NNN — text``
    engine:     ``===== NNN.jpg (1.5s) =====``  followed by the page text

We normalise (lowercase, ё→е, drop punctuation and the MANGABUFF watermark) and
report CER (character error rate) and WER (word error rate) as Levenshtein
edits over the summed reference length, plus wall-clock seconds per page when
the transcript carries timing markers.

    python scripts/score_ocr.py results/hand-cleaned.txt results/*.txt
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

PAGE_MARKER = re.compile(r"^=+\s*(\d+)\.(?:jpe?g|png)\b")
TIME_RE = re.compile(r"\(([\d.]+)\s*s\)")
REF_LINE = re.compile(r"^(\d{1,3})\s*[—:-]\s*(.*)$")
WATERMARK = re.compile(r"mangabuf+\w*\.?\w*", re.IGNORECASE)
UNREADABLE = re.compile(r"\(нечитаемо\)")


def norm(text: str) -> str:
    text = text.lower().replace("ё", "е")
    text = WATERMARK.sub(" ", text)
    text = re.sub(r"[^0-9a-zа-я\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def levenshtein(a, b) -> int:
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if not la:
        return lb
    if not lb:
        return la
    prev = list(range(lb + 1))
    for i in range(1, la + 1):
        cur = [i] + [0] * lb
        ai = a[i - 1]
        for j in range(1, lb + 1):
            cost = 0 if ai == b[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[lb]


def load_reference(path: Path) -> dict[int, str]:
    ref: dict[int, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        m = REF_LINE.match(line.strip())
        if m:
            ref[int(m.group(1))] = m.group(2).strip()
    return ref


def load_result(path: Path) -> tuple[dict[int, str], float | None, int]:
    pages: dict[int, str] = {}
    times: list[float] = []
    cur: int | None = None
    buf: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = PAGE_MARKER.match(line.strip())
        if m:
            if cur is not None:
                pages[cur] = "\n".join(buf).strip()
            cur = int(m.group(1))
            buf = []
            t = TIME_RE.search(line)
            if t:
                times.append(float(t.group(1)))
            continue
        if cur is not None:
            buf.append(line)
    if cur is not None:
        pages[cur] = "\n".join(buf).strip()
    total = sum(times) if times else None
    return pages, total, len(times)


def score(ref: dict[int, str], hyp: dict[int, str], skip_unreadable: bool):
    ce = we = rl = wl = 0
    scored = skipped = 0
    for page, rtext in ref.items():
        if page not in hyp:
            continue
        if skip_unreadable and UNREADABLE.search(rtext):
            skipped += 1
            continue
        r = norm(rtext)
        h = norm(hyp.get(page, ""))
        if not r:
            continue
        ce += levenshtein(r, h)
        we += levenshtein(r.split(), h.split())
        rl += len(r)
        wl += len(r.split())
        scored += 1
    cer = ce / rl if rl else 0.0
    wer = we / wl if wl else 0.0
    return cer, wer, scored, skipped


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("reference")
    ap.add_argument("results", nargs="+")
    ap.add_argument("--skip-unreadable", action="store_true",
                    help="ignore reference pages marked (нечитаемо)")
    args = ap.parse_args()

    ref = load_reference(Path(args.reference))
    ref_pages = len(ref)
    print(f"reference: {args.reference} ({ref_pages} pages)\n")
    header = f"{'engine':<34} {'pages':>5} {'sec/pg':>8} {'CER%':>7} {'WER%':>7}"
    print(header)
    print("-" * len(header))
    for rpath in args.results:
        p = Path(rpath)
        pages, total, n_timed = load_result(p)
        if not pages:
            print(f"{p.stem:<34} {'-':>5} {'-':>8} {'-':>7} {'-':>7}  (no page markers)")
            continue
        cer, wer, scored, skipped = score(ref, pages, args.skip_unreadable)
        spp = f"{total / n_timed:.2f}" if total and n_timed else "-"
        note = f"  [{scored}/{ref_pages} pages]"
        if skipped:
            note += f"  [{skipped} нечитаемо skipped]"
        print(f"{p.stem:<34} {scored:>5} {spp:>8} {cer * 100:>7.1f} "
              f"{wer * 100:>7.1f}{note}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
