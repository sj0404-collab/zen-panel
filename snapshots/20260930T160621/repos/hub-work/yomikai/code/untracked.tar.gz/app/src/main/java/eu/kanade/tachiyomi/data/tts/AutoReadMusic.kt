package eu.kanade.tachiyomi.data.tts

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import eu.kanade.tachiyomi.data.books.BookAmbience
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import logcat.LogPriority
import mihon.domain.ocr.service.OcrPreferences
import tachiyomi.core.common.util.system.logcat
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File
import kotlin.math.abs

/**
 * Фоновая музыка манга-авточтения — порт той же фичи, что уже есть в читалке
 * книг. Треков в проекте нет: петли процедурные, их синтезирует
 * [BookAmbience] в кэш (`book_ambience/amb_<mood>.wav`), поэтому здесь только
 * владелец MediaPlayer и логика громкости.
 *
 * Три отличия от читалки книг:
 *
 *  * **Речь и музыка играют одновременно.** Реплики манги короткие и идут
 *    плотно, пауз между ними почти нет, поэтому громкость приглушается на
 *    время озвучки ([setSpeaking]) и плавно возвращается в паузах — иначе
 *    голос тонет в аккордах.
 *  * **Громкость меняется рывками.** Мгновенный setVolume на границе фразы
 *    слышен как щелчок, поэтому громкость идёт лесенкой: шаг [RAMP_STEP]
 *    каждые [RAMP_STEP_MS] мс до целевого значения.
 *  * **Всё вызывается из движка на Dispatchers.IO.** MediaPlayer требует
 *    потока с Looper, поэтому сам плеер живёт на главном, а синтез WAV-файла
 *    — на IO. Файл готовится один раз на настроение и кэшируется, повторно
 *    не генерируется.
 *
 * Намеренно НЕ ходит в AutoReadEngine: движок сейчас правится параллельно.
 * Точки вызова — [start] в начале чтения кадра, [setSpeaking] вокруг
 * [AutoReadEngine.speakAndAwait], [pause] в `stop()`/`stopAutoReadLoop()` и
 * [release] в `finally`/`onDestroy`.
 *
 * Состояние — синглтон намеренно: движок создаётся в трёх местах
 * (ReaderActivity, OcrOverlayService, BrowserTab), и общий владелец не даёт
 * каждому экземпляру завести свой MediaPlayer на 14-секундную петлю.
 */
object AutoReadMusic {

    /** Насколько тише музыка во время произнесения реплики. */
    private const val DUCK_FACTOR = 0.32f

    /** Шаг изменения громкости при плавной подстройке. */
    private const val RAMP_STEP = 0.05f

    /** Пауза между шагами подстройки, мс. */
    private const val RAMP_STEP_MS = 120L

    /** Порог, ниже которого разницу громкости считаем нулём. */
    private const val VOLUME_EPS = 0.005f

    /** Сколько символов текста страницы смотрим при выборе настроения. */
    private const val PAGE_TEXT_SAMPLE = 400

    /** MediaPlayer живёт на главном потоке — иначе он не примет ни одного колбэка. */
    private val main = Handler(Looper.getMainLooper())

    /** Синтез/чтение WAV — тяжёлая работа, её нельзя делать в кадре UI. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var player: MediaPlayer? = null
    private var loadJob: Job? = null

    /** Настроение уже загруженного трека: смена — это перезагрузка петли. */
    private var mood: BookAmbience.Mood? = null

    /** Номер последнего запроса: отсекает запоздавший ответ на смену трека. */
    private var requestId = 0

    /** Музыку просил держать движок (не настройка, не пауза чтения). */
    private var wanted = false

    /** Сейчас произносится реплика — музыка приглушена. */
    private var speaking = false

    /** Громкость из настроек, к которой стремимся с учётом [speaking]. */
    private var baseVolume = 0.15f

    /** Текущая громкость плеера; к [targetVolume] идёт по лесенке. */
    private var currentVolume = 0f

    private val ramp = object : Runnable {
        override fun run() {
            val target = targetVolume()
            val diff = target - currentVolume
            // Дошли до цели (или осталась пыль) — фиксируем и не крутим дальше,
            // иначе Handler будет просыпаться каждые 120 мс до конца главы.
            if (abs(diff) <= RAMP_STEP || abs(diff) <= VOLUME_EPS) {
                applyVolume(target)
                return
            }
            applyVolume(currentVolume + if (diff > 0) RAMP_STEP else -RAMP_STEP)
            main.postDelayed(this, RAMP_STEP_MS)
        }
    }

    /**
     * Включить/продолжить музыку под настроение сцены.
     *
     * Вызывается в начале чтения кадра. [chapterTitle] и [pageText] — слова,
     * по которым [BookAmbience.moodFor] выбирает петлю; если их нет, берётся
     * нейтральная. Повторный вызов с тем же настроением просто возобновляет
     * уже загруженный трек.
     */
    @JvmOverloads
    fun start(context: Context, chapterTitle: String? = null, pageText: String? = null) {
        val prefs = prefs() ?: return
        wanted = true
        if (!prefs.autoReadMusicEnabled().get()) {
            pause()
            return
        }
        baseVolume = prefs.autoReadMusicVolume().get().coerceIn(0f, 1f)

        val target = BookAmbience.moodFor(keywords(chapterTitle, pageText))
        val id = ++requestId
        if (player != null && mood == target) {
            resume()
            return
        }
        loadJob?.cancel()
        val app = context.applicationContext
        loadJob = scope.launch {
            // fileFor кэширует: первый кадр платит за синтез, дальше — только чтение.
            val file = BookAmbience.fileFor(app, target) ?: return@launch
            main.post { open(file, target, id) }
        }
    }

    /** Пауза с сохранением трека в памяти: возобновление мгновенное. */
    fun pause() {
        wanted = false
        loadJob?.cancel()
        loadJob = null
        main.removeCallbacks(ramp)
        val p = player ?: return
        runCatching { if (p.isPlaying) p.pause() }
            .onFailure { logcat(LogPriority.WARN, it) { "AutoReadMusic: pause failed" } }
    }

    /**
     * Сообщить, что идёт речь: музыка плавно уходит на [DUCK_FACTOR] от
     * базовой громкости. Зовётся из колбэка `TtsSpeaker.speakAs`.
     */
    fun setSpeaking(value: Boolean) {
        if (speaking == value) return
        speaking = value
        scheduleRamp()
    }

    /** Новая базовая громкость (слайдер в настройках озвучки). */
    fun setVolume(volume: Float) {
        baseVolume = volume.coerceIn(0f, 1f)
        scheduleRamp()
    }

    /**
     * Полное освобождение. Звать при смерти сервиса/activity и в `finally`
     * движка: MediaPlayer держит нативные ресурсы, и без [release] процесс
     * держит лишний аудиопоток до самой смерти.
     */
    fun release() {
        wanted = false
        speaking = false
        loadJob?.cancel()
        loadJob = null
        main.removeCallbacks(ramp)
        val p = player
        player = null
        mood = null
        requestId++
        currentVolume = 0f
        runCatching { p?.release() }
            .onFailure { logcat(LogPriority.WARN, it) { "AutoReadMusic: release failed" } }
    }

    /** Играет ли музыка прямо сейчас (для индикатора и проверок). */
    fun isRunning(): Boolean = wanted && player != null

    // ---- внутреннее ----

    private fun prefs(): OcrPreferences? = runCatching { Injekt.get<OcrPreferences>() }.getOrNull()

    /**
     * Ключевые слова сцены. Отдельного списка «слов сцены» в авточтении нет,
     * поэтому настроение выводится из заголовка главы и текста кадра — того
     * же, по чему движок уже решает, что и как произносить.
     */
    private fun keywords(chapterTitle: String?, pageText: String?): String? = buildString {
        chapterTitle?.takeIf { it.isNotBlank() }?.let { append(it) }
        pageText?.takeIf { it.isNotBlank() }?.let {
            if (isNotEmpty()) append(' ')
            append(it.take(PAGE_TEXT_SAMPLE))
        }
    }.takeIf { it.isNotBlank() }

    private fun open(file: File, target: BookAmbience.Mood, id: Int) {
        // Пока файл готовился, чтение могло остановиться или сменить настроение.
        if (!wanted || id != requestId) return
        runCatching {
            val p = player ?: MediaPlayer().also { player = it }
            p.reset()
            p.setDataSource(file.absolutePath)
            p.isLooping = true
            p.setVolume(currentVolume, currentVolume)
            p.prepare()
            p.start()
            mood = target
        }.onFailure {
            logcat(LogPriority.WARN, it) { "AutoReadMusic: open failed" }
            release()
            return
        }
        scheduleRamp()
    }

    private fun resume() {
        val p = player ?: return
        runCatching { if (!p.isPlaying) p.start() }
            .onFailure { logcat(LogPriority.WARN, it) { "AutoReadMusic: resume failed" } }
        scheduleRamp()
    }

    private fun targetVolume(): Float = baseVolume * if (speaking) DUCK_FACTOR else 1f

    private fun applyVolume(value: Float) {
        currentVolume = value.coerceIn(0f, 1f)
        val p = player ?: return
        runCatching { p.setVolume(currentVolume, currentVolume) }
    }

    /** Перезапустить лесенку с текущей позиции, не плодя копий Runnable. */
    private fun scheduleRamp() {
        main.removeCallbacks(ramp)
        if (!wanted || player == null) return
        main.post(ramp)
    }
}
