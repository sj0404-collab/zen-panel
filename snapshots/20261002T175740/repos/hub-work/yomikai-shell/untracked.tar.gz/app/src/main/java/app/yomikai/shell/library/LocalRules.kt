package app.yomikai.shell.library

/**
 * Правила локальной библиотеки — ровно как в основном приложении.
 *
 * Здесь нет Android: только чистые решения по [Ref], поэтому каждое из
 * них проверяется обычным тестом. В первый раз эти правила были размазаны по
 * SAF-коду, из-за чего проверить их было нечем, и библиотека работала не так,
 * как задумано.
 *
 * Разметка ровно двухуровневая, как в оригинале:
 *
 * ```
 * корень/                ← корень SAF
 *   Манга/               ← манга: папка ИЛИ одиночный архив
 *     Глава.cbz          ← глава: архив, или папка, где есть хоть одна картинка
 *   Одиночная.cbz        ← манга, у которой глава одна и лежит рядом с собой
 * ```
 *
 * Вглубь не ходим: третий уровень в библиотеке не различают, и рекурсивный
 * разворот папок в первый раз превращал вложенные каталоги в кашу.
 */
object LocalRules {

    /** Форматы архивов, которые читаются. `cbr`/`rar` — это libarchive, его нет. */
    val ARCHIVE_EXTENSIONS = setOf("zip", "cbz")

    /** Epub в первой версии не читается: это отдельный парсер с xml внутри. */
    val EPUB_EXTENSIONS = setOf("epub")

    val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "avif", "jxl", "bmp")

    /**
     * Служебные каталоги внутри корня. В оригинале их список задан константой,
     * и они не должны показываться как манга.
     */
    val RESERVED_DIRECTORIES = setOf(
        "local",
        "downloads",
        "backup",
        "autobackup",
        "automatic_backups",
        "covers",
        ".thumbnails",
    )

        /** Манга — папка или одиночный архив; скрытое и служебное отбрасывается. */
    fun isManga(document: Ref): Boolean {
        if (document.name.isEmpty() || document.name.startsWith('.')) return false
        if (document.isDirectory) {
            return document.name.lowercase() !in RESERVED_DIRECTORIES
        }
        return document.extension in ARCHIVE_EXTENSIONS
    }

    /**
     * Глава — архив, epub или папка, внутри которой есть хоть одна картинка.
     *
     * Проверка «есть ли картинка» обязательна: в папке манги посторонние
     * каталоги (`.thumbnails`, `extras`, пустые папки) иначе выглядели бы
     * главами, и их нечего было бы открывать.
     */
    fun isChapter(document: Ref, children: (Ref) -> List<Ref>): Boolean {
        if (document.name.isEmpty() || document.name.startsWith('.')) return false
        return when {
            document.isDirectory -> children(document).any { isImage(it) }
            document.extension in ARCHIVE_EXTENSIONS -> true
            document.extension in EPUB_EXTENSIONS -> true
            else -> false
        }
    }

    fun isImage(document: Ref): Boolean =
        !document.isDirectory && document.extension in IMAGE_EXTENSIONS

    /** Имя главы: у папки — как есть, у файла — без расширения. */
    fun chapterName(document: Ref): String =
        if (document.isDirectory) document.name else document.nameWithoutExtension

    /** Имя манги: у папки — как есть, у архива — без расширения. */
    fun mangaName(document: Ref): String =
        if (document.isDirectory) document.name else document.nameWithoutExtension

    /**
     * Есть ли у манги своя обложка `cover.*`.
     *
     * Как в оригинале: имя без расширения сравнивается с `cover` без учёта
     * регистра, расширение должно быть картинным. Иначе обложка генерируется
     * из первой картинки самой ранней главы.
     */
    fun explicitCover(documents: List<Ref>): Ref? = documents.firstOrNull { candidate ->
        !candidate.isDirectory &&
            candidate.nameWithoutExtension.equals("cover", ignoreCase = true) &&
            isImage(candidate)
    }
}
