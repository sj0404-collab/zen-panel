package app.yomikai.shell.library

import java.io.Serializable

/**
 * Ссылка на документ: сам URI плюс URI дерева, которым он выдан.
 *
 * [tree] — не украшение. Чтобы перечислить содержимое документа, SAF требует
 * URI ДЕРЕВА: запрос по URI документа возвращает сам документ, и папка
 * выглядит одной строкой сама себя. Дерево нужно и при входе во вложенную
 * папку, поэтому оно едет вместе со ссылкой, а не хранится в памяти процесса:
 * после перезапуска приложения память пуста, и всё, что открывали вчера,
 * перестаёт открываться.
 *
 * Источник, которому дерево не нужно (папка на диске в тестах), оставляет
 * [tree] пустым.
 */
data class Ref(
    val uri: String,
    val tree: String = "",
    val name: String,
    val isDirectory: Boolean,
    val size: Long = 0,
) : Serializable {

    val extension: String get() = name.substringAfterLast('.', "").lowercase()

    val nameWithoutExtension: String get() = name.substringBeforeLast('.', name)

    companion object {
        /**
         * Ссылка на корень дерева: имя берётся из его document id
         * (`primary%3AManga` → `Manga`). Разбор строкой, а не через
         * `android.net.Uri`, чтобы класс проверялся на JVM без Android.
         */
        fun treeRoot(treeUri: String): Ref {
            val id = runCatching {
                java.net.URLDecoder.decode(
                    treeUri.substringAfter("/tree/", "").substringBefore("/document/"),
                    Charsets.UTF_8.name(),
                )
            }.getOrNull().orEmpty()
            return Ref(
                uri = treeUri,
                tree = treeUri,
                name = id.substringAfterLast(':').substringAfterLast('/').ifBlank { "Корень" },
                isDirectory = true,
            )
        }
    }
}

/**
 * Источник документов: SAF на устройстве, папка на диске в тестах.
 *
 * Логика библиотеки работает только с этим интерфейсом. Причина не в красоте:
 * SAF нельзя проверить на JVM, а именно логика библиотеки в первый раз и была
 * сломана — её нечем было проверить, и каждая правка уезжала вслепую.
 */
interface DocumentSource {
    /** Содержимое каталога. Для файла — пустой список. */
    fun children(parent: Ref): List<Ref>

    /** Файл целиком в память. `null`, если нечитаем или больше лимита. */
    fun readBytes(doc: Ref, maxBytes: Long = Long.MAX_VALUE): ByteArray?

    /**
     * Канал с seek — нужен для ZIP: запись читается по смещению из локального
     * заголовка, и без seek архив читался бы целиком на каждую страницу.
     */
    fun openChannel(doc: Ref): Opened?
}

/** Открытый файл: канал и его размер. Размер нужен, чтобы найти каталог с конца. */
class Opened(val channel: java.nio.channels.FileChannel, val size: Long) : java.io.Closeable {
    override fun close() {
        runCatching { channel.close() }
    }
}
