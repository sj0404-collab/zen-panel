package app.yomikai.shell.library

import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Проверка правил локальной библиотеки на настоящем дереве каталогов.
 *
 * Каждый тест — ситуация, которая в первой версии работала неверно и была
 * отправлена пользователю как «готово».
 */
class LocalLibraryTest {

    private lateinit var dir: File
    private lateinit var source: FileDocumentSource
    private lateinit var library: LocalLibrary

    @BeforeEach
    fun setUp() {
        dir = Files.createTempDirectory("library-test").toFile()
        source = FileDocumentSource(dir)
        library = LocalLibrary(source)
    }

    @AfterEach
    fun tearDown() {
        dir.deleteRecursively()
    }

    // Манга

    @Test
    fun `мангой считается папка и одиночный архив`() {
        put("Манга/Глава 1.cbz", zip("001.jpg"))
        put("Одинокий.cbz", zip("001.jpg"))

        val names = library.manga(FileDocumentSource.root()).map { it.name }

        assertEquals(listOf("Манга", "Одинокий"), names)
    }

    @Test
    fun `служебные папки и скрытое не становятся мангами`() {
        put("Манга/Глава 1.cbz", zip("001.jpg"))
        FileDocumentSource.mkdir(source, "downloads/что-то.cbz")
        FileDocumentSource.mkdir(source, "backup")
        FileDocumentSource.mkdir(source, ".thumbnails")
        FileDocumentSource.mkdir(source, ".секрет")

        val names = library.manga(FileDocumentSource.root()).map { it.name }

        assertEquals(listOf("Манга"), names)
    }

    @Test
    fun `картинка рядом с папками мангой не считается`() {
        FileDocumentSource.write(source, "обложка.jpg", png())
        FileDocumentSource.mkdir(source, "Манга")

        assertTrue(library.manga(FileDocumentSource.root()).none { it.name == "обложка" })
    }

    // Главы

    @Test
    fun `глава это архив или папка с картинками`() {
        put("Манга/Глава 1.cbz", zip("001.jpg"))
        FileDocumentSource.mkdir(source, "Манга/Глава 2")
        FileDocumentSource.write(source, "Манга/Глава 2/001.jpg", png())

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val chapters = library.chapters(manga)

        assertEquals(listOf("Глава 1", "Глава 2"), chapters.map { it.name })
        assertTrue(chapters[1].isFolder)
    }

    @Test
    fun `пустая папка и папка без картинок главой не являются`() {
        FileDocumentSource.mkdir(source, "Манга")
        FileDocumentSource.mkdir(source, "Манга/extras")
        FileDocumentSource.mkdir(source, "Манга/Глава 1")
        FileDocumentSource.write(source, "Манга/Глава 1/001.jpg", png())
        FileDocumentSource.write(source, "Манга/extras/заметка.txt", "привет".toByteArray())

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertEquals(listOf("Глава 1"), library.chapters(manga).map { it.name })
    }

    @Test
    fun `библиотека не лезет глубже второго уровня`() {
        FileDocumentSource.mkdir(source, "Манга/Глава 1")
        FileDocumentSource.write(source, "Манга/Глава 1/001.jpg", png())
        // Картинка на третьем уровне главой быть не должна: разметка двухуровневая.
        FileDocumentSource.mkdir(source, "Манга/Глава 1/вложенная")
        FileDocumentSource.write(source, "Манга/Глава 1/вложенная/002.jpg", png())

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val chapter = library.chapters(manga).single()

        assertEquals(listOf("001.jpg"), library.pages(chapter).map { it.name })
    }

    @Test
    fun `главы идут в порядке чтения а не по алфавиту`() {
        for (n in listOf(1, 2, 10, 11)) {
            FileDocumentSource.mkdir(source, "Манга/Глава $n")
            FileDocumentSource.write(source, "Манга/Глава $n/001.jpg", png())
        }

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertEquals(
            listOf("Глава 1", "Глава 2", "Глава 10", "Глава 11"),
            library.chapters(manga).map { it.name },
        )
    }

    @Test
    fun `у одиночного архива одна глава`() {
        put("Одинокий.cbz", zip("001.jpg"))

        val manga = library.manga(FileDocumentSource.root()).single()

        assertEquals(listOf("Одинокий"), library.chapters(manga).map { it.name })
        assertEquals(1, library.pages(library.chapters(manga).single()).size)
    }

    // Страницы

    @Test
    fun `страницы архива идут в натуральном порядке`() {
        put("Манга/Глава 1.cbz", zipOf(*listOf("1.jpg", "2.jpg", "10.jpg", "003.jpg").map { it to png() }.toTypedArray()))

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val pages = library.pages(library.chapters(manga).single())

        assertEquals(listOf("1.jpg", "2.jpg", "003.jpg", "10.jpg"), pages.map { it.name })
    }

    @Test
    fun `страница читается из архива целиком`() {
        val image = png()
        put("Манга/Глава 1.cbz", zipOf("001.jpg" to image, "002.jpg" to image))

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val pages = library.pages(library.chapters(manga).single())

        assertTrue(library.pageBytes(pages.first())!!.contentEquals(image))
    }

    @Test
    fun `страница из папки читается файлом`() {
        val image = png()
        FileDocumentSource.mkdir(source, "Манга/Глава 1")
        FileDocumentSource.write(source, "Манга/Глава 1/001.jpg", image)

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val page = library.pages(library.chapters(manga).single()).single()

        assertTrue(library.pageBytes(page)!!.contentEquals(image))
    }

    // Обложки

    @Test
    fun `свой файл cover важнее первой страницы`() {
        put("Манга/Глава 1.cbz", zip("001.jpg"))
        val own = png(0x11)
        FileDocumentSource.write(source, "Манга/cover.png", own)

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertTrue(library.coverBytes(manga)!!.contentEquals(own))
    }

    @Test
    fun `обложка без своего файла берется из самой ранней главы`() {
        val first = png(0x22)
        val second = png(0x33)
        put("Манга/Глава 1.cbz", zipOf("001.jpg" to first))
        put("Манга/Глава 2.cbz", zipOf("001.jpg" to second))

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertTrue(library.coverBytes(manga)!!.contentEquals(first))
    }

    @Test
    fun `обложка ищется и в главе-папке`() {
        val page = png(0x44)
        FileDocumentSource.mkdir(source, "Манга/Глава 1")
        FileDocumentSource.write(source, "Манга/Глава 1/001.jpg", page)

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertTrue(library.coverBytes(manga)!!.contentEquals(page))
    }

    @Test
    fun `у пустой манги обложки нет а не падает`() {
        FileDocumentSource.mkdir(source, "Манга")

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }

        assertNull(library.cover(manga))
        assertNull(library.coverBytes(manga))
    }

    @Test
    fun `битый архив не роняет ни библиотеку ни обложку`() {
        FileDocumentSource.write(source, "Манга/Глава 1.cbz", ByteArray(2048) { 7 })

        val manga = library.manga(FileDocumentSource.root()).single { it.name == "Манга" }
        val chapter = library.chapters(manga).single()

        assertNotNull(chapter)
        assertTrue(library.pages(chapter).isEmpty())
        assertNull(library.cover(manga))
    }

    private fun put(path: String, bytes: ByteArray) = FileDocumentSource.write(source, path, bytes)

    private companion object {
        fun png(marker: Int = 1): ByteArray = byteArrayOf(
            0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
            marker.toByte(), 0x00, 0x00, 0x00, 0x0D,
        )

        /** zip-архив с одной картинкой. */
        fun zip(vararg names: String): ByteArray = zipOf(*names.map { it to png() }.toTypedArray())

        /** zip-архив с заданными картинками. */
        fun zipOf(vararg files: Pair<String, ByteArray>): ByteArray {
            val out = java.io.ByteArrayOutputStream()
            ZipOutputStream(out).use { zip ->
                files.forEach { (name, bytes) ->
                    // Метод STORED требует размера и контрольной суммы заранее:
                    // иначе ZipOutputStream такую запись просто не пишет.
                    val entry = ZipEntry(name).apply {
                        method = ZipEntry.STORED
                        size = bytes.size.toLong()
                        compressedSize = bytes.size.toLong()
                        crc = CRC32().apply { update(bytes) }.value
                    }
                    zip.putNextEntry(entry)
                    zip.write(bytes)
                    zip.closeEntry()
                }
            }
            return out.toByteArray()
        }
    }
}
