package app.yomikai.shell.library

import app.yomikai.shell.archive.ZipReader
import app.yomikai.shell.archive.naturalOrder
import app.yomikai.shell.archive.openZip

/** Манга: папка или одиночный архив. Главы лежат внутри (см. [LocalRules]). */
data class Manga(
    val ref: Ref,
    val name: String,
    val isDirectory: Boolean,
    /** Файлы папки манги: нужны для поиска `cover.*`. */
    val children: List<Ref>,
)

/** Глава манги: архив, epub или папка с картинками. */
data class Chapter(
    val ref: Ref,
    val name: String,
    /** Признак, что глава — папка: у неё свой каталог картинок. */
    val isFolder: Boolean,
)

/** Страница главы: запись архива или отдельный файл. */
sealed interface PageRef {
    val name: String

    data class InArchive(
        val ref: Ref,
        val entry: String,
    ) : PageRef {
        override val name: String get() = entry.substringAfterLast('/')
    }

    data class File(
        val ref: Ref,
    ) : PageRef {
        override val name: String get() = ref.name
    }
}

/** Обложка: либо файл обложки манги, либо первая страница главы. */
sealed interface Cover {
    data class FromFile(val ref: Ref) : Cover
    data class FromPage(val page: PageRef) : Cover
}

/**
 * Локальная библиотека поверх источника документов.
 *
 * Ни Android, ни SAF: всё через [DocumentSource]. Поэтому правила проверяются
 * тестами на настоящих папках и zip-файлах, а не догадками на устройстве.
 */
class LocalLibrary(private val source: DocumentSource) {

    /**
     * Распакованные страницы вокруг текущей. Обычный LinkedHashMap без
     * синхронизации: обращение идёт из одного потока загрузки страницы,
     * а доступ из UI — только на чтение уже готового результата.
     */
    private val pageCache = LinkedHashMap<String, ByteArray>(16, 0.75f, true)

    /** Манги в корне: папки и одиночные архивы, служебное отброшено. */
    fun manga(root: Ref): List<Manga> = source.children(root)
        .filter { LocalRules.isManga(it) }
        .map { document ->
            Manga(
                ref = document,
                name = LocalRules.mangaName(document),
                isDirectory = document.isDirectory,
                // У одиночного архива «детей» нет: он и есть глава.
                children = if (document.isDirectory) source.children(document) else emptyList(),
            )
        }
        .sortedWith { a, b -> naturalOrder(a.name, b.name) }

    /** Главы манги в порядке чтения: том 1, том 2, … том 10. */
    fun chapters(manga: Manga): List<Chapter> {
        if (!manga.isDirectory) {
            // Одиночный архив — манга с одной главой.
            return listOf(Chapter(ref = manga.ref, name = manga.name, isFolder = false))
        }
        return manga.children
            .filter { LocalRules.isChapter(it, source::children) }
            .map { document ->
                Chapter(
                    ref = document,
                    name = LocalRules.chapterName(document),
                    isFolder = document.isDirectory,
                )
            }
            .sortedWith { a, b -> naturalOrder(a.name, b.name) }
    }

    /**
     * Страницы главы в натуральном порядке.
     *
     * У папки — картинки из неё, у архива — записи из центрального каталога.
     * Ничего не распаковываем: читается только оглавление архива.
     */
    fun pages(chapter: Chapter): List<PageRef> = when {
        chapter.isFolder -> source.children(chapter.ref)
            .filter { LocalRules.isImage(it) }
            .sortedWith { a, b -> naturalOrder(a.name, b.name) }
            .map { PageRef.File(it) }

        chapter.ref.extension in LocalRules.ARCHIVE_EXTENSIONS ->
            archiveEntries(chapter.ref)
                .map { entry -> PageRef.InArchive(ref = chapter.ref, entry = entry) }

        else -> emptyList()
    }

    /**
     * Обложка манги: свой файл `cover.*`, иначе первая картинка самой ранней
     * главы. Обложка из поздней главы — это уже не начало тайтла, поэтому
     * берётся именно первая по порядку.
     */
    fun cover(manga: Manga): Cover? {
        LocalRules.explicitCover(manga.children)?.let { return Cover.FromFile(it) }
        val firstChapter = chapters(manga).firstOrNull() ?: return null
        pages(firstChapter).firstOrNull()?.let { return Cover.FromPage(it) }
        return null
    }

    /** Байты обложки: файл обложки либо первая страница главы. */
    fun coverBytes(manga: Manga): ByteArray? = when (val cover = cover(manga)) {
        null -> null
        is Cover.FromFile -> source.readBytes(cover.ref)
        is Cover.FromPage -> pageBytes(cover.page)
    }

    /**
     * Байты страницы. Кэш держит несколько страниц вокруг текущей, иначе
     * листание назад распаковывает архив заново на каждом шаге.
     */
    fun pageBytes(page: PageRef): ByteArray? {
        val key = keyOf(page)
        pageCache[key]?.let { return it }
        val bytes = when (page) {
            is PageRef.File -> source.readBytes(page.ref)
            is PageRef.InArchive -> readEntry(page)
        } ?: return null
        pageCache[key] = bytes
        while (pageCache.size > CACHE_PAGES) {
            val oldest = pageCache.keys.firstOrNull() ?: break
            pageCache.remove(oldest)
        }
        return bytes
    }

    fun clearCache() = pageCache.clear()

    private fun readEntry(page: PageRef.InArchive): ByteArray? = runCatching {
        val opened = source.openChannel(page.ref) ?: return null
        opened.use {
            val zip = openZip(it.channel, it.size)
            try {
                val entry = zip.find(page.entry) ?: return null
                zip.read(entry)
            } finally {
                zip.close()
            }
        }
    }.getOrNull()

    /**
     * Записи-картинки архива.
     *
     * Битый архив — это пустой список, а не исключение: один негодный файл в
     * папке не должен ронять ни список глав, ни обложку, ни всю библиотеку.
     */
    private fun archiveEntries(ref: Ref): List<String> = runCatching {
        val opened = source.openChannel(ref) ?: return emptyList()
        opened.use {
            openZip(it.channel, it.size).use { zip: ZipReader ->
                zip.imageEntries(LocalRules.IMAGE_EXTENSIONS).map { entry -> entry.name }
            }
        }
    }.getOrDefault(emptyList())

    private fun keyOf(page: PageRef): String = when (page) {
        is PageRef.File -> page.ref.uri
        // Разделитель не встречается в URI: без него архив «том 1/» и запись
        // «том 1 стр 2» дали бы одну и ту же пару ключа.
        is PageRef.InArchive -> page.ref.uri + '\u0000' + page.entry
    }

    private companion object {
        const val CACHE_PAGES = 6
    }
}
