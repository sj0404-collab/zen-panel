package app.yomikai.shell.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import java.io.FileInputStream

/**
 * Источник документов на устройстве: SAF.
 *
 * Единственное место в приложении, которое знает про Android. Всё остальное
 * работает с [DocumentSource], и потому покрыто тестами на настоящих файлах.
 *
 * Ключевой момент, на котором ломалось всё в первой версии: содержимое
 * документа запрашивается через `buildChildDocumentsUriUsingTree` от URI
 * ДЕРЕВА. Запрос по URI документа возвращает сам документ — то есть папка
 * показывается одной строкой сама себя и войти в неё нельзя. URI дерева
 * приезжает в [Ref.tree] вместе с ссылкой, а не ищется в памяти процесса:
 * память после перезапуска пуста, и всё, что открывали вчера, перестаёт
 * открываться.
 */
class SafDocumentSource(private val context: Context) : DocumentSource {

    private val prefs = context.getSharedPreferences("roots", Context.MODE_PRIVATE)

    /** Отсортированные по имени корни: при запуске порядок не должен меняться. */
    fun roots(): List<Ref> = prefs.getStringSet("uris", emptySet()).orEmpty()
        .map { Ref.treeRoot(it) }
        .sortedBy { it.name.lowercase() }

    fun addRoot(treeUri: String): Boolean {
        val uri = Uri.parse(treeUri)
        // Права выдаются оболочке навсегда: без persistable-разрешения папка
        // перестаёт читаться уже после перезапуска процесса.
        val persisted = runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }.isSuccess
        if (!persisted) return false
        val next = prefs.getStringSet("uris", emptySet()).orEmpty().toMutableSet().apply { add(treeUri) }
        prefs.edit().putStringSet("uris", next).apply()
        return true
    }

    fun removeRoot(ref: Ref) {
        runCatching {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(ref.uri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        val next = prefs.getStringSet("uris", emptySet()).orEmpty().toMutableSet().apply { remove(ref.uri) }
        prefs.edit().putStringSet("uris", next).apply()
    }

    override fun children(parent: Ref): List<Ref> {
        // Без дерева содержимое не перечислить в принципе.
        if (parent.tree.isBlank()) return emptyList()
        val tree = Uri.parse(parent.tree)
        val document = Uri.parse(parent.uri)
        val docId = if (parent.isDirectory && document != tree) {
            DocumentsContract.getDocumentId(document)
        } else {
            DocumentsContract.getTreeDocumentId(tree)
        }
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = ArrayList<Ref>()
        context.contentResolver.query(children, null, null, null, null)?.use { cursor ->
            val idColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val sizeColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            val mimeColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val docId = if (idColumn >= 0) cursor.getString(idColumn) else null
                val name = if (nameColumn >= 0) cursor.getString(nameColumn) else null
                val size = if (sizeColumn >= 0 && !cursor.isNull(sizeColumn)) cursor.getLong(sizeColumn) else 0L
                val mime = if (mimeColumn >= 0) cursor.getString(mimeColumn) else null
                out.add(
                    Ref(
                        uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId.orEmpty()).toString(),
                        // Дерево едет вместе с ребёнком: без него вложенная
                        // папка не знает, по какому дереву себя перечислять.
                        tree = parent.tree,
                        name = name.orEmpty(),
                        isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR,
                        size = size,
                    ),
                )
            }
        }
        return out
    }

    override fun readBytes(doc: Ref, maxBytes: Long): ByteArray? = runCatching {
        context.contentResolver.openInputStream(Uri.parse(doc.uri))?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(128 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > maxBytes) return null
                out.write(buffer, 0, read)
            }
            out.toByteArray()
        }
    }.getOrNull()

    override fun openChannel(doc: Ref): Opened? = runCatching {
        val pfd = context.contentResolver.openFileDescriptor(Uri.parse(doc.uri), "r") ?: return null
        // Канал держит дескриптор открытым: закрывать pfd отдельно нельзя.
        val channel = FileInputStream(pfd.fileDescriptor).channel
        Opened(channel = channel, size = if (channel.size() > 0) channel.size() else pfd.statSize)
    }.getOrNull()
}
