package app.yomikai.shell.library

import java.io.File
import java.io.RandomAccessFile
import java.nio.file.Files

/**
 * Источник документов поверх обычной папки — для тестов.
 *
 * Ключевая деталь: здесь настоящие файлы и настоящие zip, а не заглушки. Ошибки
 * прошлой версии (глава-папка без картинок, обложка не из первой главы, потерянное
 * расширение файла) видны только на настоящем дереве каталогов.
 */
class FileDocumentSource(private val root: File) : DocumentSource {

    override fun children(parent: Ref): List<Ref> {
        val dir = file(parent.uri)
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles().orEmpty().map { of(it) }
    }

    override fun readBytes(doc: Ref, maxBytes: Long): ByteArray? = runCatching {
        val file = file(doc.uri)
        if (!file.isFile || file.length() > maxBytes) return null
        Files.readAllBytes(file.toPath())
    }.getOrNull()

    override fun openChannel(doc: Ref): Opened? = runCatching {
        val file = file(doc.uri)
        if (!file.isFile) return null
        val raf = RandomAccessFile(file, "r")
        Opened(channel = raf.channel, size = raf.length())
    }.getOrNull()

    private fun file(uri: String): File = File(root, uri.removePrefix(ROOT))

    private fun of(file: File): Ref = Ref(
        uri = ROOT + file.relativeTo(root).invariantSeparatorsPath,
        // У обычной папки дерева нет: пустая строка и есть «дерево не нужно».
        tree = "",
        name = file.name,
        isDirectory = file.isDirectory,
        size = if (file.isDirectory) 0L else file.length(),
    )

    companion object {
        const val ROOT = "/"

        fun root(): Ref = Ref(uri = ROOT, name = "корень", isDirectory = true)

        fun write(source: FileDocumentSource, path: String, bytes: ByteArray) {
            val file = File(source.root, path.removePrefix(ROOT))
            file.parentFile?.mkdirs()
            file.writeBytes(bytes)
        }

        fun mkdir(source: FileDocumentSource, path: String) {
            File(source.root, path.removePrefix(ROOT)).mkdirs()
        }
    }
}
