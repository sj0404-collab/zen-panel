package app.yomikaioverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

/**
 * Прозрачная activity, которая добывает разрешение на захват экрана
 * (MediaProjection consent). Система строго требует: диалог может вызвать
 * только activity, поэтому сервис передаёт запрос через неё.
 */
class CaptureConsentActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 42

        fun request(context: Context, next: String) {
            val i = Intent(context, CaptureConsentActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_HISTORY)
            i.putExtra("next", next)
            context.startActivity(i)
        }
    }

    private var asked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ask()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        ask()
    }

    private fun ask() {
        if (asked) return
        asked = true
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        } catch (e: Exception) {
            Toast.makeText(this, "Захват экрана не поддержан: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val next = intent.getStringExtra("next") ?: "scan"
                OverlayService.startForegroundService(this) // поднять сервис, если ещё не
                val s = Intent(this, OverlayService::class.java)
                s.action = OverlayService.ACTION_PROJECTION
                s.putExtra("resultCode", resultCode)
                s.putExtra("data", data)
                s.putExtra("next", next)
                startService(s)
            } else {
                Toast.makeText(this, "Захват экрана отклонён", Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
