package app.yomikaioverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Служба спецвозможностей для автопрокрутки страниц во время авточтения.
 * Делает свайп вверх внутри OCR-рамки (как палец по экрану).
 *
 * ВАЖНО: на Android 13+ для приложений, установленных APK-файлом, система
 * может блокировать включение («Доступ к настройкам ограничен»). Снятие
 * блокировки: Настройки → Приложения → Yomikai Оверлей → меню ⋮ →
 * «Разрешить ограниченные настройки», затем включить службу снова.
 */
class ScrollAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScrollAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Свайп «листание вперёд» внутри области [left,top,right,bottom] (пиксели экрана). */
    fun swipeForward(left: Int, top: Int, right: Int, bottom: Int): Boolean {
        val cx = clamp((left + right) / 2, 1, widthGuess() - 1).toFloat()
        val h = (bottom - top).coerceAtLeast(120)
        val yFrom = (top + h * 0.80f).toInt()
        val yTo = (top + h * 0.38f).toInt()
        return swipe(cx, yFrom.toFloat(), cx, yTo.toFloat())
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        return try {
            val path = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 380L))
                .build()
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            false
        }
    }

    private fun clamp(v: Int, lo: Int, hi: Int) = if (v < lo) lo else if (v > hi) hi else v

    private fun widthGuess(): Int = resources.displayMetrics.widthPixels.coerceAtLeast(1)
}
