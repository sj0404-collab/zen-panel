package app.yomikaioverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import app.yomikaioverlay.ot.EnginePrefs
import app.yomikaioverlay.ot.GlensOcrEngine
import app.yomikaioverlay.ot.GoogleAiOcrEngine
import app.yomikaioverlay.ot.OpenRouterOcrEngine
import app.yomikaioverlay.ot.ScriptDetect
import app.yomikaioverlay.ot.Translator
import app.yomikaioverlay.ot.ZenFreeOcrEngine
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Плавающий OCR-оверлей поверх других приложений.
 *
 * Интерфейс — как плавающее меню читалки: пузырь с тапом → тёмная
 * закруглённая карточка с круглыми кнопками: OCR скан (разовый),
 * Авточтение, Стоп чтения, Голос (♀/♂/⚙), Скорость (−/+), Движок,
 * Область (пресеты + удержание для настройки рамки), Панель вниз,
 * Скрыть, Закрыть.
 *
 * UI построен на нативных View (не Compose) — класс крашей
 * «ViewTreeLifecycleOwner not found» здесь невозможен в принципе.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START = "app.yomikaioverlay.START"
        const val ACTION_SCAN_ONCE = "app.yomikaioverlay.SCAN_ONCE"
        const val ACTION_AUTO_READ = "app.yomikaioverlay.AUTO_READ"
        const val ACTION_PROJECTION = "app.yomikaioverlay.PROJECTION"
        const val ACTION_READ_TOGGLE = "app.yomikaioverlay.READ_TOGGLE"
        private const val NOTIF_ID = 101
        private const val CH_ID = "ocr_overlay"

        @Volatile
        var running = false
            private set

        fun startForegroundService(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            i.action = ACTION_START
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                ctx.startService(i)
            }
        }

        fun scanOnceNow(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            i.action = ACTION_SCAN_ONCE
            ctx.startService(i)
        }

        fun autoReadNow(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            i.action = ACTION_AUTO_READ
            ctx.startService(i)
        }
    }

    // --- Цвета как в читалке ---
    private val cardBg = Color.parseColor("#F2262A34")
    private val btnBg = Color.parseColor("#3D404C")
    private val btnBgAccent = Color.parseColor("#FFC24C")
    private val txtTitle = Color.parseColor("#EEEFF3")
    private val txtSub = Color.parseColor("#AFC0D8")
    private val frameRed = Color.parseColor("#D32F2F")
    private val fabRed = Color.parseColor("#F44336")

    private lateinit var wm: WindowManager
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var ui: Handler

    private var ocrThread: HandlerThread? = null
    private lateinit var ocrHandler: Handler

    // Окна
    private var mainRoot: LinearLayout? = null
    private var mainLp: WindowManager.LayoutParams? = null
    private var bubbleView: View? = null
    private var panelCard: LinearLayout? = null
    private var previewText: TextView? = null
    private var frameView: View? = null
    private var frameLp: WindowManager.LayoutParams? = null
    private var selectRoot: FrameLayout? = null

    // Состояние
    private var expanded = false
    private var hiddenSnooze = false
    @Volatile private var autoReading = false
    @Volatile private var speaking = false
    private var lastText = ""
    private var repeatCount = 0
    private var preview = ""

    // MediaProjection
    private var projection: MediaProjection? = null
    private var projectionGranted = false

    // OCR: ТОЛЬКО онлайн-движки (Google Lens / Zen Free / Gemini / OpenRouter)
    // — как в overlay-translator. Оффлайн-моделей в APK нет, вес минимальный.
    private val glensOcr by lazy { GlensOcrEngine() }
    private val zenOcr by lazy { ZenFreeOcrEngine(this) }
    private val googleOcr by lazy { GoogleAiOcrEngine(this) }
    private val orOcr by lazy { OpenRouterOcrEngine(this) }
    private val translator by lazy { Translator(this) }

    // TTS: по умолчанию сетевые голоса Edge (как у пользователя везде),
    // системный TTS — резерв/фолбэк.
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var mediaPlayer: MediaPlayer? = null

    private var wakeLock: PowerManager.WakeLock? = null

    private fun dp(v: Number) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun screenSize(): Point {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val p = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
            p
        }
    }

    // ------------------------------------------------------------------
    // Жизненный цикл
    // ------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("ovr", MODE_PRIVATE)
        ui = Handler(mainLooper)
        val th = HandlerThread("overlay-ocr")
        th.start()
        ocrThread = th
        ocrHandler = Handler(th.looper)
        ensureForeground(false)
        buildWindows()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        autoReading = false
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
        ttsReady = false
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        projectionGranted = false
        removeAllWindows()
        try { ocrThread?.quitSafely() } catch (e: Exception) { }
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                ensureForeground(projectionGranted)
                showMain(true)
            }
            ACTION_SCAN_ONCE -> {
                ensureForeground(projectionGranted)
                if (!projectionGranted) {
                    CaptureConsentActivity.request(this, "scan")
                } else {
                    scanOnce()
                }
            }
            ACTION_AUTO_READ -> {
                ensureForeground(projectionGranted)
                if (!projectionGranted) {
                    CaptureConsentActivity.request(this, "read")
                } else {
                    startAutoRead()
                }
            }
            ACTION_READ_TOGGLE -> {
                if (autoReading) stopAutoRead() else startAutoReadOrAsk()
            }
            ACTION_PROJECTION -> {
                val rc = intent.getIntExtra("resultCode", 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra("data", Intent::class.java)
                } else {
                    intent.getParcelableExtra("data")
                }
                if (rc != 0 && data != null) {
                    grantProjection(rc, data)
                    when (intent.getStringExtra("next")) {
                        "read" -> startAutoRead()
                        else -> scanOnce()
                    }
                }
            }
        }
        return START_STICKY
    }

    // ------------------------------------------------------------------
    // Foreground: двухфазно (mediaPlayback → +mediaProjection после consent),
    // иначе Android 14+ роняет сервис SecurityException'ом («в других местах»).
    // ------------------------------------------------------------------

    /** Обновляет уведомление сервиса: распознанный текст виден прямо в шторке,
     * плюс кнопки-экшены «OCR скан» и «Авточтение/Стоп». */
    private fun notifyStatus(text: String?) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val content = if (text.isNullOrBlank()) getString(R.string.notif_text) else text
            val scanPi = PendingIntent.getService(
                this, 1,
                Intent(this, OverlayService::class.java).apply { action = ACTION_SCAN_ONCE },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val readPi = PendingIntent.getService(
                this, 2,
                Intent(this, OverlayService::class.java).apply { action = ACTION_READ_TOGGLE },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder(this, CH_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
            }
            b.setSmallIcon(R.drawable.ic_scan)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(if (content.length > 160) content.take(160) + "…" else content)
                .setContentIntent(
                    PendingIntent.getActivity(
                        this, 0, Intent(this, MainActivity::class.java),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                )
                .setOngoing(true)
            if (content.isNotBlank() && content != getString(R.string.notif_text)) {
                b.setStyle(Notification.BigTextStyle().bigText(content))
            }
            b.addAction(Notification.Action.Builder(null, "OCR скан", scanPi).build())
            b.addAction(
                Notification.Action.Builder(
                    null, if (autoReading) "Стоп чтения" else "Авточтение", readPi
                ).build()
            )
            nm.notify(NOTIF_ID, b.build())
        } catch (e: Exception) {
            android.util.Log.w("OverlayService", "notifyStatus: ${e.message}")
        }
    }

    private fun ensureForeground(withProjection: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(CH_ID) == null) {
                val ch = NotificationChannel(CH_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_MIN)
                nm.createNotificationChannel(ch)
            }
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_scan)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_text))
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_scan)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.notif_text))
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                if (withProjection) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                }
                startForeground(NOTIF_ID, n, type)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (se: SecurityException) {
            // Крайняя страховка: подняться без типа, но сервис должен жить.
            runCatching { startForeground(NOTIF_ID, n) }
        }
    }

    // ------------------------------------------------------------------
    // Окна оверлея
    // ------------------------------------------------------------------

    private fun overlayLp(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        flags = flags or if (touchable) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        val lp = WindowManager.LayoutParams(
            w, h,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun rounded(color: Int, rdp: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(rdp).toFloat()
    }

    private fun buildWindows() {
        val s = screenSize()

        // Рамка OCR-области (ненажимаемая, прозрачная)
        frameView = RegionFrameView()
        frameLp = overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, false)
        try { wm.addView(frameView, frameLp) } catch (e: Exception) { }

        // Пузырь + карточка панели в одном окне
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mainRoot = root
        mainLp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true).apply {
            x = s.x - dp(76)
            y = (s.y * 0.42f).toInt()
        }

        val bubble = BubbleView()
        bubbleView = bubble
        val bl = LinearLayout.LayoutParams(dp(56), dp(56))
        bubble.layoutParams = bl
        attachBubbleTouch(bubble)
        root.addView(bubble)

        val gap = View(this)
        gap.layoutParams = LinearLayout.LayoutParams(1, dp(10))
        root.addView(gap)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18f)
            visibility = View.GONE
            val w = minOf(dp(356f), s.x - dp(24))
            layoutParams = LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val pad = dp(8)
        card.setPadding(pad, pad, pad, pad)
        panelCard = card
        root.addView(card)

        try { wm.addView(root, mainLp) } catch (e: Exception) { }
    }

    private fun removeAllWindows() {
        try { selectRoot?.let { wm.removeView(it) } } catch (e: Exception) { }
        selectRoot = null
        try { mainRoot?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { frameView?.let { wm.removeView(it) } } catch (e: Exception) { }
        mainRoot = null
        frameView = null
    }

    private fun showMain(visible: Boolean) {
        hiddenSnooze = !visible
        mainRoot?.visibility = if (visible) View.VISIBLE else View.GONE
        refreshFrame()
    }

    // --- Пузырь: тап = меню; тянуть = переместить ---
    private fun attachBubbleTouch(b: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        b.setOnTouchListener { v, ev ->
            val lp = mainLp ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        val s = screenSize()
                        lp.x = clamp(startX + dx.toInt(), 0, s.x - v.width)
                        lp.y = clamp(startY + dy.toInt(), 0, s.y - v.height)
                        try { wm.updateViewLayout(mainRoot, lp) } catch (e: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExpanded()
                    moved = false
                    v.performClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun clamp(v: Int, lo: Int, hi: Int) = if (v < lo) lo else if (v > hi) hi else v

    // ------------------------------------------------------------------
    // Рамка OCR-области
    // ------------------------------------------------------------------

    private fun regionRatio(): Rect {
        val l = prefs.getFloat("reg_l", 0.025f)
        val t = prefs.getFloat("reg_t", 0.55f)
        val r = prefs.getFloat("reg_r", 0.975f)
        val b = prefs.getFloat("reg_b", 0.98f)
        val s = screenSize()
        return Rect(
            (s.x * l).toInt(), (s.y * t).toInt(),
            (s.x * r).toInt(), (s.y * b).toInt()
        )
    }

    private fun saveRegionRatio(rectPx: Rect) {
        val s = screenSize()
        prefs.edit()
            .putFloat("reg_l", rectPx.left.toFloat() / s.x)
            .putFloat("reg_t", rectPx.top.toFloat() / s.y)
            .putFloat("reg_r", rectPx.right.toFloat() / s.x)
            .putFloat("reg_b", rectPx.bottom.toFloat() / s.y)
            .putString("reg_preset", "custom")
            .apply()
        refreshFrame()
        rebuildPanel()
    }

    private fun regionLabel(): String = when (prefs.getString("reg_preset", "bottom")) {
        "full" -> "Весь экран"
        "top" -> "Верхняя половина"
        "center" -> "Центральная половина"
        "bottom" -> "Нижняя половина"
        else -> "Своя рамка"
    }

    private fun cycleRegionPreset() {
        val s = screenSize()
        when (prefs.getString("reg_preset", "bottom")) {
            "bottom" -> setPreset("full", Rect(0, 0, s.x, s.y))
            "full" -> setPreset("top", Rect(0, 0, s.x, s.y / 2))
            "top" -> setPreset("center", Rect(0, s.y / 4, s.x, (s.y * 0.75f).toInt()))
            else -> setPreset(
                "bottom",
                Rect((s.x * 0.025f).toInt(), (s.y * 0.55f).toInt(), (s.x * 0.975f).toInt(), (s.y * 0.98f).toInt())
            )
        }
    }

    private fun setPreset(name: String, rectPx: Rect) {
        prefs.edit().putString("reg_preset", name).apply()
        saveRegionRatio(rectPx)
        prefs.edit().putString("reg_preset", name).apply()
        frameView?.invalidate()
    }

    private fun refreshFrame() {
        frameView?.visibility =
            if (!hiddenSnooze && (expanded || autoReading)) View.VISIBLE else View.GONE
        frameView?.invalidate()
    }

    private inner class RegionFrameView : View(this@OverlayService) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(2.5f).toFloat()
            color = frameRed
            pathEffect = DashPathEffect(floatArrayOf(20f, 12f), 0f)
        }
        override fun onDraw(c: Canvas) {
            val r = regionRatio()
            c.drawRect(
                r.left + 2f, r.top + 2f, r.right - 2f, r.bottom - 2f, p
            )
        }
    }

    // --- Настройка рамки: удержание по строке «Область…» ---

    private fun openRegionSelect() {
        if (selectRoot != null) return
        setExpanded(false)
        val container = FrameLayout(this)
        val sel = RegionSelectView()
        container.addView(sel, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
        }
        val btnLp = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
        fun mkBtn(t: String): Button {
            val b = Button(this)
            b.text = t
            b.setTextColor(txtTitle)
            b.background = rounded(btnBg, 12f)
            b.layoutParams = btnLp
            bar.addView(b)
            return b
        }
        mkBtn("Готово").setOnClickListener {
            saveRegionRatio(sel.currentRect())
            closeRegionSelect()
            setExpanded(true)
        }
        mkBtn("Сброс").setOnClickListener {
            val s = screenSize()
            sel.setRect(Rect((s.x * 0.025f).toInt(), (s.y * 0.55f).toInt(), (s.x * 0.975f).toInt(), (s.y * 0.98f).toInt()))
        }
        mkBtn("Отмена").setOnClickListener {
            closeRegionSelect()
            setExpanded(true)
        }
        val bl = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        bl.gravity = Gravity.BOTTOM
        container.addView(bar, bl)
        val lp = overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true)
        try { wm.addView(container, lp) } catch (e: Exception) { }
        selectRoot = container
        refreshFrame()
    }

    private fun closeRegionSelect() {
        try { selectRoot?.let { wm.removeView(it) } } catch (e: Exception) { }
        selectRoot = null
        refreshFrame()
    }

    private inner class RegionSelectView : View(this@OverlayService) {
        private var rect = Rect(regionRatio())
        private val zone = dp(48)
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(3).toFloat()
            color = frameRed
        }
        private val fill = Paint().apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#33FFFFFF")
        }
        private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

        private var mode = 0 // 0..8: стороны/угол; -6 move
        private var lastX = 0f
        private var lastY = 0f

        fun currentRect() = Rect(rect)
        fun setRect(r: Rect) { rect = Rect(r); invalidate() }

        override fun onDraw(c: Canvas) {
            // затемнение снаружи
            val w = width
            val h = height
            c.drawRect(0f, 0f, w.toFloat(), rect.top.toFloat(), fill)
            c.drawRect(0f, rect.bottom.toFloat(), w.toFloat(), h.toFloat(), fill)
            c.drawRect(0f, rect.top.toFloat(), rect.left.toFloat(), rect.bottom.toFloat(), fill)
            c.drawRect(rect.right.toFloat(), rect.top.toFloat(), w.toFloat(), rect.bottom.toFloat(), fill)
            c.drawRect(rect, border)
            // четыре прямоугольника-ручки по серединам сторон + уголок справа-снизу
            val hw = dp(44f).toFloat()
            val hh = dp(12f).toFloat()
            val cx = rect.centerX().toFloat(); val cy = rect.centerY().toFloat()
            val tops = arrayOf(
                floatArrayOf(cx, rect.top.toFloat()),
                floatArrayOf(cx, rect.bottom.toFloat())
            )
            for (t in tops) c.drawRoundRect(t[0] - hw / 2, t[1] - hh / 2, t[0] + hw / 2, t[1] + hh / 2, 8f, 8f, handlePaint)
            val sides = arrayOf(
                floatArrayOf(rect.left.toFloat(), cy),
                floatArrayOf(rect.right.toFloat(), cy)
            )
            for (t in sides) c.drawRoundRect(t[0] - hh / 2, t[1] - hw / 2, t[0] + hh / 2, t[1] + hw / 2, 8f, 8f, handlePaint)
            c.drawCircle(rect.right.toFloat(), rect.bottom.toFloat(), dp(16f).toFloat(), handlePaint)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            val x = ev.x.toInt()
            val y = ev.y.toInt()
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = ev.x
                    lastY = ev.y
                    mode = zoneFor(x, y)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = screenSize()
                    val dx = (ev.x - lastX).toInt()
                    val dy = (ev.y - lastY).toInt()
                    lastX = ev.x
                    lastY = ev.y
                    applyDrag(s, dx, dy)
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = 0
                    return true
                }
            }
            return super.onTouchEvent(ev)
        }

        private fun zoneFor(x: Int, y: Int): Int {
            val nearL = Math.abs(x - rect.left) <= zone
            val nearR = Math.abs(x - rect.right) <= zone
            val nearT = Math.abs(y - rect.top) <= zone
            val nearB = Math.abs(y - rect.bottom) <= zone
            // углы имеют приоритет
            if (nearL && nearT) return 1
            if (nearR && nearT) return 2
            if (nearL && nearB) return 3
            if (nearR && nearB) return 4
            if (nearL) return 5
            if (nearR) return 6
            if (nearT) return 7
            if (nearB) return 8
            return if (rect.contains(x, y)) -6 else 0
        }

        private fun applyDrag(s: Point, dx: Int, dy: Int) {
            val minW = dp(80)
            val minH = dp(80)
            fun clampSides() {
                if (rect.left < 0) rect.left = 0
                if (rect.top < 0) rect.top = 0
                if (rect.right > s.x) rect.right = s.x
                if (rect.bottom > s.y) rect.bottom = s.y
                if (rect.right - rect.left < minW) rect.right = rect.left + minW
                if (rect.bottom - rect.top < minH) rect.bottom = rect.top + minH
            }
            when (mode) {
                -6 -> rect.offset(dx, dy)
                1 -> { rect.left += dx; rect.top += dy }
                2 -> { rect.right += dx; rect.top += dy }
                3 -> { rect.left += dx; rect.bottom += dy }
                4 -> { rect.right += dx; rect.bottom += dy }
                5 -> rect.left += dx
                6 -> rect.right += dx
                7 -> rect.top += dy
                8 -> rect.bottom += dy
            }
            clampSides()
        }
    }

    // ------------------------------------------------------------------
    // Пузырь
    // ------------------------------------------------------------------

    private inner class BubbleView : View(this@OverlayService) {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E6262A34")
        }
        private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(3f).toFloat()
            color = frameRed
            pathEffect = DashPathEffect(floatArrayOf(16f, 9f), 0f)
        }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val rad = minOf(w, h) / 2f
            c.drawRoundRect(0f, 0f, w, h, rad, rad, bgPaint)
            val inset = dp(7f).toFloat()
            c.drawRoundRect(inset, inset, w - inset, h - inset, rad - inset, rad - inset, dash)
        }
    }

    // ------------------------------------------------------------------
    // Панель меню (один в один как в читалке)
    // ------------------------------------------------------------------

    private fun setExpanded(v: Boolean) {
        expanded = v
        panelCard?.visibility = if (v) View.VISIBLE else View.GONE
        if (v) rebuildPanel()
        refreshFrame()
    }

    private fun toggleExpanded() = setExpanded(!expanded)

    private fun circle(sizeDp: Int, bgColor: Int): View {
        val v = View(this)
        v.background = rounded(bgColor, sizeDp / 2f)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun iconBtn(iconRes: Int?, glyph: String?, bgColor: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val size = dp(40f)
        f.layoutParams = LinearLayout.LayoutParams(size, size)
        f.background = rounded(bgColor, 20f)
        f.isClickable = true
        if (iconRes != null) {
            val iv = ImageView(this)
            iv.setImageResource(iconRes)
            val lp = FrameLayout.LayoutParams(dp(22f), dp(22f))
            lp.gravity = Gravity.CENTER
            iv.layoutParams = lp
            f.addView(iv)
        } else if (glyph != null) {
            val tv = TextView(this)
            tv.text = glyph
            tv.textSize = 16f
            tv.setTextColor(txtTitle)
            tv.gravity = Gravity.CENTER
            tv.layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
            )
            f.addView(tv)
        }
        f.setOnClickListener { runCatching(onClick) }
        return f
    }

    private fun addRow(
        iconRes: Int?, leadGlyph: String?, title: String, sub: String?,
        onTap: (() -> Unit)?, onLong: (() -> Unit)? = null,
        trailing: List<FrameLayout> = emptyList()
    ) {
        val card = panelCard ?: return
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        row.addView(iconBtn(iconRes, leadGlyph, btnBg) {})
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tt = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(txtTitle)
        }
        texts.addView(tt)
        if (sub != null) {
            val st = TextView(this).apply {
                text = sub
                textSize = 12f
                setTextColor(txtSub)
            }
            texts.addView(st)
        }
        val tlp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        tlp.setMargins(dp(12), 0, dp(6), 0)
        texts.layoutParams = tlp
        row.addView(texts)
        for (b in trailing) {
            val lp = b.layoutParams as LinearLayout.LayoutParams
            lp.setMargins(dp(6), 0, 0, 0)
            row.addView(b)
        }
        if (onTap != null) row.setOnClickListener { runCatching(onTap) }
        if (onLong != null) {
            row.setOnLongClickListener { runCatching(onLong); true }
        }
        card.addView(row)
    }

    private fun divider() {
        val card = panelCard ?: return
        val d = View(this)
        d.setBackgroundColor(Color.parseColor("#1AFFFFFF"))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        lp.setMargins(dp(10), 0, dp(10), 0)
        d.layoutParams = lp
        card.addView(d)
    }

    private fun rebuildPanel() {
        val card = panelCard ?: return
        card.removeAllViews()

        // превью распознанного текста / статус
        val pv = TextView(this).apply {
            val base = if (preview.isNotBlank()) preview.take(240) else "Рамка: ${regionLabel()}. Тапни «OCR скан» или «Авточтение»."
            text = base
            textSize = 13f
            setTextColor(txtSub)
            setPadding(dp(10), dp(6), dp(10), dp(8))
            maxLines = 6
        }
        previewText = pv
        card.addView(pv)
        divider()

        // 1. OCR скан — разовый
        addRow(R.drawable.ic_scan, null, "OCR скан", "распознать и прочитать рамку",
            onTap = { scanOnceOrAsk() })

        // 2/3. Авточтение + Стоп
        if (autoReading) {
            addRow(R.drawable.ic_bars, null, "Авточтение: идёт…", "стоп — ниже; листает рамку и читает",
                onTap = null)
            addRow(R.drawable.ic_stop, null, "Стоп чтения", null,
                onTap = { stopAutoRead() })
        } else {
            addRow(R.drawable.ic_play, null, "Авточтение", "читает рамку и листает",
                onTap = { startAutoReadOrAsk() })
        }

        // 4. Голос: ♀/♂ тембр, ≡ выбор конкретного голоса из списка + проба
        val gender = prefs.getString("gender", "female")
        val gsub = (if (gender == "male") "♂ мужской (тембр ниже)" else "♀ женский") + " · " + currentVoiceLabel()
        addRow(R.drawable.ic_bars, null, "Голос", gsub,
            onTap = null,
            trailing = listOf(
                iconBtn(null, "♀", if (gender != "male") btnBgAccent else btnBg) {
                    setGender("female")
                },
                iconBtn(null, "♂", if (gender == "male") btnBgAccent else btnBg) {
                    setGender("male")
                },
                iconBtn(null, "≡", btnBg) {
                    openVoicePicker()
                },
                iconBtn(null, "⚙", btnBg) {
                    try {
                        val i = Intent("com.android.settings.TTS_SETTINGS")
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Настройки TTS недоступны", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        )

        // 5. Скорость
        val rate = prefs.getFloat("rate", 1.0f)
        val pct = Math.round(rate * 100)
        addRow(null, "⏱", "Скорость: $pct%", "шаг 25%, диапазон 50…200%",
            onTap = null,
            trailing = listOf(
                iconBtn(R.drawable.ic_remove, null, btnBg) { changeRate(-0.25f) },
                iconBtn(R.drawable.ic_add, null, btnBg) { changeRate(+0.25f) },
                iconBtn(null, "1×", btnBg) { changeRate(1.0f - rate) }
            )
        )

        // 6. Движок: только онлайн (как в overlay-translator)
        val engSub = engineKeyHint() ?: when (engineId()) {
            "zen" -> "бесплатный ИИ-хаб (как Zen Free)"
            "googleai" -> "gemini-2.5-flash, верbatim OCR"
            "openrouter" -> "vision-модели через OpenRouter"
            else -> "бесключевой endpoint — самый простой"
        }
        addRow(R.drawable.ic_chip, null, "Движок: " + engineTitle(), engSub + ". Тап переключает",
            onTap = {
                val next = when (engineId()) {
                    "lens" -> "zen"
                    "zen" -> "googleai"
                    "googleai" -> "openrouter"
                    else -> "lens"
                }
                switchEngine(next)
            })

        // 6.4 Перевод: OCR → RU → озвучка
        val trOn = prefs.getBoolean("translate", false)
        addRow(null, "⇄", if (trOn) "Перевод: ВКЛ" else "Перевод: выкл", "латиница → русский перед озвучкой (онлайн)",
            onTap = {
                prefs.edit().putBoolean("translate", !trOn).apply()
                Toast.makeText(this, if (!trOn) "Перевод включён" else "Перевод выключен", Toast.LENGTH_SHORT).show()
                rebuildPanel()
            })

        // 6.5 Настройки
        addRow(null, "⚙", "Все настройки", "статус доступов, подсказки",
            onTap = {
                try {
                    val i = Intent(this, MainActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) { }
            })

        // 7. Область
        addRow(R.drawable.ic_frame, null, "Область: ${regionLabel()}", "удерживай, чтобы потянуть рамку за ручки",
            onTap = { cycleRegionPreset() },
            onLong = { openRegionSelect() })

        divider()

        // 8. Панель вниз
        addRow(R.drawable.ic_chevron_down, null, "Панель вниз", "свернуть меню, пузырь останется",
            onTap = { setExpanded(false) })

        // 9. Скрыть пузырь
        addRow(R.drawable.ic_chevron_up, null, "Скрыть пузырь на 30 с", null,
            onTap = {
                showMain(false)
                ui.postDelayed({ showMain(true) }, 30_000)
            })

        // 10. Закрыть
        addRow(R.drawable.ic_close, null, "Закрыть", "удерживай, чтобы выключить сервис",
            onTap = { Toast.makeText(this, "Удерживайте «Закрыть», чтобы выключить", Toast.LENGTH_SHORT).show() },
            onLong = {
                stopSelf()
            })
    }

    private fun switchEngine(id: String) {
        prefs.edit().putString("ocr_engine", id).apply()
        android.util.Log.i("OverlayOcr", "engine -> $id")
        rebuildPanel()
        val label = engineTitle()
        Toast.makeText(this, "Движок: $label", Toast.LENGTH_SHORT).show()
    }

    private fun setGender(g: String) {
        prefs.edit().putString("gender", g).apply()
        rebuildPanel()
    }

    private fun changeRate(delta: Float) {
        var r = prefs.getFloat("rate", 1.0f) + delta
        if (Math.abs(r - 1.0f) < 0.01f) r = 1.0f
        r = Math.max(0.5f, Math.min(2.0f, (Math.round(r * 100) / 100f)))
        prefs.edit().putFloat("rate", r).apply()
        try { tts?.setSpeechRate(r) } catch (e: Exception) { }
        rebuildPanel()
    }

    // ------------------------------------------------------------------
    // MediaProjection
    // ------------------------------------------------------------------

    private fun grantProjection(resultCode: Int, data: Intent) {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(resultCode, data)
            if (Build.VERSION.SDK_INT >= 34) {
                mp.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        projection = null
                        projectionGranted = false
                        autoReading = false
                        ui.post { rebuildPanel() }
                    }
                }, ui)
            }
            projection = mp
            projectionGranted = true
            ensureForeground(true)
        } catch (e: Exception) {
            Toast.makeText(this, "Захват экрана не запустился: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun scanOnceOrAsk() {
        if (!projectionGranted) CaptureConsentActivity.request(this, "scan") else scanOnce()
    }

    private fun startAutoReadOrAsk() {
        if (!projectionGranted) CaptureConsentActivity.request(this, "read") else startAutoRead()
    }

    // ------------------------------------------------------------------
    // Захват и OCR
    // ------------------------------------------------------------------

    private fun engineId(): String {
        val id = prefs.getString("ocr_engine", "lens") ?: "lens"
        // легаси-значения (оффлайн убран) сводим к бесключевому Lens
        return if (id == "lens" || id == "zen" || id == "googleai" || id == "openrouter") id else "lens"
    }

    private fun engineTitle(): String = when (engineId()) {
        "zen" -> "Zen Free (онлайн, без ключа)"
        "googleai" -> "Google AI Gemini Vision"
        "openrouter" -> "OpenRouter Vision"
        else -> "Google Lens (онлайн)"
    }

    /** Подсказка по ключу выбранного движка (или null, если всё ок). */
    private fun engineKeyHint(): String? = when (engineId()) {
        "googleai" -> if (EnginePrefs.googleApiKey(this).isBlank()) "нет ключа — задайте в настройках" else null
        "openrouter" -> if (EnginePrefs.openrouterKey(this).isBlank()) "нет ключа — задайте в настройках" else null
        else -> null
    }

    /** Инициализация выбранного движка в OCR-потоке (блокирующая, ~2-5 с в первый раз). */
    private fun setOverlayAlpha(alpha: Float) {
        ui.post {
            try {
                mainRoot?.alpha = alpha
                frameView?.alpha = alpha
            } catch (e: Exception) { }
        }
    }

    private fun captureRegion(): Bitmap? {
        val mp = projection ?: return null
        // VirtualDisplay с AUTO_MIRROR зеркалит ВЕСЬ экран и СЖИМАЕТ его под
        // размер выдачи: раньше экран целиком ужимался в размер рамки, текст
        // мельчал до неузнаваемости и детектор не находил строк («текст не
        // найден в рамке»). Поэтому захват всегда полноэкранный, а рамка
        // вырезается из полученного кадра — как это делает overlay-translator.
        val s = screenSize()
        val full = captureScreen(mp, s.x, s.y) ?: return null
        val r = regionRatio()
        val l = r.left.coerceIn(0, full.width - 1)
        val t = r.top.coerceIn(0, full.height - 1)
        val cw = (r.right - r.left).coerceIn(8, full.width - l)
        val ch = (r.bottom - r.top).coerceIn(8, full.height - t)
        return try {
            val cropped = Bitmap.createBitmap(full, l, t, cw, ch)
            cropped
        } finally {
            full.recycle()
        }
    }

    /** Полноэкранный кадр через MediaProjection (пиксель-в-пиксель). */
    private fun captureScreen(mp: MediaProjection, w: Int, h: Int): Bitmap? {
        val density = resources.displayMetrics.densityDpi
        var reader: ImageReader? = null
        var vd: VirtualDisplay? = null
        return try {
            setOverlayAlpha(0.0f)
            Thread.sleep(150)
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            vd = mp.createVirtualDisplay(
                "ocr-scan", w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
            Thread.sleep(480)
            val img = reader.acquireLatestImage()
            if (img == null) return null
            val plane = img.planes[0]
            val buf = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * w
            val raw = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
            buf.rewind()
            raw.copyPixelsFromBuffer(buf)
            img.close()
            val exact = Bitmap.createBitmap(raw, 0, 0, w, h)
            raw.recycle()
            exact
        } catch (e: Exception) {
            null
        } finally {
            try { vd?.release() } catch (e: Exception) { }
            try { reader?.close() } catch (e: Exception) { }
            setOverlayAlpha(1f)
        }
    }

    private fun ocrScan(onText: (String) -> Unit) {
        ocrHandler.post {
            var text = ""
            try {
                val bmp = captureRegion()
                if (bmp != null) {
                    val keyHint = engineKeyHint()
                    if (keyHint != null) {
                        ui.post {
                            preview = "⚠ " + engineTitle() + ": " + keyHint
                            previewText?.text = preview
                        }
                    } else {
                        text = try {
                            when (engineId()) {
                                "zen" -> zenOcr.recognizeText(bmp)
                                "googleai" -> googleOcr.recognizeText(bmp)
                                "openrouter" -> orOcr.recognizeText(bmp)
                                else -> glensOcr.recognizeText(bmp)
                            }
                        } catch (e: Exception) {
                            android.util.Log.w("OcrNet", engineId() + ": " + e.message)
                            ""
                        }
                    }
                    try { bmp.recycle() } catch (e: Exception) { }
                }
            } catch (e: Exception) { }
            var out = text.replace("\\s+".toRegex(), " ").trim()
            // Режим «Перевод»: латиница → русский (Zen/Google Translate/MyMemory — онлайн).
            if (out.isNotBlank() && prefs.getBoolean("translate", false) && !ScriptDetect.isMostlyCyrillic(out)) {
                try {
                    val tr = translator.translate(out, EnginePrefs.TR_AUTO, EnginePrefs.MODE_ONLINE)
                    if (!tr.isNullOrBlank() && tr != out) out = tr
                } catch (e: Exception) {
                    android.util.Log.d("OcrTr", "translate: " + e.message)
                }
            }
            ui.post { onText(out) }
        }
    }

    // ------------------------------------------------------------------
    // TTS
    // ------------------------------------------------------------------

    private fun ensureTts() {
        if (tts != null) return
        try {
            tts = TextToSpeech(applicationContext) { status ->
                ttsReady = (status == TextToSpeech.SUCCESS)
                val t = tts ?: return@TextToSpeech
                try { t.setSpeechRate(prefs.getFloat("rate", 1.0f)) } catch (e: Exception) { }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    @Deprecated("dep")
                    override fun onError(utteranceId: String?) { onDone(utteranceId) }
                    override fun onDone(utteranceId: String?) {
                        ui.post {
                            speaking = false
                            if (autoReading) {
                                ui.postDelayed({ if (autoReading) scrollAndContinue() }, 350)
                            }
                        }
                    }
                })
            }
        } catch (e: Exception) {
            tts = null
            ttsReady = false
        }
    }

    /** Применяет сохранённый голос (по имени из выбора), если задан. */
    private fun applyVoicePref(t: TextToSpeech) {
        val name = prefs.getString("voice_name", "") ?: ""
        if (name.isBlank()) return
        try {
            val v = t.voices?.firstOrNull { it.name == name } ?: return
            t.voice = v
        } catch (e: Exception) { }
    }

    private fun currentVoiceLabel(): String {
        val name = prefs.getString("voice_name", "") ?: ""
        if (name.startsWith("edge:")) return name.removePrefix("edge:").take(26) + " · Edge"
        if (name.isBlank()) return (if (ttsBackend() == "edge") edgeVoiceName().take(22) + " · Edge" else "голос системы")
        return name.replace("language", "").trim('-', ' ').take(26)
    }

    /** Окно выбора голоса: список установленных TTS-голосов, тап = выбрать и прослушать. */
    private var voiceWin: FrameLayout? = null

    private fun openVoicePicker() {
        if (voiceWin != null) return
        ensureTts()
        val container = FrameLayout(this)
        container.setBackgroundColor(Color.parseColor("#CC000000"))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cardBg, 18f)
        }
        val sp = screenSize()
        val cw = minOf(dp(360), sp.x - dp(24))
        val ch = minOf(dp(460), sp.y - dp(60))
        val scroll = android.widget.ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pad = dp(12)
        list.setPadding(pad, pad, pad, pad)
        scroll.addView(list)
        card.addView(scroll, LinearLayout.LayoutParams(cw, ch))

        fun fill() {
            list.removeAllViews()
            val t = tts
            val voices = try { t?.voices?.sortedBy { it.name } } catch (e: Exception) { null }
            val head = TextView(this).apply {
                text = "Выбор голоса (тап = выбрать и прослушать)"
                textSize = 15f
                setTextColor(txtTitle)
                setPadding(dp(4), dp(4), dp(4), dp(10))
            }
            list.addView(head)
            run {
                val hdr = TextView(this).apply {
                    text = "Голоса Edge (онлайн, как в браузере):"
                    textSize = 13f
                    setTextColor(txtSub)
                    setPadding(dp(4), dp(4), dp(4), dp(6))
                }
                list.addView(hdr)
            }
            run {
                var edge = EdgeTts.cachedVoices(this@OverlayService)
                if (edge.isEmpty()) {
                    edge = listOf(
                        EdgeTts.EdgeVoice("ru-RU-SvetlanaNeural", "Female", "ru-RU", "Светлана"),
                        EdgeTts.EdgeVoice("ru-RU-DmitryNeural", "Male", "ru-RU", "Дмитрий"),
                        EdgeTts.EdgeVoice("ru-RU-DariyaNeural", "Female", "ru-RU", "Дарья"),
                    )
                }
                val cur = prefs.getString("voice_name", "")
                for (v in edge.filter { it.locale.startsWith("ru-", true) || it.multilingual }.take(24)) {
                    val key = "edge:" + v.shortName
                    val row = TextView(this).apply {
                        text = (if (cur == key) "✅ " else "") + v.label
                        textSize = 13f
                        setTextColor(if (cur == key) btnBgAccent else txtTitle)
                        setPadding(dp(8), dp(10), dp(8), dp(10))
                        background = rounded(Color.parseColor("#2E323E"), 10f)
                    }
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(0, 0, 0, dp(6))
                    row.layoutParams = lp
                    row.setOnClickListener {
                        prefs.edit()
                            .putString("voice_name", key)
                            .putString("edge_voice", v.shortName)
                            .putString("tts_backend", "edge")
                            .apply()
                        closeVoicePicker()
                        speakNowSilentPreview("Привет! Это мой голос. Желаю приятного чтения.")
                    }
                    list.addView(row)
                }
            }
            run {
                val hdr2 = TextView(this).apply {
                    text = "Системные голоса телефона:"
                    textSize = 13f
                    setTextColor(txtSub)
                    setPadding(dp(4), dp(10), dp(4), dp(6))
                }
                list.addView(hdr2)
            }
            if (voices.isNullOrEmpty()) {
                val m = TextView(this).apply {
                    text = "TTS ещё не готов или голосов нет. Откройте системные настройки TTS (⚙) и загрузите русские голоса."
                    textSize = 13f
                    setTextColor(txtSub)
                    setPadding(dp(4), dp(6), dp(4), dp(6))
                }
                list.addView(m)
            } else {
                val cur = prefs.getString("voice_name", "")
                for (v in voices) {
                    val net = try { v.isNetworkConnectionRequired } catch (e: Exception) { false }
                    val row = TextView(this).apply {
                        text = (if (v.name == cur) "✅ " else "") + v.name + "\n" +
                            v.locale.displayName + (if (net) " · сетевой" else " · локальный")
                        textSize = 13f
                        setTextColor(if (v.name == cur) btnBgAccent else txtTitle)
                        setPadding(dp(8), dp(10), dp(8), dp(10))
                        background = rounded(Color.parseColor("#2E323E"), 10f)
                    }
                    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    lp.setMargins(0, 0, 0, dp(6))
                    row.layoutParams = lp
                    row.setOnClickListener {
                        prefs.edit()
                            .putString("voice_name", v.name)
                            .putString("tts_backend", "system")
                            .apply()
                        try { t?.voice = v } catch (e: Exception) { }
                        closeVoicePicker()
                        // проба: сразу озвучиваем короткую фразу выбранным голосом
                        speakNowSilentPreview("Привет! Это мой голос. Желаю приятного чтения.")
                    }
                    list.addView(row)
                }
            }
        }
        fill()
        Thread {
            try {
                val fresh = runBlocking { EdgeTts.fetchVoices() }
                if (fresh.isNotEmpty()) {
                    EdgeTts.cacheVoices(this@OverlayService, fresh)
                    ui.post { if (voiceWin != null) fill() }
                }
            } catch (e: Exception) {
                android.util.Log.d("Edge", "fetchVoices: ${e.message}")
            }
        }.start()
        if (voicesNoneYet(list)) {
            // TTS асинхронный: перечитать список через секунду
            ui.postDelayed({ if (voiceWin != null) fill() }, 900)
        }

        container.addView(card)
        val clp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        clp.gravity = Gravity.CENTER
        card.layoutParams = clp
        container.setOnClickListener { closeVoicePicker() }
        card.setOnClickListener { } // гасим клики по карточке
        val lp = overlayLp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true)
        try { wm.addView(container, lp) } catch (e: Exception) { }
        voiceWin = container
        rebuildPanel()
    }

    private fun voicesNoneYet(list: LinearLayout): Boolean {
        val t = tts ?: return true
        return try { !ttsReady || t.voices.isNullOrEmpty() } catch (e: Exception) { true }
    }

    private fun closeVoicePicker() {
        try { voiceWin?.let { wm.removeView(it) } } catch (e: Exception) { }
        voiceWin = null
        rebuildPanel()
    }

    /** Пробная фраза: без пометки «идёт чтение» — просто прослушать голос. */
    private fun speakNowSilentPreview(phrase: String) {
        if (ttsBackend() == "edge") {
            speakEdge(phrase)
            return
        }
        val t = tts ?: run { ui.postDelayed({ speakNowSilentPreview(phrase) }, 600); return }
        if (!ttsReady) { ui.postDelayed({ speakNowSilentPreview(phrase) }, 600); return }
        try {
            t.language = pickLocale(phrase)
            applyVoicePref(t)
            t.setSpeechRate(prefs.getFloat("rate", 1.0f))
            t.setPitch(if (prefs.getString("gender", "female") == "male") 0.82f else 1.15f)
            t.speak(phrase, TextToSpeech.QUEUE_FLUSH, android.os.Bundle(), "ovr-preview")
        } catch (e: Exception) { }
    }

    private fun ttsBackend(): String = prefs.getString("tts_backend", "edge") ?: "edge"

    /** Edge-голос: явный выбор из списка, иначе по тембру ♀/♂. */
    private fun edgeVoiceName(): String {
        val custom = prefs.getString("edge_voice", "") ?: ""
        if (custom.isNotBlank()) return custom
        return if (prefs.getString("gender", "female") == "male") "ru-RU-DmitryNeural" else "ru-RU-SvetlanaNeural"
    }

    private fun pickLocale(text: String): Locale {
        var cyr = 0
        var lat = 0
        for (ch in text) {
            if (ch in 'А'..'я' || ch == 'Ё' || ch == 'ё') cyr++
            else if (ch in 'A'..'Z' || ch in 'a'..'z') lat++
        }
        return if (cyr >= lat) Locale("ru", "RU") else Locale.ENGLISH
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        ensureTts()
        val t = tts
        if (t == null || !ttsReady) {
            if (tts == null) ensureTts()
            // повторим через мгновение
            ui.postDelayed({ speakNow(text) }, 650)
            return
        }
        speakNow(text)
    }

    private fun speakNow(text: String) {
        if (ttsBackend() == "edge") {
            speakEdge(text)
            return
        }
        speakNowSystem(text)
    }

    private fun speakNowSystem(text: String) {
        val t = tts ?: return
        try {
            t.language = pickLocale(text)
            applyVoicePref(t)
            t.setSpeechRate(prefs.getFloat("rate", 1.0f))
            t.setPitch(if (prefs.getString("gender", "female") == "male") 0.82f else 1.15f)
            speaking = true
            val params = android.os.Bundle()
            t.speak(text, TextToSpeech.QUEUE_FLUSH, params, "ovr-utterance")
        } catch (e: Exception) {
            speaking = false
        }
    }

    /** Синтез сетевым голосом Edge: тексты уходят в Microsoft, кадры — никогда. */
    private fun speakEdge(text: String) {
        speaking = true
        val voice = edgeVoiceName()
        val rate = prefs.getFloat("rate", 1.0f)
        val pitch = if (prefs.getString("gender", "female") == "male") 0.82f else 1.15f
        Thread {
            var ok = false
            try {
                val ratePercent = ((rate - 1f) * 100f).roundToInt()
                val pitchHz = ((pitch - 1f) * 200f).roundToInt()
                val file = runBlocking {
                    EdgeTts.synthesizeToFile(applicationContext, text, voice, ratePercent, pitchHz)
                }
                if (file != null) {
                    ok = true
                    ui.post { playEdgeAudio(file) }
                }
            } catch (e: Exception) {
                android.util.Log.w("Edge", "speakEdge: ${e.message}")
            }
            if (!ok) {
                // нет сети/сервер недоступен → фолбэк на системный TTS
                ui.post { speakNowSystem(text) }
            }
        }.start()
    }

    private fun playEdgeAudio(file: java.io.File) {
        try {
            runCatching { mediaPlayer?.release() }
            val mp = MediaPlayer()
            mediaPlayer = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnErrorListener { _, _, _ ->
                runCatching { file.delete() }
                speaking = false
                true
            }
            mp.setOnPreparedListener { media ->
                media.start()
            }
            mp.setOnCompletionListener { done ->
                runCatching { done.release() }
                mediaPlayer = null
                runCatching { file.delete() }
                speaking = false
                if (autoReading) {
                    ui.postDelayed({ if (autoReading) scrollAndContinue() }, 350)
                }
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            android.util.Log.w("Edge", "playback: ${e.message}")
            runCatching { file.delete() }
            speaking = false
        }
    }

    // ------------------------------------------------------------------
    // Сценарии чтения
    // ------------------------------------------------------------------

    private fun scanOnce() {
        preview = "Сканирую…"
        previewText?.text = preview
        notifyStatus("Сканирую рамку…")
        refreshFrame()
        ocrScan { text ->
            if (text.isBlank()) {
                preview = "Текст не найден в рамке"
                previewText?.text = preview
                notifyStatus("Текст не найден в рамке")
                return@ocrScan
            }
            preview = text
            previewText?.text = preview
            setExpanded(true)
            notifyStatus(text) // распознанное текстом видно в шторке
            speak(text)
        }
    }

    private fun startAutoRead() {
        if (autoReading) return
        autoReading = true
        lastText = ""
        repeatCount = 0
        setExpanded(true)
        rebuildPanel()
        refreshFrame()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ovr:read")
            wakeLock?.acquire(30 * 60 * 1000L)
        } catch (e: Exception) { }
        autoStep()
    }

    fun stopAutoRead() {
        autoReading = false
        try { tts?.stop() } catch (e: Exception) { }
        runCatching { mediaPlayer?.let { if (it.isPlaying) it.stop(); it.release() } }
        mediaPlayer = null
        speaking = false
        rebuildPanel()
        refreshFrame()
        notifyStatus(if (preview.isNotBlank()) preview else null)
    }

    private fun autoStep() {
        if (!autoReading) return
        ocrScan { text ->
            if (!autoReading) return@ocrScan
            val norm = norm(text)
            if (norm.isBlank() || norm == lastText) {
                repeatCount++
                scrollAndContinue()
                return@ocrScan
            }
            repeatCount = 0
            lastText = norm
            preview = text
            previewText?.text = preview
            notifyStatus(text)
            speak(text)
            // продолжение — из onDone говорилки
        }
    }

    private fun scrollAndContinue() {
        val r = regionRatio()
        val svc = ScrollAccessibilityService.instance
        if (svc != null) {
            try { svc.swipeForward(r.left, r.top, r.right, r.bottom) } catch (e: Exception) { }
            ui.postDelayed({ if (autoReading) autoStep() }, 1250)
        } else {
            // Автопрокрутка выключена: ждём и читаем то же место снова (так видно,
            // что службу спецвозможностей нужно включить — есть подсказка в меню).
            ui.postDelayed({
                if (!autoReading) return@postDelayed
                preview = "⚠ Автопрокрутка выключена — включите «Yomikai Оверлей — прокрутка» в спец. возможностях"
                previewText?.text = preview
                lastText = "" // пусть перечитает после включения/ручной прокрутки
                ui.postDelayed({ if (autoReading) autoStep() }, 2500)
            }, 600)
        }
    }

    private fun norm(s: String) = s.lowercase().replace("\\s+".toRegex(), " ").trim()

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshFrame()
    }
}
