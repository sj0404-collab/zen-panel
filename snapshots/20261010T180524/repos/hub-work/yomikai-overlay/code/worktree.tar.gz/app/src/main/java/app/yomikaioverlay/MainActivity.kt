package app.yomikaioverlay

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnToggle: Button
    private lateinit var engBtn: Button
    private lateinit var genderBtn: Button
    private lateinit var rateBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun rounded(color: Int, rdp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(rdp).toFloat()
    }

    private fun askNotifPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            try {
                if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
                }
            } catch (e: Exception) { }
        }
    }

    private fun buildUi() {
        askNotifPermission()
        val root = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        root.setBackgroundColor(Color.parseColor("#14161B"))

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 22f
            setTextColor(Color.parseColor("#EEEFF3"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        }
        col.addView(title)

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#AFC0D8"))
            setPadding(0, 0, 0, dp(16))
        }
        col.addView(status)

        fun bigBtn(label: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.setTextColor(Color.parseColor("#EEEFF3"))
            b.background = rounded(Color.parseColor("#3D404C"), 12)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54))
            lp.setMargins(0, 0, 0, dp(12))
            b.layoutParams = lp
            b.setOnClickListener { onClick() }
            col.addView(b)
            return b
        }

        fun prefs() = getSharedPreferences("ovr", MODE_PRIVATE)

        val sect = TextView(this).apply {
            text = "Настройки (те же, что в меню пузыря):"
            textSize = 15f
            setTextColor(Color.parseColor("#EEEFF3"))
            setPadding(0, 0, 0, 8)
        }
        col.addView(sect)

        engBtn = bigBtn("Движок: …") {
            val p = prefs()
            val cur = p.getString("ocr_engine", "lens")
            val next = when (cur) { "lens" -> "zen"; "zen" -> "googleai"; "googleai" -> "openrouter"; else -> "lens" }
            p.edit().putString("ocr_engine", next).apply()
            refresh()
        }
        genderBtn = bigBtn("Голос: …") {
            val p = prefs()
            val cur = p.getString("gender", "female")
            p.edit().putString("gender", if (cur == "male") "female" else "male").apply()
            refresh()
        }
        rateBtn = bigBtn("Скорость: …") {
            val p = prefs()
            var r = p.getFloat("rate", 1.0f) + 0.25f
            if (r > 2.0f) r = 0.5f
            p.edit().putFloat("rate", r).apply()
            refresh()
        }

        // Онлайн-ключи движков (не обязательны для Lens/Zen)
        val ep = app.yomikaioverlay.ot.EnginePrefs
        fun keyRow(label: String, getter: () -> String, setter: (String) -> Unit) {
            val et = android.widget.EditText(this).apply {
                hint = label
                setText(getter())
                setTextColor(Color.parseColor("#EEEFF3"))
                setHintTextColor(Color.parseColor("#7784A0"))
                setBackgroundColor(Color.parseColor("#1E2129"))
                setPadding(dp(12), 0, dp(12), 0)
                textSize = 13f
            }
            val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48))
            lp2.setMargins(0, 0, 0, 8)
            et.layoutParams = lp2
            col.addView(et)
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(a: android.text.Editable?) { setter(a?.toString() ?: "") }
            })
        }
        keyRow("Google AI (Gemini) ключ — необязательно", { ep.googleApiKey(this) }, { ep.setGoogleApiKey(this, it) })
        keyRow("OpenRouter ключ — необязательно", { ep.openrouterKey(this) }, { ep.setOpenrouterKey(this, it) })

        btnToggle = bigBtn("▶ Запустить оверлей") {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Оверлей остановлен", Toast.LENGTH_SHORT).show()
            } else {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Сначала разрешите показ поверх приложений", Toast.LENGTH_LONG).show()
                }
                OverlayService.startForegroundService(this)
            }
            refresh()
        }

        bigBtn("Разрешить «поверх других приложений»") {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            }
        }

        bigBtn("Включить автопрокрутку (спец. возможности)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val hint = TextView(this).apply {
            text = "Если при включении «Yomikai Оверлей — прокрутка» пишет «Доступ к настройкам ограничен»:\n\n" +
                "1. Откройте сведения о приложении (кнопка ниже)\n" +
                "2. Нажмите ⋮ в правом верхнем углу\n" +
                "3. Выберите «Разрешить ограниченные настройки»\n" +
                "4. Вернитесь и включите службу ещё раз"
            textSize = 13f
            setTextColor(Color.parseColor("#DDA025"))
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = rounded(Color.parseColor("#1E2129"), 12)
        }
        col.addView(hint)

        val lpHint = hint.layoutParams as? LinearLayout.LayoutParams
        lpHint?.setMargins(0, 0, 0, dp(12))

        bigBtn("Открыть сведения о приложении") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
            }
        }

        val note = TextView(this).apply {
            text = "При первом скане/чтении система спросит разрешение на захват экрана — это обязательный системный диалог, он появляется при каждом новом запуске сервиса.\n\nПузырь поверх других приложений: тап — открыть меню (как в читалке), перетаскивание — переместить. Рамку можно потянуть: удерживайте «Область…» в меню."
            textSize = 13f
            setTextColor(Color.parseColor("#AFC0D8"))
            setPadding(dp(2), dp(6), dp(2), 0)
        }
        col.addView(note)

        root.addView(col)
        setContentView(root)
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        val scrollOk = ScrollAccessibilityService.instance != null
        status.text =
            "Статус:\n• Показ поверх приложений: " + if (overlayOk) "✅" else "❌ (нужно разрешить)" +
                "\n• Автопрокрутка (спец. возможности): " + if (scrollOk) "✅" else "⚠ выключена — листать можно вручную" +
                "\n• Оверлей: " + if (OverlayService.running) "работает" else "остановлен"
        btnToggle.text = if (OverlayService.running) "⏹ Остановить оверлей" else "▶ Запустить оверлей"
        val p = getSharedPreferences("ovr", MODE_PRIVATE)
        engBtn.text = "Движок: " + when (p.getString("ocr_engine", "lens")) {
            "zen" -> "Zen Free (онлайн, без ключа) 🌐"
            "googleai" -> "Google AI Gemini Vision 🌐"
            "openrouter" -> "OpenRouter Vision 🌐"
            else -> "Google Lens (онлайн) 🌐"
        }
        genderBtn.text = "Голос: " + if (p.getString("gender", "female") == "male") "♂ мужской" else "♀ женский"
        rateBtn.text = "Скорость: " + Math.round(p.getFloat("rate", 1.0f) * 100) + "% (тап — переключить)"
    }
}
