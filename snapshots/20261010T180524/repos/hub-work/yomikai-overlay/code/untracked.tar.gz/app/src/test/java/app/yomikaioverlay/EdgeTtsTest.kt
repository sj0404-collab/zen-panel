package app.yomikaioverlay

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Edge TTS: протокол и разбиение длинных текстов.
 * Сеть здесь не трогаем — только чистые функции (токен, экранирование, чанки).
 */
class EdgeTtsTest {

    @Test
    fun `secMsGec is deterministic uppercase hex`() {
        val a = EdgeTts.secMsGec(1_000_000L)
        val b = EdgeTts.secMsGec(1_000_000L)
        assertEquals(a, b)
        assertEquals(64, a.length)
        assertTrue("must be uppercase hex", a.all { it.isDigit() || it in 'A'..'F' })
    }

    @Test
    fun `secMsGec is stable inside 5 minute bucket and changes across it`() {
        // WIN_EPOCH кратен 300, поэтому граница бакета совпадает с эпохой
        val base = 600L
        assertEquals(EdgeTts.secMsGec(base), EdgeTts.secMsGec(base + 1))
        assertEquals(EdgeTts.secMsGec(base), EdgeTts.secMsGec(base + 299))
        assertFalse(EdgeTts.secMsGec(base) == EdgeTts.secMsGec(base + 300))
    }

    @Test
    fun `escapeXml escapes xml specials`() {
        assertEquals(
            "a&lt;b&gt;c&amp;d&quot;e&apos;f",
            EdgeTts.escapeXml("a<b>c&d\"e'f"),
        )
        assertEquals("", EdgeTts.escapeXml(""))
    }

    @Test
    fun `short text goes in one chunk`() {
        val chunks = EdgeTts.chunkForSsml("Привет, мир!")
        assertEquals(1, chunks.size)
        assertEquals("Привет, мир!", chunks[0])
    }

    @Test
    fun `blank text produces no chunks`() {
        assertTrue(EdgeTts.chunkForSsml("").isEmpty())
        assertTrue(EdgeTts.chunkForSsml("   ").isEmpty())
    }

    @Test
    fun `long text splits without losing content`() {
        val text = buildString {
            var i = 0
            while (length < 20_000) append("слово${i++} ")
        }
        val chunks = EdgeTts.chunkForSsml(text, limit = 1000)
        assertTrue("must be multiple chunks", chunks.size > 5)
        for (c in chunks) {
            assertTrue("chunk must fit limit", c.toByteArray(Charsets.UTF_8).size <= 1000)
        }
        // содержимое сохраняется: все непробельные символы на месте
        assertEquals(
            text.filterNot { it.isWhitespace() },
            chunks.joinToString(" ").filterNot { it.isWhitespace() },
        )
    }

    @Test
    fun `chunks never end inside xml entity`() {
        val text = buildString {
            var i = 0
            while (length < 12_000) append("cue&ref${i++} &amp; tail ")
        }
        for (c in EdgeTts.chunkForSsml(text, limit = 500)) {
            assertTrue("chunk must fit byte limit", c.toByteArray(Charsets.UTF_8).size <= 500)
            assertFalse("chunk ends with bare &", c.endsWith("&"))
            assertFalse("chunk ends with partial entity", c.endsWith("&am"))
        }
    }

    @Test
    fun `tail shorter than limit does not crash`() {
        // Ровно 4100 байт: раньше последний хвост < limit ронял substring'ом.
        val text = "x".repeat(4100)
        val chunks = EdgeTts.chunkForSsml(text)
        assertEquals(2, chunks.size)
        assertEquals(4000, chunks[0].length)
        assertEquals(100, chunks[1].length)
    }
}
