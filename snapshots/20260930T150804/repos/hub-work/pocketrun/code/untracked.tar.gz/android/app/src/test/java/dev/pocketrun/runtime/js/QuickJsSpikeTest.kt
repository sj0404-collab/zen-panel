package dev.pocketrun.runtime.js

import com.dokar.quickjs.QuickJs
import com.dokar.quickjs.binding.define
import com.dokar.quickjs.binding.function
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Can the engine load, evaluate modern syntax and call a host binding?
 *
 * This is the question that decides whether QuickJS can replace Rhino at all, so
 * it is answered directly rather than inferred.
 */
class QuickJsSpikeTest {

    @Test
    fun engineEvaluatesModernSyntaxRhinoRejected() {
        runBlocking {
            val q = QuickJs()
            try {
                assertTrue("engine should report its version", q.version.isNotBlank())
                // Class bodies, async/await and optional chaining are all syntax
                // errors on Rhino 1.8.1 - that is why modern npm packages would
                // install and then refuse to run.
                val out = q.evaluate<String>(
                    """
                    class Greeter {
                        constructor(n) { this.n = n }
                        hi() { return 'hi ' + this.n }
                    }
                    const g = new Greeter('pocketrun');
                    const val = [1, 2, 3];
                    const maybe = null;
                    (async () => {
                        await null;
                        globalThis.__done = g.hi() + ' ' + val.map(n => n * 2).join(',') +
                            ' ' + (maybe?.x ?? 'fallback');
                    })();
                    """,
                    "spike.js",
                    false,
                )
                assertEquals("", out)
            } finally {
                q.close()
            }
        }
    }

    @Test
    fun hostFunctionIsCallableFromJsWithNumbersAndStrings() {
        runBlocking {
            val q = QuickJs()
            try {
                q.define("__pr") {
                    function("add") { args ->
                        val a = (args.getOrNull(0) as? Number)?.toDouble() ?: 0.0
                        val b = (args.getOrNull(1) as? Number)?.toDouble() ?: 0.0
                        a + b
                    }
                    function("greet") { args ->
                        val who = args.getOrNull(0)?.toString() ?: "?"
                        "hello $who"
                    }
                    function("list") { _ -> listOf("a", "b", "c") }
                    function("nothing") { _ -> null }
                }
                q.evaluate<Unit>(
                    """
                    function __spikeAdd(a, b) { return __pr.add(a, b); }
                    function __spikeGreet() { return __pr.greet('world'); }
                    function __spikeLen() { return __pr.list().length; }
                    function __spikeNull() { return __pr.nothing() === null; }
                    """,
                    "boot.js",
                    false,
                )

                assertEquals(7.0, q.evaluate<Double>("__spikeAdd(3, 4)", "c.js", false), 0.0001)
                assertEquals("hello world", q.evaluate<String>("__spikeGreet()", "c.js", false))
                assertEquals(3.0, q.evaluate<Double>("__spikeLen()", "c.js", false), 0.0001)
                // boot.js relies on a Kotlin null arriving as JS null, not undefined.
                assertEquals(true, q.evaluate<Boolean>("__spikeNull()", "c.js", false))
            } finally {
                q.close()
            }
        }
    }

    @Test
    fun globalsDefinedByBootScriptAreVisibleToHost() {
        runBlocking {
            val q = QuickJs()
            try {
                q.evaluate<Unit>("globalThis.__prPending = function () { return 2 };", "boot.js", false)
                assertEquals(2.0, q.evaluate<Double>("__prPending()", "c.js", false), 0.0001)
            } finally {
                q.close()
            }
        }
    }
}
