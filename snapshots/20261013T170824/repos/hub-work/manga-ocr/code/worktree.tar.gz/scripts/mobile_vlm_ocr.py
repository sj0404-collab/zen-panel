#!/usr/bin/env python3
"""OCR manga pages with a small "mobile" VLM (SmolVLM / moondream2).

Raw, verbatim prompt: read every visible text, no translation, no invention.

Usage:
  python mobile_vlm_ocr.py <model_id[@revision]> <pages_dir> <out.txt> [n_pages]
"""
import glob
import os
import sys
import time

import torch
from PIL import Image

MODEL = sys.argv[1]
REVISION = None
if "@" in MODEL:
    MODEL, REVISION = MODEL.split("@", 1)
PAGES = sys.argv[2]
OUT = sys.argv[3]
N = int(sys.argv[4]) if len(sys.argv) > 4 else 5

PROMPT = (
    "Read ALL text on this manga page exactly as written. "
    "Output only the text, line by line, in the original language. "
    "Do not translate, do not describe the picture, do not explain."
)

IS_MOONDREAM = "moondream" in MODEL.lower()

print(f"[i] loading {MODEL} rev={REVISION}", flush=True)
if IS_MOONDREAM:
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model = AutoModelForCausalLM.from_pretrained(
        MODEL, trust_remote_code=True, revision=REVISION, torch_dtype=torch.float16
    )
    tok = AutoTokenizer.from_pretrained(MODEL, revision=REVISION)
else:
    from transformers import AutoModelForVision2Seq, AutoProcessor

    processor = AutoProcessor.from_pretrained(MODEL, revision=REVISION)
    ip = processor.image_processor
    if hasattr(ip, "size") and hasattr(ip, "max_image_size"):
        ip.size = dict(ip.max_image_size)
        ip.do_image_splitting = False
    model = AutoModelForVision2Seq.from_pretrained(
        MODEL, revision=REVISION, torch_dtype=torch.float16
    )
model.eval()


def run(img: Image.Image) -> str:
    if IS_MOONDREAM:
        if hasattr(model, "query"):
            return model.query(img, PROMPT).strip()
        enc = model.encode_image(img)
        return model.answer_question(enc, PROMPT, tok).strip()
    messages = [
        {"role": "user", "content": [{"type": "image"}, {"type": "text", "text": PROMPT}]}
    ]
    text = processor.apply_chat_template(messages, add_generation_prompt=True)
    inputs = processor(text=text, images=[img], return_tensors="pt")
    with torch.inference_mode():
        ids = model.generate(**inputs, max_new_tokens=512, do_sample=False)
    gen = ids[0][inputs["input_ids"].shape[1]:]
    return processor.decode(gen, skip_special_tokens=True).strip()


pages = sorted(
    p
    for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    img = Image.open(p).convert("RGB")
    t0 = time.time()
    try:
        txt = run(img)
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n{txt}\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
