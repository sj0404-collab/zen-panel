#!/usr/bin/env python3
"""OCR with PaddleOCR PP-OCRv5 East-Slavic mobile recognizer."""
import glob
import os
import sys
import time

import os as _os
_os.environ.setdefault('FLAGS_use_mkldnn','0')
from paddleocr import PaddleOCR

PAGES = sys.argv[1]
OUT = sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 5
MODEL = os.environ.get("ESLAV_MODEL", "eslav_PP-OCRv5_mobile_rec")

ocr = PaddleOCR(
    text_recognition_model_name=MODEL,
    use_doc_orientation_classify=False,
    use_doc_unwarping=False,
    use_textline_orientation=True,
    device="cpu",
    enable_mkldnn=False,
)

pages = sorted(
    p for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    t0 = time.time()
    lines = []
    try:
        for r in ocr.predict(p):
            lines.extend(r["rec_texts"])
    except Exception as exc:  # noqa: BLE001
        lines = [f"<ERROR {type(exc).__name__}: {exc}>"]
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n")
    out.write("\n".join(lines) + "\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
