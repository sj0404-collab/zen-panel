#!/usr/bin/env python3
"""Tiny (<600MB) VLM OCR: Florence-2-base-ft with the <OCR> task prompt."""
import glob
import os
import sys
import time

import torch
from PIL import Image
from transformers import AutoModelForCausalLM, AutoProcessor

MODEL = sys.argv[1]
PAGES = sys.argv[2]
OUT = sys.argv[3]
N = int(sys.argv[4]) if len(sys.argv) > 4 else 5
TASK = "<OCR>"

print(f"[i] loading {MODEL}", flush=True)
model = AutoModelForCausalLM.from_pretrained(
    MODEL, trust_remote_code=True, torch_dtype=torch.float16
)
processor = AutoProcessor.from_pretrained(MODEL, trust_remote_code=True)
model.eval()

pages = sorted(
    p for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    img = Image.open(p).convert("RGB")
    t0 = time.time()
    try:
        inputs = processor(text=TASK, images=img, return_tensors="pt")
        with torch.inference_mode():
            ids = model.generate(
                input_ids=inputs["input_ids"],
                pixel_values=inputs["pixel_values"].to(torch.float16),
                max_new_tokens=1024,
                num_beams=3,
                do_sample=False,
            )
        raw = processor.batch_decode(ids, skip_special_tokens=False)[0]
        parsed = processor.post_process_generation(
            raw, task=TASK, image_size=(img.width, img.height)
        )
        txt = parsed.get(TASK, raw)
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n{txt}\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
