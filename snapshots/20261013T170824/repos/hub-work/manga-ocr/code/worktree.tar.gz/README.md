# manga-ocr

Сырой (verbatim) OCR русскоязычной главы манхвы разными движками, плюс скрипты
и workflow, которыми это получено. Никакой коррекции и «додумывания» — только
то, что реально вернул движок.

Фикстура: `Том 1 Глава 74` (63 страницы JPG, внутри `fixtures/vol1-ch74.cbz`).

## Что внутри

- `scripts/normcap_ocr.py` — ансамбль через OCR-слой NormCap (Tesseract):
  конфиги `resize_factor × psm`, победа по средней уверенности. Основной движок.
- `scripts/easyocr_ocr.py` — EasyOCR.
- `scripts/florence_ocr.py` — крошечный VLM `microsoft/Florence-2-base-ft` (463 МБ) с задачей `<OCR>`.
- `scripts/mobile_vlm_ocr.py` — маленькие VLM (`SmolVLM-256M-Instruct` 513 МБ и др.).
- `.github/workflows/ocr-win.yml` — прогон NormCap/EasyOCR на Windows-раннере.
- `results/*.txt` — полученные сырые транскрипты.

## Результаты (63 страницы)

| Движок | Размер | Скорость | Качество на этом тексте |
|---|---|---|---|
| NormCap / Tesseract-`rus` | ~15 МБ (tessdata) | ~9 с/стр | **лучший**, читаемый русский текст |
| EasyOCR | ~100 МБ | ~30–90 с/стр | плохо: системно `Л→/`, `Н→H`, `Д→А/4`, `Ж→AI` |
| Florence-2-base-ft (VLM) | 463 МБ | ~170–200 с/стр (CPU) | частично: кириллицу узнаёт, но с ошибками и клеит строки без пробелов |
| SmolVLM-256M-Instruct (VLM) | 513 МБ | ~10–250 с/стр (CPU) | не OCR: описывает картинку, галлюцинирует |

Вывод: среди моделей ≤600 МБ Florence-2-base-ft — единственная, что реально
читает текст, но по точности уступает Tesseract/NormCap; SmolVLM-256M для OCR
непригодна.

## Воспроизведение

```bash
# NormCap (нужен tesseract с языком rus)
python scripts/normcap_ocr.py <pages_dir> <out_dir>

# EasyOCR
python scripts/easyocr_ocr.py <pages_dir> <out_dir>

# Florence-2 (transformers, trust_remote_code; CPU ок)
pip install torch transformers timm
python scripts/florence_ocr.py microsoft/Florence-2-base-ft <pages_dir> <out.txt> 63

# SmolVLM-256M
pip install torch transformers accelerate einops
python scripts/mobile_vlm_ocr.py HuggingFaceTB/SmolVLM-256M-Instruct <pages_dir> <out.txt> 63
```
