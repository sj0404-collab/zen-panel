package yomikai.presentation.category

import android.content.Context
import androidx.compose.runtime.Composable
import yomikai.core.common.i18n.stringResource
import yomikai.domain.category.model.Category
import yomikai.i18n.MR
import yomikai.presentation.core.i18n.stringResource

val Category.visualName: String
    @Composable
    get() = when {
        isSystemCategory -> stringResource(MR.strings.label_default)
        else -> name
    }

fun Category.visualName(context: Context): String =
    when {
        isSystemCategory -> context.stringResource(MR.strings.label_default)
        else -> name
    }
