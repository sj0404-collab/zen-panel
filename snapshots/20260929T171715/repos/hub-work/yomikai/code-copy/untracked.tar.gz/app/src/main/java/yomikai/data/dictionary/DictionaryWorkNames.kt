package yomikai.data.dictionary

internal object DictionaryWorkNames {
    const val IMPORT_AND_MIGRATION = "DictionaryImportAndMigration"
}
