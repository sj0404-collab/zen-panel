package yomikai.di

import android.app.Application
import yomikai.domain.base.BasePreferences
import yomikai.domain.dictionary.DictionaryPreferences
import yomikai.domain.source.service.SourcePreferences
import yomikai.domain.track.service.TrackPreferences
import yomikai.domain.ui.UiPreferences
import yomikai.core.security.SecurityPreferences
import yomikai.network.NetworkPreferences
import yomikai.ui.reader.setting.ReaderPreferences
import yomikai.util.system.isDebugBuildType
import yomikai.domain.ocr.service.OcrPreferences
import yomikai.core.common.preference.AndroidPreferenceStore
import yomikai.core.common.preference.PreferenceStore
import yomikai.core.common.storage.AndroidStorageFolderProvider
import yomikai.domain.backup.service.BackupPreferences
import yomikai.domain.download.service.DownloadPreferences
import yomikai.domain.library.service.LibraryPreferences
import yomikai.domain.storage.service.StoragePreferences
import yomikai.domain.updates.service.UpdatesPreferences
import uy.kohesive.injekt.api.InjektModule
import uy.kohesive.injekt.api.InjektRegistrar
import uy.kohesive.injekt.api.addSingletonFactory
import uy.kohesive.injekt.api.get

class PreferenceModule(val app: Application) : InjektModule {

    override fun InjektRegistrar.registerInjectables() {
        addSingletonFactory<PreferenceStore> {
            AndroidPreferenceStore(app)
        }
        addSingletonFactory {
            NetworkPreferences(
                preferenceStore = get(),
                verboseLoggingDefault = isDebugBuildType,
            )
        }
        addSingletonFactory {
            SourcePreferences(get())
        }
        addSingletonFactory {
            SecurityPreferences(get())
        }
        addSingletonFactory {
        }
        addSingletonFactory {
            LibraryPreferences(get())
        }
        addSingletonFactory {
            UpdatesPreferences(get())
        }
        addSingletonFactory {
            ReaderPreferences(get())
        }
        addSingletonFactory {
            OcrPreferences(get())
        }
        addSingletonFactory {
            TrackPreferences(get())
        }
        addSingletonFactory {
            DownloadPreferences(get())
        }
        addSingletonFactory {
            BackupPreferences(get())
        }
        addSingletonFactory {
            StoragePreferences(
                folderProvider = get<AndroidStorageFolderProvider>(),
                preferenceStore = get(),
            )
        }
        addSingletonFactory {
            UiPreferences(get())
        }
        addSingletonFactory {
            BasePreferences(app, get())
        }
        addSingletonFactory {
            DictionaryPreferences(get())
        }
    }
}
