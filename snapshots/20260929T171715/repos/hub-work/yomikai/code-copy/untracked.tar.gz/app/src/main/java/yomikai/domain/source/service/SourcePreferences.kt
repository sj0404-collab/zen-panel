package yomikai.domain.source.service

import yomikai.domain.source.interactor.SetMigrateSorting
import yomikai.domain.source.model.ContentType
import yomikai.util.system.LocaleHelper
import yomikai.domain.migration.models.MigrationFlag
import yomikai.core.common.preference.Preference
import yomikai.core.common.preference.PreferenceStore
import yomikai.core.common.preference.getEnum
import yomikai.core.common.preference.getLongArray
import yomikai.domain.library.model.LibraryDisplayMode

class SourcePreferences(
    preferenceStore: PreferenceStore,
) {

    val sourceDisplayMode: Preference<LibraryDisplayMode> = preferenceStore.getObjectFromString(
        "pref_display_mode_catalogue",
        LibraryDisplayMode.default,
        LibraryDisplayMode.Serializer::serialize,
        LibraryDisplayMode.Serializer::deserialize,
    )

    val enabledLanguages: Preference<Set<String>> = preferenceStore.getStringSet(
        "source_languages",
        LocaleHelper.getDefaultEnabledLanguages(),
    )

    val disabledSources: Preference<Set<String>> = preferenceStore.getStringSet("hidden_catalogues", emptySet())

    val pinnedSources: Preference<Set<String>> = preferenceStore.getStringSet("pinned_catalogues", emptySet())

    val lastUsedSource: Preference<Long> = preferenceStore.getLong(
        Preference.appStateKey("last_catalogue_source"),
        -1,
    )

    val showNsfwSource: Preference<Boolean> = preferenceStore.getBoolean("show_nsfw_source", true)

    val migrationSortingMode: Preference<SetMigrateSorting.Mode> = preferenceStore.getEnum(
        "pref_migration_sorting",
        SetMigrateSorting.Mode.ALPHABETICAL,
    )

    val migrationSortingDirection: Preference<SetMigrateSorting.Direction> = preferenceStore.getEnum(
        "pref_migration_direction",
        SetMigrateSorting.Direction.ASCENDING,
    )

    val hideInLibraryItems: Preference<Boolean> = preferenceStore.getBoolean("browse_hide_in_library_items", false)

    val globalSearchFilterState: Preference<Boolean> = preferenceStore.getBoolean(
        Preference.appStateKey("has_filters_toggle_state"),
        false,
    )

    val migrationSources: Preference<List<Long>> = preferenceStore.getLongArray("migration_sources", emptyList())

    val migrationFlags: Preference<Set<MigrationFlag>> = preferenceStore.getObjectFromInt(
        key = "migration_flags",
        defaultValue = MigrationFlag.entries.toSet(),
        serializer = { MigrationFlag.toBit(it) },
        deserializer = { value: Int -> MigrationFlag.fromBit(value) },
    )

    val migrationDeepSearchMode: Preference<Boolean> = preferenceStore.getBoolean("migration_deep_search", false)

    val migrationPrioritizeByChapters: Preference<Boolean> = preferenceStore.getBoolean(
        "migration_prioritize_by_chapters",
        false,
    )

    val migrationHideUnmatched: Preference<Boolean> = preferenceStore.getBoolean("migration_hide_unmatched", false)

    val migrationHideWithoutUpdates: Preference<Boolean> = preferenceStore.getBoolean(
        "migration_hide_without_updates",
        false,
    )

    /**
     * Трекинг состояния источников: sourceId → JSON с successCount, failCount, lastCheck.
     * Позволяет показывать индикатор здоровья и авто-отключать сломанные.
     */
    val sourceHealth: Preference<String> = preferenceStore.getString("source_health_data", "{}")

    /**
     * Зеркала для источников: sourceId → List<домен>.
     * Используется для автоматического переключения при недоступности основного домена.
     */
    val sourceMirrorDomains: Preference<String> = preferenceStore.getString("source_mirror_domains", "{}")

    val contentType: Preference<ContentType> = preferenceStore.getObjectFromString(
        "content_type",
        ContentType.DEFAULT,
        ContentType::name,
        { ContentType.valueOf(it) },
    )
}
