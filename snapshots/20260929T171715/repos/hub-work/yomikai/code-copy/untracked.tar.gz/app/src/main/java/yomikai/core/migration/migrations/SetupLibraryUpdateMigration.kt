package yomikai.core.migration.migrations

import android.app.Application
import yomikai.data.library.LibraryUpdateJob
import yomikai.core.migration.Migration
import yomikai.core.migration.MigrationContext

class SetupLibraryUpdateMigration : Migration {
    override val version: Float = Migration.ALWAYS

    override suspend fun invoke(migrationContext: MigrationContext): Boolean {
        val context = migrationContext.get<Application>() ?: return false
        LibraryUpdateJob.setupTask(context)
        return true
    }
}
