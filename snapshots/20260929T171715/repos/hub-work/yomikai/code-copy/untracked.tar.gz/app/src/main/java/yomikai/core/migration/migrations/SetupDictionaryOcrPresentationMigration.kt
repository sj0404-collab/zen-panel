package yomikai.core.migration.migrations

import yomikai.domain.dictionary.OcrResultPresentation
import yomikai.core.migration.Migration
import yomikai.core.migration.MigrationContext
import yomikai.core.common.preference.PreferenceStore
import yomikai.core.common.preference.getEnum
import yomikai.core.common.util.lang.withIOContext

class SetupDictionaryOcrPresentationMigration : Migration {
    override val version: Float = 20f

    override suspend fun invoke(migrationContext: MigrationContext): Boolean = withIOContext {
        val preferenceStore = migrationContext.get<PreferenceStore>() ?: return@withIOContext false

        val presentationPreference = preferenceStore.getEnum(
            key = "pref_dictionary_ocr_result_presentation",
            defaultValue = OcrResultPresentation.POPUP,
        )
        if (!presentationPreference.isSet()) {
            presentationPreference.set(OcrResultPresentation.SHEET)
        }

        val dimBackgroundPreference = preferenceStore.getBoolean(
            key = "pref_dictionary_ocr_result_dim_background",
            defaultValue = true,
        )
        if (!dimBackgroundPreference.isSet()) {
            dimBackgroundPreference.set(true)
        }

        return@withIOContext true
    }
}
