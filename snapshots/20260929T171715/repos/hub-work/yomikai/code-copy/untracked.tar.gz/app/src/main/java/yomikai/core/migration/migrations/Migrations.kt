package yomikai.core.migration.migrations

import yomikai.core.migration.Migration

val migrations: List<Migration>
    get() = listOf(
        SetupBackupCreateMigration(),
        SetupLibraryUpdateMigration(),
        CategoryPreferencesCleanupMigration(),
        SetupDictionaryOcrPresentationMigration(),
        InstallationIdMigration(),
        VerticalNavigatorMigration(),
    )
