package yomikai.domain

import android.app.Application
import yomikai.domain.chapter.interactor.GetAvailableScanlators
import yomikai.domain.chapter.interactor.SetReadStatus
import yomikai.domain.chapter.interactor.SyncChaptersWithSource
import yomikai.domain.download.interactor.DeleteDownload
import yomikai.domain.manga.interactor.GetExcludedScanlators
import yomikai.domain.manga.interactor.SetExcludedScanlators
import yomikai.domain.manga.interactor.SetMangaViewerFlags
import yomikai.domain.manga.interactor.UpdateManga
import yomikai.domain.source.interactor.GetEnabledSources
import yomikai.domain.source.interactor.GetIncognitoState
import yomikai.domain.source.interactor.GetLanguagesWithSources
import yomikai.domain.source.interactor.GetSourcesWithFavoriteCount
import yomikai.domain.source.interactor.SetMigrateSorting
import yomikai.domain.source.interactor.ToggleLanguage
import yomikai.domain.source.interactor.ToggleSource
import yomikai.domain.source.interactor.ToggleSourcePin
import yomikai.domain.track.interactor.AddTracks
import yomikai.domain.track.interactor.RefreshTracks
import yomikai.domain.track.interactor.SyncChapterProgressWithTrack
import yomikai.domain.track.interactor.TrackChapter
import yomikai.data.dictionary.audio.DictionaryAudioPlayerImpl
import yomikai.data.dictionary.audio.DictionaryAudioRepositoryImpl
import yomikai.data.ocr.OcrChapterScanner
import yomikai.data.ocr.OcrPageSourceGateway
import yomikai.data.ocr.OcrPageSourceGatewayImpl
import yomikai.data.ocr.OcrPageSourceResolver
import yomikai.data.ocr.OcrQueueActions
import yomikai.data.ocr.OcrScanManager
import yomikai.data.ocr.OcrScanNotifier
import yomikai.data.ocr.OcrScanStore
import yomikai.ui.reader.ReaderSelectionCropper
import yomikai.data.ankidroid.AnkiDroidRepositoryImpl
import yomikai.data.dictionary.DictionaryParserImpl
import yomikai.data.dictionary.DictionaryRepositoryImpl
import yomikai.data.dictionary.DictionarySearchGatewayImpl
import yomikai.data.dictionary.HoshiDictionaryStore
import yomikai.data.dictionary.LegacyDictionaryArchiveBuilder
import yomikai.data.ocr.OcrRepositoryImpl
import yomikai.data.panel.PanelDetectionRepositoryImpl
import yomikai.domain.ankidroid.interactor.AddDictionaryCard
import yomikai.domain.ankidroid.interactor.FindExistingAnkiNotes
import yomikai.domain.ankidroid.repository.AnkiDroidRepository
import yomikai.domain.chapter.interactor.FilterChaptersForDownload
import yomikai.domain.dictionary.audio.DictionaryAudioPlayer
import yomikai.domain.dictionary.audio.DictionaryAudioRepository
import yomikai.domain.dictionary.interactor.DictionaryInteractor
import yomikai.domain.dictionary.interactor.SearchDictionaryTerms
import yomikai.domain.dictionary.repository.DictionaryLegacyRepository
import yomikai.domain.dictionary.repository.DictionaryMigrationStatusRepository
import yomikai.domain.dictionary.repository.DictionaryRepository
import yomikai.domain.dictionary.service.DictionaryArchiveBuilder
import yomikai.domain.dictionary.service.DictionaryParser
import yomikai.domain.dictionary.service.DictionarySearchBackend
import yomikai.domain.dictionary.service.DictionarySearchGateway
import yomikai.domain.dictionary.service.DictionaryStorageGateway
import yomikai.domain.migration.usecases.MigrateMangaUseCase
import yomikai.domain.ocr.interactor.ClearCachedChapterOcr
import yomikai.domain.ocr.interactor.ClearOcrCache
import yomikai.domain.ocr.interactor.GetCachedChapterIdsOcr
import yomikai.domain.ocr.interactor.GetCachedPageOcr
import yomikai.domain.ocr.interactor.GetOcrCacheSize
import yomikai.domain.ocr.interactor.OcrProcessor
import yomikai.domain.ocr.interactor.ScanPageOcr
import yomikai.domain.ocr.interactor.WithOcrScanSession
import yomikai.domain.ocr.repository.OcrRepository
import yomikai.domain.panel.interactor.DetectPanels
import yomikai.domain.panel.repository.PanelDetectionRepository
import yomikai.domain.source.interactor.UpdateMangaFromRemote
import yomikai.domain.upcoming.interactor.GetUpcomingManga
import yomikai.data.category.CategoryRepositoryImpl
import yomikai.data.chapter.ChapterRepositoryImpl
import yomikai.data.history.HistoryRepositoryImpl
import yomikai.data.manga.MangaRepositoryImpl
import yomikai.data.release.ReleaseServiceImpl
import yomikai.data.source.SavedSearchRepositoryImpl
import yomikai.data.source.SourceRepositoryImpl
import yomikai.data.source.StubSourceRepositoryImpl
import yomikai.data.track.TrackRepositoryImpl
import yomikai.data.updates.UpdatesRepositoryImpl
import yomikai.domain.ankidroid.service.AnkiDroidPreferences
import yomikai.domain.category.interactor.CreateCategoryWithName
import yomikai.domain.category.interactor.DeleteCategory
import yomikai.domain.category.interactor.GetCategories
import yomikai.domain.category.interactor.RenameCategory
import yomikai.domain.category.interactor.ReorderCategory
import yomikai.domain.category.interactor.ResetCategoryFlags
import yomikai.domain.category.interactor.SetDisplayMode
import yomikai.domain.category.interactor.SetMangaCategories
import yomikai.domain.category.interactor.SetSortModeForCategory
import yomikai.domain.category.interactor.UpdateCategory
import yomikai.domain.category.repository.CategoryRepository
import yomikai.domain.chapter.interactor.GetBookmarkedChaptersByMangaId
import yomikai.domain.chapter.interactor.GetChapter
import yomikai.domain.chapter.interactor.GetChapterByUrlAndMangaId
import yomikai.domain.chapter.interactor.GetChaptersByMangaId
import yomikai.domain.chapter.interactor.SetMangaDefaultChapterFlags
import yomikai.domain.chapter.interactor.ShouldUpdateDbChapter
import yomikai.domain.chapter.interactor.UpdateChapter
import yomikai.domain.chapter.repository.ChapterRepository
import yomikai.domain.history.interactor.GetHistory
import yomikai.domain.history.interactor.GetNextChapters
import yomikai.domain.history.interactor.GetTotalReadDuration
import yomikai.domain.history.interactor.RemoveHistory
import yomikai.domain.history.interactor.UpsertHistory
import yomikai.domain.history.repository.HistoryRepository
import yomikai.domain.manga.interactor.FetchInterval
import yomikai.domain.manga.interactor.GetDuplicateLibraryManga
import yomikai.domain.manga.interactor.GetFavorites
import yomikai.domain.manga.interactor.GetLibraryManga
import yomikai.domain.manga.interactor.GetManga
import yomikai.domain.manga.interactor.GetMangaByUrlAndSourceId
import yomikai.domain.manga.interactor.GetMangaWithChapters
import yomikai.domain.manga.interactor.NetworkToLocalManga
import yomikai.domain.manga.interactor.ResetViewerFlags
import yomikai.domain.manga.interactor.SetMangaChapterFlags
import yomikai.domain.manga.interactor.UpdateMangaNotes
import yomikai.domain.manga.repository.MangaRepository
import yomikai.domain.release.interactor.GetApplicationRelease
import yomikai.domain.release.service.ReleaseService
import yomikai.domain.source.interactor.DeleteSavedSearchById
import yomikai.domain.source.interactor.GetRemoteManga
import yomikai.domain.source.interactor.GetSavedSearchById
import yomikai.domain.source.interactor.GetSavedSearchBySourceId
import yomikai.domain.source.interactor.GetSourcesWithNonLibraryManga
import yomikai.domain.source.interactor.InsertSavedSearch
import yomikai.domain.source.repository.SavedSearchRepository
import yomikai.domain.source.repository.SourceRepository
import yomikai.domain.source.repository.StubSourceRepository
import yomikai.domain.track.interactor.DeleteTrack
import yomikai.domain.track.interactor.GetTracks
import yomikai.domain.track.interactor.GetTracksPerManga
import yomikai.domain.track.interactor.InsertTrack
import yomikai.domain.track.repository.TrackRepository
import yomikai.domain.updates.interactor.GetUpdates
import yomikai.domain.updates.repository.UpdatesRepository
import uy.kohesive.injekt.api.InjektModule
import uy.kohesive.injekt.api.InjektRegistrar
import uy.kohesive.injekt.api.addFactory
import uy.kohesive.injekt.api.addSingletonFactory
import uy.kohesive.injekt.api.get

class DomainModule : InjektModule {

    override fun InjektRegistrar.registerInjectables() {
        addSingletonFactory<CategoryRepository> { CategoryRepositoryImpl(get()) }
        addFactory { GetCategories(get()) }
        addFactory { ResetCategoryFlags(get(), get()) }
        addFactory { SetDisplayMode(get()) }
        addFactory { SetSortModeForCategory(get(), get()) }
        addFactory { CreateCategoryWithName(get(), get()) }
        addFactory { RenameCategory(get()) }
        addFactory { ReorderCategory(get()) }
        addFactory { UpdateCategory(get()) }
        addFactory { DeleteCategory(get(), get(), get()) }

        addSingletonFactory<MangaRepository> { MangaRepositoryImpl(get()) }
        addFactory { GetDuplicateLibraryManga(get()) }
        addFactory { GetFavorites(get()) }
        addFactory { GetLibraryManga(get()) }
        addFactory { GetMangaWithChapters(get(), get()) }
        addFactory { GetMangaByUrlAndSourceId(get()) }
        addFactory { GetManga(get()) }
        addFactory { GetNextChapters(get(), get(), get()) }
        addFactory { GetUpcomingManga(get()) }
        addFactory { ResetViewerFlags(get()) }
        addFactory { SetMangaChapterFlags(get()) }
        addFactory { FetchInterval(get()) }
        addFactory { SetMangaDefaultChapterFlags(get(), get(), get()) }
        addFactory { SetMangaViewerFlags(get()) }
        addFactory { NetworkToLocalManga(get()) }
        addFactory { UpdateManga(get(), get()) }
        addFactory { UpdateMangaNotes(get()) }
        addFactory { SetMangaCategories(get()) }
        addFactory { GetExcludedScanlators(get()) }
        addFactory { SetExcludedScanlators(get()) }
        addFactory {
            MigrateMangaUseCase(
                get(), get(), get(), get(), get(), get(), get(), get(), get(), get(), get(), get(), get(),
            )
        }

        addSingletonFactory<ReleaseService> { ReleaseServiceImpl(get(), get()) }
        addFactory { GetApplicationRelease(get(), get()) }

        addSingletonFactory<TrackRepository> { TrackRepositoryImpl(get()) }
        addFactory { TrackChapter(get(), get(), get(), get()) }
        addFactory { AddTracks(get(), get(), get(), get()) }
        addFactory { RefreshTracks(get(), get(), get(), get()) }
        addFactory { DeleteTrack(get()) }
        addFactory { GetTracksPerManga(get()) }
        addFactory { GetTracks(get()) }
        addFactory { InsertTrack(get()) }
        addFactory { SyncChapterProgressWithTrack(get(), get(), get()) }

        addSingletonFactory<ChapterRepository> { ChapterRepositoryImpl(get()) }
        addFactory { GetChapter(get()) }
        addFactory { GetChaptersByMangaId(get()) }
        addFactory { GetBookmarkedChaptersByMangaId(get()) }
        addFactory { GetChapterByUrlAndMangaId(get()) }
        addFactory { UpdateChapter(get()) }
        addFactory { SetReadStatus(get(), get(), get(), get()) }
        addFactory { ShouldUpdateDbChapter() }
        addFactory { SyncChaptersWithSource(get(), get(), get(), get(), get(), get(), get(), get(), get()) }
        addFactory { GetAvailableScanlators(get()) }
        addFactory { FilterChaptersForDownload(get(), get(), get()) }

        addSingletonFactory<HistoryRepository> { HistoryRepositoryImpl(get()) }
        addFactory { GetHistory(get()) }
        addFactory { UpsertHistory(get()) }
        addFactory { RemoveHistory(get()) }
        addFactory { GetTotalReadDuration(get()) }

        addFactory { DeleteDownload(get(), get()) }


        addSingletonFactory<UpdatesRepository> { UpdatesRepositoryImpl(get()) }
        addFactory { GetUpdates(get()) }

        addSingletonFactory<SourceRepository> { SourceRepositoryImpl(get(), get()) }
        addSingletonFactory<StubSourceRepository> { StubSourceRepositoryImpl(get()) }
        addSingletonFactory<SavedSearchRepository> { SavedSearchRepositoryImpl(get()) }
        addFactory { GetEnabledSources(get(), get()) }
        addFactory { GetLanguagesWithSources(get(), get()) }
        addFactory { GetRemoteManga(get()) }
        addFactory { GetSavedSearchById(get()) }
        addFactory { GetSavedSearchBySourceId(get()) }
        addFactory { InsertSavedSearch(get()) }
        addFactory { DeleteSavedSearchById(get()) }
        addFactory { GetSourcesWithFavoriteCount(get(), get()) }
        addFactory { GetSourcesWithNonLibraryManga(get()) }
        addFactory { SetMigrateSorting(get()) }
        addFactory { ToggleLanguage(get()) }
        addFactory { ToggleSource(get()) }
        addFactory { ToggleSourcePin(get()) }


        addFactory { GetIncognitoState(get()) }

        addSingletonFactory { DictionaryRepositoryImpl(get()) }
        addSingletonFactory<DictionaryRepository> { get<DictionaryRepositoryImpl>() }
        addSingletonFactory<DictionaryLegacyRepository> { get<DictionaryRepositoryImpl>() }
        addSingletonFactory<DictionaryMigrationStatusRepository> { get<DictionaryRepositoryImpl>() }
        addSingletonFactory<DictionaryParser> { DictionaryParserImpl() }
        addSingletonFactory { HoshiDictionaryStore(get<Application>(), get(), get()) }
        addSingletonFactory<DictionarySearchBackend> { get<HoshiDictionaryStore>() }
        addSingletonFactory<DictionaryStorageGateway> { get<HoshiDictionaryStore>() }
        addSingletonFactory { DictionarySearchGatewayImpl(get(), get()) }
        addSingletonFactory<DictionarySearchGateway> { get<DictionarySearchGatewayImpl>() }
        addSingletonFactory { LegacyDictionaryArchiveBuilder(get(), get()) }
        addSingletonFactory<DictionaryArchiveBuilder> { get<LegacyDictionaryArchiveBuilder>() }
        addFactory { DictionaryInteractor(get()) }
        addFactory { SearchDictionaryTerms(get(), get()) }
        addSingletonFactory<DictionaryAudioRepository> { DictionaryAudioRepositoryImpl(get<Application>(), get()) }
        addSingletonFactory<DictionaryAudioPlayer> { DictionaryAudioPlayerImpl() }

        addSingletonFactory { AnkiDroidPreferences(get()) }
        addSingletonFactory<AnkiDroidRepository> { AnkiDroidRepositoryImpl(get<Application>(), get()) }
        addFactory { AddDictionaryCard(get()) }
        addFactory { FindExistingAnkiNotes(get()) }

        addSingletonFactory<OcrRepository> {
            OcrRepositoryImpl(context = get<Application>())
        }
        addSingletonFactory { OcrScanStore(get<Application>(), get()) }
        addSingletonFactory<OcrPageSourceGateway> { OcrPageSourceGatewayImpl(get<Application>(), get(), get()) }
        addSingletonFactory { OcrPageSourceResolver(get(), get(), get()) }
        addSingletonFactory { ReaderSelectionCropper(get()) }
        addSingletonFactory { OcrScanNotifier(get<Application>()) }
        addSingletonFactory { OcrChapterScanner(get<Application>(), get(), get(), get(), get(), get(), get(), get()) }
        addSingletonFactory { OcrScanManager(get<Application>(), get(), get(), get()) }
        addFactory { OcrQueueActions(get(), get()) }
        addFactory { OcrProcessor(get()) }
        addFactory { WithOcrScanSession(get()) }
        addFactory { ScanPageOcr(get()) }
        addFactory { GetCachedChapterIdsOcr(get()) }
        addFactory { GetCachedPageOcr(get()) }
        addFactory { ClearCachedChapterOcr(get()) }
        addFactory { ClearOcrCache(get()) }
        addFactory { GetOcrCacheSize(get()) }

        addSingletonFactory<PanelDetectionRepository> {
            PanelDetectionRepositoryImpl(
                context = get<Application>(),
                // Фолбэк: YOLO-модель из встроенного в APK tar.xz —
                // детектор панелей/баллонов работает без скачивания
                embeddedModelProvider = {
                    // YOLO вынесен из APK (вес): при первом использовании
                    // докачивается 6МБ пак panel_detector
                    val app = get<Application>()
                    yomikai.data.ocr.OcrModelDownloader.ensurePanelDetector(app)
                },
            )
        }
        addFactory { DetectPanels(get()) }
        addFactory { UpdateMangaFromRemote(get(), get(), get(), get(), get(), get(), get()) }
    }
}
