package yomikai.data.ocr

import yomikai.source.Source
import yomikai.domain.chapter.model.Chapter
import yomikai.domain.manga.model.Manga
import yomikai.source.local.LocalSource

internal interface OcrPageSourceGateway {
    suspend fun resolveDownloadedPages(
        manga: Manga,
        chapter: Chapter,
        source: Source,
    ): ResolvedOcrPages

    suspend fun resolveLocalPages(
        source: LocalSource,
        chapter: Chapter,
    ): ResolvedOcrPages
}
