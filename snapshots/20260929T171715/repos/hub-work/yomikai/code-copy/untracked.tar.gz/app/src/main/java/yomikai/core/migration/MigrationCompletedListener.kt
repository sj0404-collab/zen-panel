package yomikai.core.migration

typealias MigrationCompletedListener = () -> Unit
