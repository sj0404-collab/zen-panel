package yomikai.feature.support

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import yomikai.presentation.components.AppBar
import yomikai.presentation.more.settings.widget.TextPreferenceWidget
import yomikai.presentation.util.Screen
import yomikai.core.common.Constants
import yomikai.i18n.MR
import yomikai.presentation.core.components.material.padding
import yomikai.presentation.core.i18n.stringResource
import yomikai.presentation.core.icons.CustomIcons
import yomikai.presentation.core.icons.Github

class SupportUsScreen : Screen() {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        val uriHandler = LocalUriHandler.current

        Scaffold(
            topBar = {
                AppBar(
                    title = stringResource(MR.strings.label_support_us),
                    navigateUp = navigator::pop,
                )
            },
        ) { paddingValues ->
            Column(
                verticalArrangement = Arrangement.spacedBy(MaterialTheme.padding.small),
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(
                    remember(paddingValues) {
                        object : PaddingValues {
                            override fun calculateLeftPadding(layoutDirection: LayoutDirection): Dp {
                                return paddingValues.calculateLeftPadding(layoutDirection) +
                                    MaterialTheme.padding.medium
                            }

                            override fun calculateTopPadding(): Dp {
                                return 0.dp
                            }

                            override fun calculateRightPadding(layoutDirection: LayoutDirection): Dp {
                                return paddingValues.calculateRightPadding(layoutDirection) +
                                    MaterialTheme.padding.medium
                            }

                            override fun calculateBottomPadding(): Dp {
                                return paddingValues.calculateBottomPadding() +
                                    MaterialTheme.padding.medium
                            }
                        }
                    },
                ),
            ) {
                Spacer(modifier = Modifier.height(paddingValues.calculateTopPadding()))

                Text(
                    text = stringResource(MR.strings.supportUsScreen_projectPageMessage),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = MaterialTheme.padding.medium),
                )

                SupportItem(
                    icon = CustomIcons.Github,
                    title = stringResource(MR.strings.supportUsScreen_projectPage),
                    onClick = { uriHandler.openUri(Constants.PROJECT_URL) },
                )

                Spacer(modifier = Modifier.height(paddingValues.calculateBottomPadding()))
            }
        }
    }

    @Composable
    private fun SupportItem(
        icon: ImageVector,
        title: String,
        onClick: () -> Unit,
    ) {
        Card {
            TextPreferenceWidget(
                title = title,
                icon = icon,
                widget = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                    )
                },
                onPreferenceClick = onClick,
            )
        }
    }
}
