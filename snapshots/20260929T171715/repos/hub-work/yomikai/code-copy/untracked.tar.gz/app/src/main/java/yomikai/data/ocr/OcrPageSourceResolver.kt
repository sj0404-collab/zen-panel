package yomikai.data.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import yomikai.domain.chapter.model.toSChapter
import yomikai.data.download.DownloadManager
import yomikai.data.download.model.Download
import yomikai.source.Source
import yomikai.source.model.Page
import yomikai.source.online.HttpSource
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeoutOrNull
import yomikai.core.common.util.lang.withIOContext
import yomikai.domain.chapter.model.Chapter
import yomikai.domain.manga.model.Manga
import yomikai.domain.source.service.SourceManager
import yomikai.source.local.LocalSource
import java.io.InputStream
import kotlin.time.Duration.Companion.seconds

internal class OcrPageSourceResolver(
    private val sourceManager: SourceManager,
    private val downloadManager: DownloadManager,
    private val pageSourceGateway: OcrPageSourceGateway,
) {
    suspend fun resolve(
        manga: Manga,
        chapter: Chapter,
    ): ResolvedOcrPages {
        val source = sourceManager.getOrStub(manga.source)
        val downloadedPagesReady = if (source is HttpSource) {
            awaitDownloadedChapterPages(manga, chapter)
        } else {
            false
        }
        return when {
            downloadedPagesReady -> resolveDownloadedPages(manga, chapter, source)
            source is LocalSource -> resolveLocalPages(source, chapter)
            source is HttpSource -> resolveRemotePages(source, chapter)
            else -> ResolvedOcrPages(emptyList())
        }
    }

    private suspend fun awaitDownloadedChapterPages(
        manga: Manga,
        chapter: Chapter,
    ): Boolean {
        val queuedDownload = downloadManager.getQueuedDownloadOrNull(chapter.id)
        if (queuedDownload == null) {
            return isChapterDownloaded(manga, chapter)
        }

        return withTimeoutOrNull(DOWNLOAD_WAIT_TIMEOUT.inWholeMilliseconds) {
            queuedDownload.statusFlow
                .map { status ->
                    val isStillQueued = downloadManager.getQueuedDownloadOrNull(chapter.id) != null
                    val downloaded = isChapterDownloaded(manga, chapter)
                    when {
                        downloaded && !isStillQueued -> true
                        status == Download.State.ERROR || status == Download.State.NOT_DOWNLOADED -> false
                        else -> null
                    }
                }
                .filterNotNull()
                .first()
        } ?: false
    }

    private fun isChapterDownloaded(
        manga: Manga,
        chapter: Chapter,
    ): Boolean {
        return downloadManager.isChapterDownloaded(
            chapter.name,
            chapter.scanlator,
            chapter.url,
            manga.title,
            manga.source,
            skipCache = true,
        )
    }

    private suspend fun resolveDownloadedPages(
        manga: Manga,
        chapter: Chapter,
        source: Source,
    ): ResolvedOcrPages {
        return pageSourceGateway.resolveDownloadedPages(manga, chapter, source)
    }

    private suspend fun resolveLocalPages(
        source: LocalSource,
        chapter: Chapter,
    ): ResolvedOcrPages {
        return pageSourceGateway.resolveLocalPages(source, chapter)
    }

    private suspend fun resolveRemotePages(
        source: HttpSource,
        chapter: Chapter,
    ): ResolvedOcrPages {
        val pages = source.getPageList(chapter.toSChapter())
            .mapIndexed { index, page -> Page(index, page.url, page.imageUrl, page.uri) }
            .map { page ->
                OcrPageInput(
                    pageIndex = page.index,
                    openBitmap = {
                        decodeOcrBitmapWithFallback { decode ->
                            openRemotePageBitmap(page, source, decode)
                        }
                    },
                    openBitmapRegion = { sourceRect ->
                        decodeOcrRegionWithFallback(sourceRect) { decode ->
                            openRemotePageBitmap(page, source, decode)
                        }
                    },
                )
            }

        return ResolvedOcrPages(pages)
    }

    private suspend fun <T> openRemotePageBitmap(
        page: Page,
        source: HttpSource,
        decode: (InputStream) -> T?,
    ): T? {
        return withIOContext {
            if (page.imageUrl.isNullOrBlank()) {
                page.imageUrl = source.getImageUrl(page)
            }
            source.getImage(page).use { response ->
                decode(response.body.byteStream())
            }
        }
    }
}

private val DOWNLOAD_WAIT_TIMEOUT = 15.seconds

data class OcrPageInput(
    val pageIndex: Int,
    val openBitmap: suspend () -> Bitmap?,
    val openBitmapRegion: suspend (Rect) -> Bitmap?,
)

internal class ResolvedOcrPages(
    val pages: List<OcrPageInput>,
    private val closeBlock: () -> Unit = {},
) : AutoCloseable {
    fun getPageInput(pageIndex: Int): OcrPageInput? {
        return pages.firstOrNull { it.pageIndex == pageIndex }
    }

    override fun close() {
        closeBlock()
    }
}
