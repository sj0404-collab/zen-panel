package yomikai.domain.source.models

import yomikai.domain.chapter.model.Chapter
import yomikai.domain.manga.model.Manga

data class RemoteMangaUpdate(
    val manga: Manga,
    val newChapters: List<Chapter>,
)
