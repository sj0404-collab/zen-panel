package yomikai.crash

import android.content.Intent
import android.os.Bundle
import androidx.core.view.WindowCompat
import yomikai.presentation.crash.CrashScreen
import yomikai.ui.base.activity.BaseActivity
import yomikai.ui.main.MainActivity
import yomikai.util.view.setComposeContent

class CrashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        val exception = GlobalExceptionHandler.getThrowableFromIntent(intent)
        setComposeContent {
            CrashScreen(
                exception = exception,
                onRestartClick = {
                    finishAffinity()
                    startActivity(Intent(this@CrashActivity, MainActivity::class.java))
                },
            )
        }
    }
}
