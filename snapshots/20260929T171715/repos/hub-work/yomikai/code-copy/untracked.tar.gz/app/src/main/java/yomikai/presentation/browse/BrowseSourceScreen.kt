package yomikai.presentation.browse

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import yomikai.util.system.toast
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import yomikai.presentation.browse.components.BrowseSourceComfortableGrid
import yomikai.presentation.browse.components.BrowseSourceCompactGrid
import yomikai.presentation.browse.components.BrowseSourceList
import yomikai.presentation.components.AppBar
import yomikai.presentation.util.formattedMessage
import yomikai.source.Source
import yomikai.util.source.SourceHealthManager
import kotlinx.coroutines.flow.StateFlow
import yomikai.core.common.i18n.stringResource
import yomikai.domain.library.model.LibraryDisplayMode
import yomikai.domain.manga.model.Manga
import yomikai.domain.source.model.StubSource
import yomikai.i18n.MR
import yomikai.presentation.core.components.material.Scaffold
import yomikai.presentation.core.i18n.stringResource
import yomikai.presentation.core.screens.EmptyScreen
import yomikai.presentation.core.screens.EmptyScreenAction
import yomikai.presentation.core.screens.LoadingScreen
import yomikai.source.local.LocalSource

@Composable
fun BrowseSourceContent(
    source: Source?,
    mangaList: LazyPagingItems<StateFlow<Manga>>,
    columns: GridCells,
    displayMode: LibraryDisplayMode,
    snackbarHostState: SnackbarHostState,
    contentPadding: PaddingValues,
    onWebViewClick: () -> Unit,
    onHelpClick: () -> Unit,
    onLocalSourceHelpClick: () -> Unit,
    onMangaClick: (Manga) -> Unit,
    onMangaLongClick: (Manga) -> Unit,
) {
    val context = LocalContext.current
    val storagePreferences = remember { Injekt.get<yomikai.domain.storage.service.StoragePreferences>() }

    val pickFolderLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        if (uri != null) {
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
            // Папка добавляется в СТОРОННЮЮ библиотеку (можно сколько угодно
            // папок из любых мест, включая Android/data). Основное хранилище
            // приложения (загрузки из сети) не трогаем — никаких дублей.
            storagePreferences.externalLibraryRoots.set(
                storagePreferences.externalLibraryRoots.get() + uri.toString(),
            )
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                { mangaList.refresh() },
                600,
            )
        }
    }

    val errorState = mangaList.loadState.refresh.takeIf { it is LoadState.Error }
        ?: mangaList.loadState.append.takeIf { it is LoadState.Error }

    val getErrorMessage: (LoadState.Error) -> String = { state ->
        with(context) { state.error.formattedMessage }
    }

    // Трекер здоровья: записываем ошибку и показываем статус
    val sourcePreferences = remember { Injekt.get<yomikai.domain.source.service.SourcePreferences>() }
    LaunchedEffect(errorState) {
        if (errorState is LoadState.Error && source != null) {
            SourceHealthManager.recordFailure(sourcePreferences, source.id)
        }
    }
    val sourceHealth = remember(source) {
        source?.let { SourceHealthManager.getHealth(sourcePreferences, it.id) }
    }

    LaunchedEffect(errorState) {
        if (mangaList.itemCount > 0 && errorState != null && errorState is LoadState.Error) {
            val result = snackbarHostState.showSnackbar(
                message = getErrorMessage(errorState),
                actionLabel = context.stringResource(MR.strings.action_retry),
                duration = SnackbarDuration.Indefinite,
            )
            when (result) {
                SnackbarResult.Dismissed -> snackbarHostState.currentSnackbarData?.dismiss()
                SnackbarResult.ActionPerformed -> mangaList.retry()
            }
        }
    }

    if (mangaList.itemCount == 0 && mangaList.loadState.refresh is LoadState.Loading) {
        LoadingScreen(Modifier.padding(contentPadding))
        return
    }

    if (mangaList.itemCount == 0) {
        val healthWarning = if (sourceHealth != null && !sourceHealth.isHealthy) {
            "\n\nИсточник имеет проблемы с доступностью (${sourceHealth.failCount} ошибок из ${sourceHealth.successCount + sourceHealth.failCount}). Попробуйте позже или проверьте зеркала."
        } else ""
        EmptyScreen(
            modifier = Modifier.padding(contentPadding),
            message = when (errorState) {
                is LoadState.Error -> getErrorMessage(errorState) + healthWarning
                else -> stringResource(MR.strings.no_results_found)
            },
            actions = if (source is LocalSource) {
                listOf(
                    EmptyScreenAction(
                        stringRes = MR.strings.action_select_local_folder,
                        icon = Icons.Outlined.FolderOpen,
                        onClick = { pickFolderLauncher.launch(null) },
                    ),
                    EmptyScreenAction(
                        stringRes = MR.strings.local_source_help_guide,
                        icon = Icons.AutoMirrored.Outlined.HelpOutline,
                        onClick = onLocalSourceHelpClick,
                    ),
                )
            } else {
                listOf(
                    EmptyScreenAction(
                        stringRes = MR.strings.action_retry,
                        icon = Icons.Outlined.Refresh,
                        onClick = mangaList::refresh,
                    ),
                    EmptyScreenAction(
                        stringRes = MR.strings.action_open_in_web_view,
                        icon = Icons.Outlined.Public,
                        onClick = onWebViewClick,
                    ),
                    EmptyScreenAction(
                        stringRes = MR.strings.label_help,
                        icon = Icons.AutoMirrored.Outlined.HelpOutline,
                        onClick = onHelpClick,
                    ),
                )
            },
        )

        return
    }

    when (displayMode) {
        LibraryDisplayMode.ComfortableGrid -> {
            BrowseSourceComfortableGrid(
                mangaList = mangaList,
                columns = columns,
                contentPadding = contentPadding,
                onMangaClick = onMangaClick,
                onMangaLongClick = onMangaLongClick,
            )
        }
        LibraryDisplayMode.List -> {
            BrowseSourceList(
                mangaList = mangaList,
                contentPadding = contentPadding,
                onMangaClick = onMangaClick,
                onMangaLongClick = onMangaLongClick,
            )
        }
        LibraryDisplayMode.CompactGrid, LibraryDisplayMode.CoverOnlyGrid -> {
            BrowseSourceCompactGrid(
                mangaList = mangaList,
                columns = columns,
                contentPadding = contentPadding,
                onMangaClick = onMangaClick,
                onMangaLongClick = onMangaLongClick,
            )
        }
    }
}

@Composable
internal fun MissingSourceScreen(
    source: StubSource,
    navigateUp: () -> Unit,
) {
    Scaffold(
        topBar = { scrollBehavior ->
            AppBar(
                title = source.name,
                navigateUp = navigateUp,
                scrollBehavior = scrollBehavior,
            )
        },
    ) { paddingValues ->
        EmptyScreen(
            message = stringResource(MR.strings.source_not_installed, source.toString()),
            modifier = Modifier.padding(paddingValues),
        )
    }
}
