package yomikai.domain.download.interactor

import yomikai.data.download.DownloadManager
import yomikai.core.common.util.lang.withNonCancellableContext
import yomikai.domain.chapter.model.Chapter
import yomikai.domain.manga.model.Manga
import yomikai.domain.source.service.SourceManager

class DeleteDownload(
    private val sourceManager: SourceManager,
    private val downloadManager: DownloadManager,
) {

    suspend fun awaitAll(manga: Manga, vararg chapters: Chapter) = withNonCancellableContext {
        sourceManager.get(manga.source)?.let { source ->
            downloadManager.deleteChapters(chapters.toList(), manga, source)
        }
    }
}
