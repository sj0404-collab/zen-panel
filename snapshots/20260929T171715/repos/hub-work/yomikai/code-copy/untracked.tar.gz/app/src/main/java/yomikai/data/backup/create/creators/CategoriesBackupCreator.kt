package yomikai.data.backup.create.creators

import yomikai.data.backup.models.BackupCategory
import yomikai.data.backup.models.backupCategoryMapper
import yomikai.domain.category.interactor.GetCategories
import yomikai.domain.category.model.Category
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

class CategoriesBackupCreator(
    private val getCategories: GetCategories = Injekt.get(),
) {

    suspend operator fun invoke(): List<BackupCategory> {
        return getCategories.await()
            .filterNot(Category::isSystemCategory)
            .map(backupCategoryMapper)
    }
}
