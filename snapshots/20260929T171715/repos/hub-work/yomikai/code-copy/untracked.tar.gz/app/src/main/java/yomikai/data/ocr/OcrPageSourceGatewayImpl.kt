package yomikai.data.ocr

import android.content.Context
import com.hippo.unifile.UniFile
import yomikai.domain.chapter.model.toSChapter
import yomikai.data.download.DownloadManager
import yomikai.data.download.DownloadProvider
import yomikai.source.Source
import yomikai.util.lang.compareToCaseInsensitiveNaturalOrder
import yomikai.core.archive.archiveReader
import yomikai.core.archive.epubReader
import yomikai.core.common.util.lang.withIOContext
import yomikai.core.common.util.system.ImageUtil
import yomikai.domain.chapter.model.Chapter
import yomikai.domain.manga.model.Manga
import yomikai.source.local.LocalSource
import yomikai.source.local.io.Format

internal class OcrPageSourceGatewayImpl(
    private val context: Context,
    private val downloadManager: DownloadManager,
    private val downloadProvider: DownloadProvider,
) : OcrPageSourceGateway {

    override suspend fun resolveDownloadedPages(
        manga: Manga,
        chapter: Chapter,
        source: Source,
    ): ResolvedOcrPages {
        val chapterPath = downloadProvider.findChapterDir(
            chapter.name,
            chapter.scanlator,
            chapter.url,
            manga.title,
            source,
        )
        if (chapterPath?.isFile == true) {
            return resolveArchivePages(chapterPath)
        }

        val pages = downloadManager.buildPageList(source, manga, chapter).map { page ->
            buildStreamDecoderOcrInput(
                pageIndex = page.index,
                openStream = {
                    page.uri?.let(context.contentResolver::openInputStream)
                },
            )
        }

        return ResolvedOcrPages(pages)
    }

    override suspend fun resolveLocalPages(
        source: LocalSource,
        chapter: Chapter,
    ): ResolvedOcrPages {
        return when (val format = source.getFormat(chapter.toSChapter())) {
            is Format.Directory -> resolveDirectoryPages(format.file)
            is Format.Archive -> resolveArchivePages(format.file)
            is Format.Epub -> resolveEpubPages(format.file)
        }
    }

    private fun resolveDirectoryPages(file: UniFile): ResolvedOcrPages {
        val pages = file.listFiles()
            ?.filter { !it.isDirectory && ImageUtil.isImage(it.name) { it.openInputStream() } }
            ?.sortedWith { file1, file2 ->
                file1.name.orEmpty().compareToCaseInsensitiveNaturalOrder(file2.name.orEmpty())
            }
            ?.mapIndexed { index, imageFile ->
                buildStreamDecoderOcrInput(
                    pageIndex = index,
                    openStream = imageFile::openInputStream,
                )
            }
            .orEmpty()

        return ResolvedOcrPages(pages)
    }

    private suspend fun resolveArchivePages(file: UniFile): ResolvedOcrPages {
        val reader = file.archiveReader(context)
        val entryNames = withIOContext {
            buildList {
                reader.useEntriesAndStreams { entry, stream ->
                    if (entry.isFile && isArchiveImageEntry(entry.name, stream)) {
                        add(entry.name)
                    }
                }
            }
        }
            .sortedWith { entry1, entry2 ->
                entry1.compareToCaseInsensitiveNaturalOrder(entry2)
            }

        val pages = entryNames.mapIndexed { index, entryName ->
            buildArchiveDecoderOcrInput(
                pageIndex = index,
                openStream = { reader.getInputStream(entryName) },
            )
        }

        return ResolvedOcrPages(
            pages = pages,
            closeBlock = reader::close,
        )
    }

    private suspend fun resolveEpubPages(file: UniFile): ResolvedOcrPages {
        val reader = file.epubReader(context)
        val imagePaths = withIOContext { reader.getImagesFromPages() }

        val pages = imagePaths.mapIndexed { index, path ->
            buildArchiveDecoderOcrInput(
                pageIndex = index,
                openStream = { reader.getInputStream(path) },
            )
        }

        return ResolvedOcrPages(
            pages = pages,
            closeBlock = reader::close,
        )
    }
}
