package yomikai.core.migration.migrations

import android.app.Application
import yomikai.data.backup.create.BackupCreateJob
import yomikai.core.migration.Migration
import yomikai.core.migration.MigrationContext

class SetupBackupCreateMigration : Migration {
    override val version: Float = Migration.ALWAYS

    override suspend fun invoke(migrationContext: MigrationContext): Boolean {
        val context = migrationContext.get<Application>() ?: return false
        BackupCreateJob.setupTask(context)
        return true
    }
}
