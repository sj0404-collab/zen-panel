# Архитектура

**ACLG** — Android cloud local gaming: экран одного Android-телефона (хост) передаётся
на второй телефон (клиент) по локальной сети через WebRTC, а касания клиента
доставляются обратно на хост. Работает по очереди: либо на телефоне сидит владелец,
либо удалённый игрок. Без root, без облака.

```
┌───────────────────── телефон-хост ─────────────────────┐
│                                                        │
│  Host PWA (браузер, вкладка во весь экран)             │
│   getDisplayMedia ──> MediaStream                     │
│        │                                               │
│        ├─ RTCPeerConnection (H.264 video + audio) ─────┼──┐
│        └─ RTCDataChannel 'input' ◄── (касания)         │  │
│                       │                                │  │
│                       ▼                                │  │
│   HostHelper APK: AccessibilityService → dispatchGesture│  │
│   + Wi-Fi ADB: виртуальный дисплей (экспериментально)  │  │
│                                                        │  │
└─────────────────────────┬───────────────────────────────┘  │
                          │ WebSocket (SDP/ICE relay)        │
                ┌─────────▼─────────┐                        │
                │ signaling server │                        │
                │     (LAN)        │                        │
                └─────────┬─────────┘                        │
                          │                                  │
┌─────────────────────────▼──────────────────────────┐      │
│  Клиент (PWA в браузере второго устройства)        │      │
│   RTCPeerConnection ──> <video> ──> стрим хоста     │ ◄────┘
│   pointer events ──> DataChannel ──> касания хосту  │
└────────────────────────────────────────────────────┘
```

## Роли

| Компонент | Что делает | Где |
|---|---|---|
| `packages/host` | Захват экрана (`getDisplayMedia`), WebRTC-sender, превью, пересылка инпута в HostHelper | PWA на хосте |
| `packages/client` | WebRTC-receiver, рендер `<video>`, pointer→сообщения инпута | PWA у игрока |
| `packages/signaling` | room-реле SDP/ICE по WebSocket | Node-процесс в LAN |
| `packages/shared` | Протокол DataChannel, маппинг координат, сообщения signaling | общий код + тесты |
| `helper/` | Android APK: `AccessibilityService` (инпут без root), управление virtual display через Wi-Fi ADB, keep-awake | APK на хосте |

## Поток данных

1. `HostHelper` (Service) с `AccessibilityService` поднят на хосте и слушает
   `ws://127.0.0.1:9100`.
2. Хост открывает Host PWA во весь экран, жмёт «Начать трансляцию» —
   `navigator.mediaDevices.getDisplayMedia()` даёт пиксели дисплея.
3. Хост и клиент подключаются к `ws://lan-ip:8787/?room=<name>`. Когда клиент
   зашёл в комнату, сервер шлёт хосту `peer_joined`.
4. Хост делает `offer`, клиент отвечает `answer`, дальше обмениваются ICE —
   PeerConnection устанавливается напрямую (LAN, `iceServers: []`).
5. Хост шлёт `hello` (разрешение видео) и стримит; клиент видит картинку.
6. Касания клиента → норм. координаты в `[0,1]` → `tap/swipe/pinch/longpress/key`
   по DataChannel → хост пересылает в HostHelper → `dispatchGesture()`.

## Подключение инпута (без root)

Браузер не может вводить касания в чужие приложения, поэтому PWA-хост отдаёт
инпут в HostHelper (`ws://127.0.0.1:9100`). HostHelper использует
`AccessibilityService.dispatchGesture()` — касания/жесты «кликают» по активному
окну. Root не нужен.

## План «второго монитора» (экспериментально)

Чтобы на хосте был браузер, а Genshin одновременно ушёл «вторым монитором» к
клиенту: HostHelper через **Wireless debugging (Wi-Fi ADB)** создаёт virtual
display и запускает на него игру (`am start --display`). Работает не на всех
прошивках. Fallback — общий экран (стримится то, что в форграунде).

## Ограничения

- **Без root** нельзя: рендер чужого приложения в off-screen дисплей (кроме
  оговорённого ADB-пути), общий внутренний кеш клонов.
- **Внутренний звук** (AudioPlaybackCapture) — только Android 10+.
- **DRM-видео** (YouTube/Netflix) в фолбек-режиме отдаёт чёрный кадр в стрим —
  сам контент ок.
- **VPN** рвёт прямое LAN-соединение: нужен «разрешить локальную сеть»
  в настройках VPN либо выключение для сессии.