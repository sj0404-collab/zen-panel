# Протокол

Версия протокола: `1` (`PROTOCOL_VERSION`).
Все сообщения — JSON. Координаты — **нормализованные `[0,1]`** относительно
видеокадра (0,0 = левый верх). Хост умножает на реальное разрешение устройства.

Типы определены в `packages/shared/src/`.

## DataChannel `input` (клиент → хост)

```jsonc
// Tap — одиночное касание
{ "type": "tap", "p": { "x": 0.5, "y": 0.7 } }

// Swipe/драг
{ "type": "swipe", "from": { "x": 0.5, "y": 0.7 }, "to": { "x": 0.6, "y": 0.3 }, "durationMs": 180 }

// Pinch (двумя пальцами): onmove-события меняют distanceFrom→distanceTo
{ "type": "pinch", "c": { "x": 0.5, "y": 0.5 }, "distanceFrom": 40, "distanceTo": 88, "durationMs": 80 }

// Долгое нажатие
{ "type": "longpress", "p": { "x": 0.5, "y": 0.5 }, "durationMs": 600 }

// Системная клавиша
{ "type": "key", "key": "back" | "home" | "recents" | "power" | "volume_up" | "volume_down" | "menu" | "enter" }
```

`distanceFrom/distanceTo` — расстояние между пальцами в экранных пикселях
норм. пространства, умноженных на внутренние размеры клиента (см. `input.ts`).

## DataChannel `input` (хост → клиент)

```jsonc
{ "type": "hello", "proto": 1, "video": { "w": 1280, "h": 720 }, "dpi": null, "audio": true }

{ "type": "session", "state": "connected" | "ended" | "error", "reason": "..." }
```

## WebSocket signaling (`ws://<lan-ip>:8787/?room=<name>`)

```jsonc
{ "kind": "join", "role": "host" | "client" }   // при подключении
{ "kind": "peer_joined", "role": "..." }         // сервер — другим участникам комнаты
{ "kind": "offer",  "sdp": "..." }               // хост
{ "kind": "answer", "sdp": "..." }               // клиент
{ "kind": "ice", "candidate": "...", "mid": "0" } // обе стороны
```

Сервер — «глупый» реле: шлёт каждое сообщение всем остальным в комнате.

## Маршрут инпута

1. Клиент: `pointerdown/move/up` → `normalizedFromElement()` → `ClientMessage`.
2. DataChannel `input` на хост.
3. Хост: `decodeClientMessage()` → пересылка в `ws://127.0.0.1:9100` (HostHelper).
4. HostHelper: `AccessibilityService.dispatchGesture()` по активному окну.