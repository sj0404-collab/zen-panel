/**
 * LAN signaling server for Android-cloud-local-gaming.
 *
 * Dumb room relay over WebSocket. Both the host PWA and the client PWA
 * connect to `ws://<host>:<port>/?room=<name>` and all signaling messages
 * (join / peer_joined / offer / answer / ice) are broadcast to the other
 * peer(s) in the same room. No TURN/STUN — LAN only by design.
 */

import { createServer, type IncomingMessage } from 'node:http';
import { URL } from 'node:url';
import { WebSocket, WebSocketServer } from 'ws';
import { decodeSignalingMessage } from '@aclg/shared';

const PORT = Number(process.env.WS_SIGNALING_PORT ?? 8787);
const HOST = process.env.WS_SIGNALING_HOST ?? '0.0.0.0';

interface Peer {
  socket: WebSocket;
  room: string;
  role: 'host' | 'client' | null;
}

const peers = new Map<WebSocket, Peer>();

function room(name: string, except?: WebSocket): Peer[] {
  return [...peers.values()].filter((p) => p.socket !== except && p.room === name);
}

function send(socket: WebSocket, data: unknown): void {
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(data));
  }
}

function handleMessage(socket: WebSocket, raw: string): void {
  const peer = peers.get(socket);
  if (!peer) return;

  const msg = decodeSignalingMessage(raw);
  if (!msg) {
    send(socket, { kind: 'error', reason: 'malformed message' });
    return;
  }

  switch (msg.kind) {
    case 'join':
      peer.role = msg.role;
      for (const other of room(peer.room, socket)) {
        send(other.socket, { kind: 'peer_joined', role: msg.role });
      }
      break;
    case 'offer':
    case 'answer':
    case 'ice':
      for (const other of room(peer.room, socket)) {
        send(other.socket, msg);
      }
      break;
    default:
      break;
  }
}

function roomFrom(req: IncomingMessage): string {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  return url.searchParams.get('room') ?? 'default';
}

function logPeers(): void {
  const active = [...peers.values()].filter((p) => p.role);
  console.log(
    `[signaling] rooms: ${JSON.stringify(
      [...new Set(active.map((p) => p.room))].map((room) => ({
        room,
        peers: active.filter((p) => p.room === room).map((p) => p.role),
      })),
    )}`,
  );
}

const server = createServer((_req, res) => {
  res.writeHead(200, { 'content-type': 'text/plain' });
  res.end('aclg signaling is running');
});

const wss = new WebSocketServer({ server });

wss.on('connection', (socket, req) => {
  const room = roomFrom(req);
  peers.set(socket, { socket, room, role: null });
  console.log(`[signaling] peer joined room="${room}" (${peers.size} total)`);

  socket.on('message', (data) => handleMessage(socket, String(data)));
  socket.on('error', () => socket.close());
  socket.on('close', () => {
    peers.delete(socket);
    console.log(`[signaling] peer left room="${room}" (${peers.size} total)`);
    logPeers();
  });

  logPeers();
});

server.listen(PORT, HOST, () => {
  console.log(`[signaling] listening on ws://${HOST}:${PORT}`);
});