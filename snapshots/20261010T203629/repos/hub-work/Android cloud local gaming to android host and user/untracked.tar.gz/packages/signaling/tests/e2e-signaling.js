// Self-contained E2E: start signaling server, simulate host+client, verify relay, stop server.
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import WebSocket from 'ws';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = 8799;

const server = spawn(process.execPath, [join(__dirname, '..', 'dist', 'server.js')], {
  env: { ...process.env, WS_SIGNALING_PORT: String(PORT) },
  stdio: 'ignore',
});

const got = [];
const waitFor = (pred, ms = 4000) =>
  new Promise((resolve, reject) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (pred()) {
        clearInterval(iv);
        resolve();
      } else if (Date.now() - t0 > ms) {
        clearInterval(iv);
        reject(new Error('timeout; got=' + JSON.stringify(got)));
      }
    }, 20);
  });

try {
  await new Promise((r) => setTimeout(r, 400));
  const url = `ws://127.0.0.1:${PORT}/?room=e2e`;
  const host = new WebSocket(url);
  const client = new WebSocket(url);
  host.on('message', (d) => got.push('host:' + d));
  client.on('message', (d) => got.push('client:' + d));

  await new Promise((r) => host.on('open', r));
  await new Promise((r) => client.on('open', r));

  host.send(JSON.stringify({ kind: 'join', role: 'host' }));
  await waitFor(() => got.some((g) => g.startsWith('client:') && g.includes('peer_joined')));

  client.send(JSON.stringify({ kind: 'join', role: 'client' }));
  await waitFor(() => got.some((g) => g.startsWith('host:') && g.includes('peer_joined')));

  host.send(JSON.stringify({ kind: 'offer', sdp: 'SDP_HOST_1' }));
  await waitFor(() => got.some((g) => g.startsWith('client:') && g.includes('offer')));

  client.send(JSON.stringify({ kind: 'answer', sdp: 'SDP_CLI_1' }));
  await waitFor(() => got.some((g) => g.startsWith('host:') && g.includes('answer')));

  host.send(JSON.stringify({ kind: 'ice', candidate: 'cand1', mid: '0' }));
  await waitFor(() => got.some((g) => g.startsWith('client:') && g.includes('ice')));

  const has = (needle, who) => {
    if (!got.some((g) => g.startsWith(who) && g.includes(needle))) {
      throw new Error('missing ' + needle + ' for ' + who + '; all=' + JSON.stringify(got));
    }
  };
  has('peer_joined', 'host');
  has('peer_joined', 'client');
  has('SDP_HOST_1', 'client');
  has('SDP_CLI_1', 'host');
  has('cand1', 'client');

  host.close();
  client.close();
  console.log('SIGNALING E2E OK');
} finally {
  server.kill('SIGKILL');
}