/**
 * Signaling protocol relayed over the LAN WebSocket server.
 * The server is a dumb room relay: every message sent to a room is
 * broadcast to the other peers in the same room.
 */

export type SignalingMessage =
  | { kind: 'join'; role: 'host' | 'client' }
  | { kind: 'peer_joined'; role: 'host' | 'client' }
  | { kind: 'offer'; sdp: string }
  | { kind: 'answer'; sdp: string }
  | { kind: 'ice'; candidate: string; mid: string | null };

export function encodeSignalingMessage(msg: SignalingMessage): string {
  return JSON.stringify(msg);
}

export function decodeSignalingMessage(data: string): SignalingMessage | null {
  try {
    const value = JSON.parse(data);
    if (typeof value !== 'object' || value === null) return null;
    const v = value as { kind?: unknown };
    if (v.kind === 'peer_joined') return value as SignalingMessage;
    if (v.kind === 'ice') {
      if (typeof value.candidate !== 'string') return null;
      return value as SignalingMessage;
    }
    if (v.kind === 'offer' || v.kind === 'answer') {
      if (typeof value.sdp !== 'string') return null;
      return value as SignalingMessage;
    }
    if (v.kind === 'join') {
      if (value.role !== 'host' && value.role !== 'client') return null;
      return value as SignalingMessage;
    }
    return null;
  } catch {
    return null;
  }
}