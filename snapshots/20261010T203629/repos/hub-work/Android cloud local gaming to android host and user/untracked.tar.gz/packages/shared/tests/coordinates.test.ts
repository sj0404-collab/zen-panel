import { describe, expect, it } from 'vitest';
import {
  clampPoint,
  denormalize,
  normalize,
  normalizedFromElement,
  remap,
  type Size,
} from '../src/coordinates.js';

const frame: Size = { w: 1920, h: 1080 };

describe('normalize/denormalize', () => {
  it('maps pixels to [0,1] and back', () => {
    const p = { x: 960, y: 540 };
    const n = normalize(p, frame);
    expect(n.x).toBeCloseTo(0.5);
    expect(n.y).toBeCloseTo(0.5);
    const back = denormalize(n, frame);
    expect(back.x).toBe(960);
    expect(back.y).toBe(540);
  });

  it('clamps out-of-range points', () => {
    const n = normalize({ x: -100, y: 2000 }, frame);
    expect(n).toEqual({ x: 0, y: 1 });
    expect(clampPoint({ x: 5000, y: -5 }, frame)).toEqual({ x: 1920, y: 0 });
  });

  it('survives resolution changes via remap', () => {
    const abs = { x: 1920, y: 540 };
    const smaller: Size = { w: 800, h: 450 };
    const p = remap(abs, frame, smaller);
    expect(p).toEqual({ x: 800, y: 225 });
  });
});

describe('normalizedFromElement (letterbox)', () => {
  function el(overrides: Partial<DOMRect> = {}): DOMRect {
    const base: DOMRect = {
      x: 0,
      y: 0,
      left: 0,
      top: 0,
      right: 400,
      bottom: 300,
      width: 400,
      height: 300,
      toJSON: () => ({}),
    };
    return { ...base, ...overrides };
  }

  it('maps the video area when container has the same aspect ratio', () => {
    const video = { videoWidth: 1600, videoHeight: 900 };
    const bounds = el();
    expect(normalizedFromElement(200, 150, video, bounds)).toEqual({ x: 0.5, y: 0.5 });
  });

  it('handles letterbox on the right (wider container)', () => {
    const video = { videoWidth: 1600, videoHeight: 900 };
    const bounds = el({ left: 10, top: 5, width: 400, height: 300 });
    // scale = min(400/1600, 300/900) = 0.25 -> content 400x225, height fits full.
    const left = 10;
    const top = 5 + (300 - 225) / 2;
    expect(normalizedFromElement(left + 200, top + 112.5, video, bounds)).toEqual({
      x: 0.5,
      y: 0.5,
    });
  });

  it('returns null when video has no dimensions', () => {
    const video = { videoWidth: 0, videoHeight: 0 };
    expect(normalizedFromElement(10, 10, video, el())).toBeNull();
  });

  it('returns null for taps on the black bar', () => {
    const video = { videoWidth: 1600, videoHeight: 900 };
    const bounds = el({ left: 0, top: 0, width: 400, height: 300 });
    // Black bar top area (content starts at y=37.5)
    expect(normalizedFromElement(200, 10, video, bounds)).toBeNull();
  });
});