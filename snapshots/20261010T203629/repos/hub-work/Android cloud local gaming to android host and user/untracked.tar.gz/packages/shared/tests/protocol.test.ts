import { describe, expect, it } from 'vitest';
import {
  decodeClientMessage,
  isClientMessage,
  PROTOCOL_VERSION,
  type ClientMessage,
} from '../src/protocol.js';

describe('client message codec', () => {
  it('round-trips a tap message', () => {
    const raw = JSON.stringify({ type: 'tap', p: { x: 0.5, y: 0.25 } });
    const msg = decodeClientMessage(raw);
    expect(msg).toEqual({ type: 'tap', p: { x: 0.5, y: 0.25 } });
  });

  it('isClientMessage rejects malformed payloads', () => {
    expect(isClientMessage({ type: 'nope' })).toBe(false);
    expect(isClientMessage({ type: 'tap' })).toBe(true);
    expect(isClientMessage('tap')).toBe(false);
    expect(isClientMessage(null)).toBe(false);
  });

  it('rejects invalid JSON', () => {
    expect(decodeClientMessage('{not json')).toBeNull();
  });

  it('exposes a stable protocol version', () => {
    expect(PROTOCOL_VERSION).toBe(1);
  });

  it('accepts all known input kinds', () => {
    const kinds: ClientMessage['type'][] = ['tap', 'swipe', 'pinch', 'longpress', 'key'];
    for (const kind of kinds) {
      expect(isClientMessage({ type: kind, p: { x: 0, y: 0 } })).toBe(true);
    }
  });
});