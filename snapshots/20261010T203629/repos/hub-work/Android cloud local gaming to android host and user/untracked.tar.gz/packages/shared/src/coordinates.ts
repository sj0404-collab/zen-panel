/**
 * Coordinate mapping between video frame space and the device screen space.
 *
 * All input coordinates are transmitted as NORMALIZED values in [0, 1]
 * relative to the captured video frame. The host multiplies them by the
 * real device resolution it announced in HANDSHAKE, so the client never
 * has to know the device's physical resolution. Point (0,0) is the
 * top-left corner of the video.
 */

export interface Point {
  x: number;
  y: number;
}

export interface Size {
  w: number;
  h: number;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function clampPoint(p: Point, size: Size): Point {
  return { x: clamp(p.x, 0, size.w), y: clamp(p.y, 0, size.h) };
}

/** Normalize absolute pixel coordinates in `frameSize` to [0,1] space. */
export function normalize(p: Point, frameSize: Size): Point {
  return {
    x: frameSize.w === 0 ? 0 : clamp(p.x / frameSize.w, 0, 1),
    y: frameSize.h === 0 ? 0 : clamp(p.y / frameSize.h, 0, 1),
  };
}

/** Convert normalized coordinates back to absolute pixels in `frameSize`. */
export function denormalize(p: Point, frameSize: Size): Point {
  return clampPoint({ x: p.x * frameSize.w, y: p.y * frameSize.h }, frameSize);
}

/**
 * Remap an ABSOLUTE pixel point from one frame size to another
 * (e.g. after the host's encoder changed resolution). Input and output
 * are pixel coordinates within their respective frames.
 */
export function remap(p: Point, from: Size, to: Size): Point {
  return {
    x: from.w === 0 ? p.x : (p.x * to.w) / from.w,
    y: from.h === 0 ? p.y : (p.y * to.h) / from.h,
  };
}

/**
 * Given a pointer event on a video element that is letterboxed inside its
 * bounding rectangle, return normalized coordinates of the actual video
 * content. Handles the black bars so taps match pixels even when the
 * aspect ratio of the container differs from the video.
 */
export function normalizedFromElement(
  clientX: number,
  clientY: number,
  video: Pick<HTMLVideoElement, 'videoWidth' | 'videoHeight'> | { videoWidth: number; videoHeight: number },
  bounds: DOMRect,
): Point | null {
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  if (!vw || !vh) return null;

  const scale = Math.min(bounds.width / vw, bounds.height / vh);
  const boxWidth = vw * scale;
  const boxHeight = vh * scale;
  const offsetX = (bounds.width - boxWidth) / 2;
  const offsetY = (bounds.height - boxHeight) / 2;

  const relX = clientX - bounds.left;
  const relY = clientY - bounds.top;
  if (relX < offsetX || relX > offsetX + boxWidth || relY < offsetY || relY > offsetY + boxHeight) {
    return null;
  }
  return { x: (relX - offsetX) / boxWidth, y: (relY - offsetY) / boxHeight };
}