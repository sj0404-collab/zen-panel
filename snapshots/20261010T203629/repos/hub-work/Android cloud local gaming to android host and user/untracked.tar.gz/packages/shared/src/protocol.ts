import type { Point } from './coordinates.js';

/**
 * DataChannel protocol between the client PWA and the host PWA.
 * All messages are JSON, versioned by `proto`.
 */

export const PROTOCOL_VERSION = 1;
export const DATA_CHANNEL_LABEL = 'input';

/** Client -> Host touch/key injection. Coordinates are normalized [0,1]. */
export type ClientMessage =
  | ClientTap
  | ClientSwipe
  | ClientPinch
  | ClientLongPress
  | ClientKey;

/** Host -> Client session info. */
export type HostMessage = HostHello | HostSession;

export interface ClientTap {
  type: 'tap';
  p: Point;
}

export interface ClientSwipe {
  type: 'swipe';
  from: Point;
  to: Point;
  durationMs: number;
}

export interface ClientPinch {
  type: 'pinch';
  c: Point;
  distanceFrom: number;
  distanceTo: number;
  durationMs: number;
}

export interface ClientLongPress {
  type: 'longpress';
  p: Point;
  durationMs: number;
}

export type KeyCode =
  | 'back'
  | 'home'
  | 'recents'
  | 'power'
  | 'volume_up'
  | 'volume_down'
  | 'menu'
  | 'enter';

export interface ClientKey {
  type: 'key';
  key: KeyCode;
}

export interface HostHello {
  type: 'hello';
  proto: number;
  /** Pixel size of the captured video stream. */
  video: { w: number; h: number };
  /** Logical dpi of the device (optional). */
  dpi: number | null;
  /** Whether audio is part of the stream. */
  audio: boolean;
}

export interface HostSession {
  type: 'session';
  state: 'connected' | 'ended' | 'error';
  reason?: string;
}

export function isClientMessage(value: unknown): value is ClientMessage {
  if (typeof value !== 'object' || value === null) return false;
  const v = value as { type?: unknown };
  return (
    v.type === 'tap' ||
    v.type === 'swipe' ||
    v.type === 'pinch' ||
    v.type === 'longpress' ||
    v.type === 'key'
  );
}

export function encodeClientMessage(msg: ClientMessage): string {
  return JSON.stringify(msg);
}

export function decodeClientMessage(data: string): ClientMessage | null {
  try {
    const value: unknown = JSON.parse(data);
    return isClientMessage(value) ? value : null;
  } catch {
    return null;
  }
}