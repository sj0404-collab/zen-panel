import {
  DATA_CHANNEL_LABEL,
  decodeClientMessage,
  encodeSignalingMessage,
  PROTOCOL_VERSION,
  type HostMessage,
  type SignalingMessage,
} from '@aclg/shared';

export interface HostUi {
  capture: HTMLButtonElement;
  stop: HTMLButtonElement;
  signalUrl: HTMLInputElement;
  room: HTMLInputElement;
  helperUrl: HTMLInputElement;
  preview: HTMLVideoElement;
  status: HTMLElement;
  logEl: HTMLElement;
}

export class HostSession {
  private pc: RTCPeerConnection | null = null;
  private channel: RTCDataChannel | null = null;
  private stream: MediaStream | null = null;
  private ws: WebSocket | null = null;
  private helper: WebSocket | null = null;
  private capture: MediaStreamTrack | null = null;
  private room = 'default';
  private helperUrl = 'ws://127.0.0.1:9100';

  constructor(private ui: HostUi) {}

  status(text: string): void {
    this.ui.status.textContent = text;
  }

  log(text: string): void {
    const li = document.createElement('li');
    li.textContent = `[${new Date().toLocaleTimeString()}] ${text}`;
    this.ui.logEl.prepend(li);
  }

  async start(): Promise<void> {
    this.stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30 } },
      audio: true,
    });
    this.capture = this.stream.getVideoTracks()[0] ?? null;
    const audioTrack = this.stream.getAudioTracks()[0] ?? null;
    this.ui.preview.srcObject = this.stream;
    this.ui.capture.disabled = true;
    this.ui.stop.disabled = false;
    this.status(`Захват: ${this.videoSize()?.map((s) => s)}  аудио: ${audioTrack ? 'да' : 'нет'}`);

    this.room = this.ui.room.value.trim() || 'default';
    this.helperUrl = this.ui.helperUrl.value.trim() || this.helperUrl;

    this.connectHelper();
    this.connectSignaling();
  }

  private videoSize(): [number, number] | null {
    const t = this.capture;
    if (!t) return null;
    const s = t.getSettings();
    const c = t.getConstraints();
    const resolve = (v: number | ConstrainULong | undefined, fallback: number): number => {
      if (typeof v === 'number') return v;
      if (v && typeof v === 'object' && 'ideal' in v) return (v as { ideal?: number }).ideal ?? fallback;
      return fallback;
    };
    return [resolve(s.width, 1280), resolve(s.height, 720)];
  }

  private connectHelper(): void {
    try {
      this.helper = new WebSocket(this.helperUrl);
      this.helper.onopen = () => this.log(`Помощник подключён: ${this.helperUrl}`);
      this.helper.onmessage = (e) => this.log(`← helper: ${e.data}`);
      this.helper.onclose = () => this.log('Помощник отключён (инпут не будет доставляться)');
      this.helper.onerror = () => this.log('Помощник недоступен');
    } catch {
      this.log(`Помощник недоступен: ${this.helperUrl}`);
    }
  }

  private connectSignaling(): void {
    const url = this.ui.signalUrl.value.trim();
    const base = url || `ws://${location.hostname || '127.0.0.1'}:8787`;
    const wsUrl = `${base}${base.includes('?') ? '&' : '?'}room=${encodeURIComponent(this.room)}`;
    this.log(`Signaling: ${wsUrl}`);

    const ws = new WebSocket(wsUrl);
    this.ws = ws;
    ws.onopen = () => {
      const msg: SignalingMessage = { kind: 'join', role: 'host' };
      ws.send(encodeSignalingMessage(msg));
      this.status('Ожидание клиента…');
    };
    ws.onmessage = (e) => void this.onSignal(String(e.data));
    ws.onclose = () => {
      this.status('Signaling отключён');
      this.log('Signaling закрыт');
    };
    ws.onerror = () => this.log('Signaling error');
  }

  private async onSignal(raw: string): Promise<void> {
    const msg = this.parse<SignalingMessage>(raw);
    if (!msg) return;

    if (msg.kind === 'peer_joined') {
      this.log(`Клиент (${msg.role}) в комнате — делаю offer`);
      this.pc = this.createPeer();
      await this.createOffer();
    } else if (msg.kind === 'answer' && this.pc) {
      await this.pc.setRemoteDescription({ type: 'answer', sdp: msg.sdp });
      this.status('Соединено');
    } else if (msg.kind === 'ice' && this.pc) {
      await this.pc.addIceCandidate({ candidate: msg.candidate, sdpMid: msg.mid, sdpMLineIndex: 0 });
    }
  }

  private parse<T>(raw: string): T | null {
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  }

  private createPeer(): RTCPeerConnection {
    const pc = new RTCPeerConnection({ iceServers: [] });
    for (const track of this.stream?.getTracks() ?? []) {
      if (track.kind === 'audio' || track.kind === 'video') pc.addTrack(track, this.stream!);
    }

    const ch = pc.createDataChannel(DATA_CHANNEL_LABEL, { ordered: true });
    ch.onopen = () => this.onChannelOpen(ch);
    ch.onmessage = (e) => this.onClientMessage(String(e.data));
    ch.onclose = () => this.log('DataChannel закрыт');
    this.channel = ch;

    pc.onicecandidate = (e) => {
      if (e.candidate && this.ws?.readyState === WebSocket.OPEN) {
        const msg: SignalingMessage = {
          kind: 'ice',
          candidate: e.candidate.candidate,
          mid: e.candidate.sdpMid,
        };
        this.ws.send(encodeSignalingMessage(msg));
      }
    };
    pc.onconnectionstatechange = () => {
      this.status(`WebRTC: ${pc.connectionState}`);
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
        this.sendHost({ type: 'session', state: 'ended', reason: pc.connectionState });
      }
    };
    return pc;
  }

  private async createOffer(): Promise<void> {
    if (!this.pc) return;
    const offer = await this.pc.createOffer();
    await this.pc.setLocalDescription(offer);
    const msg: SignalingMessage = { kind: 'offer', sdp: offer.sdp ?? '' };
    this.ws?.send(encodeSignalingMessage(msg));
  }

  private onChannelOpen(ch: RTCDataChannel): void {
    this.log('DataChannel открыт');
    const [w, h] = this.videoSize() ?? [1280, 720];
    const hello: HostMessage = {
      type: 'hello',
      proto: PROTOCOL_VERSION,
      video: { w, h },
      dpi: null,
      audio: (this.stream?.getAudioTracks().length ?? 0) > 0,
    };
    ch.send(JSON.stringify(hello));
  }

  private onClientMessage(raw: string): void {
    const msg = decodeClientMessage(raw);
    if (!msg) return;
    if (this.helper?.readyState === WebSocket.OPEN) {
      this.helper.send(JSON.stringify(msg));
    } else {
      this.log(`input (helper off): ${raw}`);
    }
  }

  private sendHost(msg: HostMessage): void {
    if (this.channel?.readyState === 'open') this.channel.send(JSON.stringify(msg));
  }

  stop(): void {
    for (const track of this.stream?.getTracks() ?? []) track.stop();
    this.pc?.close();
    this.ws?.close();
    this.helper?.close();
    this.pc = null;
    this.ws = null;
    this.helper = null;
    this.stream = null;
    this.ui.preview.srcObject = null;
    this.ui.capture.disabled = false;
    this.ui.stop.disabled = true;
    this.status('Остановлено');
  }
}