import { HostSession } from './host.js';

function el<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`#${id} not found`);
  return node as T;
}

const session = new HostSession({
  capture: el('capture'),
  stop: el('stop'),
  signalUrl: el('signal-url'),
  room: el('room'),
  helperUrl: el('helper-url'),
  preview: el('preview'),
  status: el('status'),
  logEl: el('log'),
});

el('capture').addEventListener('click', () => {
  void session.start().catch((err: unknown) => {
    session.log(`Ошибка захвата: ${err}`);
  });
});
el('stop').addEventListener('click', () => session.stop());

if ('serviceWorker' in navigator) {
  void navigator.serviceWorker.register('./sw.js').catch(() => undefined);
}