import { ClientSession } from './client.js';
import { TouchToMessage } from './input.js';

function el<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`#${id} not found`);
  return node as T;
}

const video = el<HTMLVideoElement>('screen');
const session = new ClientSession({
  signalUrl: el('signal-url'),
  room: el('room'),
  connect: el('connect'),
  disconnect: el('disconnect'),
  home: el('home'),
  back: el('back'),
  video,
  status: el('status'),
  touchHint: el('touch'),
});

const touch = new TouchToMessage({ video }, { sendInput: (m) => session.sendInput(m) });

const stage = document.querySelector('.stage') as HTMLElement | null;
if (stage) {
  stage.addEventListener('pointerdown', (e) => touch.pointerDown(e as PointerEvent));
  stage.addEventListener('pointermove', (e) => touch.pointerMove(e as PointerEvent));
  stage.addEventListener('pointerup', (e) => touch.pointerUp(e as PointerEvent));
  stage.addEventListener('pointercancel', (e) => touch.pointerCancel(e as PointerEvent));
}

el('connect').addEventListener('click', () => session.connect());
el('disconnect').addEventListener('click', () => session.disconnect());
el('home').addEventListener('click', () => session.sendKey('home'));
el('back').addEventListener('click', () => session.sendKey('back'));

if ('serviceWorker' in navigator) {
  void navigator.serviceWorker.register('./sw.js').catch(() => undefined);
}