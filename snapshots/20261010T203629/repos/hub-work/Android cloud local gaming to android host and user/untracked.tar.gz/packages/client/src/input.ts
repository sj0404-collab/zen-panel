import { normalizedFromElement, type ClientMessage, type Point } from '@aclg/shared';

/**
 * Converts browser pointer events over a <video> element into protocol
 * touch messages (tap / swipe / longpress / pinch). Coordinates are
 * normalized against the actual video content (letterbox-aware).
 */

export interface InputTarget {
  video: HTMLVideoElement;
}

const MOVE_THRESHOLD = 12; // px before a tap becomes a swipe
const LONGPRESS_MS = 600;

interface ActivePointer {
  id: number;
  start: Point;
  last: Point;
  startTime: number;
  moved: boolean;
}

export interface GestureSink {
  sendInput(msg: ClientMessage): void;
}

export class TouchToMessage {
  private pointers = new Map<number, ActivePointer>();
  private pinchBase: { distance: number; start: Point } | null = null;
  private longpressTimer: number | null = null;
  private sink: GestureSink;
  private target: InputTarget;
  private lastTapAt = 0;

  constructor(target: InputTarget, sink: GestureSink) {
    this.target = target;
    this.sink = sink;
  }

  private pointFromEvent(e: PointerEvent): Point | null {
    return normalizedFromElement(
      e.clientX,
      e.clientY,
      this.target.video,
      this.target.video.getBoundingClientRect(),
    );
  }

  pointerDown(e: PointerEvent): void {
    const p = this.pointFromEvent(e);
    if (!p) return;
    const active: ActivePointer = { id: e.pointerId, start: p, last: p, startTime: e.timeStamp, moved: false };
    this.pointers.set(e.pointerId, active);
    e.preventDefault();

    // Gesture is a pinch when the pop of the second finger happens close to the first.
    if (this.pointers.size === 2) {
      this.clearLongpress();
      this.pinchBase = this.distanceBetween();
    } else if (this.pointers.size === 1) {
      this.longpressTimer = window.setTimeout(() => this.sendLongPress(longpress(active)), LONGPRESS_MS);
    }
  }

  pointerMove(e: PointerEvent): void {
    const p = this.pointFromEvent(e);
    if (!p) return;
    const active = this.pointers.get(e.pointerId);
    if (!active) return;

    const dx = Math.abs(p.x - active.last.x) * screenWidth();
    const dy = Math.abs(p.y - active.last.y) * screenHeight();
    if (dx > MOVE_THRESHOLD || dy > MOVE_THRESHOLD) {
      active.moved = true;
      this.clearLongpress();
    }
    active.last = p;
    e.preventDefault();

    if (this.pointers.size === 2) {
      const dist = this.distanceBetween();
      if (this.pinchBase && dist) {
        this.sink.sendInput({
          type: 'pinch',
          c: { x: (this.pinchBase.start.x + p.x) / 2, y: (this.pinchBase.start.y + p.y) / 2 },
          distanceFrom: this.pinchBase.distance,
          distanceTo: dist.distance,
          durationMs: 80,
        });
        this.pinchBase = { distance: dist.distance, start: this.pinchBase.start };
      }
    }
  }

  pointerUp(e: PointerEvent): void {
    const p = this.pointFromEvent(e);
    const active = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    this.clearLongpress();
    if (!active) return;
    e.preventDefault();

    const multi = this.pointers.size > 0;
    if (multi) return; // other finger still down — pinch continued elsewhere

    const duration = e.timeStamp - active.startTime;

    if (!active.moved && duration < LONGPRESS_MS) {
      const now = performance.now();
      // double-tap = keep a tap; single tap threshold ~250ms
      const isDouble = now - this.lastTapAt < 260;
      this.lastTapAt = now;
      void isDouble;
      this.sink.sendInput({ type: 'tap', p: active.start });
    } else if (active.moved) {
      this.sink.sendInput({
        type: 'swipe',
        from: active.start,
        to: p ?? active.last,
        durationMs: Math.max(40, duration),
      });
    }
  }

  pointerCancel(e: PointerEvent): void {
    this.pointers.delete(e.pointerId);
    this.clearLongpress();
  }

  private distanceBetween(): { distance: number; start: Point } | null {
    const [a, b] = [...this.pointers.values()];
    if (!a || !b) return null;
    const dx = (a.last.x - b.last.x) * screenWidth();
    const dy = (a.last.y - b.last.y) * screenHeight();
    const start: Point = { x: (a.last.x + b.last.x) / 2, y: (a.last.y + b.last.y) / 2 };
    return { distance: Math.hypot(dx, dy), start };
  }

  private clearLongpress(): void {
    if (this.longpressTimer !== null) {
      window.clearTimeout(this.longpressTimer);
      this.longpressTimer = null;
    }
  }

  private sendLongPress(msg: ClientMessage): void {
    this.clearLongpress();
    this.sink.sendInput(msg);
    // swallow the lingering pointerup so it becomes neither tap nor swipe
    this.pointers.clear();
  }
}

function longpress(active: ActivePointer): ClientMessage {
  return { type: 'longpress', p: active.start, durationMs: LONGPRESS_MS };
}

function screenWidth(): number {
  return window.innerWidth || 1000;
}

function screenHeight(): number {
  return window.innerHeight || 1000;
}