import {
  DATA_CHANNEL_LABEL,
  decodeSignalingMessage,
  encodeSignalingMessage,
  type ClientMessage,
  type HostMessage,
  type SignalingMessage,
} from '@aclg/shared';

export interface ClientUi {
  signalUrl: HTMLInputElement;
  room: HTMLInputElement;
  connect: HTMLButtonElement;
  disconnect: HTMLButtonElement;
  home: HTMLButtonElement;
  back: HTMLButtonElement;
  video: HTMLVideoElement;
  status: HTMLElement;
  touchHint: HTMLElement;
}

export class ClientSession {
  private pc: RTCPeerConnection | null = null;
  private channel: RTCDataChannel | null = null;
  private ws: WebSocket | null = null;

  constructor(private ui: ClientUi) {}

  status(text: string): void {
    this.ui.status.textContent = text;
  }

  connect(): void {
    const room = this.ui.room.value.trim() || 'default';
    const base = this.ui.signalUrl.value.trim() || `ws://${location.hostname || '127.0.0.1'}:8787`;
    const wsUrl = `${base}${base.includes('?') ? '&' : '?'}room=${encodeURIComponent(room)}`;

    const ws = new WebSocket(wsUrl);
    this.ws = ws;
    ws.onopen = () => {
      ws.send(encodeSignalingMessage({ kind: 'join', role: 'client' }));
      this.status('Ожидание хоста…');
      this.ui.connect.disabled = true;
      this.ui.disconnect.disabled = false;
      this.enableKeys(true);
    };
    ws.onmessage = (e) => void this.onSignal(String(e.data));
    ws.onclose = () => this.teardown('Signaling закрыт');
    ws.onerror = () => this.teardown('Signaling ошибка');
  }

  private async onSignal(raw: string): Promise<void> {
    const msg = decodeSignalingMessage(raw);
    if (!msg) return;

    if (msg.kind === 'offer') {
      const pc = (this.pc = new RTCPeerConnection({ iceServers: [] }));
      pc.ondatachannel = (e) => {
        const ch = e.channel;
        if (ch.label === DATA_CHANNEL_LABEL) this.wireChannel(ch);
      };
      pc.ontrack = (e) => {
        const stream = e.streams[0] ?? new MediaStream([e.track]);
        this.ui.video.srcObject = stream;
        this.ui.video.play().catch(() => undefined);
        this.status('Стрим получен');
      };
      pc.onicecandidate = (e) => {
        if (e.candidate && this.ws?.readyState === WebSocket.OPEN) {
          this.ws.send(
            encodeSignalingMessage({
              kind: 'ice',
              candidate: e.candidate.candidate,
              mid: e.candidate.sdpMid,
            }),
          );
        }
      };
      pc.onconnectionstatechange = () => {
        this.status(`WebRTC: ${pc.connectionState}`);
        if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
          this.ws?.close();
        }
      };

      await pc.setRemoteDescription({ type: 'offer', sdp: msg.sdp });
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      const relay: SignalingMessage = { kind: 'answer', sdp: answer.sdp ?? '' };
      this.ws?.send(encodeSignalingMessage(relay));
    } else if (msg.kind === 'ice' && this.pc) {
      await this.pc.addIceCandidate({ candidate: msg.candidate, sdpMid: msg.mid, sdpMLineIndex: 0 });
    }
  }

  private wireChannel(ch: RTCDataChannel): void {
    this.channel = ch;
    ch.onmessage = (e) => {
      const hostMsg = this.parse<HostMessage>(String(e.data));
      if (!hostMsg) return;
      if (hostMsg.type === 'hello') {
        this.status(
          `Соединено · ${hostMsg.video.w}×${hostMsg.video.h}${hostMsg.audio ? ' · +звук' : ''}`,
        );
      } else if (hostMsg.type === 'session') {
        this.status(hostMsg.state === 'connected' ? 'Соединено' : hostMsg.reason ?? hostMsg.state);
      }
    };
    ch.onclose = () => this.teardown('Канал закрыт');
  }

  sendInput(msg: ClientMessage): void {
    if (this.channel?.readyState === 'open') {
      this.channel.send(JSON.stringify(msg));
    }
  }

  sendKey(key: 'home' | 'back'): void {
    this.sendInput({ type: 'key', key });
  }

  private parse<T>(raw: string): T | null {
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  }

  private enableKeys(on: boolean): void {
    this.ui.home.disabled = !on;
    this.ui.back.disabled = !on;
  }

  disconnect(): void {
    this.pc?.close();
    this.ws?.close();
    this.channel?.close();
    this.teardown('Отключено вручную');
  }

  private teardown(reason: string): void {
    this.pc?.close();
    this.ws?.close();
    this.pc = null;
    this.ws = null;
    this.channel = null;
    this.ui.video.srcObject = null;
    this.ui.connect.disabled = false;
    this.ui.disconnect.disabled = true;
    this.enableKeys(false);
    this.status(reason);
  }
}