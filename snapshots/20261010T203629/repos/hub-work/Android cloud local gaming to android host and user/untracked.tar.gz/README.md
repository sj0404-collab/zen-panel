# ACLG — Android Cloud Local Gaming

Передача экрана телефона-хоста на второй Android-телефон по LAN через WebRTC,
с доставкой касаний обратно. **Без root, без облака.** «Астер, но для телефона»:
хост играет/сидит в браузере, а удалённый игрок играет в игру на том же телефоне
(по очереди, либо «вторым монитором» через Wi-Fi ADB — экспериментально).

```
   телефон А (хост)                     телефон Б (клиент)
┌──────────────────────┐           ┌──────────────────────┐
│ Host PWA (браузер)   │           │ Client PWA (браузер) │
│  getDisplayMedia ────┼──WebRTC──▶│  <video> + касания   │
│  DataChannel ◄────────┤  (LAN)   │  pointer events      │
│        │              │           └──────────┬───────────┘
│   HostHelper APK      │                      │
│   (инпут, virtual dsp)│              ws://lan-ip:8787
└─────────┬──────────────┘                      │
          └──────► signaling server ◄──────────┘
```

## Состав

| Папка | Роль |
|---|---|
| [`packages/host`](packages/host) | PWA хоста — захват экрана, WebRTC sender, превью |
| [`packages/client`](packages/client) | PWA клиента — приём стрима, касания/жесты |
| [`packages/signaling`](packages/signaling) | LAN WebSocket-сервер (SDP/ICE relay) |
| [`packages/shared`](packages/shared) | протокол, маппинг координат, тесты |
| [`helper/`](helper) | Android APK — инпут без root (`AccessibilityService`), virtual display (Wi-Fi ADB) |

## Быстрый старт

```bash
npm install
npm run dev:signaling     # ws://<lan-ip>:8787 — в той же сети
npm run dev:host          # телефон А: http://<ip>:5173
npm run dev:client        # телефон Б: http://<ip>:5174
```

Подробности, права, VPN/DRM/аудио-нюансы и настройка «второго монитора» — в
[`docs/SETUP.md`](docs/SETUP.md), [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md),
[`docs/PROTOCOL.md`](docs/PROTOCOL.md).

## Статус

- [x] Протокол + координатный маппинг + юнит-тесты (12).
- [x] Signaling relay (LAN).
- [x] Host PWA: `getDisplayMedia` + WebRTC + превью + пересылка инпута в helper.
- [x] Client PWA: приём видео + tap/swipe/pinch/longpress/key.
- [ ] HostHelper APK: `AccessibilityService` + Wi-Fi ADB virtual display.
- [ ] Аудио-режимы + adaptive bitrate.
- [ ] Интеграция Dual App / инструкция по второму аккаунту.

## Тесты и сборка

```bash
npm test            # vitest, пакет shared
npm run build       # tsc + vite для всех пакетов
npm run typecheck
```

## Ограничения (честно)

- Без root общий внутренний кеш клонов и off-screen рендер чужого приложения
  штатно недоступны (ADB-путь — экспериментально, не все прошивки).
- Внутренний звук — Android 10+.
- DRM-видео в общей зоне экрана стримится «чёрным кадром».
- VPN ломает прямое LAN-соединение — нужен «allow local network».
- Риск античита при работе с клонами игры — вопрос пользователя.