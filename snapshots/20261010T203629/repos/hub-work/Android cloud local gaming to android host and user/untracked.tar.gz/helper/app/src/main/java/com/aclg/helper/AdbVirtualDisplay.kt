package com.aclg.helper

import android.content.Context

/**
 * Экспериментальный путь «второго монитора»: переместить игру на virtual
 * display, пока на физическом экране открыт браузер.
 *
 * Без root обычное приложение не может запустить чужой Activity на свой
 * virtual display. Единственный штатно-доступный мостик — Wireless debugging
 * (Wi-Fi ADB, Android 11+). Этот класс — best-effort обвязка поверх `adb`
 * shell-команд; часть команд потребует прав приложения, которого у обычного
 * APK нет. Работает не на всех прошивках.
 */
object AdbVirtualDisplay {

    /** Список известных дисплеев через dumpsys (диагностика). */
    fun listDisplays(context: Context): String =
        runShell("dumpsys display | grep -E 'mDisplayId|DisplayDeviceInfo' | head -40") ?: "n/a"

    /**
     * Попытка запустить пакет на конкретный display.
     * @param packageName напр. "com.miHoYo.GenshinImpact"
     * @param displayId id виртуального дисплея из listDisplays()
     */
    fun launchOnDisplay(packageName: String, displayId: Int): String =
        runShell("am start --user 0 --display $displayId -n $packageName") ?: "adb недоступен"

    /** Попытка собрать virtual display: запускаем нашу HeadlessActivity как мишень. */
    fun tryCreateAndLaunch(packageName: String): String {
        // Создать VirtualDisplay из обычного приложения можно только для своего
        // контента (Presentation/MediaProjection). Чужой Activity сюда не уедет.
        // Здесь — заглушка-маршрут: делимся строками команд для диагностики.
        return "no-root limit: cannot render third-party activity off-screen; " +
            "use shared-screen fallback or root/virtualization path"
    }

    private fun runShell(cmd: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText().trim()
            p.waitFor()
            (out.trim() + (if (err.isNotEmpty()) "\n[err] " + err else "")).ifEmpty { null }
        } catch (e: Exception) {
            e.message
        }
    }
}