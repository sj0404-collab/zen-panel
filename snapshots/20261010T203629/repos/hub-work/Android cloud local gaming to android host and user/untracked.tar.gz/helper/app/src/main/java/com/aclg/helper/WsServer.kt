package com.aclg.helper

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64

/**
 * Минимальный WebSocket-сервер (текстовые кадры) на чистой Java-стандартной
 * библиотеке — без внешних зависимостей. Достаточен, чтобы хост-PWA слал
 * сообщения инпута на ws://127.0.0.1:9100.
 */
class WsServer(
    private val port: Int,
    private val onMessage: (String) -> Unit,
    private val onClientChange: (Int) -> Unit,
) : AutoCloseable {

    private val server = ServerSocket(port)
    @Volatile private var running = true
    private val clients = java.util.concurrent.CopyOnWriteArraySet<Socket>()
    private val threads = mutableListOf<Thread>()

    fun start() {
        val t = Thread({ loop() }, "aclg-ws")
        t.isDaemon = true
        t.start()
        threads += t
    }

    private fun loop() {
        while (running) {
            try {
                val sock = server.accept()
                clients += sock
                onClientChange(clients.size)
                val h = Thread({ handle(sock) }, "aclg-ws-client")
                h.isDaemon = true
                h.start()
                threads += h
            } catch (_: Exception) {
                if (running) Thread.sleep(50)
            }
        }
    }

    val connectionCount: Int get() = clients.size

    private enum class Op(val value: Int) {
        CONTINUATION(0x0), TEXT(0x1), BINARY(0x2), CLOSE(0x8), PING(0x9), PONG(0xA);

        companion object {
            fun from(v: Int): Op? = entries.firstOrNull { it.value == v }
        }
    }

    private fun handle(sock: Socket) {
        try {
            val input = DataInputStream(BufferedInputStream(sock.getInputStream()))
            val output = sock.getOutputStream()

            // --- handshake ---
            val headers = LinkedHashMap<String, String>()
            val requestLine = input.readLineSafe() ?: return
            if (!requestLine.startsWith("GET")) return
            while (true) {
                val line = input.readLineSafe() ?: return
                if (line.isEmpty()) break
                val idx = line.indexOf(':')
                if (idx > 0) headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
            }
            val key = headers["sec-websocket-key"] ?: return
            val accept = handshakeAccept(key)
            output.write(
                (
                    "HTTP/1.1 101 Switching Protocols\r\n" +
                        "Upgrade: websocket\r\n" +
                        "Connection: Upgrade\r\n" +
                        "Sec-WebSocket-Accept: $accept\r\n\r\n"
                ).toByteArray(),
            )
            output.flush()

            // --- frames ---
            var pendingOpcode: Op? = null
            val pending = ByteArrayOutputStream()
            while (running) {
                val b0 = input.read()
                if (b0 < 0) break
                val b1 = input.read()
                if (b1 < 0) break
                val fin = b0 and 0x80 != 0
                val rawOp = b0 and 0x0F
                val masked = b1 and 0x80 != 0
                var len = b1 and 0x7F

                if (len == 126) len = input.readUnsignedShort()
                else if (len == 127) {
                    val hi = input.readLong()
                    len = (hi and 0x7FFF_FFFF_FFFF_FFFFL).toInt()
                }
                val maskKey = if (masked) {
                    ByteArray(4).also { input.readFully(it) }
                } else null
                val payload = ByteArray(len).also { input.readFully(it) }
                if (maskKey != null) {
                    for (i in payload.indices) payload[i] = (payload[i].toInt() xor maskKey[i and 3].toInt()).toByte()
                }

                val op = Op.from(rawOp) ?: continue
                when (op) {
                    Op.TEXT, Op.BINARY, Op.CONTINUATION -> {
                        pendingOpcode = if (op == Op.CONTINUATION) pendingOpcode ?: Op.BINARY else op
                        pending.write(payload)
                        if (fin) {
                            val complete = pending.toByteArray()
                            if (pendingOpcode == Op.TEXT) {
                                onMessage(String(complete, StandardCharsets.UTF_8))
                            }
                            pending.reset()
                            pendingOpcode = null
                        }
                    }
                    Op.CLOSE -> {
                        output.write(frame(Op.CLOSE, byteArrayOf(0x03, 0xE8.toByte())))
                        output.flush()
                        return
                    }
                    Op.PING -> {
                        pong(output, payload)
                    }
                    Op.PONG -> Unit
                }
            }
        } catch (_: Exception) {
            // drop connection
        } finally {
            try {
                sock.close()
            } catch (_: Exception) {
            }
            clients -= sock
            onClientChange(clients.size)
        }
    }

    private fun send(sock: Socket, text: String) {
        try {
            sock.getOutputStream().write(frame(Op.TEXT, text.toByteArray(StandardCharsets.UTF_8)))
            sock.getOutputStream().flush()
        } catch (_: Exception) {
        }
    }

    fun broadcast(text: String) {
        for (s in clients) send(s, text)
    }

    private fun pong(output: OutputStream, payload: ByteArray) {
        output.write(frame(Op.PONG, payload))
        output.flush()
    }

    private fun frame(op: Op, payload: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        out.write(0x80 or op.value)
        val n = payload.size
        when {
            n < 126 -> out.write(n)
            n < 0x10000 -> {
                out.write(126)
                out.write(n shr 8 and 0xFF)
                out.write(n and 0xFF)
            }
            else -> {
                out.write(127)
                for (i in 7 downTo 0) out.write((n.toLong() shr (i * 8)).toInt() and 0xFF)
            }
        }
        out.write(payload)
        return out.toByteArray()
    }

    private fun handshakeAccept(key: String): String {
        val digest = MessageDigest.getInstance("SHA-1")
            .digest((key + WS_GUID).toByteArray(StandardCharsets.UTF_8))
        return Base64.getEncoder().encodeToString(digest)
    }

    override fun close() {
        running = false
        try {
            server.close()
        } catch (_: Exception) {
        }
        for (s in clients) {
            try {
                s.close()
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    }
}

private fun DataInputStream.readLineSafe(): String? {
    val sb = StringBuilder()
    while (true) {
        val b = read()
        if (b < 0) return if (sb.isEmpty()) null else sb.toString()
        if (b == '\n'.code) {
            val s = sb.toString()
            if (s.endsWith("\r")) sb.setLength(sb.length - 1)
            return s
        }
        sb.append(b.toChar())
        if (sb.length > 16_384) return sb.toString()
    }
}