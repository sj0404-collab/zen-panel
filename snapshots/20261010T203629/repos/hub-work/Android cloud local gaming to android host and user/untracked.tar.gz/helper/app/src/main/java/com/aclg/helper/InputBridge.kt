package com.aclg.helper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * Наивный маршрут «протокол -> жесты». Координаты в сообщениях нормализованы
 * [0,1] относительно видео (те же оси, что у экрана устройства).
 */
object InputBridge {

    private const val TAP_STROKE_MS = 80L

    @Volatile
    var service: InputAccessibilityService? = null

    /** Dispatch a protocol message. Returns false if nothing could be injected. */
    fun inject(type: String, args: Map<String, Any>): Boolean {
        val svc = service ?: return false
        val size = displaySize(svc)
        if (size.x <= 0 || size.y <= 0) return false

        fun p(x: Any?, y: Any?): Point =
            Point((x as Double * size.x).toInt(), (y as Double * size.y).toInt())

        fun pFrom(o: Any?): Point = p(o?.field("x"), o?.field("y"))

        return when (type) {
            "tap" -> svc.tap(pFrom(args["p"]))
            "longpress" -> {
                val dur = (args["durationMs"] as? Number)?.toLong() ?: 600L
                svc.longPress(pFrom(args["p"]), dur)
            }
            "swipe" -> {
                val dur = (args["durationMs"] as? Number)?.toLong() ?: 180L
                svc.swipe(pFrom(args["from"]), pFrom(args["to"]), dur)
            }
            "pinch" -> {
                val c = pFrom(args["c"])
                val d0 = (args["distanceFrom"] as? Number)?.toFloat() ?: 40f
                val d1 = (args["distanceTo"] as? Number)?.toFloat() ?: 80f
                val dur = (args["durationMs"] as? Number)?.toLong() ?: 80L
                svc.pinch(c, d0, d1, dur)
            }
            "key" -> svc.performGlobalActionCompat(args["key"] as? String ?: return false)
            else -> false
        }
    }

    private fun Any?.field(name: String): Any? = (this as? Map<*, *>)?.get(name)

    private fun displaySize(svc: InputAccessibilityService): android.graphics.Point {
        val metrics = DisplayMetrics()
        svc.applicationContext.getSystemService(WindowManager::class.java).defaultDisplay
            .getRealMetrics(metrics)
        return android.graphics.Point(metrics.widthPixels, metrics.heightPixels)
    }
}

class InputAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        InputBridge.service = this
    }

    override fun onDestroy() {
        InputBridge.service = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    fun tap(pt: Point): Boolean = gesture(listOf(TapStroke(pt)))

    fun longPress(pt: Point, durationMs: Long): Boolean =
        gesture(listOf(MoveStroke(pt, pt, durationMs)))

    fun swipe(from: Point, to: Point, durationMs: Long): Boolean =
        gesture(listOf(MoveStroke(from, to, durationMs)))

    fun pinch(center: Point, d0: Float, d1: Float, durationMs: Long): Boolean {
        val left = Point((center.x - d0 / 2).toInt(), center.y)
        val leftEnd = Point((center.x - d1 / 2).toInt(), center.y)
        val right = Point((center.x + d0 / 2).toInt(), center.y)
        val rightEnd = Point((center.x + d1 / 2).toInt(), center.y)
        val pathA = Path().apply { moveTo(left.x.toFloat(), left.y.toFloat()); lineTo(leftEnd.x.toFloat(), leftEnd.y.toFloat()) }
        val pathB = Path().apply { moveTo(right.x.toFloat(), right.y.toFloat()); lineTo(rightEnd.x.toFloat(), rightEnd.y.toFloat()) }
        val desc = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(pathA, 0, durationMs))
            .addStroke(GestureDescription.StrokeDescription(pathB, 0, durationMs))
            .build()
        return dispatchGesture(desc, null, handler)
    }

    fun performGlobalActionCompat(key: String): Boolean = when (key) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "power" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        "menu" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        else -> false
    }

    private sealed class GestureStroke {
        abstract fun path(): Path
        abstract val durationMs: Long
    }

    private class TapStroke(val pt: Point) : GestureStroke() {
        override val durationMs = 80L
        override fun path(): Path = Path().apply {
            moveTo(pt.x.toFloat(), pt.y.toFloat())
            lineTo(pt.x.toFloat() + 1f, pt.y.toFloat() + 1f)
        }
    }

    private class MoveStroke(
        val from: Point,
        val to: Point,
        override val durationMs: Long,
    ) : GestureStroke() {
        override fun path(): Path = Path().apply {
            moveTo(from.x.toFloat(), from.y.toFloat())
            lineTo(to.x.toFloat(), to.y.toFloat())
        }
    }

    private fun gesture(strokes: List<GestureStroke>): Boolean {
        if (strokes.isEmpty()) return false
        val builder = GestureDescription.Builder()
        for (s in strokes) {
            builder.addStroke(GestureDescription.StrokeDescription(s.path(), 0, s.durationMs))
        }
        return dispatchGesture(builder.build(), null, handler)
    }
}