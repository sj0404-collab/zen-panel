package com.aclg.helper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import org.json.JSONObject

/**
 * Фоновый сервис-мост: держит маленький WebSocket-сервер на 9100 и переводит
 * сообщения инпута (JSON) в жесты через InputBridge/AccessibilityService.
 */
class HelperService : Service() {

    private var ws: WsServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastError: String? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aclg:helper").apply { acquire() }
        startWs()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        ws?.close()
        ws = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startWs() {
        try {
            val server = WsServer(9100, this::onWsMessage) { count ->
                Log.i(TAG, "ws clients: $count")
            }
            server.start()
            ws = server
            Log.i(TAG, "WS listening on 9100")
        } catch (e: Exception) {
            lastError = e.message
            Log.e(TAG, "WS start failed", e)
        }
    }

    private fun onWsMessage(raw: String) {
        try {
            val obj = JSONObject(raw)
            val type = obj.getString("type")
            val args = obj.toSerializableArgs()
            val ok = InputBridge.inject(type, args)
            if (!ok) Log.w(TAG, "inject failed for $type (service bound? ${InputBridge.service != null})")
        } catch (e: Exception) {
            Log.w(TAG, "bad ws message: $raw", e)
        }
    }

    private fun startForegroundCompat() {
        val channelId = "aclg_bridge"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                channelId,
                "ACLG Bridge",
                NotificationManager.IMPORTANCE_LOW,
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val openIntent =
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), pendingFlags())
        val notif: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle(getString(R.string.service_name))
            .setContentText("WS-порт 9100 · включи спец. возможности для инпута")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
        startForeground(1, notif)
    }

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0

    companion object {
        private const val TAG = "ACLGHelper"
    }
}

@Suppress("UNCHECKED_CAST")
private fun JSONObject.toSerializableArgs(): Map<String, Any> {
    val out = mutableMapOf<String, Any>()
    keys().forEach { key ->
        out[key] = get(key) as Any
    }
    return out
}