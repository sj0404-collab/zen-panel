package com.aclg.helper

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val status: TextView get() = findViewById(R.id.status)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.start).setOnClickListener { startHelper() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopHelper() }
        findViewById<Button>(R.id.accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startHelper() {
        startForegroundService(Intent(this, HelperService::class.java))
    }

    private fun stopHelper() {
        stopService(Intent(this, HelperService::class.java))
    }

    private fun refresh() {
        val isRunning = isServiceRunning(HelperService::class.java)
        val accEnabled = isAccessibilityEnabled()
        status.text = buildString {
            append("Сервис: ").append(if (isRunning) "вкл" else "выкл").append('\n')
            append("Спец. возможности (инпут): ").append(if (accEnabled) "вкл" else "ВЫКЛ — без инпута\n").append('\n')
            append("WS-порт: 9100 (хосту указать ws://127.0.0.1:9100)")
        }
    }

    private fun isServiceRunning(cls: Class<*>): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.getRunningServices(100).any { it.service.className == cls.name }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, InputAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it)?.flattenToString() == expected }
    }
}