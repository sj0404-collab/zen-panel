package dev.pocketrun.agent.opencode

import java.io.File

/**
 * Text filters for the sandbox shell: everything that turns bytes into other
 * bytes. Each one reads stdin when no file is named, exactly like the real tool,
 * so they compose in a pipeline.
 *
 * These are deliberate subsets. A half-implemented `sed` that silently drops
 * half its syntax is worse than none, because the model will believe the edit
 * happened; where something is unsupported the command says so and exits
 * non-zero.
 */
internal object ShellText {

    /** Resolves a shell path to a sandboxed file, or null when it escapes. */
    typealias Resolve = (String, File) -> File?

    fun run(name: String, args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result? =
        when (name) {
            "sort" -> sort(args, dir, stdin, resolve)
            "uniq" -> uniq(args, dir, stdin, resolve)
            "cut" -> cut(args, dir, stdin, resolve)
            "tr" -> tr(args, dir, stdin, resolve)
            "sed" -> sed(args, dir, stdin, resolve)
            "awk" -> awk(args, dir, stdin, resolve)
            "nl" -> nl(args, dir, stdin, resolve)
            "tac" -> transform(args, dir, stdin, resolve) { it.reversed() }
            "rev" -> transform(args, dir, stdin, resolve) { it.reversed() }
            "fold" -> fold(args, dir, stdin, resolve)
            "expand" -> transform(args, dir, stdin, resolve, tab = 8) { it.replace("\t", " ".repeat(tab)) }
            "tee" -> tee(args, dir, stdin, resolve)
            "seq" -> seq(args)
            "printf" -> printf(args)
            "basename" -> basename(args)
            "dirname" -> dirname(args)
            "diff" -> diff(args, dir, resolve)
            "jq" -> Jq.run(args, dir, stdin, resolve)
            else -> null
        }

    // ---------------------------------------------------------------- input

    /** Reads the named files, or stdin when there are none. */
    private fun input(args: List<String>, dir: File, stdin: String, resolve: Resolve): Pair<String, Int> {
        val files = args.filter { !it.startsWith("-") }
        if (files.isEmpty()) return stdin to 0
        val out = StringBuilder()
        var exit = 0
        for (f in files) {
            val file = resolve(f, dir)
            if (file == null || !file.isFile) { exit = 1; out.append("нет такого файла: $f\n"); continue }
            if (file.length() > MiniShell.MAX_FILE) { exit = 1; out.append("файл слишком большой: $f\n"); continue }
            out.append(file.readText(Charsets.UTF_8))
        }
        return out.toString() to exit
    }

    private fun lines(text: String): List<String> = text.split("\n").let {
        if (it.isNotEmpty() && it.last().isEmpty()) it.dropLast(1) else it
    }

    private fun join(list: List<String>): String =
        if (list.isEmpty()) "" else list.joinToString("\n") + "\n"

    private inline fun transform(
        args: List<String>,
        dir: File,
        stdin: String,
        resolve: Resolve,
        tab: Int = 0,
        block: (String) -> String,
    ): MiniShell.Result {
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)
        return MiniShell.Result(0, join(lines(text).map(block)))
    }

    // ---------------------------------------------------------------- sort

    private fun sort(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val numeric = args.any { it == "-n" || it == "-g" }
        val reverse = args.any { it == "-r" }
        val unique = args.any { it == "-u" }
        val ignoreCase = args.any { it == "-f" }
        val keyField = args.firstOrNull { it.startsWith("-k") }?.removePrefix("-k")?.substringBefore(' ')
            ?.split(',')?.firstOrNull()?.trim()?.toIntOrNull()
        val sep = args.firstOrNull { it.startsWith("-t") }?.removePrefix("-t")?.takeIf { it.isNotEmpty() }

        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        fun fieldOf(line: String): String {
            if (keyField == null) return line
            val parts = if (sep != null) line.split(sep) else line.split(Regex("\\s+"))
            return parts.getOrNull(keyField - 1) ?: ""
        }

        var rows = lines(text)
        val sorted = rows.sortedWith(
            compareBy<String> { line ->
                val key = fieldOf(line)
                if (numeric) key.trim().toDoubleOrNull() ?: Double.NEGATIVE_INFINITY else key
            }.thenBy { if (ignoreCase) it.lowercase() else it },
        )
        if (reverse) sorted.reverse()
        if (unique) sorted = sorted.distinctBy { fieldOf(it) }
        rows = sorted
        return MiniShell.Result(0, join(rows))
    }

    // ---------------------------------------------------------------- uniq

    private fun uniq(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val count = args.any { it == "-c" }
        val onlyDuplicates = args.any { it == "-d" }
        val onlyUnique = args.any { it == "-u" }
        val ignoreCase = args.any { it == "-i" }
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        val out = mutableListOf<String>()
        var runLine: String? = null
        var runCount = 0
        fun flush() {
            val line = runLine ?: return
            val keep = when {
                onlyDuplicates -> runCount > 1
                onlyUnique -> runCount == 1
                else -> true
            }
            if (keep) out += if (count) "${runCount.toString().padStart(7)} $line" else line
        }
        for (line in lines(text)) {
            val comparable = if (ignoreCase) line.lowercase() else line
            if (runLine != null && comparable == (if (ignoreCase) runLine!!.lowercase() else runLine)) {
                runCount++
            } else {
                flush()
                runLine = line
                runCount = 1
            }
        }
        flush()
        return MiniShell.Result(0, join(out))
    }

    // ---------------------------------------------------------------- cut

    private fun cut(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val delim = args.firstOrNull { it.startsWith("-d") }?.removePrefix("-d")?.takeIf { it.isNotEmpty() }
            ?: args.firstOrNull { it.startsWith("--delimiter=") }?.removePrefix("--delimiter=")
        val fieldsSpec = args.firstOrNull { it.startsWith("-f") }?.removePrefix("-f")
        val charsSpec = args.firstOrNull { it.startsWith("-c") }?.removePrefix("-c")
        if (fieldsSpec == null && charsSpec == null) {
            return MiniShell.Result(1, "cut: нужен -f (поля) или -c (символы)\n")
        }
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        // A spec is a comma-separated list of positions and inclusive ranges; an
        // open-ended range ("3-") runs to the end of the line or record.
        fun positions(spec: String, size: Int): List<IntRange> =
            spec.split(',').mapNotNull { part ->
                val p = part.trim()
                if (p.isEmpty()) return@mapNotNull null
                val range = p.split('-')
                when (range.size) {
                    1 -> p.toIntOrNull()?.let { it..it }
                    else -> {
                        val from = range[0].trim().toIntOrNull() ?: return@mapNotNull null
                        val toRaw = range[1].trim()
                        if (toRaw.isEmpty()) from..Int.MAX_VALUE else {
                            val to = toRaw.toIntOrNull() ?: return@mapNotNull null
                            if (to < from) return@mapNotNull null
                            from..to
                        }
                    }
                }
            }.mapNotNull { r -> if (size == 0) null else r.intersect(1..size).takeIf { it.isNotEmpty() } }

        val out = lines(text).map { line ->
            if (fieldsSpec != null) {
                val parts = if (delim != null) line.split(delim) else line.split("\t")
                positions(fieldsSpec, parts.size)
                    .map { r -> parts.subList(r.first - 1, r.last).joinToString(delim ?: "\t") }
                    .joinToString(delim ?: "\t")
            } else {
                buildString {
                    for (r in positions(charsSpec!!, line.length)) {
                        for (i in r) append(line[i])
                    }
                }
            }
        }
        return MiniShell.Result(0, join(out))
    }

    // ---------------------------------------------------------------- tr

    private fun tr(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val sets = args.filter { !it.startsWith("-") }
        if (sets.size < 2) return MiniShell.Result(1, "tr: нужны SET1 и SET2\n")
        val delete = args.any { it.startsWith("-d") && !it.startsWith("--") }
        val squeeze = args.any { it.startsWith("-s") && !it.startsWith("--") }
        val complement = args.any { it == "-c" || it == "-C" || it == "--complement" }

        val from = expandSet(sets[0])
        val to = if (sets.size > 1) expandSet(sets[1]) else from
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        fun inSet(ch: Char): Boolean {
            val hit = from.contains(ch)
            return if (complement) !hit else hit
        }

        val out = StringBuilder()
        var previousMapped: Char? = null
        for (ch in text) {
            if (inSet(ch) && (delete || complement)) {
                // deleted, or replaced from an empty SET2
                if (complement && !delete && to.isNotEmpty()) {
                    val mapped = to[((ch.code - 32).mod(to.size))]
                    if (squeeze && mapped == previousMapped) continue
                    out.append(mapped); previousMapped = mapped
                }
                continue
            }
            val mapped = if (complement) ch else to.getOrNull(from.indexOf(ch)) ?: ch
            if (squeeze && mapped == previousMapped) continue
            out.append(mapped)
            previousMapped = mapped
        }
        return MiniShell.Result(0, out.toString())
    }

    /** Expands `a-z0-9_` and `\n`-style escapes into the characters they name. */
    private fun expandSet(spec: String): List<Char> {
        val out = mutableListOf<Char>()
        var i = 0
        while (i < spec.length) {
            val c = spec[i]
            when {
                c == '\\' && i + 1 < spec.length -> {
                    out += when (val n = spec[i + 1]) {
                        'n' -> '\n'
                        't' -> '\t'
                        'r' -> '\r'
                        '0' -> '\u0000'
                        else -> n
                    }
                    i += 2
                }
                c == '[' -> {
                    val close = spec.indexOf(']', i)
                    if (close < 0) { out += c; i++ } else {
                        out += expandSet(spec.substring(i + 1, close))
                        i = close + 1
                    }
                }
                i + 2 < spec.length && spec[i + 1] == '-' && spec[i + 2] != ']' -> {
                    for (ch in c.code..spec[i + 2].code) out += ch.toChar()
                    i += 3
                }
                else -> { out += c; i++ }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- sed

    /**
     * `sed` with the two things an agent actually uses: line addressing and
     * `s///` substitution, with `g`, `i` and `p` flags, plus `d`, `q` and `y`.
     *
     * Anything else - `h`/`H`/`x` hold space, `r`/`w` file commands, branches -
     * is refused rather than ignored.
     */
    private fun sed(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val script = args.firstOrNull { !it.startsWith("-") }
            ?: return MiniShell.Result(1, "sed: нужен скрипт, например sed 's/a/b/g' file\n")
        val quiet = args.any { it == "-n" }
        val inPlace = args.any { it == "-i" || it.startsWith("-i.") }

        val commands = parseSed(script)
            ?: return MiniShell.Result(1, "sed: неподдерживаемый скрипт «$script» (доступны s///, d, y///, p, q с адресами)\n")

        val files = args.filter { !it.startsWith("-") && it != script }
        val (text, exit) = input(files, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        var quit = false
        val out = mutableListOf<String>()
        for ((index, line) in lines(text).withIndex()) {
            val n = index + 1
            for (c in commands) {
                if (!c.addresses.any { it.matches(n) }) continue
                when (c.op) {
                    's' -> {
                        val flags = RegexOption.IGNORE_CASE.takeIf { c.flags.contains('i') }
                        val pattern = c.regex
                        line = line.replace(c.regex, c.replacement) {
                            val m = it
                            var result = c.replacement
                            c.groups.forEachIndexed { gi, g ->
                                result = result.replace("\\${gi + 1}", m.groups.getOrNull(g)?.value ?: "")
                            }
                            if (c.flags.contains('g')) {
                                if (flags != null) m.value else m.value
                            } else {
                                m.value
                            }
                        }
                    }
                    'y' -> line = translate(line, c.from, c.to)
                    'd' -> { line = null }
                    'p' -> out += line
                    'q' -> { out += line; quit = true; break }
                }
            }
            if (quit) break
            if (line != null) out += line
        }
        val rendered = if (quiet) "" else join(out)
        val result = MiniShell.Result(0, rendered)
        if (inPlace && files.isNotEmpty()) {
            for (f in files) {
                val file = resolve(f, dir) ?: continue
                runCatching { file.writeText(join(out), Charsets.UTF_8) }
            }
            return MiniShell.Result(0, "")
        }
        return result
    }

    private class SedCommand(
        val addresses: List<SedAddress>,
        val op: Char,
        val regex: Regex = Regex(""),
        val replacement: String = "",
        val flags: Set<Char> = emptySet(),
        val from: String = "",
        val to: String = "",
        val groups: List<Int> = emptyList(),
    )

    private sealed interface SedAddress {
        fun matches(line: Int): Boolean
        data class Num(val n: Int) : SedAddress { override fun matches(line: Int) = line == n }
        data class Last(val re: Regex) : SedAddress { override fun matches(line: Int) = re.containsMatchIn(line.toString()) }
    }

    private fun parseSed(script: String): List<SedCommand>? {
        val out = mutableListOf<SedCommand>()
        var i = 0
        while (i < script.length) {
            while (i < script.length && (script[i] == ' ' || script[i] == ';')) i++
            if (i >= script.length) break
            val addresses = mutableListOf<SedAddress>()
            while (i < script.length) {
                if (script[i].isDigit()) {
                    var n = 0
                    while (i < script.length && script[i].isDigit()) { n = n * 10 + (script[i] - '0'); i++ }
                    addresses += SedAddress.Num(n)
                } else if (script[i] == '$') {
                    addresses += SedAddress.Last(Regex(".*")); i++
                } else if (script[i] == '/') {
                    val close = script.indexOf('/', i + 1)
                    if (close < 0) return null
                    addresses += SedAddress.Last(Regex(script.substring(i + 1, close))); i = close + 1
                } else break
                if (i < script.length && script[i] == ',') i++ else break
            }
            if (i >= script.length) return null
            when (script[i]) {
                's' -> {
                    if (i + 1 >= script.length || script[i + 1] != '/') return null
                    val end = findDelimiter(script, i + 2, '/')
                    val body = script.substring(i + 2, end)
                    val parts = splitUnescaped(body, '/')
                    if (parts.size < 2) return null
                    val flagsPart = parts.getOrNull(2)?.trim().orEmpty()
                    if (flagsPart.any { it !in "gip" }) return null
                    out += SedCommand(
                        addresses = addresses,
                        op = 's',
                        regex = Regex(parts[0], RegexOption.IGNORE_CASE.takeIf { flagsPart.contains('i') } ?: RegexOption.NONE),
                        replacement = parts[1],
                        flags = flagsPart.toSet(),
                        groups = Regex(parts[0]).let { re -> (1..9).filter { re.groupsCount() >= it } },
                    )
                    i = end + 1
                }
                'y' -> {
                    if (i + 1 >= script.length || script[i + 1] != '/') return null
                    val end = findDelimiter(script, i + 2, '/')
                    val body = script.substring(i + 2, end)
                    val parts = splitUnescaped(body, '/')
                    if (parts.size < 2) return null
                    out += SedCommand(addresses, 'y', from = parts[0], to = parts[1])
                    i = end + 1
                }
                'd', 'p', 'q' -> { out += SedCommand(addresses, script[i]); i++ }
                else -> return null
            }
        }
        return out.ifEmpty { null }
    }

    private fun findDelimiter(s: String, from: Int, delim: Char): Int {
        var i = from
        while (i < s.length) {
            if (s[i] == '\\') { i += 2; continue }
            if (s[i] == delim) return i
            i++
        }
        return s.length
    }

    private fun splitUnescaped(s: String, delim: Char): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == '\\' && i + 1 < s.length -> { cur.append(c).append(s[i + 1]); i += 2 }
                c == delim -> { out += cur.toString(); cur.clear(); i++ }
                else -> { cur.append(c); i++ }
            }
        }
        out += cur.toString()
        return out
    }

    private fun translate(line: String, from: String, to: String): String {
        val f = expandSet(from)
        val t = expandSet(to)
        return buildString {
            for (ch in line) {
                val i = f.indexOf(ch)
                append(if (i >= 0) t.getOrNull(i) ?: ch else ch)
            }
        }
    }

    // ---------------------------------------------------------------- awk

    /**
     * A deliberately small awk: one or two `[pattern] { action }` rules with the
     * `print`, `printf` and field-reference actions, `-F` and `-v`.
     *
     * A real awk language would be a project of its own, and a partial one that
     * accepts a script and quietly does something else is a trap.
     */
    private fun awk(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        var fieldSep: String? = null
        var begin: String? = null
        var rest = args.toMutableList()
        while (rest.isNotEmpty()) {
            when (val a = rest.first()) {
                "-F" -> { fieldSep = rest.getOrNull(1); rest = rest.drop(2).toMutableList() }
                "-v" -> { begin = rest.getOrNull(1); rest = rest.drop(2).toMutableList() }
                else -> if (a.startsWith("-F")) { fieldSep = a.substring(2); rest = rest.drop(1).toMutableList() }
                else -> break
            }
        }
        if (rest.isEmpty()) return MiniShell.Result(1, "awk: нужен скрипт\n")
        val script = rest.first()
        rest = rest.drop(1)

        val rules = parseAwk(script) ?: return MiniShell.Result(1, "awk: поддержаны только правила [шаблон]{print/printf}\n")
        val (text, exit) = input(rest, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)

        val vars = HashMap<String, String>()
        begin?.let { stmt ->
            val m = Regex("""^\s*([A-Za-z_][\w]*)\s*=\s*(.+?)\s*$""").find(stmt)
            if (m != null) vars[m.groupValues[1]] = m.groupValues[2].trim().trim('"', '\'')
        }
        vars["FS"] = fieldSep ?: " "
        vars["OFS"] = " "

        val out = StringBuilder()
        var nr = 0
        for (line in lines(text)) {
            nr++
            val fields = splitFields(line, vars["FS"]!!)
            fun field(i: String): String = when {
                i == "NF" -> fields.size.toString()
                i == "NR" -> nr.toString()
                i.startsWith("$") -> {
                    val n = i.drop(1).toIntOrNull() ?: 0
                    if (n == 0) line else fields.getOrNull(n - 1) ?: ""
                }
                else -> vars[i] ?: ""
            }
            for (rule in rules) {
                if (!awkMatches(rule.pattern, line, vars)) continue
                val rendered = when (rule.action) {
                    null -> line
                    else -> renderAwk(rule.action, field, vars["OFS"] ?: " ")
                }
                out.append(rendered).append('\n')
            }
        }
        return MiniShell.Result(0, out.toString())
    }

    private class AwkRule(val pattern: String?, val action: String?)

    private fun parseAwk(script: String): List<AwkRule>? {
        val rules = mutableListOf<AwkRule>()
        var i = 0
        while (i < script.length) {
            while (i < script.length && script[i].isWhitespace()) i++
            if (i >= script.length) break
            if (script[i] == '{') {
                val end = script.indexOf('}', i)
                if (end < 0) return null
                val action = script.substring(i + 1, end).trim()
                if (!action.startsWith("print") && !action.startsWith("printf")) return null
                rules += AwkRule(null, action)
                i = end + 1
            } else {
                var pattern = StringBuilder()
                while (i < script.length && script[i] != '{' && script[i] != '\n') { pattern.append(script[i]); i++ }
                while (i < script.length && script[i] != '{') i++
                if (i >= script.length) return null
                val end = script.indexOf('}', i)
                if (end < 0) return null
                val action = script.substring(i + 1, end).trim()
                if (!action.startsWith("print") && !action.startsWith("printf")) return null
                rules += AwkRule(pattern.toString().trim(), action)
                i = end + 1
            }
        }
        return rules.ifEmpty { null }
    }

    private fun awkMatches(pattern: String?, line: String, vars: Map<String, String>): Boolean {
        if (pattern.isNullOrEmpty()) return true
        var resolved = pattern
        for ((k, v) in vars) resolved = resolved.replace("\$$k", v)
        if (resolved.startsWith("/") && resolved.endsWith("/") && resolved.length > 1) {
            return runCatching { Regex(resolved.substring(1, resolved.length - 1)).containsMatchIn(line) }
                .getOrDefault(false)
        }
        val m = Regex("""^\$?\s*([A-Za-z_][\w]*)\s*([=!<>]=?)\s*["']?([^"']*)["']?$""").find(resolved)
        if (m != null) {
            val actual = vars[m.groupValues[1]] ?: ""
            val want = m.groupValues[3].trim()
            return when (m.groupValues[2]) {
                "=" -> actual == want
                "==" -> actual == want
                "!=" -> actual != want
                else -> false
            }
        }
        return runCatching { Regex(resolved).containsMatchIn(line) }.getOrDefault(false)
    }

    private fun splitFields(line: String, sep: String): List<String> =
        if (sep == " ") line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        else if (sep == "\\t") line.split("\t")
        else line.split(sep)

    /**
     * Renders `print ...` / `printf ...`.
     *
     * The argument list is a comma-separated sequence of field references ($1,
     * $NF), quoted literals and bare words; OFS is a space unless the action
     * sets it. Anything with an operator is refused by [parseAwk] rather than
     * silently printed.
     */
    private fun renderAwk(action: String, field: (String) -> String, ofs: String): String {
        val isPrintf = action.startsWith("printf")
        val body = action.substring(if (isPrintf) 6 else 5).trim()
        if (body.isEmpty()) return field("$0")
        val out = StringBuilder()
        body.split(',').forEachIndexed { index, raw ->
            val token = raw.trim()
            val value = when {
                token.length >= 2 && token.first() == '"' && token.last() == '"' ->
                    token.substring(1, token.length - 1)
                token.startsWith("\$") -> field(token)
                token.isEmpty() -> ""
                else -> field("\$$token")
            }
            out.append(value)
            if (index < body.split(',').lastIndex) out.append(ofs)
        }
        return if (isPrintf) out.toString() else out.toString()
    }

    // ---------------------------------------------------------------- nl / tee / fold

    /** POSIX nl numbers non-empty lines; -ba numbers blank ones too. */
    private fun nl(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val numberBlanks = args.any { it == "-ba" }
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)
        var n = 0
        return MiniShell.Result(
            0,
            join(lines(text).map { line ->
                if (line.isEmpty() && !numberBlanks) line
                else { n++; n.toString().padStart(6) + "\t" + line }
            }),
        )
    }

    private fun tee(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val append = args.any { it == "-a" }
        for (target in args.filter { !it.startsWith("-") }) {
            val f = resolve(target, dir) ?: continue
            runCatching {
                f.parentFile?.mkdirs()
                if (append) f.appendText(stdin, Charsets.UTF_8) else f.writeText(stdin, Charsets.UTF_8)
            }
        }
        return MiniShell.Result(0, stdin)
    }

    private fun fold(args: List<String>, dir: File, stdin: String, resolve: Resolve): MiniShell.Result {
        val width = args.firstOrNull { it.startsWith("-w") }?.removePrefix("-w")?.toIntOrNull() ?: 80
        val (text, exit) = input(args, dir, stdin, resolve)
        if (exit != 0) return MiniShell.Result(exit, text)
        val out = StringBuilder()
        for (line in lines(text)) {
            var i = 0
            if (line.isEmpty()) { out.append('\n'); continue }
            while (i < line.length) {
                out.append(line, i, minOf(i + width, line.length)).append('\n')
                i += width
            }
        }
        return MiniShell.Result(0, out.toString())
    }

    // ---------------------------------------------------------------- trivial

    private fun seq(args: List<String>): MiniShell.Result {
        val nums = args.filter { !it.startsWith("-") }
        val sep = args.firstOrNull { it.startsWith("-s") }?.removePrefix("-s")
        val (first, incr, last) = when (nums.size) {
            1 -> listOf(1L, 1L, nums[0].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n"))
            2 -> {
                val a = nums[0].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n")
                val b = nums[1].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n")
                listOf(a, 1L, b)
            }
            3 -> listOf(
                nums[0].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n"),
                nums[1].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n"),
                nums[2].toLongOrNull() ?: return MiniShell.Result(1, "seq: нужно число\n"),
            )
            else -> return MiniShell.Result(1, "seq: нужно от одного до трёх чисел\n")
        }
        if (incr == 0L) return MiniShell.Result(1, "seq: шаг не может быть нулём\n")
        val out = StringBuilder()
        var i = first
        var guard = 0
        while ((incr > 0 && i <= last) || (incr < 0 && i >= last)) {
            if (guard++ > 1_000_000) break
            out.append(i)
            if (sep != null) out.append(sep) else out.append('\n')
            i += incr
        }
        return MiniShell.Result(0, out.toString())
    }

    private fun printf(args: List<String>): MiniShell.Result {
        if (args.isEmpty()) return MiniShell.Result(0, "")
        val format = args.first()
        val values = args.drop(1)
        var argIndex = 0
        val out = buildString {
            var i = 0
            while (i < format.length) {
                val c = format[i]
                if (c == '\\') {
                    append(
                        when (val n = format.getOrNull(i + 1)) {
                            'n' -> '\n'
                            't' -> '\t'
                            'r' -> '\r'
                            '\\' -> '\\'
                            '0' -> '\u0000'
                            null -> { append(c); i++; continue }
                            else -> n
                        },
                    )
                    i += 2
                    continue
                }
                if (c == '%' && format.getOrNull(i + 1) == '%') { append('%'); i += 2; continue }
                if (c == '%') {
                    val specEnd = generateSequence(i + 1, format) { it.isLetterOrDigit() || it in ".-+ #0" }
                        .let { i + 1 + it }
                    val spec = format.substring(i + 1, specEnd)
                    val value = values.getOrNull(argIndex++)
                    append(formatValue(spec, value))
                    i = specEnd
                    continue
                }
                append(c)
                i++
            }
        }
        return MiniShell.Result(0, out.toString())
    }

    private fun formatValue(spec: String, value: String?): String {
        if (value == null) return ""
        val letter = spec.lastOrNull() ?: return value
        val body = spec.dropLast(1)
        val width = Regex("(\\d+)\$").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val leftAlign = body.contains('-')
        val zeroPad = body.startsWith("0") || body.contains("0")
        val precision = Regex("\\.(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull()
        var text = when (letter) {
            'd', 'i' -> {
                val n = value.trim().toDoubleOrNull()?.toLong() ?: return value
                val s = kotlin.math.abs(n).toString()
                if (n < 0) "-$s" else s
            }
            'f', 'F' -> {
                val n = value.trim().toDoubleOrNull() ?: return value
                String.format(Locale.US, "%.${precision ?: 6}f", n)
            }
            'x' -> (value.trim().toLongOrNull() ?: return value).toString(16)
            'X' -> (value.trim().toLongOrNull() ?: return value).toString(16).uppercase()
            'o' -> (value.trim().toLongOrNull() ?: return value).toString(8)
            'e', 'g' -> value.trim()
            else -> value
        }
        if (precision != null && letter == 's') text = text.take(precision)
        if (width > text.length) {
            val pad = if (leftAlign) " " else if (zeroPad && letter != 's') "0" else " "
            val sign = if (!leftAlign && zeroPad && text.startsWith("-")) {
                text = text.drop(1); "-"
            } else ""
            text = sign + pad.repeat(width - text.length) + text
        }
        return text
    }

    private fun basename(args: List<String>): MiniShell.Result {
        val path = args.firstOrNull() ?: return MiniShell.Result(1, "basename: нужен путь\n")
        val suffix = args.getOrNull(1)
        var name = path.trimEnd('/').substringAfterLast('/').ifEmpty { "/" }
        if (suffix != null && name.length > suffix.length && name.endsWith(suffix)) {
            name = name.dropLast(suffix.length)
        }
        return MiniShell.Result(0, "$name\n")
    }

    private fun dirname(args: List<String>): MiniShell.Result {
        val path = args.firstOrNull() ?: return MiniShell.Result(1, "dirname: нужен путь\n")
        val trimmed = path.trimEnd('/')
        if (!trimmed.contains('/')) return MiniShell.Result(0, ".\n")
        if (trimmed == "/" || trimmed.count { it == '/' } == 0) return MiniShell.Result(0, "/\n")
        return MiniShell.Result(0, trimmed.substringBeforeLast('/').ifEmpty { "/" } + "\n")
    }

    // ---------------------------------------------------------------- xargs / diff

    private fun diff(args: List<String>, dir: File, resolve: Resolve): MiniShell.Result {
        val files = args.filter { !it.startsWith("-") }
        if (files.size != 2) return MiniShell.Result(1, "diff: нужны два файла\n")
        val brief = args.any { it == "-q" }
        val a = resolve(files[0], dir)?.takeIf { it.isFile }
            ?: return MiniShell.Result(2, "diff: ${files[0]}: нет такого файла\n")
        val b = resolve(files[1], dir)?.takeIf { it.isFile }
            ?: return MiniShell.Result(2, "diff: ${files[1]}: нет такого файла\n")
        val left = a.readLines()
        val right = b.readLines()
        if (left == right) return MiniShell.Result(0, "")
        if (brief) return MiniShell.Result(1, "Файлы ${files[0]} и ${files[1]} различаются\n")
        val out = StringBuilder("--- ${files[0]}\n+++ ${files[1]}\n")
        var i = 0
        while (i < maxOf(left.size, right.size)) {
            val l = left.getOrNull(i)
            val r = right.getOrNull(i)
            when {
                l == r -> Unit
                l == null -> out.append("+${r}\n")
                r == null -> out.append("-${l}\n")
                else -> { out.append("-${l}\n+${r}\n") }
            }
            i++
        }
        return MiniShell.Result(1, out.toString())
    }
}
