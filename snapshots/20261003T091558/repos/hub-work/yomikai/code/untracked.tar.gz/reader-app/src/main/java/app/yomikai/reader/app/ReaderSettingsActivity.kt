package app.yomikai.reader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.blue
import androidx.compose.ui.graphics.green
import androidx.compose.ui.graphics.red
import eu.kanade.tachiyomi.ui.reader.setting.ReaderOrientation
import eu.kanade.tachiyomi.ui.reader.setting.ReaderPreferences
import eu.kanade.tachiyomi.ui.reader.setting.ReadingMode
import tachiyomi.core.common.preference.getAndSet
import tachiyomi.i18n.MR
import tachiyomi.presentation.core.components.CheckboxItem
import tachiyomi.presentation.core.components.HeadingItem
import tachiyomi.presentation.core.components.SettingsChipRow
import tachiyomi.presentation.core.components.SliderItem
import tachiyomi.presentation.core.i18n.stringResource
import tachiyomi.presentation.core.util.collectAsState
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Настройки читалки.
 *
 * Экран собран прямо против [ReaderPreferences], без общего списка настроек
 * приложения. Пока настройки жили в общем экране, новый пункт требовал
 * правки в трёх местах сразу (объявление, список всех настроек, UI), а из
 * самой читалки их нельзя было ни посмотреть, ни поменять. Теперь
 * настройки принадлежат приложению читалки и правятся в нём же.
 */
class ReaderSettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ReaderSettingsScreen()
            }
        }
    }
}

@Composable
fun ReaderSettingsScreen(
    preferences: ReaderPreferences = remember { Injekt.get() },
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(MR.strings.pref_category_reader)) },
                actions = {
                    IconButton(onClick = { preferences.persistCurrent() }) {
                        Icon(
                            imageVector = Icons.Outlined.Save,
                            contentDescription = stringResource(MR.strings.reader_constructor_save),
                        )
                    }
                    IconButton(onClick = { preferences.resetToDefaults() }) {
                        Icon(
                            imageVector = Icons.Outlined.Restore,
                            contentDescription = stringResource(MR.strings.reader_constructor_defaults),
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
        ) {
            ReadingModeGroup(preferences, Modifier.padding(padding))
        }
    }
}

@Composable
private fun ReadingModeGroup(preferences: ReaderPreferences, modifier: Modifier = Modifier) {
    val mode by preferences.defaultReadingMode.collectAsState()
    val orientation by preferences.defaultOrientationType.collectAsState()

    Column(modifier) {
        SettingsChipRow(MR.strings.pref_viewer_type) {
            ReadingMode.entries.drop(1).forEach { entry ->
                FilterChip(
                    selected = mode == entry.flagValue,
                    onClick = { preferences.defaultReadingMode.set(entry.flagValue) },
                    label = { Text(stringResource(entry.stringRes)) },
                )
            }
        }

        SettingsChipRow(MR.strings.pref_rotation_type) {
            ReaderOrientation.entries.drop(1).forEach { entry ->
                FilterChip(
                    selected = orientation == entry.flagValue,
                    onClick = { preferences.defaultOrientationType.set(entry.flagValue) },
                    label = { Text(stringResource(entry.stringRes)) },
                )
            }
        }

        DisplayGroup(preferences)
        EInkGroup(preferences)
        ReadingGroup(preferences)
        ColorFilterGroup(preferences)
        ControlsGroup(preferences)
    }
}

@Composable
private fun DisplayGroup(preferences: ReaderPreferences) {
    val theme by preferences.readerTheme.collectAsState()

    HeadingItem(MR.strings.pref_category_display)
    CheckboxItem(stringResource(MR.strings.pref_fullscreen), preferences.fullscreen)
    CheckboxItem(stringResource(MR.strings.pref_keep_screen_on), preferences.keepScreenOn)
    CheckboxItem(stringResource(MR.strings.pref_show_page_number), preferences.showPageNumber)
    CheckboxItem(stringResource(MR.strings.pref_page_transitions), preferences.pageTransitions)

    val themes = listOf(
        MR.strings.black_background to 1,
        MR.strings.gray_background to 2,
        MR.strings.white_background to 0,
        MR.strings.automatic_background to 3,
    )
    SettingsChipRow(MR.strings.pref_reader_theme) {
        themes.forEach { (labelRes, value) ->
            FilterChip(
                selected = theme == value,
                onClick = { preferences.readerTheme.set(value) },
                label = { Text(stringResource(labelRes)) },
            )
        }
    }
}

@Composable
private fun EInkGroup(preferences: ReaderPreferences) {
    val duration by preferences.flashDurationMillis.collectAsState()
    val interval by preferences.flashPageInterval.collectAsState()
    val flashColor by preferences.flashColor.collectAsState()

    HeadingItem("E-Ink")
    CheckboxItem(stringResource(MR.strings.pref_flash_page), preferences.flashOnPageChange)

    SliderItem(
        value = duration / ReaderPreferences.MILLI_CONVERSION,
        valueRange = 1..15,
        label = stringResource(MR.strings.pref_flash_duration),
        onChange = { preferences.flashDurationMillis.set(it * ReaderPreferences.MILLI_CONVERSION) },
        valueString = stringResource(MR.strings.pref_flash_duration_summary, duration),
    )
    SliderItem(
        value = interval,
        valueRange = 1..10,
        label = stringResource(MR.strings.pref_flash_page_interval),
        onChange = { preferences.flashPageInterval.set(it) },
    )

    val colors = listOf(
        MR.strings.pref_flash_style_black to ReaderPreferences.FlashColor.BLACK,
        MR.strings.pref_flash_style_white to ReaderPreferences.FlashColor.WHITE,
        MR.strings.pref_flash_style_white_black to ReaderPreferences.FlashColor.WHITE_BLACK,
    )
    SettingsChipRow(MR.strings.pref_flash_with) {
        colors.forEach { (labelRes, value) ->
            FilterChip(
                selected = flashColor == value,
                onClick = { preferences.flashColor.set(value) },
                label = { Text(stringResource(labelRes)) },
            )
        }
    }
}

@Composable
private fun ReadingGroup(preferences: ReaderPreferences) {
    val speed by preferences.doubleTapAnimSpeed.collectAsState()

    HeadingItem(MR.strings.pref_category_reading)
    CheckboxItem(stringResource(MR.strings.pref_crop_borders), preferences.cropBorders)
    CheckboxItem(stringResource(MR.strings.pref_navigate_pan), preferences.navigateToPan)
    CheckboxItem(stringResource(MR.strings.pref_panel_navigation), preferences.panelNavigation)
    CheckboxItem(stringResource(MR.strings.pref_landscape_zoom), preferences.landscapeZoom)
    CheckboxItem(stringResource(MR.strings.pref_skip_read_chapters), preferences.skipRead)
    CheckboxItem(stringResource(MR.strings.pref_skip_filtered_chapters), preferences.skipFiltered)
    CheckboxItem(stringResource(MR.strings.pref_skip_dupe_chapters), preferences.skipDupe)
    CheckboxItem(stringResource(MR.strings.pref_crop_borders_webtoon), preferences.cropBordersWebtoon)

    val sidePadding by preferences.webtoonSidePadding.collectAsState()
    SliderItem(
        value = sidePadding,
        valueRange = ReaderPreferences.WEBTOON_PADDING_MIN..ReaderPreferences.WEBTOON_PADDING_MAX,
        label = stringResource(MR.strings.pref_webtoon_side_padding),
        onChange = { preferences.webtoonSidePadding.set(it) },
    )

    val speeds = listOf(
        MR.strings.double_tap_anim_speed_0 to 1,
        MR.strings.double_tap_anim_speed_fast to 250,
        MR.strings.double_tap_anim_speed_normal to 500,
    )
    SettingsChipRow(MR.strings.pref_double_tap_anim_speed) {
        speeds.forEach { (labelRes, value) ->
            FilterChip(
                selected = speed == value,
                onClick = { preferences.doubleTapAnimSpeed.set(value) },
                label = { Text(stringResource(labelRes)) },
            )
        }
    }
}

@Composable
private fun ColorFilterGroup(preferences: ReaderPreferences) {
    val brightness by preferences.customBrightnessValue.collectAsState()
    val filterValue by preferences.colorFilterValue.collectAsState()
    val filterMode by preferences.colorFilterMode.collectAsState()

    HeadingItem(MR.strings.pref_category_color_filter)
    CheckboxItem(stringResource(MR.strings.pref_custom_brightness), preferences.customBrightness)
    SliderItem(
        value = brightness,
        valueRange = -75..100,
        label = stringResource(MR.strings.pref_custom_brightness),
        onChange = { preferences.customBrightnessValue.set(it) },
    )

    CheckboxItem(stringResource(MR.strings.pref_custom_color_filter), preferences.colorFilter)
    SliderItem(
        value = filterValue.red,
        valueRange = 0..255,
        label = stringResource(MR.strings.color_filter_r_value),
        onChange = { newValue ->
            preferences.colorFilterValue.getAndSet { packColorChannel(it, newValue, RED_MASK, 16) }
        },
    )
    SliderItem(
        value = filterValue.green,
        valueRange = 0..255,
        label = stringResource(MR.strings.color_filter_g_value),
        onChange = { newValue ->
            preferences.colorFilterValue.getAndSet { packColorChannel(it, newValue, GREEN_MASK, 8) }
        },
    )
    SliderItem(
        value = filterValue.blue,
        valueRange = 0..255,
        label = stringResource(MR.strings.color_filter_b_value),
        onChange = { newValue ->
            preferences.colorFilterValue.getAndSet { packColorChannel(it, newValue, BLUE_MASK, 0) }
        },
    )

    val modes = ReaderPreferences.ColorFilterMode.mapIndexed { index, entry -> index to entry.first }
    SettingsChipRow(MR.strings.pref_color_filter_mode) {
        modes.forEach { (index, labelRes) ->
            FilterChip(
                selected = filterMode == index,
                onClick = { preferences.colorFilterMode.set(index) },
                label = { Text(stringResource(labelRes)) },
            )
        }
    }

    CheckboxItem(stringResource(MR.strings.pref_grayscale), preferences.grayscale)
    CheckboxItem(stringResource(MR.strings.pref_inverted_colors), preferences.invertedColors)
}

@Composable
private fun ControlsGroup(preferences: ReaderPreferences) {
    HeadingItem(MR.strings.pref_category_general)
    CheckboxItem(stringResource(MR.strings.pref_read_with_long_tap), preferences.readWithLongTap)
    CheckboxItem(stringResource(MR.strings.pref_long_tap_ocr), preferences.longTapOcr)
    CheckboxItem(stringResource(MR.strings.pref_read_with_volume_keys), preferences.readWithVolumeKeys)
    CheckboxItem(
        stringResource(MR.strings.pref_read_with_volume_keys_inverted),
        preferences.readWithVolumeKeysInverted,
    )
    val tappingInverted by preferences.pagerNavInverted.collectAsState()
    CheckboxItem(
        label = stringResource(MR.strings.pref_read_with_tapping_inverted),
        checked = tappingInverted != ReaderPreferences.TappingInvertMode.NONE,
        onClick = {
            preferences.pagerNavInverted.set(
                if (tappingInverted == ReaderPreferences.TappingInvertMode.NONE) {
                    ReaderPreferences.TappingInvertMode.BOTH
                } else {
                    ReaderPreferences.TappingInvertMode.NONE
                },
            )
        },
    )
    CheckboxItem(stringResource(MR.strings.pref_show_reading_mode), preferences.showReadingMode)
    CheckboxItem(
        stringResource(MR.strings.pref_show_navigation_mode),
        preferences.showNavigationOverlayOnStart,
    )
}

/** Значение фильтра цвета хранится упакованным ARGB, поэтому каналы правятся по маске. */
private fun packColorChannel(currentColor: Int, channel: Int, mask: Long, bitShift: Int): Int {
    return (channel shl bitShift) or (currentColor and mask.inv().toInt())
}

private const val RED_MASK: Long = 0x00FF0000
private const val GREEN_MASK: Long = 0x0000FF00
private const val BLUE_MASK: Long = 0x000000FF
