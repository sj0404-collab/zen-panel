package app.yomikai.reader.app

import android.app.Application
import eu.kanade.tachiyomi.ui.reader.setting.ReaderPreferences
import tachiyomi.core.common.preference.AndroidPreferenceStore
import tachiyomi.core.common.preference.PreferenceStore
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.InjektModule
import uy.kohesive.injekt.api.InjektRegistrar
import uy.kohesive.injekt.api.addSingletonFactory
import uy.kohesive.injekt.api.get

/**
 * Приложение читалки.
 *
 * Пока здесь только настройки: перенос самой читалки из Yomikai идёт
 * по шагам, и настройки переехали первыми, потому что именно их правка
 * была самой неудобной — три разных экрана в трёх разных фреймворках.
 *
 * [ReaderPreferences] регистрируется на собственном хранилище этого
 * приложения: настройки читалки принадлежат читалке, и Yomikai к ним
 * отношения не имеет.
 */
class ReaderApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Injekt.importModule(ReaderModule(this))
    }
}

class ReaderModule(private val app: Application) : InjektModule {

    override fun InjektRegistrar.registerInjectables() {
        addSingletonFactory<PreferenceStore> {
            AndroidPreferenceStore(app)
        }
        addSingletonFactory {
            ReaderPreferences(get())
        }
    }
}
