package eu.kanade.tachiyomi.ui.reader.setting

import eu.kanade.tachiyomi.ui.reader.ReaderActivity
import eu.kanade.tachiyomi.ui.reader.viewer.Viewer
import eu.kanade.tachiyomi.ui.reader.viewer.pager.L2RPagerViewer
import eu.kanade.tachiyomi.ui.reader.viewer.pager.R2LPagerViewer
import eu.kanade.tachiyomi.ui.reader.viewer.pager.VerticalPagerViewer
import eu.kanade.tachiyomi.ui.reader.viewer.webtoon.WebtoonViewer

/**
 * Создание зрителя по режиму чтения.
 *
 * Живёт в приложении, а не рядом с [ReadingMode], потому что зрители — это код
 * читалки: держать его в общем модуле настроек значило бы, что модуль
 * настроек знает про Activity и её подклассы. Настройки читалки должны уехать
 * в отдельное приложение раньше, чем это станет проблемой, а зависимость
 * должна идти «настройки → движок», а не наоборот.
 *
 * Когда зрители переедут вместе с читалкой, эта функция переедет туда же.
 */
fun ReadingMode.toViewer(activity: ReaderActivity): Viewer {
    return when (this) {
        ReadingMode.LEFT_TO_RIGHT -> L2RPagerViewer(activity)
        ReadingMode.RIGHT_TO_LEFT -> R2LPagerViewer(activity)
        ReadingMode.VERTICAL -> VerticalPagerViewer(activity)
        ReadingMode.WEBTOON -> WebtoonViewer(activity)
        ReadingMode.CONTINUOUS_VERTICAL -> WebtoonViewer(activity, isContinuous = false)
        ReadingMode.DEFAULT -> throw IllegalStateException("Preference value must be resolved: $this")
    }
}
