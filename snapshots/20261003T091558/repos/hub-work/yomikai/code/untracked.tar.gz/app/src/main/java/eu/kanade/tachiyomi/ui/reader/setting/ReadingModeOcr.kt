package eu.kanade.tachiyomi.ui.reader.setting

import mihon.data.ocr.OcrViewerHint

/**
 * Режим чтения, который предписывает пресет типа контента OCR.
 *
 * `null` означает «пресет не трогает вьюер» ([OcrViewerHint.KEEP], то есть
 * BALANCED): выбор пользователя остаётся за ним.
 *
 * Живёт здесь, а не в [ReadingMode], потому что [OcrViewerHint] — это тип из
 * `:data`, а модуль настроек читалки от слоя данных свободен: иначе перенос
 * настроек в отдельное приложение тащил бы за собой OCR-движки.
 */
fun ReadingMode.Companion.fromOcrHint(hint: OcrViewerHint): ReadingMode? = when (hint) {
    OcrViewerHint.KEEP -> null
    OcrViewerHint.PAGER_RTL -> ReadingMode.RIGHT_TO_LEFT
    OcrViewerHint.PAGER_LTR -> ReadingMode.LEFT_TO_RIGHT
    OcrViewerHint.WEBTOON -> ReadingMode.WEBTOON
}
