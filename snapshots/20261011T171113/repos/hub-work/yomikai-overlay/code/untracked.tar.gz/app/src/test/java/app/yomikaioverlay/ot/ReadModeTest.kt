package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadModeTest {

    @Test
    fun defaultIsNormal() {
        assertEquals(ReadMode.NORMAL, ReadMode.normalize(null))
        assertEquals(ReadMode.NORMAL, ReadMode.normalize("что-то"))
    }

    @Test
    fun cycleCoversAllModesAndWraps() {
        var m: String = ReadMode.DEFAULT
        val seen = ArrayList<String>()
        seen.add(m)
        repeat(ReadMode.MODES.size - 1) {
            m = ReadMode.next(m)
            seen.add(m)
        }
        // За size-1 шагов посещены все режимы ровно по одному разу.
        assertEquals(ReadMode.MODES.toSet(), seen.toSet())
        assertEquals(ReadMode.MODES.size, seen.size)
        // Ещё один шаг — полный круг, возвращаемся к исходному.
        assertEquals(ReadMode.DEFAULT, ReadMode.next(m))
    }

    @Test
    fun everyModeHasLabelAndIcon() {
        for (m in ReadMode.MODES) {
            assertTrue(ReadMode.label(m).isNotBlank())
            assertTrue(ReadMode.icon(m).isNotBlank())
        }
    }

    @Test
    fun verticalModesUseVerticalOrder() {
        assertEquals(ReadingOrder.VERTICAL, ReadMode.order(ReadMode.MANGA))
        assertEquals(ReadingOrder.VERTICAL, ReadMode.order(ReadMode.MANHUA))
        assertEquals(ReadingOrder.BOTTOM_UP, ReadMode.order(ReadMode.MANHWA))
        assertEquals(ReadingOrder.LTR, ReadMode.order(ReadMode.COMIC))
        assertEquals(ReadingOrder.AUTO, ReadMode.order(ReadMode.NORMAL))
    }

    @Test
    fun translationOnlyChangedByExplicitModes() {
        assertEquals(true, ReadMode.translate(ReadMode.TR_ON))
        assertEquals(false, ReadMode.translate(ReadMode.TR_OFF))
        assertEquals(false, ReadMode.translate(ReadMode.LIVE))
        assertEquals(false, ReadMode.translate(ReadMode.GAME_SUB))
        assertNull(ReadMode.translate(ReadMode.MANGA))
        assertNull(ReadMode.translate(ReadMode.NORMAL))
    }

    @Test
    fun liveAndGameSubtitlesDoNotAutoScroll() {
        assertTrue(!ReadMode.autoScroll(ReadMode.LIVE))
        assertTrue(!ReadMode.autoScroll(ReadMode.GAME_SUB))
        assertTrue(ReadMode.autoScroll(ReadMode.MANGA))
        assertTrue(ReadMode.autoScroll(ReadMode.NORMAL))
    }

    @Test
    fun mangaModesUseFullRegion() {
        assertEquals(Region.PRESET_FULL, ReadMode.regionPreset(ReadMode.MANGA))
        assertEquals(Region.PRESET_FULL, ReadMode.regionPreset(ReadMode.COMIC))
        assertEquals(Region.PRESET_BOTTOM, ReadMode.regionPreset(ReadMode.LIVE))
    }
}