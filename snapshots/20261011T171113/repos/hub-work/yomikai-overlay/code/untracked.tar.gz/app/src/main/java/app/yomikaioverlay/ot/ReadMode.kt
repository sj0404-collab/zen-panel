package app.yomikaioverlay.ot

/**
 * Режимы чтения: один тап — и движок, перевод, порядок блоков и рамка
 * настроены под сценарий (лайв, обычный, перевод, субтитры, манга…).
 *
 * Чистая логика без Android-зависимостей — покрыта юнит-тестами.
 */
object ReadMode {
    const val LIVE = "live"          // Лайв: озвучка текущего экрана, без прокрутки
    const val NORMAL = "normal"      // Обычный: скан + озвучка + автопрокрутка
    const val TR_ON = "tr_on"        // С переводом
    const val TR_OFF = "tr_off"      // Без перевода
    const val GAME_SUB = "game_sub"  // Субтитры игр: нижняя полоса, без перевода
    const val MANGA = "manga"        // Манга: вертикальные колонки справа налево
    const val COMIC = "comic"        // Комикс: страницы слева направо
    const val MANHWA = "manhwa"      // Манхва (вебтун): лента снизу вверх
    const val MANHUA = "manhua"      // Маньхуа: вертикальные колонки справа налево

    val MODES = listOf(
        LIVE, NORMAL, TR_ON, TR_OFF, GAME_SUB, MANGA, COMIC, MANHWA, MANHUA,
    )
    const val DEFAULT = NORMAL

    fun normalize(mode: String?): String = if (mode != null && mode in MODES) mode else DEFAULT

    fun next(mode: String?): String {
        val list = MODES
        return list[(list.indexOf(normalize(mode)) + 1) % list.size]
    }

    fun label(mode: String?): String = when (normalize(mode)) {
        LIVE -> "Лайв"
        NORMAL -> "Обычный"
        TR_ON -> "С переводом"
        TR_OFF -> "Без перевода"
        GAME_SUB -> "Субтитры игр"
        MANGA -> "Манга"
        COMIC -> "Комикс"
        MANHWA -> "Манхва"
        MANHUA -> "Маньхуа"
        else -> "Обычный"
    }

    /** Иконка-эмодзи для плитки режима. */
    fun icon(mode: String?): String = when (normalize(mode)) {
        LIVE -> "◉"
        NORMAL -> "▤"
        TR_ON -> "⇄"
        TR_OFF -> "⇄"
        GAME_SUB -> "🎮"
        MANGA, MANHUA -> "📖"
        COMIC -> "📄"
        MANHWA -> "📜"
        else -> "▤"
    }

    /** Порядок блоков 1..N для режима. */
    fun order(mode: String?): String = when (normalize(mode)) {
        MANGA, MANHUA -> ReadingOrder.VERTICAL
        MANHWA -> ReadingOrder.BOTTOM_UP
        COMIC -> ReadingOrder.LTR
        GAME_SUB -> ReadingOrder.AUTO
        else -> ReadingOrder.AUTO
    }

    /**
     * Включать ли перевод. `null` — режим не трогает пользовательскую настройку
     * (так переключение «Манга» не затирает выбранный ранее перевод).
     */
    fun translate(mode: String?): Boolean? = when (normalize(mode)) {
        TR_ON -> true
        TR_OFF, LIVE, GAME_SUB -> false
        else -> null
    }

    /** Листать страницы автоматически. */
    fun autoScroll(mode: String?): Boolean = when (normalize(mode)) {
        LIVE, GAME_SUB -> false
        else -> true
    }

    /** Рамка OCR по умолчанию для режима. */
    fun regionPreset(mode: String?): String = when (normalize(mode)) {
        MANGA, COMIC, MANHWA, MANHUA -> Region.PRESET_FULL
        else -> Region.PRESET_BOTTOM
    }
}