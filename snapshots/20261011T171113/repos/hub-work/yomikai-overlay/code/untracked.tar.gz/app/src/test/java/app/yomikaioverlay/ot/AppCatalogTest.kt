package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Test

class AppCatalogTest {

    private fun apps() = listOf(
        AppCatalog.App("com.a.reader", "Манга Редер"),
        AppCatalog.App("com.b.games", "Игры"),
        AppCatalog.App("com.c.browser", "Браузер"),
    )

    @Test
    fun emptyQueryKeepsEverything() {
        assertEquals(3, AppCatalog.filter(apps(), null).size)
        assertEquals(3, AppCatalog.filter(apps(), "").size)
        assertEquals(3, AppCatalog.filter(apps(), "   ").size)
    }

    @Test
    fun matchesLabelIgnoringCaseAndSpaces() {
        assertEquals(listOf("com.a.reader"), AppCatalog.filter(apps(), "МАНГА").map { it.pkg })
        assertEquals(listOf("com.a.reader"), AppCatalog.filter(apps(), "мангаредер").map { it.pkg })
        assertEquals(listOf("com.c.browser"), AppCatalog.filter(apps(), "браузер").map { it.pkg })
    }

    @Test
    fun matchesPackageName() {
        assertEquals(listOf("com.b.games"), AppCatalog.filter(apps(), "com.b").map { it.pkg })
    }

    @Test
    fun noMatchesGivesEmptyList() {
        assertEquals(0, AppCatalog.filter(apps(), "zzz").size)
    }
}