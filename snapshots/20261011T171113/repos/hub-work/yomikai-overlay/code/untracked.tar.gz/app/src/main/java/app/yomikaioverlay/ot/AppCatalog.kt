package app.yomikaioverlay.ot

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

/**
 * Список запускаемых приложений устройства — чтобы открыть нужное в один тап,
 * а не искать его в списке приложений телефона.
 */
object AppCatalog {

    class App(
        val pkg: String,
        val label: String,
    )

    private var cache: List<App>? = null

    /** Все приложения с лаунчером, отсортированные по названию. */
    fun load(ctx: Context, force: Boolean = false): List<App> {
        cache?.let { if (!force) return it }
        val pm = ctx.packageManager
        val out = ArrayList<App>()
        try {
            val pkgs = pm.getInstalledPackages(0)
            for (p in pkgs) {
                if (pm.getLaunchIntentForPackage(p.packageName) == null) continue
                val label = try {
                    pm.getApplicationLabel(p.applicationInfo).toString()
                } catch (e: Exception) { continue }
                out.add(App(p.packageName, label))
            }
        } catch (e: Exception) { }
        val sorted = out.sortedBy { it.label.lowercase() }
        cache = sorted
        return sorted
    }

    /** Иконка приложения (рисуется в списке). */
    fun icon(ctx: Context, app: App): Drawable? = try {
        ctx.packageManager.getApplicationIcon(app.pkg)
    } catch (e: Exception) {
        null
    }

    /**
     * Поиск по названию или пакету. Пустой запрос — отдаём всё.
     * Регистр не учитываем, пробелы в запросе склеиваем.
     */
    fun filter(apps: List<App>, query: String?): List<App> {
        val q = query?.trim()?.lowercase()?.replace(" ", "") ?: return apps
        if (q.isEmpty()) return apps
        return apps.filter {
            it.label.lowercase().replace(" ", "").contains(q) ||
                it.pkg.lowercase().contains(q)
        }
    }

    /** Запустить приложение. */
    fun launch(ctx: Context, app: App): Boolean {
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}