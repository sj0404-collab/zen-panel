package app.yomikai.shell.web

import android.content.Context
import app.yomikai.shell.storage.DeviceLibrary
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Веб-интерфейс оболочки: сначала `workspace/web` с устройства, потом assets.
 *
 * Зачем так: правка интерфейса в assets требует пересборки APK, а интерфейс —
 * ровно та часть, которую правишь часто. Поэтому в каждом корне библиотеки
 * (и в собственном каталоге приложения) ищется папка `workspace/web`: что
 * лежит в ней — отдаётся вместо ассета, остальное берётся из APK. Файл
 * появился или поправился — интерфейс меняется без пересборки.
 *
 * Порядок слоёв: SAF-корень пользователя, потом собственный каталог
 * приложения, потом assets. Первый нашедшийся выигрывает — так собственные
 * файлы приложения не затирают правки пользователя.
 *
 * Поиск папок идёт через SAF, то есть это запрос в binder, поэтому он
 * выполняется не на главном потоке и результат кэшируется до следующего
 * [refreshAsync] (старт приложения, возврат из фона, кнопка «перезагрузить»).
 */
class WebAssets(
    private val context: Context,
    private val library: DeviceLibrary,
) {

    /** Откуда читается конкретный файл интерфейса. */
    private class Layer(val read: () -> ByteArray?)

    @Volatile
    private var overrides: Map<String, Layer> = emptyMap()

    /** Человекочитаемый список найденных папок `workspace/web`. */
    @Volatile
    var dirs: List<String> = emptyList()
        private set

    private val assets = HashMap<String, ByteArray>()

    /** Файлы с устройства, которые не удалось прочитать: видны в настройках. */
    private val unreadable = ConcurrentHashMap.newKeySet<String>()

    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread(r, "shell-web-assets").apply { isDaemon = true }
    }

    /**
     * Пересканировать `workspace/web`. Вызывается с любого потока: SAF-запросы
     * уходят в [worker], смена слоёв атомарна.
     */
    fun refreshAsync(onChanged: (Boolean) -> Unit = {}) {
        // Поток мог быть уже остановлен (activity уничтожена, а отложенный
        // вызов от JS остался): это не повод падать.
        runCatching {
            worker.execute {
                val found = runCatching { scan() }.getOrElse { emptyMap() }
                val changed = found.keys != overrides.keys
                overrides = found
                unreadable.retainAll(found.keys)
                runCatching { onChanged(changed) }
            }
        }
    }

    /**
     * Байты файла интерфейса: `workspace/web`, если есть, иначе ассет.
     * Отсутствие файла — это `null`, а не исключение: сервер на такой запрос
     * отвечает 404.
     */
    fun read(path: String): Pair<InputStream, Long>? {
        val name = sanitize(path) ?: return null
        val layer = overrides[name]
        if (layer != null) {
            val bytes = layer.read()
            if (bytes != null) return ByteArrayInputStream(bytes) to bytes.size.toLong()
            // Файл нашёлся, но не прочитался: отдаём ассет и запоминаем
            // имя, иначе в настройках будет видно «правлен с устройства»,
            // а на экране — файл из APK, и непонятно, где расхождение.
            unreadable.add(name)
        }
        // Ассеты неизменны в пределах сборки — держать их в памяти дешевле,
        // чем открывать поток на каждый запрос (страница тянет три файла).
        val bytes = synchronized(assets) {
            assets[name] ?: loadAsset(name)?.also { assets[name] = it }
        } ?: return null
        return ByteArrayInputStream(bytes) to bytes.size.toLong()
    }

    /** JSON для веб-слоя: откуда взялся интерфейс и чем он переопределён. */
    fun infoJson(): String {
        val overridden = overrides.keys.sorted()
        return JSONObject()
            .put("overridden", JSONArray(overridden))
            .put("dirs", JSONArray(dirs))
            .put("unreadable", JSONArray(unreadable.sorted()))
            .put("assetsOnly", overridden.isEmpty())
            .toString()
    }

    fun shutdown() {
        worker.shutdownNow()
    }

    private fun scan(): Map<String, Layer> {
        val found = LinkedHashMap<String, Layer>()
        val labels = mutableListOf<String>()

        // Корень отдельно от остальных: права на него могли отобрать, и один
        // такой корень не должен обнулять слои, найденные в других.
        for (root in library.roots()) {
            runCatching { collect(root, found, labels) }
        }

        // Собственный каталог приложения: сюда оболочка кладёт файлы сама
        // (например, свой сброс интерфейса). Пользователь сюда не доходит.
        ownWebDir().takeIf { it.isDirectory }?.let { dir ->
            labels += dir.absolutePath
            dir.listFiles()?.forEach { file ->
                if (!file.isFile) return@forEach
                val name = sanitize(file.name) ?: return@forEach
                found.putIfAbsent(name, Layer { file.readBounded() })
            }
        }

        dirs = labels
        return found
    }

    private fun collect(root: String, found: MutableMap<String, Layer>, labels: MutableList<String>) {
        val webDir = findWebDir(root) ?: return
        labels += "${library.rootName(root)}/$OVERRIDE_DIR/web"
        library.list(webDir).forEach { node ->
            if (node.isDirectory) return@forEach
            val name = sanitize(node.name) ?: return@forEach
            found.putIfAbsent(name, Layer { library.readBytes(node.uri, MAX_UI_BYTES) })
        }
    }

    /** `<корень>/workspace/web`, если такая папка есть. */
    private fun findWebDir(root: String): String? {
        val workspace = library.list(root).firstOrNull {
            it.isDirectory && it.name == OVERRIDE_DIR
        } ?: return null
        val web = library.list(workspace.uri).firstOrNull { it.isDirectory && it.name == "web" }
        return web?.uri
    }

    private fun ownWebDir(): File = File(context.filesDir, "$OVERRIDE_DIR/web")

    private fun loadAsset(name: String): ByteArray? = runCatching {
        context.assets.open("web/$name").use { it.readBytes() }
    }.getOrNull()

    private fun File.readBounded(): ByteArray? = runCatching {
        if (length() > MAX_UI_BYTES) null else readBytes()
    }.getOrNull()

    companion object {
        const val OVERRIDE_DIR = "workspace"
        private const val MAX_UI_BYTES = 8L * 1024 * 1024

        /**
         * Имя файла интерфейса из URL. Здесь обрезается всё, чем можно полезть
         * наружу: `..`, пустые сегменты и ведущий `/`. Иначе запрос
         * `/ui/../../databases/shell` прочитал бы файл приложения — тем более
         * теперь, когда сервер отдаёт не только ассеты, но и файлы с устройства.
         */
        internal fun sanitize(path: String): String? {
            val raw = path.removePrefix("/").trim()
            if (raw.isEmpty()) return "index.html"
            if (raw.contains('\u0000')) return null
            val clean = raw.split('/').filter { it.isNotEmpty() && it != "." }
            if (clean.isEmpty()) return null
            if (clean.any { it == ".." }) return null
            return clean.joinToString("/")
        }
    }
}
