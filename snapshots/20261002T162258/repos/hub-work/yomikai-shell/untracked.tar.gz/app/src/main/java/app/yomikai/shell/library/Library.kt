package app.yomikai.shell.library

import java.io.Serializable

/**
 * Модель локальной библиотеки: папка — тайтл, тома и страницы внутри.
 *
 * Ни базы, ни кэша метаданных: список строится из того, что отдаёт SAF, и
 * пересобирается при открытии. Тайтл — это папка, том — архив `zip`/`cbz` или
 * отдельная картинка, страница — запись архива.
 *
 * Модель [Serializable], потому что тайтл целиком кладётся в Intent читалки:
 * он маленький (список URI и имён), и читать папку заново при каждом
 * открытии страницы было бы лишним обходом SAF.
 */
object Library {

    /** Одна страница: либо запись архива, либо отдельный файл. */
    sealed interface Page : Serializable {
        val name: String

        /** Запись внутри архива: URI тома плюс имя записи. */
        data class InArchive(
            override val name: String,
            val archiveUri: String,
            val entry: String,
        ) : Page

        /** Отдельный файл-картинка. */
        data class File(
            override val name: String,
            val uri: String,
        ) : Page
    }

    /** Том: архив с главами или одиночная картинка. */
    data class Volume(
        val name: String,
        val uri: String,
        val isArchive: Boolean,
    ) : Serializable

    /** Тайтл: папка со всеми томами и страницами. */
    data class Title(
        val name: String,
        val uri: String,
        val volumes: List<Volume>,
        val pages: List<Page>,
    ) : Serializable

    /**
     * Собрать тайтл из содержимого папки.
     *
     * Порядок глав и страниц — натуральный: «том 2» обязан идти раньше «тома 10»,
     * иначе тайтл читается не по порядку. Архивы и картинки вперемешку не
     * разводим: страницы идут в том порядке, в каком тома стоят в папке.
     */
    fun buildTitle(
        name: String,
        uri: String,
        nodes: List<Node>,
        natural: (String, String) -> Int,
        maxPages: Int,
        entriesOf: (Volume) -> List<String>,
    ): Title {
        val archives = nodes
            .filter { !it.isDirectory && it.extension in ARCHIVE_EXTENSIONS }
            .sortedWith { a, b -> natural(a.name, b.name) }
            .map { Volume(it.name, it.uri, true) }
        val loose = nodes
            .filter { !it.isDirectory && it.extension in IMAGE_EXTENSIONS }
            .sortedWith { a, b -> natural(a.name, b.name) }
            .map { Volume(it.name, it.uri, false) }
        // Подпапки — тоже тома: вложенная «Том 3/» внутри тайтла обязана
        // попасть в чтение, иначе тайтл читается не весь.
        val subdirs = nodes
            .filter { it.isDirectory }
            .sortedWith { a, b -> natural(a.name, b.name) }

        val volumes = ArrayList<Volume>(archives.size + loose.size + subdirs.size)
        val pages = ArrayList<Page>()
        for (volume in archives + loose) {
            if (pages.size >= maxPages) break
            volumes.add(volume)
            if (volume.isArchive) {
                for (entry in entriesOf(volume)) {
                    if (pages.size >= maxPages) break
                    pages.add(Page.InArchive(name = entry.substringAfterLast('/'), archiveUri = volume.uri, entry = entry))
                }
            } else {
                pages.add(Page.File(name = volume.name, uri = volume.uri))
            }
        }
        return Title(name = name, uri = uri, volumes = volumes, pages = pages)
    }

    /** Заголовок каталога: имя папки, в которой могут лежать главы. */
    data class Node(
        val uri: String,
        val name: String,
        val isDirectory: Boolean,
        val size: Long,
        val extension: String,
    ) {
        companion object {
            fun of(uri: String, name: String, isDirectory: Boolean, size: Long): Node = Node(
                uri = uri,
                name = name,
                isDirectory = isDirectory,
                size = size,
                extension = name.substringAfterLast('.', "").lowercase(),
            )
        }
    }

    val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "avif", "jxl")
    val ARCHIVE_EXTENSIONS = setOf("zip", "cbz")
    val BOOK_EXTENSIONS = setOf("pdf", "epub", "fb2", "docx", "txt", "md", "html")
}