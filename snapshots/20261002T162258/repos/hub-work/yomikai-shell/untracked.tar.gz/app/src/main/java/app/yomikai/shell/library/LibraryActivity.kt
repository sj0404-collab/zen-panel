package app.yomikai.shell.library

import android.content.Intent
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.yomikai.shell.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Библиотека: корни и папки, нативный список.
 *
 * Экран не хранит состояние — при каждом показе каталог перечитывается с
 * устройства. Так список всегда актуален: файл, добавленный на телефон, виден
 * сразу, без кнопки «обновить» и без кэша метаданных.
 */
class LibraryActivity : AppCompatActivity() {

    private lateinit var repository: TitleRepository
    private lateinit var recycler: RecyclerView
    private lateinit var header: TextView

    /** Стек открытых папок: URI каждой, чтобы «назад» вернулся к родителю. */
    private val path = ArrayDeque<Pair<String, String>>()

    private val pickRoot = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri == null) return@registerForActivityResult
        val name = rootNameOf(uri)
        // Права выдаются оболочке навсегда: без persistable-разрешения папка
        // перестаёт читаться уже после перезапуска процесса.
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { repository.addRoot(uri.toString(), name) }
            showRoots()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = TitleRepository(this)
        setContentView(R.layout.activity_library)

        header = findViewById(R.id.header)
        recycler = findViewById(R.id.list)
        recycler.layoutManager = LinearLayoutManager(this)

        findViewById<Button>(R.id.addRoot).setOnClickListener { pickRoot.launch(null) }
        findViewById<Button>(R.id.refresh).setOnClickListener { showCurrent() }

        onBackPressedDispatcher.addCallback(this) {
            // Кнопка «назад» сначала поднимает на уровень выше по дереву
            // папок и только потом закрывает приложение.
            if (path.size > 1) {
                path.removeLast()
                showCurrent()
            } else {
                finish()
            }
        }

        showCurrent()
    }

    override fun onResume() {
        super.onResume()
        // Возврат из выбора папки или из читалки меняет содержимое каталога.
        if (::recycler.isInitialized) showCurrent()
    }

    private fun showCurrent() {
        val current = path.lastOrNull()
        if (current == null) showRoots() else showFolder(current.first, current.second)
    }

    private fun showRoots() {
        path.clear()
        header.text = getString(R.string.library_roots)
        lifecycleScope.launch {
            val roots = withContext(Dispatchers.IO) { repository.roots() }
            render(
                roots.map { Item.Root(it.uri, it.name) },
                onOpen = { uri, name ->
                    path.addLast(uri to name)
                    showFolder(uri, name)
                },
                onRemove = { uri ->
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) { repository.removeRoot(uri) }
                        showRoots()
                    }
                },
            )
        }
    }

    private fun showFolder(uri: String, name: String) {
        header.text = name
        lifecycleScope.launch {
            val nodes = withContext(Dispatchers.IO) { repository.list(uri) }
            val back = Item.Back
            val folders = nodes
                .filter { it.isDirectory }
                .sortedWith { a, b -> app.yomikai.shell.archive.naturalOrder(a.name, b.name) }
                .map { Item.Folder(it.uri, it.name) }
            val files = nodes
                .filter { !it.isDirectory }
                .sortedWith { a, b -> app.yomikai.shell.archive.naturalOrder(a.name, b.name) }
                .map { node ->
                    val volume = node.extension in Library.ARCHIVE_EXTENSIONS
                    Item.Volume(
                        node.uri,
                        node.name,
                        isArchive = volume,
                        isImage = node.extension in Library.IMAGE_EXTENSIONS,
                    )
                }
            render(
                buildList {
                    if (path.size > 1) add(back)
                    // Кнопка «Читать» есть только у папки с главами: если
                    // внутри нет архивов и картинок, читать нечего.
                    add(Item.ReadTitle(uri, name, hasContent = nodes.any {
                        !it.isDirectory && (
                            it.extension in Library.ARCHIVE_EXTENSIONS ||
                                it.extension in Library.IMAGE_EXTENSIONS
                            )
                    }))
                    addAll(folders)
                    addAll(files)
                },
                onOpen = { openUri, openName ->
                    path.addLast(openUri to openName)
                    showFolder(openUri, openName)
                },
                onRead = { readUri, readName -> openReader(readUri, readName) },
            )
        }
    }

    private fun openReader(uri: String, name: String) {
        lifecycleScope.launch {
            val title = withContext(Dispatchers.IO) { repository.title(uri, name) }
            if (title.pages.isEmpty()) {
                android.widget.Toast
                    .makeText(this@LibraryActivity, R.string.reader_no_pages, android.widget.Toast.LENGTH_SHORT)
                    .show()
                return@launch
            }
            startActivity(
                Intent(this@LibraryActivity, ReaderActivity::class.java)
                    .putExtra(ReaderActivity.EXTRA_TITLE, title),
            )
        }
    }

    /** Строка списка. Запечатанные типы вместо флагов: у каждого свои действия. */
    private sealed interface Item {
        val label: String

        data class Root(val uri: String, val name: String) : Item {
            override val label: String get() = name
        }

        data class Folder(val uri: String, val name: String) : Item {
            override val label: String get() = name
        }

        data class Volume(
            val uri: String,
            val name: String,
            val isArchive: Boolean,
            val isImage: Boolean,
        ) : Item {
            override val label: String get() = name
        }

        data class ReadTitle(val uri: String, val name: String, val hasContent: Boolean) : Item {
            override val label: String get() = name
        }

        data object Back : Item {
            override val label: String = ".."
        }
    }

    private fun render(
        items: List<Item>,
        onOpen: (String, String) -> Unit,
        onRead: (String, String) -> Unit = { _, _ -> },
        onRemove: (String) -> Unit = { },
    ) {
        recycler.adapter = object : RecyclerView.Adapter<Holder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_library, parent, false),
            )

            override fun getItemCount() = items.size

            override fun onBindViewHolder(holder: Holder, position: Int) {
                holder.bind(
                    items[position],
                    onOpen = onOpen,
                    onRead = onRead,
                    onRemove = onRemove,
                )
            }
        }
    }

    private inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = view.findViewById(R.id.name)
        private val action: Button = view.findViewById(R.id.action)

        fun bind(
            item: Item,
            onOpen: (String, String) -> Unit,
            onRead: (String, String) -> Unit,
            onRemove: (String) -> Unit,
        ) {
            action.setOnClickListener(null)
            title.text = item.label
            when (item) {
                is Item.Root -> {
                    action.text = getString(R.string.library_remove)
                    action.setOnClickListener { onRemove(item.uri) }
                    title.setOnClickListener { onOpen(item.uri, item.name) }
                }
                is Item.Folder -> {
                    action.text = getString(R.string.library_open)
                    action.setOnClickListener { onOpen(item.uri, item.name) }
                    title.setOnClickListener { onOpen(item.uri, item.name) }
                }
                is Item.Volume -> {
                    // Архив читается как тайтл одной главы, картинка — как
                    // страница; остальное (книги, видео) оболочка не открывает,
                    // поэтому кнопка у них пустая.
                    action.text = if (item.isArchive) getString(R.string.library_read) else ""
                    action.setOnClickListener {
                        if (item.isArchive) onRead(item.uri, item.name)
                    }
                    title.setOnClickListener { onOpen(item.uri, item.name) }
                }
                is Item.ReadTitle -> {
                    action.text = getString(R.string.library_read_title)
                    action.isEnabled = item.hasContent
                    action.setOnClickListener { onRead(item.uri, item.name) }
                    title.setOnClickListener { onRead(item.uri, item.name) }
                }
                Item.Back -> {
                    action.text = getString(R.string.library_up)
                    action.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
                    title.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
                }
            }
        }
    }

    /**
     * Имя корня: последний сегмент document id. У дерева `primary:Download` он
     * читаемый, а URI целиком — нет. Если id не разобрался, показываем «..»
     * по названию корня, а не пустую строку.
     */
    private fun rootNameOf(uri: android.net.Uri): String =
        runCatching { DocumentsContract.getTreeDocumentId(uri) }
            .getOrNull()
            ?.substringAfterLast(':')
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: getString(R.string.library_root_fallback)
}