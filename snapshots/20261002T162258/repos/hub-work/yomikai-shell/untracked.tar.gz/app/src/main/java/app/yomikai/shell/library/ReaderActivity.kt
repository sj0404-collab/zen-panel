package app.yomikai.shell.library

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import app.yomikai.shell.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Читалка: страницы тайтла подряд, слева направо.
 *
 * Страница декодируется по размеру экрана, а не по полному разрешению файла:
 * JPEG на 4000×6000 в [BitmapFactory] без подбора размера весит 96 МБ, а на
 * экране всё равно видно 1080 пикселей. Декодирование уходит в [Dispatchers.IO],
 * иначе первая страница подвисала бы интерфейс на время распаковки.
 */
class ReaderActivity : AppCompatActivity() {

    private lateinit var repository: TitleRepository
    private lateinit var pager: ViewPager2
    private lateinit var status: TextView

    private lateinit var title: Library.Title

    /** Декодированные страницы: [LruCache] сам выкидывает лишние по размеру. */
    private val bitmaps = object : LruCache<String, android.graphics.Bitmap>(BITMAP_CACHE_BYTES) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap): Int = value.byteCount
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reader)

        val serializable = intent.getSerializableExtra(EXTRA_TITLE) as? Library.Title
        if (serializable == null || serializable.pages.isEmpty()) {
            finish()
            return
        }
        title = serializable
        repository = TitleRepository(this)

        pager = findViewById(R.id.pages)
        status = findViewById(R.id.status)
        pager.adapter = object : RecyclerView.Adapter<PageHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PageHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.item_page, parent, false),
            )

            override fun getItemCount() = title.pages.size

            override fun onBindViewHolder(holder: PageHolder, position: Int) {
                holder.bind(title.pages[position], position, title.pages.size)
            }
        }

        // Страница меняется — заголовок обязан меняться тоже, иначе в статусе
        // остаётся имя первого файла, а читатель на тридцатой странице.
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateStatus(position)
        })
        pager.offscreenPageLimit = 1
        updateStatus(0)
    }

    private fun updateStatus(position: Int) {
        val page = title.pages.getOrNull(position) ?: return
        status.text = getString(R.string.reader_status, position + 1, title.pages.size, page.name)
    }

    override fun onPause() {
        super.onPause()
        // Кэш распакованных байт на паузе не нужен: он пересоберётся из архива
        // дешевле, чем будет висеть в памяти, пока приложение в фоне.
        repository.clearCache()
    }

    override fun onDestroy() {
        super.onDestroy()
        bitmaps.evictAll()
    }

    private inner class PageHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val image: android.widget.ImageView = view.findViewById(R.id.page)
        private val placeholder: TextView = view.findViewById(R.id.placeholder)

        fun bind(page: Library.Page, position: Int, total: Int) {
            val key = keyOf(page)
            val cached = bitmaps.get(key)
            if (cached != null) {
                image.setImageBitmap(cached)
                placeholder.text = ""
                return
            }
            image.setImageDrawable(null)
            placeholder.text = view.context.getString(R.string.reader_loading)
            val width = view.resources.displayMetrics.widthPixels
            val height = view.resources.displayMetrics.heightPixels
            lifecycleScope.launch {
                val bytes = withContext(Dispatchers.IO) { repository.bytes(page) }
                if (bytes == null) {
                    placeholder.text = view.context.getString(R.string.reader_failed)
                    return@launch
                }
                val bitmap = withContext(Dispatchers.Default) { decode(bytes, width, height) }
                if (bitmap == null) {
                    placeholder.text = view.context.getString(R.string.reader_failed)
                    return@launch
                }
                bitmaps.put(key, bitmap)
                // Экземпляр переиспользован, пока грузилась другая страница:
                // без проверки позиции картинка отставала бы на страницу.
                if (bindingAdapterPosition == position) {
                    image.setImageBitmap(bitmap)
                    placeholder.text = ""
                }
            }
        }
    }

    private fun keyOf(page: Library.Page): String = when (page) {
        is Library.Page.File -> page.uri
        is Library.Page.InArchive -> page.archiveUri + ' ' + page.entry
    }

    /**
     * Декодировать с подбором размера под [targetWidth].
     *
     * `inSampleSize` — степень двойки: телефон показывает картинку с шириной
     * экрана, а не её полные 4000 пикселей. Сначала читаются только границы
     * (`inJustDecodeBounds`), потом картинка разжимается уже в нужном размере.
     */
    private fun decode(bytes: ByteArray, targetWidth: Int, targetHeight: Int): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, targetWidth, targetHeight)
            inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }

    private fun sampleSize(width: Int, height: Int, targetWidth: Int, targetHeight: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= targetWidth && height / (sample * 2) >= targetHeight) {
            sample *= 2
        }
        return sample
    }

    companion object {
        const val EXTRA_TITLE = "title"

        /** Кэш декодированных страниц: 1/8 доступной памяти, но не больше 64 МБ. */
        private val BITMAP_CACHE_BYTES = minOf(
            Runtime.getRuntime().maxMemory() / 8,
            64L * 1024 * 1024,
        ).toInt()
    }
}