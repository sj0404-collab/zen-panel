import { clamp } from './coordinates.js';

export interface BandwidthLimits {
  min: number;
  max: number;
}

/**
 * Pure bitrate-adjustment rule based on loss ratio and RTT.
 * Kept framework-free so it can be unit-tested and shared between the
 * host PWA and any future native sender.
 */
export function nextBitrate(
  currentBps: number,
  lossRatio: number,
  rttMs: number,
  limits: BandwidthLimits,
): number {
  let next = currentBps;
  if (lossRatio >= 0.08) {
    next = currentBps * 0.7;
  } else if (lossRatio >= 0.02) {
    next = currentBps * 0.9;
  } else if (lossRatio < 0.005 && rttMs < 120) {
    next = currentBps * 1.05;
  }
  return clamp(next, Math.max(limits.min, 1), Math.max(limits.max, limits.min));
}