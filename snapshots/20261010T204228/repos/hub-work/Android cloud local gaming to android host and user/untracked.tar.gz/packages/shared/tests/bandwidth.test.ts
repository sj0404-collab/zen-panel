import { describe, expect, it } from 'vitest';
import { nextBitrate } from '../src/bandwidth.js';

const limits = { min: 500_000, max: 12_000_000 };

describe('nextBitrate', () => {
  it('cuts hard on heavy loss', () => {
    expect(nextBitrate(6_000_000, 0.10, 50, limits)).toBe(4_200_000);
  });

  it('cuts gently on moderate loss', () => {
    expect(nextBitrate(6_000_000, 0.03, 50, limits)).toBe(5_400_000);
  });

  it('grows when the link is healthy', () => {
    expect(nextBitrate(6_000_000, 0.001, 40, limits)).toBe(6_300_000);
  });

  it('does not grow on lossy or laggy links', () => {
    expect(nextBitrate(6_000_000, 0.006, 40, limits)).toBe(6_000_000);
    expect(nextBitrate(6_000_000, 0.001, 140, limits)).toBe(6_000_000);
  });

  it('respects min and max bounds', () => {
    expect(nextBitrate(200_000, 0.10, 50, limits)).toBe(500_000);
    expect(nextBitrate(11_500_000, 0.001, 10, limits)).toBe(12_000_000);
  });
});