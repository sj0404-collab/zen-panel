package app.yomikaioverlay

import android.content.Context
import android.util.AttributeSet
import android.widget.ScrollView

/**
 * ScrollView с ограничением максимальной высоты программно.
 * Нужен, чтобы панель меню не уезжала за нижний край экрана.
 */
class MaxScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.scrollViewStyle
) : ScrollView(context, attrs, defStyleAttr) {

    var maxHeightPx: Int = Int.MAX_VALUE
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
            }
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = heightMeasureSpec
        val sh = if (maxHeightPx < Int.MAX_VALUE) {
            MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST)
        } else {
            h
        }
        super.onMeasure(widthMeasureSpec, sh)
    }
}
