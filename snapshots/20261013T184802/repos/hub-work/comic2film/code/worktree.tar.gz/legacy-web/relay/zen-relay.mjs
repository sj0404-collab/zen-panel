#!/usr/bin/env node
/* Zen-релей для VoiceComic.
 *
 * OpenCode Zen free tier («демо-режим», модели big-pickle, mimo-v2.5-free и
 * др.) пускает запросы БЕЗ ключа только при условии, что они «выглядят» как
 * запросы opencode-CLI: нужны identity-заголовки (User-Agent: opencode/<ver>,
 * x-opencode-session/request/client/project), stream:true, tool_choice:auto и
 * официальный набор builtin-тулов. Браузер не может подменить User-Agent, а у
 * zen нет CORS — поэтому для keyless-моделей из PWA/APK нужен этот релей.
 *
 * Понимает два эндпоинта zen (выбираются автоматически по модели):
 *   - /v1/chat/completions — oa-compat модели (big-pickle, mimo-*, nemotron-*,
 *     ling-*, space-bunny-free, deepseek-v4-flash-free);
 *   - /v1/responses       — Responses-модели (muse-spark-*-contributor-free;
 *     тулы конвертируются в Responses-формат и поднимается max_output_tokens);
 *   - jev-*               — это «система решений» структуры state+questions,
 *     не чат; релей возвращает понятную ошибку.
 * Оба пути сворачиваются в обычный JSON chat.completion, так что клиент
 * (non-stream) ничего не знает про SSE. Вызовы инструментов (zen их требует
 * для keyless-режима) не выбрасываются, а возвращаются как tool_calls: иначе
 * модель обещает действие, которого не будет, и следующий ход рассыпается.
 *
 * Запуск:        node relay/zen-relay.mjs [порт]
 *                 (порт по умолчанию 8789; можно ZEN_RELAY_PORT=…)
 * Проверка:      curl -s localhost:8789/healthz
 * Пример:
 *   POST http://localhost:8789/v1/chat/completions
 *   { "model":"big-pickle","messages":[{"role":"user","content":"привет"}] }
 *   — демо-модели без ключа; платные — если прислать Authorization: Bearer <ключ Zen>.
 */

import http from 'node:http';
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.argv[2] || process.env.ZEN_RELAY_PORT || 8789);
const ZEN = 'https://opencode.ai/zen/v1';
const OPENCODE_VERSION = '1.18.31';
const TOOLS = JSON.parse(readFileSync(path.join(ROOT, 'builtin_tools.json'), 'utf8'));

const RESPONSES_MODELS = /muse-spark-\S*contributor-free/;
const JEV_MODELS = /^jev-/;

const B62 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
function ocId(prefix) {
  const packed = Date.now() * 0x1000;
  let tail = '';
  for (const b of crypto.randomBytes(14)) tail += B62[b % 62];
  return prefix + packed.toString(16).padStart(12, '0').slice(-12) + tail;
}

const PROBE_MSG = { type: 'user', content: 'ping' };

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Access-Control-Expose-Headers', '*');
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(body);
}

async function readBody(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  return Buffer.concat(chunks);
}

function identityHeaders(req) {
  const h = {
    'Content-Type': 'application/json',
    'User-Agent': `opencode/${OPENCODE_VERSION}`,
    'x-opencode-client': 'cli',
    'x-opencode-project': 'global',
    'x-opencode-session': ocId('ses_'),
    'x-opencode-request': ocId('msg_'),
    Accept: 'application/json, text/event-stream',
  };
  if (req.headers.authorization) h.Authorization = req.headers.authorization;
  return h;
}

function mergeTools(clientTools) {
  if (Array.isArray(clientTools) && clientTools.length) return [...clientTools];
  return TOOLS;
}

function responsesTools() {
  return TOOLS.map((t) => ({
    type: 'function',
    name: t.function.name,
    description: t.function.description,
    parameters: t.function.parameters,
  }));
}

/* Сложить потоковые дельты tool_calls (id приходит один раз, arguments —
 * кусками в том же chunk). На порядок не полагаемся: сортируем по index.
 * Имя некоторые провайдеры присылают целиком в каждой дельте, поэтому
 * одинаковое повторе не склеивается, а разные куски — склеиваются. */
function foldToolCalls(acc, deltas) {
  for (const d of deltas) {
    if (!d) continue;
    const i = Number.isInteger(d.index) ? d.index : acc.size;
    let c = acc.get(i);
    if (!c) { c = { id: '', type: 'function', function: { name: '', arguments: '' } }; acc.set(i, c); }
    if (d.id) c.id = d.id;
    if (d.type) c.type = d.type;
    const f = d.function || {};
    if (f.name) {
      c.function.name = !c.function.name ? f.name
        : c.function.name === f.name ? f.name
        : c.function.name + f.name;
    }
    if (typeof f.arguments === 'string') c.function.arguments += f.arguments;
  }
}

export function sseFoldChat(raw) {
  let content = '';
  let finish_reason = 'stop';
  let err = null;
  let usage = null;
  const calls = new Map();
  for (const line of raw.split(/\r?\n/)) {
    const s = line.trim();
    if (!s.startsWith('data:')) continue;
    const payload = s.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    try {
      const o = JSON.parse(payload);
      // stream=true у zen всегда присылает сначала error-событие
      if (o.error) { err = o.error; continue; }
      // реальная телеметрия приходит последним chunk'ом — раньше она
      // выбрасывалась, и клиенту уходила выдуманная оценка по символам
      if (o.usage) usage = o.usage;
      const d = o.choices && o.choices[0];
      if (!d) continue;
      if (d.delta && typeof d.delta.content === 'string') content += d.delta.content;
      if (d.delta && Array.isArray(d.delta.tool_calls)) foldToolCalls(calls, d.delta.tool_calls);
      if (d.finish_reason) finish_reason = d.finish_reason;
    } catch (_) { /* skip partial */ }
  }
  const tool_calls = [...calls.keys()].sort((a, b) => a - b).map((k) => calls.get(k));
  const out = { content, finish_reason, usage, tool_calls };
  if (err) return { ...out, finish_reason: 'error', error: errText(err) };
  if (finish_reason === 'length') {
    return { ...out, error: 'модель упёрлась в лимит длины ответа (сократите запрос)' };
  }
  // Ответ-вызов инструментов — тоже ответ: раньше он попадал в «пустой
  // ответ» (502), потому что текста в нём может не быть вовсе.
  if (!content.trim() && !tool_calls.length) {
    return { ...out, error: 'модель вернула пустой ответ' };
  }
  return out;
}

function errText(e) {
  if (!e) return 'неизвестная ошибка zen';
  if (typeof e === 'string') return e;
  return e.message || e.code || JSON.stringify(e).slice(0, 200);
}

export function sseFoldResponses(raw) {
  let content = '';
  let status = 'completed';
  let stopped = false;
  let err = null;
  let incomplete = null;
  let usage = null;
  // Responses-API отдаёт вызов инструмента отдельными событиями (added →
  // function_call_arguments.delta* → done), а не дельтами в choices. Раньше
  // они молча терялись, и ход без текста уходил в 502 «пустой ответ».
  const calls = new Map();
  const callEntry = (key, item) => {
    const k = String(key);
    let c = calls.get(k);
    if (!c) { c = { id: '', type: 'function', function: { name: '', arguments: '' } }; calls.set(k, c); }
    if (item) {
      if (item.call_id) c.id = item.call_id;
      else if (item.id) c.id = item.id;
      if (item.name && !c.function.name) c.function.name = item.name;
      if (typeof item.arguments === 'string' && item.arguments) c.function.arguments = item.arguments;
    }
    return c;
  };
  for (const line of raw.split(/\r?\n/)) {
    const s = line.trim();
    if (!s.startsWith('data:')) continue;
    const payload = s.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    try {
      const o = JSON.parse(payload);
      if (o.type === 'response.output_text.delta') content += o.delta || '';
      if (o.type === 'response.output_item.added' && o.item && o.item.type === 'function_call') {
        callEntry(o.item.id != null ? o.item.id : o.output_index, o.item);
      }
      if (o.type === 'response.function_call_arguments.delta') {
        callEntry(o.item_id != null ? o.item_id : o.output_index, null).function.arguments +=
          typeof o.delta === 'string' ? o.delta : '';
      }
      if (o.type === 'response.output_item.done' && o.item && o.item.type === 'function_call') {
        callEntry(o.item.id != null ? o.item.id : o.output_index, o.item);
      }
      if (o.type === 'response.completed') { status = (o.response && o.response.status) || 'completed'; stopped = true; if (o.response && o.response.usage) usage = o.response.usage; }
      if (o.type === 'response.incomplete') { incomplete = o.response && o.response.incomplete_details; stopped = true; }
      if (o.type === 'response.failed' || o.type === 'error') { err = o; status = 'failed'; stopped = true; }
      if (o.type === 'response.error') { err = o; status = 'failed'; stopped = true; }
    } catch (_) { /* skip partial */ }
  }
  const tool_calls = [...calls.values()];
  const out = { content, status, stopped, tool_calls };
  if (err) return { ...out, finish_reason: 'error', error: errText(err.error || err.response || err) };
  if (incomplete) {
    return { ...out, finish_reason: 'error',
      error: 'модель не закончила ответ: ' + (incomplete.reason || 'incomplete') };
  }
  if (status !== 'completed') {
    return { ...out, finish_reason: 'error', error: 'статус ответа zen: ' + status };
  }
  if (!content.trim() && !tool_calls.length) {
    return { ...out, finish_reason: 'error', error: 'модель вернула пустой ответ' };
  }
  return { ...out, finish_reason: 'stop', usage };
}

export function completionJson(model, result) {
  const msg = { role: 'assistant', content: result.content || '' };
  // Вызовы инструментов возвращаем как есть: раньше они молча терялись, и
  // клиент получал текст без обещанного действия (а следующий ход модели
  // рассыпался на «nullnullnull…»).
  if (Array.isArray(result.tool_calls) && result.tool_calls.length) {
    msg.tool_calls = result.tool_calls;
    if (!msg.content) msg.content = null;
  }
  return {
    id: 'chatcmpl-relay-' + Date.now(),
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model,
    choices: [{
      index: 0,
      message: msg,
      finish_reason: result.finish_reason || 'stop',
    }],
    usage: usageOf(result),
  };
}

/* Считаем по-настоящему. Раньше здесь всегда стояли нули — это фиктивные
 * данные, которые выглядят как настоящая телеметрия. Теперь сюда попадает
 * настоящий usage из последнего chunk'а потока, а оценка по символам —
 * только если апстрим токенов не отдал. */
function usageOf(result) {
  const u = (result && result.usage) || {};
  const prompt = Number(u.prompt_tokens ?? u.input_tokens ?? 0) || 0;
  const completion = Number(u.completion_tokens ?? u.output_tokens ?? 0) || 0;
  if (prompt || completion) {
    return { prompt_tokens: prompt, completion_tokens: completion, total_tokens: prompt + completion };
  }
  // Токенизатор zen не отдаёт, поэтому считаем хотя бы по символам и
  // честно помечаем оценку, чтобы клиент не принял её за точные числа.
  const text = (result && result.content) || '';
  const chars = text.length;
  return {
    prompt_tokens: 0,
    completion_tokens: chars,
    total_tokens: chars,
    estimated: true,
  };
}

async function handleChat(req, res) {
  let body;
  try {
    body = JSON.parse((await readBody(req)).toString('utf8') || '{}');
  } catch (e) {
    return sendJson(res, 400, { error: { type: 'invalid_request_error', message: 'Bad JSON body' } });
  }

  const model = body.model || '';
  if (typeof model !== 'string' || !model.trim()) {
    return sendJson(res, 400, { error: { type: 'invalid_request_error', message: 'model is required' } });
  }
  if (JEV_MODELS.test(model)) {
    return sendJson(res, 400, {
      error: { type: 'model_not_chat', message: `«${model}» (Jev) — это не чат-модель, а «система решений» (state+questions); в VoiceComic не используется.` },
    });
  }

  const h = identityHeaders(req);
  const isResponses = RESPONSES_MODELS.test(model);

  let out;
  let upstreamUrl;
  if (isResponses) {
    upstreamUrl = ZEN + '/responses';
    out = {
      ...body,
      model,
      stream: true,
      tools: responsesTools(),
      tool_choice: 'auto',
      // без запас по токенам muse-модели возвращают «incomplete»
      max_output_tokens: Math.max(body.max_output_tokens || 800, 800),
      input: Array.isArray(body.messages) && body.messages.length
        ? body.messages.map((m) => ({
            role: m.role || 'user',
            content: [{ type: 'input_text', text: textOf(m.content) }],
          }))
        : [{ role: 'user', content: [{ type: 'input_text', text: 'ping' }] }],
    };
    delete out.messages;
    delete out.max_tokens;
  } else {
    upstreamUrl = ZEN + '/chat/completions';
    out = {
      ...body,
      model,
      stream: true,
      tool_choice: body.tool_choice || 'auto',
      tools: mergeTools(body.tools),
      messages: (body.messages && body.messages.length) ? body.messages : [PROBE_MSG],
    };
    delete out.unused;
  }

  let upstream;
  try {
    upstream = await fetch(upstreamUrl, {
      method: 'POST',
      headers: h,
      body: JSON.stringify(out),
      signal: AbortSignal.timeout(90000),
    });
  } catch (e) {
    return sendJson(res, 502, { error: { type: 'relay_error', message: 'Upstream unreachable: ' + e.message } });
  }

  const raw = await upstream.text();
  if (upstream.status !== 200) {
    const ct = (upstream.headers.get('content-type') || '').toLowerCase();
    let payload = { error: { type: 'upstream_error', message: `Zen HTTP ${upstream.status}` } };
    if (ct.includes('json')) {
      try { payload = JSON.parse(raw); } catch (_) { /* keep default */ }
    }
    return sendJson(res, upstream.status, payload);
  }

  const result = isResponses ? sseFoldResponses(raw) : sseFoldChat(raw);
  // Провал больше не прячется за HTTP 200 с пустым content: клиент получал
  // «пустой ответ» без объяснения и без возможности отличить сбой от молчания.
  if (result.error) {
    return sendJson(res, 502, {
      error: { type: isResponses ? 'upstream_failed' : 'upstream_error', message: result.error },
    });
  }
  return sendJson(res, 200, completionJson(model, result));
}

function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.map((p) => (p && p.text != null ? p.text : '')).join('\n');
  }
  return String(content || '');
}

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'GET' && url.pathname === '/healthz') {
    return sendJson(res, 200, { ok: true, zen: ZEN, version: OPENCODE_VERSION, tools: TOOLS.length });
  }
  if (req.method === 'POST' && url.pathname === '/v1/chat/completions') {
    return handleChat(req, res);
  }
  return sendJson(res, 404, { error: { type: 'not_found', message: url.pathname } });
});

server.listen(PORT, () => {
  console.log('zen-relay on :' + PORT + ' → ' + ZEN);
  console.log('демо-модели без ключа:');
  console.log('  chat: big-pickle, mimo-v2.5-free, mimo-v2.6-flash-free, nemotron-3-ultra-free,');
  console.log('        nemotron-3.5-lightning-free, ling-3.0-flash-fin-free, space-bunny-free, deepseek-v4-flash-free');
  console.log('  responses: muse-spark-1.3-contributor-free, muse-spark-1.2-contributor-free');
  console.log('  jev-* — decision-модель, не чат (не поддерживается)');
});