plugins {
    alias(mihonx.plugins.android.library)

    alias(mihonx.plugins.spotless)
}

android {
    namespace = "app.yomikai.reader"
}

dependencies {
    // Настройки читалки — это тонкая обёртка над PreferenceStore, поэтому
    // модуль зависит только от ядра настроек и строк. Ни Compose-Material, ни
    // слоя данных, ни Injekt: всё это придёт вместе с самой читалкой, и
    // пока модуль не содержит её кода, тянуть эти зависимости незачем.
    api(projects.core.common)
    api(projects.i18n)

    // ReaderPreferences описывает режимы фильтра цвета через BlendMode, а
    // ReaderOrientation отдаёт иконки направления экрана.
    implementation(libs.androidx.compose.materialIcons)
}
