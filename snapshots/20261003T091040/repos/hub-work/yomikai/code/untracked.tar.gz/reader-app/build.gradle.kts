plugins {
    alias(mihonx.plugins.android.application)
    alias(mihonx.plugins.compose)

    alias(mihonx.plugins.spotless)
}

android {
    namespace = "app.yomikai.reader.app"

    defaultConfig {
        // Отдельное приложение, а не экран внутри Yomikai: своя подпись в
        // списке установленных, свои настройки, своё хранилище. Именно этим
        // оно и отличается от оверлея, который тоже живёт рядом, но отдельной
        // установки не требует.
        applicationId = "com.yomikai.reader"

        // Версию ставит release-workflow читалки по тегу; пока сборка идёт
        // только как проверка компиляции в CI, значения не意义 значимы.
        versionCode = 1
        versionName = "0.1.0"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        freeCompilerArgs.addAll(
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=kotlinx.coroutines.FlowPreview",
        )
    }
}

dependencies {
    implementation(projects.core.common)
    implementation(projects.i18n)
    implementation(projects.presentationCore)
    implementation(projects.reader)

    // Compose
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.materialIcons)
    implementation(libs.androidx.compose.uiToolingPreview)
    debugImplementation(libs.androidx.compose.uiTooling)

    implementation(libs.androidx.core)

    implementation(libs.bundles.kotlinx.coroutines)

    // Dependency injection
    implementation(libs.injekt)
}
