package app.yomikaioverlay.ot

import android.graphics.Rect

/**
 * Порядок чтения распознанных блоков текста: номера 1..N и направление.
 * Чистая логика без Android-зависимостей (кроме Rect) — покрыта тестами.
 */
object ReadingOrder {
    const val AUTO = "auto"          // как вернул распознаватель
    const val LTR = "ltr"            // слева → направо, строки сверху вниз
    const val RTL = "rtl"            // справа → налево, строки сверху вниз
    const val VERTICAL = "vertical"  // колонки справа → налево, внутри сверху вниз
    const val BOTTOM_UP = "bottom_up" // снизу вверх, строки слева направо

    val MODES = listOf(AUTO, LTR, RTL, VERTICAL, BOTTOM_UP)
    const val DEFAULT = AUTO

    fun normalize(mode: String?): String = if (mode in MODES) mode else DEFAULT

    fun label(mode: String?): String = when (normalize(mode)) {
        AUTO -> "Как распознано"
        LTR -> "→ слева направо"
        RTL -> "← справа налево"
        VERTICAL -> "↓ вертикально"
        BOTTOM_UP -> "↑ снизу вверх"
        else -> "Как распознано"
    }

    /** Краткое направление для заголовка кнопки. */
    fun short(mode: String?): String = when (normalize(mode)) {
        AUTO -> "Авто"
        LTR -> "→"
        RTL -> "←"
        VERTICAL -> "↓"
        BOTTOM_UP -> "↑"
        else -> "Авто"
    }

    fun next(mode: String?): String {
        val list = MODES
        return list[(list.indexOf(normalize(mode)) + 1) % list.size]
    }

    /** Блоки в порядке чтения 1..N по выбранному направлению. */
    fun order(rects: List<Rect>, mode: String?): List<Rect> {
        if (rects.size < 2) return rects
        return when (normalize(mode)) {
            AUTO -> rects
            LTR -> rows(rects).flatMap { it.sortedBy { r -> r.left } }
            RTL -> rows(rects).flatMap { it.sortedByDescending { r -> r.right } }
            BOTTOM_UP -> rows(rects).reversed().flatMap { it.sortedBy { r -> r.left } }
            VERTICAL -> columns(rects)
                .sortedByDescending { c -> c.first().centerX() }
                .flatMap { it.sortedBy { r -> r.top } }
            else -> rects
        }
    }

    /** Разбивает блоки на строки по вертикальному пересечению полос. */
    fun rows(rects: List<Rect>): List<List<Rect>> = groupByBand(rects, horizontal = true)

    /** Разбивает блоки на колонки по горизонтальному пересечению полос. */
    fun columns(rects: List<Rect>): List<List<Rect>> = groupByBand(rects, horizontal = false)

    private fun groupByBand(rects: List<Rect>, horizontal: Boolean): List<List<Rect>> {
        val sorted = if (horizontal) rects.sortedBy { it.top } else rects.sortedBy { it.left }
        val bands = mutableListOf<MutableList<Rect>>()
        for (r in sorted) {
            val band = bands.firstOrNull { members -> overlap(members.first(), r, horizontal) }
            if (band != null) band.add(r) else bands.add(mutableListOf(r))
        }
        return bands
    }

    private fun overlap(a: Rect, b: Rect, horizontal: Boolean): Boolean {
        val aS = if (horizontal) a.top else a.left
        val aE = if (horizontal) a.bottom else a.right
        val bS = if (horizontal) b.top else b.left
        val bE = if (horizontal) b.bottom else b.right
        val inter = minOf(aE, bE) - maxOf(aS, bS)
        val minLen = minOf(aE - aS, bE - bS)
        if (minLen <= 0) return false
        return inter.toFloat() / minLen >= 0.4f
    }
}