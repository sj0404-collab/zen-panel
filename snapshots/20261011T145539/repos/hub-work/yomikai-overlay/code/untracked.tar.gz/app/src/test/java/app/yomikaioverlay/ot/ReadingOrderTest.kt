package app.yomikaioverlay.ot

import android.graphics.Rect
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReadingOrderTest {

    // Сетка 2×2: два блока сверху и два снизу.
    private val tl = Rect(10, 10, 100, 50)
    private val tr = Rect(120, 10, 210, 50)
    private val bl = Rect(10, 60, 100, 100)
    private val br = Rect(120, 60, 210, 100)
    private val grid = listOf(tl, tr, bl, br)

    @Test fun `normalize пустой mode даёт AUTO`() {
        assertEquals(ReadingOrder.DEFAULT, ReadingOrder.normalize(null))
        assertEquals(ReadingOrder.DEFAULT, ReadingOrder.normalize("banana"))
    }

    @Test fun `ltr читает строки сверху вниз, внутри слева направо`() {
        assertEquals(listOf(tl, tr, bl, br), ReadingOrder.order(grid, ReadingOrder.LTR))
    }

    @Test fun `rtl внутри строки справа налево`() {
        assertEquals(listOf(tr, tl, br, bl), ReadingOrder.order(grid, ReadingOrder.RTL))
    }

    @Test fun `bottom_up идёт снизу вверх`() {
        assertEquals(listOf(bl, br, tl, tr), ReadingOrder.order(grid, ReadingOrder.BOTTOM_UP))
    }

    @Test fun `vertical читает правую колонку сверху вниз, затем левую`() {
        val ordered = ReadingOrder.order(grid, ReadingOrder.VERTICAL)
        assertEquals(listOf(tr, br, tl, bl), ordered)
    }

    @Test fun `auto без изменений`() {
        assertEquals(grid, ReadingOrder.order(grid, ReadingOrder.AUTO))
    }

    @Test fun `перетасовка входного порядка не влияет на ltr`() {
        val shuffled = listOf(br, tl, bl, tr)
        assertEquals(listOf(tl, tr, bl, br), ReadingOrder.order(shuffled, ReadingOrder.LTR))
    }

    @Test fun `вертикальные колонки манги: правая колонка первой`() {
        // Три блока: два в правой колонке (сверху и снизу), один в левой.
        val rightTop = Rect(200, 10, 300, 60)
        val rightBottom = Rect(200, 70, 300, 120)
        val left = Rect(10, 10, 110, 60)
        val ordered = ReadingOrder.order(listOf(left, rightBottom, rightTop), ReadingOrder.VERTICAL)
        assertEquals(listOf(rightTop, rightBottom, left), ordered)
    }
}