package dev.pocketrun.runtime.js

import com.dokar.quickjs.QuickJs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Test

/** Probing the engine's value conversion so the runtime can be written against facts. */
class QuickJsProbeTest {

    @Test
    fun probe() = runBlocking {
        val q = QuickJs.create(Dispatchers.Default)
        try {
            probe("evaluate<Any?> on void script") {
                q.evaluate<Any?>("globalThis.a = 1;", "t.js", false)
            }
            probe("evaluate<Any?> on expression") {
                q.evaluate<Any?>("1 + 2", "t.js", false)
            }
            probe("evaluate<Any?> on string") {
                q.evaluate<Any?>("'hi'", "t.js", false)
            }
            probe("evaluate<Any?> on undefined") {
                q.evaluate<Any?>("undefined", "t.js", false)
            }
            probe("evaluate<Double> on undefined") {
                q.evaluate<Double>("undefined", "t.js", false)
            }
            probe("evaluate<Boolean> on comparison") {
                q.evaluate<Boolean>("1 < 2", "t.js", false)
            }
            probe("evaluate<String> on object") {
                q.evaluate<String>("({a:1})", "t.js", false)
            }
            probe("global read via Any?") {
                q.evaluate<Any?>("typeof globalThis.fn", "t.js", false)
            }
        } finally {
            q.close()
        }
    }

    private inline fun probe(name: String, block: () -> Any?) {
        val out = try {
            val v = block()
            "${v?.javaClass?.simpleName} = $v"
        } catch (t: Throwable) {
            "THREW ${t.javaClass.simpleName}: ${t.message?.take(120)}"
        }
        println("PROBE [$name] -> $out")
    }
}
