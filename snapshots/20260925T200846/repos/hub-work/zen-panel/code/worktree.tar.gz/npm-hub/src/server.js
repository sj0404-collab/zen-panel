#!/usr/bin/env node
const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const net = require('net');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');
const pty = require('node-pty');
const StorageManager = require('./storage/manager');
const ModelManager = require('./models/manager');
const { startTunnel } = require('./tunnel');

// Opus for the remote-audio bridge. Pure JS (asm.js/wasm) on purpose: it also
// loads on the Windows runners, where native modules are painful to build.
// Optional — without it the bridge keeps using raw PCM.
let OpusScript = null;
try { OpusScript = require('opusscript'); } catch {}

const app = express();
const HOME = os.homedir();
const safeFilename = (s) => String(s).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 200);

// Content-Disposition: HTTP header values must be ASCII. Кириллица/прочие
// не-ASCII в имени файла заставляют Node бросить "Invalid character in header
// content" (клиент получает 500, кнопка «глаз» не открывает файл). Даём
// ASCII-версию имени + RFC 5987 filename* (UTF-8) — браузер сохранит файл
// под настоящим именем.
const cdHeader = (mode, name) => {
  const plain = String(name).replace(/[\r\n"]/g, '_').replace(/[^\x20-\x7E]/g, '_');
  return `${mode}; filename="${plain}"; filename*=UTF-8''${encodeURIComponent(String(name))}`;
};
const mimeForPath = (p) => {
  const lower = String(p || '').toLowerCase();
  if (lower.endsWith('.apk')) return 'application/vnd.android.package-archive';
  if (lower.endsWith('.aab')) return 'application/octet-stream';
  if (lower.endsWith('.apks') || lower.endsWith('.xapk') || lower.endsWith('.zip')) return 'application/zip';
  if (lower.endsWith('.tar.xz')) return 'application/x-xz';
  if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) return 'application/gzip';
  if (lower.endsWith('.tar.bz2') || lower.endsWith('.tbz2')) return 'application/x-bzip2';
  if (lower.endsWith('.tar.zst') || lower.endsWith('.tzst')) return 'application/zstd';
  if (lower.endsWith('.tar')) return 'application/x-tar';
  const ext = (path.extname(lower) || '').toLowerCase();
  return ({ '.xz': 'application/x-xz', '.gz': 'application/gzip', '.bz2': 'application/x-bzip2',
    '.zst': 'application/zstd', '.7z': 'application/x-7z-compressed', '.rar': 'application/vnd.rar',
    '.deb': 'application/vnd.debian.binary-package', '.rpm': 'application/x-rpm',
    '.jar': 'application/java-archive', '.png': 'image/png', '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.bmp': 'image/bmp', '.ico': 'image/x-icon',
    '.pdf': 'application/pdf', '.html': 'text/html',
    '.htm': 'text/html', '.json': 'application/json', '.xml': 'application/xml',
    '.txt': 'text/plain', '.md': 'text/plain', '.log': 'text/plain', '.js': 'application/javascript',
    '.mjs': 'application/javascript', '.cjs': 'application/javascript', '.css': 'text/css', '.csv': 'text/csv',
    '.ts': 'text/plain', '.tsx': 'text/plain', '.py': 'text/plain', '.rb': 'text/plain', '.go': 'text/plain',
    '.rs': 'text/plain', '.java': 'text/plain', '.c': 'text/plain', '.h': 'text/plain',
    '.cpp': 'text/plain', '.hpp': 'text/plain', '.php': 'text/plain', '.sh': 'text/plain',
    '.bat': 'text/plain', '.yml': 'text/plain', '.yaml': 'text/plain', '.ini': 'text/plain',
    '.cfg': 'text/plain', '.conf': 'text/plain', '.toml': 'text/plain', '.sql': 'text/plain',
    '.mp4': 'video/mp4', '.webm': 'video/webm', '.ogg': 'video/ogg',
    '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.webp': 'image/webp', '.m4a': 'audio/mp4',
    '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff',
    '.ttf': 'font/ttf', '.otf': 'font/otf',
  })[ext] || 'application/octet-stream';
};
// Both roots are overridable so an operator can keep clones and state on a
// persistent volume (a mounted folder that survives restarts). By default they
// live under $HOME, which is stable across tool restarts - unlike /tmp, which
// the machine may wipe.
const WORK_DIR = process.env.HUB_WORK_DIR || path.join(HOME, 'hub-work');
// Home dirs under ~/.npm-hub: the runner works transparently here and never
// uses the OS /tmp (which the machine may wipe and is invisible to CLI agents).
const DATA_DIR = process.env.HUB_DATA_DIR || path.join(HOME, '.npm-hub');
const TMP_DIR = path.join(DATA_DIR, 'tmp');
const LOG_DIR = path.join(DATA_DIR, 'logs');
try {
  fs.mkdirSync(WORK_DIR, { recursive: true });
  fs.mkdirSync(TMP_DIR, { recursive: true });
  fs.mkdirSync(LOG_DIR, { recursive: true });
} catch {}
const PORT = process.env.PORT || 8090;
const HOST = '0.0.0.0';
// Local DNS alias, e.g. HOST_ALIAS=nmp.local → the hub is reachable as
// http://nmp.local:PORT from every device on the LAN, DNS resolution done by
// /etc/hosts alone - no external tunnel/DDNS service involved. Best-effort:
// appending to /etc/hosts needs root, so it tries a plain write first (owner
// or writable file), then `sudo -n tee` (password-less sudo), and degrades
// silently: the alias field is simply not advertised when it cannot be
// guaranteed. Both work and are reported through /api/networks + info.
const HOST_ALIAS = String(process.env.HOST_ALIAS || '').trim().toLowerCase().replace(/^https?:\/\//, '');
const HOSTS_FILE = process.platform === 'win32' ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'drivers', 'etc', 'hosts') : '/etc/hosts';
function lanIP() {
  try {
    for (const [name, iface] of Object.entries(os.networkInterfaces())) {
      for (const cfg of iface) if (cfg.family === 'IPv4' && !cfg.internal) return cfg.address;
    }
  } catch {}
  return '127.0.0.1';
}
const HOST_ALIAS_IP = lanIP();
let hostAliasInstalled = false;
async function ensureHostAlias() {
  if (!HOST_ALIAS) return;
  const line = `${HOST_ALIAS_IP}\t${HOST_ALIAS} # npm-hub\n`;
  try {
    const cur = fs.readFileSync(HOSTS_FILE, 'utf8');
    const hit = cur.split('\n').some(l => l.trim() === `${HOST_ALIAS_IP}\t${HOST_ALIAS}` || l.includes(` ${HOST_ALIAS}`));
    if (hit) { hostAliasInstalled = true; return; }
    if (cur.includes(HOST_ALIAS)) {
      // alias mapped elsewhere - leave it; a resolvable alias is better than none.
      hostAliasInstalled = true; return;
    }
  } catch {}
  for (const attempt of [
    () => fs.appendFileSync(HOSTS_FILE, line),
    () => require('child_process').execSync(`echo '${line}' | sudo -n tee -a '${HOSTS_FILE}'`, { timeout: 5000 }),
  ]) {
    try { attempt(); hostAliasInstalled = true; break; } catch {}
  }
}
// How much terminal scrollback the hub keeps in memory for the reconnect
// replay. 256KB hid almost everything once a build flooded a session:
// reconnecting rolled back to "just the tail", so sessions looked reset.
// 4MB (~a real terminal's worth) is configurable for low-memory runners.
const SESSION_OUTPUT_CAP = parseInt(process.env.SESSION_OUTPUT_CAP || String(4 * 1024 * 1024), 10) || (4 * 1024 * 1024);
const SESSION_OUTPUT_CHUNK = 64 * 1024; // replay frames this size so a phone stays responsive
const STATE_FILE = path.join(HOME, '.npm-hub-state.json');

app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, '..', 'public'), {
  setHeaders: (res, filePath) => {
    if (/\.(html?|js|css|json)$/.test(filePath)) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));

// ─── ROUTES: / → launcher, /d → dashboard, /m → mobile, separate pages ───
function noCache(res) {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
}
// Каждая вкладка — отдельная страница. Общий «мост» bridge.js даёт им
// одинаковую верхнюю панель, состояние и helpers.
app.get('/d', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'dashboard.html'));
});
app.get('/d/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'dashboard.html'));
});
app.get('/files', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'files.html'));
});
app.get('/files/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'files.html'));
});
app.get('/linux', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'linux.html'));
});
app.get('/linux/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'linux.html'));
});
app.get('/git', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'git.html'));
});
app.get('/git/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'git.html'));
});
app.get('/m', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'mobile.html'));
});
app.get('/m/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'mobile.html'));
});
// Внешняя память — standalone PWA-зеркало репо и сборок (свой SW и манифест).
app.get('/vault', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'external-memory.html'));
});
app.get('/vault/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'external-memory.html'));
});
// Standalone terminal site: survives a refresh of the dashboard because its
// tabs reconnect to the same server-side tmux sessions and replay the buffer.
// Sessions themselves live on the server, so they run even with no page open.
app.get('/term', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'term.html'));
});
app.get('/term/*', (req, res) => {
  noCache(res);
  res.sendFile(path.join(__dirname, '..', 'public', 'term.html'));
});

// ─── CORS — allow all origins (for phone access) ───
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// ─── Activity for the session relay (handoff) ───────────────────────────
// "Nothing is happening" has to mean the USER is doing nothing, not that the
// dashboard is idle: the hub and the panel poll /api/handoff, /api/sessions and
// /api/info every few seconds, and counting those would keep a dead session
// alive forever. So only real work counts - anything that changes state, plus
// terminal input (counted at the websocket) and file downloads.
const HANDOFF_QUIET = /^\/(api\/(handoff|info|sessions|sessions\.|storages|networks|tools|runner|fs\/(list|ls|browse|stat|dirs|search)|gh\/(artifacts|browse|repos|search|file|tree)|models|stats|logs|system|health|phone|metrics|cache|proxy))/;
app.use((req, res, next) => {
  if (typeof handoff !== 'undefined' && handoff) {
    const p = String(req.path || '');
    if (!HANDOFF_QUIET.test(p)) {
      const work = (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS')
        || /^\/api\/fs\/(download|view|open|save)/.test(p);
      if (work) handoff.noteActivity();
    }
  }
  next();
});

// ─── Idempotency for replayed offline actions ───
// The panel queues a mutation that failed offline and replays it when the
// network returns. If the original actually reached us and only the response
// was lost, a naive replay would run it twice (two artifacts, two commits).
// The client sends a stable x-hub-idem key; the first response is remembered
// for a day and handed back instead of executing the action again.
const IDEM_DIR = path.join(DATA_DIR, 'idem');
try { fs.mkdirSync(IDEM_DIR, { recursive: true }); } catch {}
try {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const f of fs.readdirSync(IDEM_DIR)) {
    const p = path.join(IDEM_DIR, f);
    try { if (fs.statSync(p).mtimeMs < cutoff) fs.unlinkSync(p); } catch {}
  }
} catch {}
app.use((req, res, next) => {
  const key = req.get('x-hub-idem');
  if (!key || req.method === 'GET' || req.method === 'HEAD') return next();
  const file = path.join(IDEM_DIR, safeFilename(key) + '.json');
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (j && j.ts && Date.now() - j.ts < 24 * 60 * 60 * 1000) {
      res.setHeader('x-hub-idem-replay', '1');
      return res.status(j.status || 200).json(j.body);
    }
  } catch {}
  const origJson = res.json.bind(res);
  res.json = (body) => {
    try { fs.writeFileSync(file, JSON.stringify({ ts: Date.now(), status: res.statusCode || 200, body })); } catch {}
    return origJson(body);
  };
  next();
});

// ── tool metadata: local = offline via Ollama/llama.cpp; free = no paid API key needed; keyEnv = env var required for runtime; phone = works well on mobile/Termux ──
// Только реальные, официальные и бесплатные CLI-агенты + локальные рантаймы
// (sesori-bridge, ollama). Проверено по npm/pypi/GitHub: фейки, дубли,
// несуществующие пакеты и инструменты, требующие обязательной регистрации /
// платных ключей, убраны.
const TOOLS = [
  // ── free / local — работают без ключей или через локальные модели ──
  { id: 'opencode', name: 'OpenCode', cmd: 'opencode', pkg: 'opencode-ai', color: '#00d4aa', icon: 'OC', local: true, free: true, keyEnv: null, phone: true },
  { id: 'aider', name: 'Aider', cmd: 'aider', pkg: null, color: '#79c0ff', icon: 'AD', local: true, free: true, keyEnv: null, phone: true, hint: 'pip install aider-chat' },
  { id: 'openclaw', name: 'OpenClaw', cmd: 'openclaw', pkg: 'openclaw', color: '#f2c66d', icon: 'CW', local: true, free: true, keyEnv: null, phone: true },
  { id: 'continue', name: 'Continue CLI', cmd: 'cn', pkg: '@continuedev/cli', color: '#d2a8ff', icon: 'CN', local: true, free: true, keyEnv: null },
  { id: 'forge', name: 'Forge Code', cmd: 'forge', pkg: 'forge-code-ai', color: '#ffa657', icon: 'FO', local: true, free: true, keyEnv: null },
  { id: 'goose', name: 'Goose', cmd: 'goose', pkg: null, color: '#8b5cf6', icon: 'GS', local: true, free: true, keyEnv: null, phone: true, hint: 'curl -fsSL https://github.com/block/goose/releases/download/stable/download_cli.sh | bash' },
  { id: 'sgpt', name: 'ShellGPT', cmd: 'sgpt', pkg: null, color: '#3fb950', icon: 'SG', local: true, free: true, keyEnv: null, phone: true, hint: 'pip install shell-gpt' },
  { id: 'llm', name: 'LLM (SimonW)', cmd: 'llm', pkg: null, color: '#f778ba', icon: 'LM', local: true, free: true, keyEnv: null, hint: 'pip install llm' },
  { id: 'openhands', name: 'OpenHands', cmd: 'openhands', pkg: null, color: '#e6a23c', icon: 'OH', local: true, free: true, keyEnv: null, hint: 'uv tool install openhands --python 3.12' },
  { id: 'ollama', name: 'Ollama', cmd: 'ollama', pkg: null, color: '#bc8cff', icon: 'OL', local: true, free: true, keyEnv: null, phone: true, hint: 'curl -fsSL https://ollama.com/install.sh | sh' },
  { id: 'aish', name: 'AI Shell (offline)', cmd: 'aish', pkg: '@offline-ai/ai-shell', color: '#a5d6ff', icon: 'AH', local: true, free: true, keyEnv: null },
  { id: 'utim', name: 'UTIM', cmd: 'utim', pkg: '@emend-ai/utim', color: '#7ee787', icon: 'UT', local: true, free: true, keyEnv: null },
  { id: 'cli-agent', name: 'CLI Agent', cmd: 'agent', pkg: null, color: '#f59e0b', icon: 'CA', local: true, free: true, keyEnv: null },
  // ── sesori-bridge: установка через официальный скрипт (npm-пакета sesori нет) ──
  { id: 'sesori', name: 'Sesori', cmd: 'sesori-bridge', pkg: null, color: '#10b981', icon: 'SR', local: true, free: true, keyEnv: null, phone: true, hint: 'curl -fsSL https://sesori.com/install.sh | bash' }
];

const storage = new StorageManager();
const modelManager = new ModelManager();

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { return { lastDirs: {}, pathHistory: [], recentPaths: [] }; }
}
function saveState(s) { fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2)); }

// Persist the Android AVD choice instead of falling back to a different
// machine/environment default after every hub restart.
const DEFAULT_EMULATOR = 'pixel_7_api34';
const cleanEmulatorName = (value) => {
  const s = String(value || '').trim();
  return /^[A-Za-z0-9._-]{1,80}$/.test(s) ? s : null;
};
const getDefaultEmulator = () => {
  const state = loadState();
  return cleanEmulatorName(state.defaultEmulator) || cleanEmulatorName(process.env.ANDROID_AVD) || DEFAULT_EMULATOR;
};
const setDefaultEmulator = (value) => {
  const emulator = cleanEmulatorName(value);
  if (!emulator) return null;
  const state = loadState();
  state.defaultEmulator = emulator;
  saveState(state);
  return emulator;
};
const getDefaultPhoneRunner = () => {
  const state = loadState();
  return cleanEmulatorName(state.phoneRunner) || cleanEmulatorName(process.env.PHONE_RUNNER) || 'emulator';
};
const setDefaultPhoneRunner = (value) => {
  const runner = cleanEmulatorName(value);
  if (!runner) return null;
  const state = loadState();
  state.phoneRunner = runner;
  saveState(state);
  return runner;
};

function isInstalled(cmd) {
  const isWin = process.platform === 'win32';
  const safe = String(cmd).replace(/[;&|`$()]/g, '');
  try {
    require('child_process').execSync(`${isWin ? 'where' : 'which'} ${safe}`, { stdio: 'ignore', timeout: 3000 });
    return true;
  } catch { return false; }
}
function getVersion(cmd) {
  const safe = String(cmd).replace(/[;&|`$()]/g, '');
  try { return require('child_process').execSync(`${safe} --version`, { stdio: 'pipe', timeout: 5000 }).toString().trim().split('\n')[0]; }
  catch { return null; }
}

// Build version from the repo, survived of shallow clones: date.shortSha.
// Anything goes wrong → falls back to a readable "dev" stamp instead of dying.
let HUB_BUILD = null;
function hubBuildInfo() {
  if (HUB_BUILD) return HUB_BUILD;
  const run = args => {
    try {
      return require('child_process').execSync('git ' + args.join(' '), {
        cwd: path.join(__dirname, '..', '..'), encoding: 'utf8', timeout: 2500
      }).trim();
    } catch { return ''; }
  };
  const sha = run(['rev-parse', '--short', 'HEAD']);
  const when = run(['log', '-1', '--format=%cI']);
  const day = (when || '').slice(0, 10).replace(/-/g, '.');
  HUB_BUILD = { version: day && sha ? `${day}.${sha}` : 'dev', commit: sha || null, committedAt: when || null };
  return HUB_BUILD;
}

function getAccessInfo(req) {
  const addr = req.socket.remoteAddress || '';
  const isLocal = addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1' || addr === '';
  return { ip: addr.replace('::ffff:', ''), isLocal, mode: isLocal ? 'local' : 'remote', hostname: os.hostname() };
}

// ─── TOOLS ───
app.get('/api/tools', (req, res) => {
  const tools = TOOLS.map(t => ({ ...t, installed: isInstalled(t.cmd), version: null }));
  for (const t of tools) if (t.installed) t.version = getVersion(t.cmd);
  res.json({ success: true, warming: false, runId: process.env.GITHUB_RUN_ID || '', runNumber: process.env.GITHUB_RUN_NUMBER || '', tools });
});

// ─── TOOL INSTALL — one at a time, live log via polling ───
const installs = new Map(); // id -> { status, log, code }
app.post('/api/tools/install', (req, res) => {
  const t = TOOLS.find(x => x.id === (req.body && req.body.id));
  if (!t || !t.pkg) return res.json({ success: false, error: 'у этого инструмента нет npm-пакета' });
  const cur = installs.get(t.id);
  if (cur && cur.status === 'running') return res.json({ success: true, status: 'running' });
  for (const s of installs.values()) {
    if (s.status === 'running') return res.json({ success: false, error: 'уже идёт другая установка — дождись' });
  }
  const st = { status: 'running', log: '', code: null };
  installs.set(t.id, st);
  const push = d => {
    st.log += String(d);
    if (st.log.length > 200000) st.log = st.log.slice(-200000);
  };
  push('$ npm install -g ' + t.pkg + '\n');
  let child;
  try {
    child = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm',
      ['install', '-g', '--no-audit', '--no-fund', t.pkg],
      { shell: process.platform === 'win32' });
  } catch (e) { st.status = 'error'; push('\n✗ ' + e.message + '\n'); return res.json({ success: true, status: 'error' }); }
  child.stdout.on('data', push);
  child.stderr.on('data', push);
  child.on('error', e => { st.status = 'error'; push('\n✗ ' + e.message + '\n'); });
  child.on('close', code => {
    st.code = code;
    st.status = code === 0 ? 'done' : 'error';
    push(code === 0 ? '\n✓ готово\n' : '\n✗ ошибка, код ' + code + '\n');
  });
  res.json({ success: true, status: 'running' });
});
app.get('/api/tools/install-status', (req, res) => {
  const t = TOOLS.find(x => x.id === req.query.id);
  if (!t) return res.json({ success: false, error: 'нет такого инструмента' });
  const st = installs.get(t.id) || { status: 'idle', log: '' };
  const from = Math.max(0, parseInt(req.query.from || '0', 10) || 0);
  res.json({ success: true, status: st.status, log: st.log.slice(from), len: st.log.length, installed: isInstalled(t.cmd) });
});

// ─── TOOL TEST — проверка «а работает ли оно»: бинарь + нужен ли ключ ───
function hasToolKey(k) {
  if (!k) return true;
  if (process.env[k]) return true;
  if (k === 'OPENROUTER_API_KEY' && modelManager.getKeyForProvider('openrouter')) return true;
  if (k === 'GITHUB_TOKEN' && process.env.GH_TOKEN) return true;
  return false;
}
function probeTool(t) {
  const installed = isInstalled(t.cmd);
  const version = installed ? getVersion(t.cmd) : null;
  const needKey = !!(t.keyEnv && !hasToolKey(t.keyEnv));
  const ok = installed && !!version && !needKey;
  return { id: t.id, name: t.name, success: ok, installed, version, needKey, keyEnv: t.keyEnv || null, free: !!t.free, local: !!t.local };
}
app.get('/api/tools/test', (req, res) => {
  const t = TOOLS.find(x => x.id === req.query.id);
  if (!t) return res.json({ success: false, error: 'нет такого инструмента' });
  res.json(probeTool(t));
});
app.post('/api/tools/test', (req, res) => {
  const t = TOOLS.find(x => x.id === (req.body && req.body.id));
  if (!t) return res.json({ success: false, error: 'нет такого инструмента' });
  res.json(probeTool(t));
});

// ─── INFO ───
// The runner session clock, shared with the session relay (handoff): the
// GitHub Actions job that hosts this hub is killed at six hours without
// warning, so the panel has to show "how much left" - and the relay has to
// hand the work over before that happens. SESSION_LIMIT_MS/SESSION_STARTED_MS
// come from the workflow. A manual run (no env vars) has NO limit: only the
// workflow may set one, so the clock keeps "elapsed" only and never fabricates
// a 6h deadline + «осталось 0» for a process that outlived that window (e.g. a
// self-hosted runner).
const sessionClock = () => {
  const limitMs = parseInt(process.env.SESSION_LIMIT_MS || '0', 10) || 0;
  let startedMs = parseInt(process.env.SESSION_STARTED_MS || '0', 10);
  const uptimeStart = Date.now() - Math.round(process.uptime() * 1000);
  if (!startedMs || startedMs > Date.now() + 60000) {
    // No env, or a timestamp from the future — keep the uptime fallback.
    startedMs = uptimeStart;
  } else if (limitMs && Date.now() - startedMs > limitMs + 3600000) {
    // The workflow always writes a fresh session-start per run, but a
    // self-hosted runner may resume with leftovers from days ago. An elapsed
    // far beyond a limit that dies at ~6h can only be a stale timestamp:
    // reset to this process's own start instead of showing «осталось 0».
    startedMs = uptimeStart;
  }
  const elapsedMs = Math.max(0, Date.now() - startedMs);
  return { startedMs, limitMs, elapsedMs, remainingMs: limitMs ? Math.max(0, limitMs - elapsedMs) : null };
};

app.get('/api/info', (req, res) => {
  const state = loadState();
  state.defaultEmulator = getDefaultEmulator();
  state.phoneRunner = getDefaultPhoneRunner();
  const { startedMs, limitMs, elapsedMs, remainingMs } = sessionClock();
  res.json({ home: HOME, workDir: WORK_DIR, platform: process.platform, runId: process.env.GITHUB_RUN_ID || '', runNumber: process.env.GITHUB_RUN_NUMBER || '', ...hubBuildInfo(), ...getAccessInfo(req), state,
    alias: (HOST_ALIAS && hostAliasInstalled) ? { name: HOST_ALIAS, ip: HOST_ALIAS_IP, url: `http://${HOST_ALIAS}:${+process.env.PORT || PORT}` } : null,
    session: { startedMs, elapsedMs, limitMs, remainingMs } });
});

// ─── NETWORKS — all IPs for phone access ───
app.get('/api/networks', (req, res) => {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const [name, iface] of Object.entries(nets)) {
    for (const cfg of iface) {
      if (cfg.family === 'IPv4' && !cfg.internal) {
        ips.push({ name, address: cfg.address, url: `http://${cfg.address}:${PORT}` });
      }
    }
  }
  res.json({
    success: true, ips, port: +process.env.PORT || PORT, hostname: os.hostname(),
    alias: (HOST_ALIAS && hostAliasInstalled) ? { name: HOST_ALIAS, ip: HOST_ALIAS_IP, url: `http://${HOST_ALIAS}:${+process.env.PORT || PORT}` } : null
  });
});

// ─── STORAGE ───
app.get('/api/storages', (req, res) => {
  res.json({ success: true, storages: storage.listAll() });
});

app.post('/api/storages/add', (req, res) => {
  storage.addStorage(req.body).then(r => res.json(r)).catch(e => res.json({ success: false, error: e.message }));
});

app.post('/api/storages/remove', (req, res) => {
  storage.removeStorage(req.body.id).then(r => res.json(r)).catch(e => res.json({ success: false, error: e.message }));
});

// ─── DEVICES ───
app.get('/api/devices', async (req, res) => {
  try {
    const devices = await storage.discoverDevices();
    res.json({ success: true, devices });
  } catch (e) {
    res.json({ success: false, error: e.message, devices: [] });
  }
});

// ─── ADB ───
app.post('/api/adb/connect', (req, res) => {
  const { host, port } = req.body;
  const AdbStorage = require('./storage/adb');
  AdbStorage.connectTcp(host, port).then(r => res.json(r)).catch(e => res.json({ success: false, error: e.message }));
});

app.post('/api/adb/disconnect', (req, res) => {
  const AdbStorage = require('./storage/adb');
  AdbStorage.disconnect(req.body.deviceId).then(r => res.json(r)).catch(e => res.json({ success: false, error: e.message }));
});

app.get('/api/adb/info', (req, res) => {
  const deviceId = req.query.device;
  const AdbStorage = require('./storage/adb');
  const adb = new AdbStorage(deviceId);
  adb.getInfo().then(info => res.json({ success: true, info })).catch(e => res.json({ success: false, error: e.message }));
});

// ─── DRIVES ───
app.get('/api/drives', (req, res) => {
  const isWin = process.platform === 'win32';
  if (isWin) {
    try { const drives = require('child_process').execSync('wmic logicaldisk get name', { timeout: 3000 }).toString().trim().split('\n').slice(1).map(l => l.trim()).filter(l => l); res.json({ success: true, drives: drives.map(d => d + '\\') }); } catch { res.json({ success: true, drives: ['C:\\'] }); }
  } else {
    res.json({ success: true, drives: ['/'] });
  }
});

// ─── BROWSE (universal) ───
app.get('/api/browse', async (req, res) => {
  const backendId = req.query.backend || 'local';
  const dirPath = req.query.path || HOME;
  try {
    const backend = storage.get(backendId);
    const result = await backend.list(dirPath);
    res.json({ success: true, ...result, backend: backendId });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// ─── VAULT TREE — рекурсивный слепок рабочей папки для офлайн-зеркала ───
// Тот же фильтр, что и в файловом менеджере (без node_modules и dot-имён).
// Файлы крупнее 50 МБ в стек клиента не качаются — помечаются в «big».
const VAULT_MAX_BYTES = 50 * 1024 * 1024;
function vaultWalk(dir, depth, ctx) {
  if (depth > 128) return;
  let real;
  try { real = fs.realpathSync(dir); } catch (e) { return; }
  if (ctx.seen.has(real)) return;
  ctx.seen.add(real);
  let names;
  try { names = fs.readdirSync(dir); } catch (e) { return; }
  names.sort((a, b) => a.localeCompare(b));
  for (const n of names) {
    if (n === 'node_modules' || (n.startsWith('.') && n !== '..')) continue;
    const p = path.join(dir, n);
    let st;
    try { st = fs.lstatSync(p); } catch (e) { continue; }
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) {
      ctx.entries.push({ path: p, isDir: true, size: 0, mtime: st.mtime ? +st.mtime : 0 });
      vaultWalk(p, depth + 1, ctx);
    } else if (st.isFile()) {
      ctx.entries.push({ path: p, isDir: false, size: st.size, mtime: st.mtime ? +st.mtime : 0 });
      ctx.files++; ctx.totalBytes += st.size;
      if (st.size > VAULT_MAX_BYTES) ctx.big.push({ path: p, size: st.size });
    }
  }
}
app.get('/api/fs/tree', (req, res) => {
  const hubWork = path.join(HOME, 'hub-work');
  const defaultRoot = fs.existsSync(hubWork) ? hubWork : HOME;
  const startPath = req.query.path ? String(req.query.path) : defaultRoot;
  const ctx = { seen: new Set(), entries: [], big: [], files: 0, totalBytes: 0 };
  try {
    vaultWalk(startPath, 0, ctx);
    res.json({
      success: true, root: startPath, base: HOME, maxBytes: VAULT_MAX_BYTES,
      entries: ctx.entries, dirs: ctx.entries.length - ctx.files,
      files: ctx.files, totalBytes: ctx.totalBytes, big: ctx.big
    });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── FILE OPERATIONS (universal) ───
app.post('/api/fs/mkdir', async (req, res) => {
  try {
    const backend = storage.get(req.body.backend || 'local');
    await backend.mkdir(req.body.path);
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post('/api/fs/delete', async (req, res) => {
  try {
    const backend = storage.get(req.body.backend || 'local');
    await backend.delete(req.body.path);
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post('/api/fs/rename', async (req, res) => {
  try {
    const backend = storage.get(req.body.backend || 'local');
    await backend.rename(req.body.oldPath, req.body.newPath);
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post('/api/fs/read', async (req, res) => {
  try {
    const backend = storage.get(req.body.backend || 'local');
    const content = await backend.read(req.body.path);
    res.json({ success: true, content });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post('/api/fs/write', async (req, res) => {
  try {
    const backend = storage.get(req.body.backend || 'local');
    await backend.write(req.body.path, req.body.content);
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.get('/api/fs/download', async (req, res) => {
  try {
    const backend = storage.get(req.query.backend || 'local');
    const filename = path.basename(req.query.path).replace(/[\r\n"]/g, '_');
    const inline = req.query.inline === '1';
    res.setHeader('Content-Disposition', cdHeader(inline ? 'inline' : 'attachment', filename));
    res.setHeader('Content-Type', mimeForPath(filename));
    const data = await backend.readBinary(req.query.path);
    if (data === null || data === undefined) { res.end(); return; }
    res.end(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Inline view — the browser renders the file in a tab itself (image, PDF, video,
// audio, HTML, JSON, plain-text/code: any format). Same binary-safe read as
// download, but Content-Disposition: inline so nothing forced to save.
app.get('/api/fs/view', async (req, res) => {
  try {
    const backend = storage.get(req.query.backend || 'local');
    const filename = path.basename(req.query.path).replace(/[\r\n"]/g, '_');
    res.setHeader('Content-Disposition', cdHeader('inline', filename));
    res.setHeader('Cache-Control', 'no-cache');
    const data = await backend.readBinary(req.query.path);
    if (data === null || data === undefined) { res.end(); return; }
    // Serve code/text with utf-8; everything else keeps its own MIME from the map.
    const type = mimeForPath(filename);
    res.setHeader('Content-Type', type.startsWith('text/') || type === 'application/json'
      ? type + '; charset=utf-8' : type);
    res.end(data);
  } catch (e) { res.status(e.statusCode && 404 || 500).json({ error: e.message }); }
});

// Binary-safe upload: raw body (the file bytes) + target in ?path=. This is
// what the phone's SAF file picker and fmUpload() post to. It writes through
// the filesystem, so an APK keeps its bytes (the generic StorageBase backends
// deal in utf-8 text and would mangle a binary).
//
// `type: () => true` instead of `'*/*'`: a browser only sets Content-Type from
// File.type, and files with an unknown MIME type (Android SAF picks, drag&drop
// from some apps, unknown extensions) are POSTed with NO Content-Type at all.
// type-is then refuses to match, the raw parser skips the body, req.body stays
// an empty object and the old String()-based fallback wrote the 15-byte literal
// text "[object Object]" while still answering {success:true} — every such
// image landed on disk broken.
app.post('/api/fs/upload', express.raw({ type: () => true, limit: '200mb' }), async (req, res) => {
  try {
    const filePath = (req.query && req.query.path) || '';
    if (!filePath) return res.json({ success: false, error: 'укажи ?path=...' });
    if (!Buffer.isBuffer(req.body)) return res.json({ success: false, error: 'пустое тело запроса' });
    const buf = req.body;
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, buf);
    res.json({ success: true, size: buf.length });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── MODELS ───
app.get('/api/models', (req, res) => {
  const freeOnly = req.query.freeOnly === 'true';
  const models = modelManager.getAllModels(freeOnly);
  res.json({ success: true, models, selected: modelManager.getSelectedModel(), provider: modelManager.getSelectedProvider() });
});

app.get('/api/providers', (req, res) => {
  res.json({ success: true, providers: modelManager.getProviders() });
});

app.get('/api/models/full', (req, res) => {
  const models = modelManager.getModelsFull();
  const providers = modelManager.getProviders();
  res.json({ success: true, models, providers, selected: modelManager.getSelectedModel(), provider: modelManager.getSelectedProvider() });
});

app.post('/api/models/select', (req, res) => {
  const { modelId, providerId } = req.body;
  modelManager.selectModel(modelId, providerId);
  res.json({ success: true, selected: modelId, provider: providerId });
});

app.post('/api/models/key', (req, res) => {
  const { env, key } = req.body;
  modelManager.setKey(env, key);
  res.json({ success: true });
});

// Alias: /api/models/apikey — sets OPENROUTER_API_KEY
app.post('/api/models/apikey', (req, res) => {
  const { apiKey } = req.body;
  if (apiKey) modelManager.setKey('OPENROUTER_API_KEY', apiKey);
  res.json({ success: true });
});

app.post('/api/models/freeonly', (req, res) => {
  const { freeOnly } = req.body;
  modelManager.setFreeOnly(freeOnly);
  res.json({ success: true });
});

app.get('/api/models/current', (req, res) => {
  res.json({ success: true, model: modelManager.getSelectedModel(), apiKey: modelManager.getApiKey() });
});

// ─── PERSISTENT EMULATOR DEFAULT ───
app.get('/api/emulator/default', (req, res) => {
  res.json({ success: true, emulator: getDefaultEmulator(), runner: getDefaultPhoneRunner() });
});
app.post('/api/emulator/default', (req, res) => {
  const body = req.body || {};
  // Validate everything before persisting anything: a request that fails must
  // not half-apply (e.g. save the runner while rejecting the emulator).
  const emulator = cleanEmulatorName(body.emulator || body.avd);
  const runner = body.runner ? cleanEmulatorName(body.runner) : null;
  if (!emulator) return res.status(400).json({ success: false, error: 'некорректное имя эмулятора' });
  if (body.runner && !runner) return res.status(400).json({ success: false, error: 'некорректная метка cloud runner' });
  const savedEmulator = setDefaultEmulator(emulator);
  const savedRunner = runner ? setDefaultPhoneRunner(runner) : getDefaultPhoneRunner();
  res.json({ success: true, emulator: savedEmulator, runner: savedRunner });
});
app.get('/api/phone/runner', (req, res) => {
  res.json({ success: true, runner: getDefaultPhoneRunner() });
});
app.post('/api/phone/runner', (req, res) => {
  const runner = setDefaultPhoneRunner(req.body && req.body.runner);
  if (!runner) return res.status(400).json({ success: false, error: 'некорректная метка cloud runner' });
  res.json({ success: true, runner });
});

// ─── PATH HISTORY ───
app.post('/api/path-history', (req, res) => {
  const { p } = req.body;
  const state = loadState();
  if (!state.recentPaths) state.recentPaths = [];
  state.recentPaths = state.recentPaths.filter(x => x !== p);
  state.recentPaths.unshift(p);
  if (state.recentPaths.length > 50) state.recentPaths = state.recentPaths.slice(0, 50);
  saveState(state);
  res.json({ success: true, recentPaths: state.recentPaths });
});

app.get('/api/path-history', (req, res) => {
  const state = loadState();
  res.json({ success: true, recentPaths: state.recentPaths || [] });
});

app.post('/api/last-dir', (req, res) => {
  const { toolId, dir } = req.body;
  const state = loadState();
  if (!state.lastDirs) state.lastDirs = {};
  state.lastDirs[toolId] = dir;
  saveState(state);
  res.json({ success: true });
});

app.get('/api/last-dir/:toolId', (req, res) => {
  const state = loadState();
  res.json({ success: true, dir: state.lastDirs?.[req.params.toolId] || HOME });
});

// ─── AUTO-APPROVE TOGGLE ────────────────────────────────────────────────
// Persisted in STATE_FILE. When enabled, the hub writes /autoon into CLI
// agent sessions that support it (/autooff to disable), so builds run
// without manual confirmation on every tool call.
const AGENT_SUPPORTS_SLASH = new Set(['cli-agent', 'agent']);
app.get('/api/auto-approve', (req, res) => {
  const state = loadState();
  res.json({ success: true, enabled: !!state.autoApprove });
});
app.post('/api/auto-approve', (req, res) => {
  const enabled = !!req.body.enabled;
  const state = loadState();
  state.autoApprove = enabled;
  saveState(state);
  // Send command to every live agent session right now.
  for (const s of sessions.values()) {
    if (s.toolId && AGENT_SUPPORTS_SLASH.has(s.toolId)) {
      const cmd = (enabled ? '/autoon' : '/autooff') + '\r';
      if (s.tmux) tmuxInput(s.id, cmd);
      else if (s.pty) s.pty.write(cmd);
    }
  }
  res.json({ success: true, enabled });
});

// ─── NGROK TOKEN ───
const NGROK_TOKEN_FILE = path.join(HOME, '.npm-hub-ngrok-token');

app.get('/api/ngrok-token', (req, res) => {
  try {
    const token = fs.existsSync(NGROK_TOKEN_FILE) ? fs.readFileSync(NGROK_TOKEN_FILE, 'utf8').trim() : '';
    res.json({ success: true, token: token ? token.slice(0, 8) + '...' + token.slice(-4) : '' });
  } catch { res.json({ success: true, token: '' }); }
});

app.post('/api/ngrok-token', (req, res) => {
  const { token } = req.body;
  if (!token || typeof token !== 'string') return res.json({ success: false, error: 'No token' });
  try {
    fs.writeFileSync(NGROK_TOKEN_FILE, token.trim(), { mode: 0o600 });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── ARCHIVE: tar.xz download ───────────────────────────────────────────
// GET /api/fs/archive?path=/some/dir  → streams <basename>.tar.xz
// Folders are always packed as tar.xz — never renamed to a different ext.
app.get('/api/fs/archive', (req, res) => {
  const filePath = req.query.path;
  if (!filePath || !fs.existsSync(filePath)) return res.status(404).json({ error: 'path not found' });
  const stat = fs.statSync(filePath);
  const basename = path.basename(filePath);
  const isDir = stat.isDirectory();
  const name = safeFilename(basename) + '.tar.xz';

  const { spawn } = require('child_process');
  res.setHeader('Content-Type', 'application/x-xz');
  res.setHeader('Content-Disposition', cdHeader('attachment', name));
  res.removeHeader('Content-Length');

  const dir = isDir ? path.dirname(filePath) : path.dirname(filePath);
  const target = isDir ? path.basename(filePath) : path.basename(filePath);
  let child;
  try {
    child = spawn('tar', ['-cJf', '-', target], { cwd: dir, stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (e) {
    if (!res.headersSent) res.status(500).json({ error: e.message });
    return;
  }
  child.stdout.pipe(res);
  child.stderr.on('data', () => {});
  child.on('error', () => {
    if (!res.headersSent) res.status(500).json({ error: 'tar failed' });
  });
  req.on('close', () => { try { child.kill(); } catch {} });
});

// ─── GITHUB SAVE (session-state branch) ───────────────────────────────
// POST /api/gh/save  { path: "/tmp/foo.apk" }
// Saves a file or directory to the session-state branch under artifacts/.
// GitHub Contents API handles single files only: directories are packed to
// <name>-<ts>.tar.xz first, oversized sources become a tar.xz too (the API
// refuses files over 100 MB) — so the branch always receives one binary file.
// Requires GH_TOKEN env or PAT in body.
app.post('/api/gh/save', express.json({ limit: '50mb' }), async (req, res) => {
  const filePath = req.body && req.body.path;
  if (!filePath || !fs.existsSync(filePath)) return res.json({ success: false, error: 'path not found' });
  const token = process.env.GH_TOKEN || (req.body && req.body.token) || '';
  if (!token) return res.json({ success: false, error: 'GH_TOKEN not set; pass token in body or set env' });

  const repo = process.env.GITHUB_REPOSITORY || 'sj0404-collab/zen-panel';
  const branch = 'session-state';
  const stat = fs.statSync(filePath);
  const isDir = stat.isDirectory();
  const basename = path.basename(filePath);
  const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
  let uploadFile = filePath;
  let uploadName = basename;

  try {
    if (isDir || stat.size > 90 * 1024 * 1024) {
      const ext = isDir ? 'tar.xz' : (path.extname(filePath) || '.bin');
      const tmp = path.join(TMP_DIR, `gsave-${Date.now()}-${basename.replace(/[^\w.-]/g, '_')}-${stamp}.${ext}`);
      const packaged = isDir
        ? await tarXz(filePath, tmp)
        : await new Promise((resolve) => {
            const gz = tmp.replace(/\.bin$/, '.tar.xz');
            try { resolve(tarXz(filePath, gz)); } catch { resolve(false); }
          });
      if (!packaged) return res.json({ success: false, error: 'не смог упаковать в tar.xz' });
      uploadFile = tmp;
      uploadName = `${basename}-${stamp}.tar.xz`;
    }
    const data = fs.readFileSync(uploadFile);
    if (data.length > 97 * 1024 * 1024) {
      return res.json({ success: false, error: 'этот файл больше лимита GitHub (97 МБ) и как архив тоже. Скачай его кнопкой «на телефон».' });
    }
    const content = data.toString('base64');
    const target = `artifacts/${uploadName}`;
    const apiUrl = `https://api.github.com/repos/${repo}/contents/${target}`;
    // Check if file exists (to get sha for overwrite)
    let sha = '';
    try {
      const existing = await fetch(apiUrl + `?ref=${branch}`, {
        headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' }
      });
      if (existing.ok) { const j = await existing.json(); sha = j.sha || ''; }
    } catch {}

    const body = { message: `save ${uploadName} (${new Date().toISOString()})`, content, branch };
    if (sha) body.sha = sha;

    const result = await fetch(apiUrl, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!result.ok) {
      const errText = await result.text().catch(() => '');
      return res.json({ success: false, error: `GitHub API ${result.status}: ${errText.slice(0, 200)}` });
    }

    const rawUrl = `https://raw.githubusercontent.com/${repo}/${branch}/${target}`;
    return res.json({ success: true, url: rawUrl, api_url: apiUrl, packed: isDir || stat.size > 90 * 1024 * 1024 });
  } catch (e) {
    return res.json({ success: false, error: e.message });
  }
});

// GET /api/gh/artifacts — list files in artifacts/ on session-state branch
app.get('/api/gh/artifacts', async (req, res) => {
  const token = process.env.GH_TOKEN || '';
  if (!token) return res.json({ success: true, files: [] });
  const repo = process.env.GITHUB_REPOSITORY || 'sj0404-collab/zen-panel';
  const branch = 'session-state';
  try {
    const r = await fetch(
      `https://api.github.com/repos/${repo}/contents/artifacts?ref=${branch}`,
      { headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' } }
    );
    if (!r.ok) return res.json({ success: true, files: [] });
    const items = await r.json();
    const files = (Array.isArray(items) ? items : []).map(i => ({
      name: i.name, size: i.size, url: i.download_url, sha: i.sha
    }));
    return res.json({ success: true, files });
  } catch { return res.json({ success: true, files: [] }); }
});

// ─── RUNNER: backup / stop / restart ────────────────────────────────────
// Runs inside a GitHub Actions launch, so process.env carries the run's own
// identity (GITHUB_*). Locally (pc-local) those are absent and the endpoints
// answer `actions:false` — the buttons are then disabled in the UI.
const ghApi = async (method, url, token, body) => {
  let r;
  try {
    r = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {})
      },
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (e) { return { status: 0, error: e.message, j: null }; }
  let j = null;
  try { j = await r.json(); } catch {}
  return { status: r.status, j };
};

const runnerEnv = () => {
  const onActions = !!process.env.GITHUB_RUN_ID;
  const wfRef = process.env.GITHUB_WORKFLOW_REF || '';
  const file = (wfRef.match(/\.github\/workflows\/([^@/]+)/) || [])[1] || '';
  return {
    actions: onActions,
    repo: process.env.GITHUB_REPOSITORY || '',
    workflow: process.env.GITHUB_WORKFLOW || '',
    workflowFile: file,
    runId: process.env.GITHUB_RUN_ID || '',
    runNumber: process.env.GITHUB_RUN_NUMBER || '',
    attempt: process.env.GITHUB_RUN_ATTEMPT || '',
    ref: (process.env.GITHUB_REF || 'main').replace(/^refs\/heads\//, ''),
    os: process.env.RUNNER_OS || process.platform,
    workspace: process.env.GITHUB_WORKSPACE || '',
    hostname: os.hostname(),
    home: HOME,
    workDir: WORK_DIR,
    tunnel: (tunnelInfo && tunnelInfo.state === 'ready' && tunnelInfo.url) || null,
    uptimeSec: Math.round(process.uptime())
  };
};

// Size of a directory, via du (fast) with a Node fallback.
const dirSize = (p) => new Promise((resolve) => {
  const isWin = process.platform === 'win32';
  const child = isWin
    ? spawn('powershell', ['-NoProfile', '-Command',
        `(Get-ChildItem -LiteralPath '${String(p).replace(/'/g, "''")}' -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum`],
        { stdio: ['ignore', 'pipe', 'pipe'] })
    : spawn('du', ['-sb', p], { stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  child.stdout.on('data', d => { out += String(d); });
  child.on('error', () => resolve(null));
  child.on('close', () => {
    const n = parseInt(out.replace(/\s.*$/, '').replace(/[^\d]/g, ''), 10);
    resolve(Number.isFinite(n) ? n : null);
  });
});

const GITHUB_BASE = (repo) => `https://api.github.com/repos/${repo || process.env.GITHUB_REPOSITORY || 'sj0404-collab/zen-panel'}`;

const runnerToken = () => process.env.GH_TOKEN || process.env.GITHUB_TOKEN || '';

// Everything the backup may touch — keep it to places the user actually works.
const runnerRoot = (p) => {
  const roots = [WORK_DIR];
  if (process.env.GITHUB_WORKSPACE) roots.push(process.env.GITHUB_WORKSPACE);
  const resolved = path.resolve(String(p || ''));
  return roots.some(r => r && (resolved === r || resolved.startsWith(r + path.sep)));
};

// APKs (a single file, kept a file) and heavy top-level folders (→ tar.xz).
const scanRunnerFiles = async () => {
  const apks = [];
  const folders = [];
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (!e || e.name.startsWith('.') || e.name === 'node_modules' || e.name === '__pycache__') continue;
      const full = path.join(dir, e.name);
      try {
        if (e.isDirectory()) {
          if (depth < 3) walk(full, depth + 1);
        } else if (/\.apk$/i.test(e.name)) {
          const st = fs.statSync(full);
          apks.push({ name: e.name, path: full, size: st.size, isDir: false });
        }
      } catch {}
    }
  };
  walk(WORK_DIR, 0);
  if (process.env.GITHUB_WORKSPACE && process.env.GITHUB_WORKSPACE !== WORK_DIR) walk(process.env.GITHUB_WORKSPACE, 0);
  // Heavy folders in the work dir (hub-work itself first, then its children).
  const sizes = [];
  for (const d of [WORK_DIR, ...(function () {
    const out = [];
    try { for (const e of fs.readdirSync(WORK_DIR, { withFileTypes: true })) if (e.isDirectory()) out.push(path.join(WORK_DIR, e.name)); } catch {}
    return out;
  })()]) {
    if (d === WORK_DIR || !['.git', 'node_modules'].some(x => d.endsWith(path.sep + x) || d.endsWith('/' + x))) {
      const s = await dirSize(d);
      if (s != null && s > 20 * 1024 * 1024) sizes.push({ name: d === WORK_DIR ? 'hub-work' : path.basename(d), path: d, size: s, isDir: true });
    }
  }
  sizes.sort((a, b) => b.size - a.size);
  folders.push(...sizes.slice(0, 12));
  return { apks: apks.slice(0, 30), folders };
};

app.get('/api/runner', async (req, res) => {
  try {
    const env = runnerEnv();
    const scan = env.actions ? await scanRunnerFiles() : { apks: [], folders: [] };
    res.json({ success: true, ...env, ...scan });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// POST /api/runner/backup  { items: [{ path, dest: 'phone'|'branch'|'keep' }] }
//   phone  → client downloads (file → /api/fs/download, dir → /api/fs/archive)
//   branch → pack dirs to <name>-backup-<ts>.tar.xz, files stay as-is, push to
//            the session-state branch under artifacts/ (GitHub Contents API)
//   keep   → leave in place (implicit)
app.post('/api/runner/backup', express.json({ limit: '5mb' }), async (req, res) => {
  const items = (req.body && Array.isArray(req.body.items) ? req.body.items : [])
    .filter(i => i && typeof i.path === 'string');
  if (!items.length) return res.json({ success: true, results: [] });
  const token = runnerToken();
  const repo = process.env.GITHUB_REPOSITORY || '';
  const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
  const results = [];
  for (const it of items) {
    const p = it.path;
    const entry = { path: p, ok: false };
    if (!runnerRoot(p)) { entry.error = 'путь вне рабочих папок'; results.push(entry); continue; }
    let st;
    try { st = fs.statSync(p); } catch { entry.error = 'путь не найден'; results.push(entry); continue; }
    const isDir = st.isDirectory();
    const base = path.basename(p) || 'folder';
    entry.isDir = isDir; entry.name = base; entry.size = isDir ? null : st.size;
    const dest = it.dest === 'phone' ? 'phone' : it.dest === 'branch' ? 'branch' : 'keep';
    entry.action = dest;
    if (dest === 'phone' || dest === 'keep') { entry.ok = true; results.push(entry); continue; }
    try {
      let archivePath = p;
      let uploadName = base;
      if (isDir) {
        const tmp = path.join(TMP_DIR, `zbak-${Date.now()}-${base.replace(/[^\w.-]/g, '_')}.tar.xz`);
        if (!await tarXz(p, tmp)) { entry.error = 'tar не смог упаковать (нет xz?)'; results.push(entry); continue; }
        archivePath = tmp;
        uploadName = `${base}-backup-${stamp}.tar.xz`;
      }
      const buf = fs.readFileSync(archivePath);
      if (buf.length > 90 * 1024 * 1024) {
        entry.error = 'слишком большой для ветки (>90 МБ) — выбери «на телефон»';
        results.push(entry);
        continue;
      }
      if (!token) { entry.error = 'нет GH_TOKEN — вставь gh_token в запуске хаба'; results.push(entry); continue; }
      const target = `artifacts/${uploadName}`;
      let sha = '';
      const existing = await ghApi('GET', `${GITHUB_BASE(repo)}/contents/${target}?ref=session-state`, token);
      if (existing.status === 200 && existing.j && existing.j.sha) sha = existing.j.sha;
      const put = await ghApi('PUT', `${GITHUB_BASE(repo)}/contents/${target}`, token, {
        message: `backup ${uploadName} (${stamp})`,
        content: buf.toString('base64'),
        branch: 'session-state',
        ...(sha ? { sha } : {})
      });
      if (put.status >= 200 && put.status < 300) {
        entry.ok = true;
        entry.size = buf.length;
        entry.url = `https://raw.githubusercontent.com/${repo || 'sj0404-collab/zen-panel'}/session-state/${target}`;
      } else {
        entry.error = `GitHub ${put.status}${put.j && put.j.message ? ' ' + put.j.message : ''}`;
      }
    } catch (e) { entry.error = e.message; }
    results.push(entry);
  }
  res.json({ success: true, results });
});

// Pack a path into a .tar.xz (falls back to .tar.gz) — returns the ext, or null.
const tarXz = (p, out) => new Promise((resolve) => {
  const dir = path.dirname(p);
  const target = path.basename(p);
  let child;
  try {
    child = spawn('tar', ['-cJf', out, target], { cwd: dir, stdio: ['ignore', 'pipe', 'pipe'] });
  } catch { return resolve(false); }
  child.stderr.on('data', () => {});
  child.on('error', () => resolve(false));
  child.on('close', (code) => {
    if (code === 0) return resolve(true);
    const gz = out.replace(/\.tar\.xz$/, '.tar.gz');
    let gc;
    try { gc = spawn('tar', ['-czf', gz, target], { cwd: dir, stdio: ['ignore', 'pipe', 'pipe'] }); } catch { return resolve(false); }
    gc.stderr.on('data', () => {});
    gc.on('error', () => resolve(false));
    gc.on('close', (c) => {
      if (c === 0) {
        try { fs.renameSync(gz, out); return resolve(true); } catch { return resolve(false); }
      }
      resolve(false);
    });
  });
});

app.post('/api/runner/stop', async (req, res) => {
  const env = runnerEnv();
  if (!env.actions || !env.runId) return res.json({ success: false, actions: false, error: 'не на Actions-раннере' });
  const token = runnerToken();
  if (!token) return res.json({ success: false, error: 'нет токена для остановки' });
  const r = await ghApi('POST', `${GITHUB_BASE(env.repo)}/actions/runs/${env.runId}/cancel`, token);
  res.json({ success: r.status === 202 || r.status === 409, status: r.status, runId: env.runId, repo: env.repo });
});

app.post('/api/runner/restart', async (req, res) => {
  const env = runnerEnv();
  if (!env.actions || !env.runId) return res.json({ success: false, actions: false, error: 'не на Actions-раннере' });
  if (!env.workflowFile) return res.json({ success: false, error: 'неизвестен workflow-файл' });
  const token = runnerToken();
  if (!token) return res.json({ success: false, error: 'нет токена для перезапуска' });
  // A fresh dispatch with the inputs we know (os + gh_token). The old run is
  // cancelled in the background — GitHub can take minutes to actually kill it.
  const dispatch = await ghApi(
    'POST', `${GITHUB_BASE(env.repo)}/actions/workflows/${env.workflowFile}/dispatches`, token,
    { ref: env.ref, inputs: {
      os: process.platform === 'win32' ? 'windows' : 'linux',
      label: process.env.HUB_LABEL || 'hub',
      token: process.env.HUB_TOKEN || '',
      gh_token: token,
      replace: true
    } });
  let cancelOld = false;
  if (dispatch.status >= 200 && dispatch.status < 300) {
    const c = await ghApi('POST', `${GITHUB_BASE(env.repo)}/actions/runs/${env.runId}/cancel`, token);
    cancelOld = c.status === 202 || c.status === 409;
  }
  res.json({ success: dispatch.status >= 200 && dispatch.status < 300, status: dispatch.status, mode: 'dispatch', workflow: env.workflowFile, ref: env.ref, repo: env.repo, cancelOld });
});

// ─── ЭСТАФЕТА СЕССИИ: передать работу новому раннеру ────────────────────
// WHAT
//   The rules live in ./handoff.js (unit-tested, no I/O). This block is the
//   hands: it runs the durable save (tools/handoff.sh), launches the successor
//   workflow, waits until the successor has really published itself and only
//   then lets this runner step aside. A failed save or a successor that never
//   appears leaves the user exactly where they were - that is the whole point.
//
// WHERE THE SETTINGS LIVE
//   handoff.json on the session-state branch of the control repo: the limits
//   must outlive the runner they were set on (that is the entire premise of a
//   relay), and the panel has to be able to read and write them without a
//   runner at all. Locally (pc-local) the same file is kept under ~/.npm-hub.
const { createHandoff, normalizePolicy } = require('./handoff');
const HANDOFF_SH = path.join(__dirname, '..', '..', 'tools', 'handoff.sh');
// The branch is organised in folders now: live/ holds what is alive (session
// descriptors + the relay's own state), models/ the roster, snapshots/ the
// audit+code pair, history/<date>/<weekday>/ everything historical. The old
// flat name is still read, so a branch that was never migrated works.
const HANDOFF_FILE = 'live/handoff.json';
const HANDOFF_FILE_LEGACY = 'handoff.json';
const HANDOFF_LOCAL = path.join(DATA_DIR, HANDOFF_FILE);
const HANDOFF_TICK_MS = 15000;
const HANDOFF_SLOT = process.env.HUB_SLOT || 'hub-linux';

let handoff = null;          // created below, once sessionClock() is available
let handoffPolicy = normalizePolicy({});
let handoffDocSha = '';
let handoffDocPath = '';
let handoffSavedIn = 'local';
let handoffBusy = false;
let handoffStatusAt = 0;
let handoffStatusDirty = true;

const handoffLog = (msg) => {
  const line = `[handoff ${new Date().toISOString()}] ${msg}\n`;
  console.log(line.trim());
  try { fs.appendFileSync(path.join(LOG_DIR, 'handoff.log'), line); } catch {}
};

const handoffCapability = () => {
  if (!process.env.GITHUB_RUN_ID) return { available: false, reason: 'локальный запуск: передавать некуда' };
  if (!runnerToken()) return { available: false, reason: 'нет токена GitHub: нечем сохранить и запустить следующий раннер' };
  if (!fs.existsSync(HANDOFF_SH)) return { available: false, reason: 'нет tools/handoff.sh в этом checkout' };
  if (!process.env.GITHUB_WORKFLOW_REF) return { available: false, reason: 'неизвестен workflow: нечем запустить следующий раннер' };
  return { available: true, reason: '' };
};

// ── the global settings file ──
const handoffReadDoc = async () => {
  const token = runnerToken();
  if (token && process.env.GITHUB_REPOSITORY) {
    for (const name of [HANDOFF_FILE, HANDOFF_FILE_LEGACY]) {
      const r = await ghApi('GET', `${GITHUB_BASE(process.env.GITHUB_REPOSITORY)}/contents/${name}?ref=session-state&t=${Date.now()}`, token);
      if (r.status === 200 && r.j && r.j.content) {
        handoffDocSha = r.j.sha || '';
        handoffDocPath = name;
        try { return { doc: JSON.parse(Buffer.from(String(r.j.content).replace(/\n/g, ''), 'base64').toString('utf8')), where: 'repo' }; } catch {}
      }
    }
  }
  try { return { doc: JSON.parse(fs.readFileSync(HANDOFF_LOCAL, 'utf8')), where: 'local' }; } catch {}
  return { doc: null, where: 'none' };
};

// Merge, never clobber: the panel writes the policy while the runner writes
// the live status, and both go through the same file. A 409 means somebody
// committed in between - re-read once and try again.
const handoffWriteDoc = async (patch) => {
  const nowIso = new Date().toISOString();
  for (let attempt = 0; attempt < 2; attempt++) {
    const cur = await handoffReadDoc();
    const doc = Object.assign({}, cur.doc && typeof cur.doc === 'object' ? cur.doc : {}, patch, { updatedAt: nowIso });
    const token = runnerToken();
    if (token && process.env.GITHUB_REPOSITORY) {
      const body = { message: `handoff ${patch.policy ? 'policy' : 'status'} ${nowIso}`, content: Buffer.from(JSON.stringify(doc, null, 2), 'utf8').toString('base64'), branch: 'session-state' };
      if (handoffDocSha) body.sha = handoffDocSha;
      const put = await ghApi('PUT', `${GITHUB_BASE(process.env.GITHUB_REPOSITORY)}/contents/${handoffDocPath || HANDOFF_FILE}`, token, body);
      if (put.status >= 200 && put.status < 300) { handoffSavedIn = 'repo'; return { ok: true, where: 'repo' }; }
      if (put.status === 409 || put.status === 422) { handoffDocSha = ''; continue; }
      handoffLog(`could not write ${HANDOFF_FILE} to GitHub: ${put.status}`);
    }
    try {
      fs.mkdirSync(path.dirname(HANDOFF_LOCAL), { recursive: true });
      fs.writeFileSync(HANDOFF_LOCAL, JSON.stringify(doc, null, 2));
      handoffSavedIn = 'local';
      return { ok: true, where: 'local' };
    } catch (e) { return { ok: false, error: e.message }; }
  }
  return { ok: false, error: 'не удалось записать настройки' };
};

const handoffStatusBody = () => ({
  ...handoff.status(),
  savedIn: handoffSavedIn,
  session: sessionClock()
});

const handoffPublishStatus = async (force) => {
  if (!handoff) return;
  const now = Date.now();
  // A running handoff republishes every minute so the panel can render the
  // countdown; an idle runner only every five minutes, since a status write is
  // a real commit to the control repo.
  const gap = handoff.state === 'idle' ? 300000 : 60000;
  if (!force && !handoffStatusDirty && now - handoffStatusAt < gap) return;
  handoffStatusDirty = false;
  handoffStatusAt = now;
  const r = await handoffWriteDoc({ status: handoffStatusBody(), policy: handoff.policy });
  if (!r.ok) handoffLog('status not published: ' + (r.error || 'unknown'));
};

// ── step 1: the durable save ──
const handoffSave = () => new Promise((resolve) => {
  const startedIso = new Date(sessionClock().startedMs).toISOString();
  const env = Object.assign({}, process.env, {
    GH_TOKEN: runnerToken(),
    GITHUB_TOKEN: runnerToken(),
    HUB_LOGS: LOG_DIR,
    HANDOFF_SLOT,
    HANDOFF_KIND: 'NPM-Hub',
    HANDOFF_LABEL: process.env.HUB_LABEL || 'handoff',
    HANDOFF_URL: (tunnelInfo && tunnelInfo.state === 'ready' && tunnelInfo.url) || '',
    HANDOFF_STARTED_AT: startedIso,
    WORK_BACKUP_ROOT: HOME
  });
  handoffLog(`saving before the handover (${startedIso})`);
  let out = '';
  let child;
  try {
    child = spawn('bash', [HANDOFF_SH], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (e) { return resolve({ ok: false, error: e.message }); }
  const timer = setTimeout(() => { try { child.kill(); } catch {} }, 9 * 60000);
  child.stdout.on('data', d => { out += String(d); handoffLog(String(d).trim()); });
  child.stderr.on('data', d => { out += String(d); });
  child.on('error', e => { clearTimeout(timer); resolve({ ok: false, error: e.message }); });
  child.on('close', code => {
    clearTimeout(timer);
    if (code === 0) return resolve({ ok: true, out });
    const lines = out.trim().split('\n').map(s => s.trim()).filter(Boolean);
    resolve({ ok: false, error: (lines[lines.length - 1] || `tools/handoff.sh завершился с кодом ${code}`).slice(0, 300) });
  });
});

// ── step 2: launch the successor ──
// replace stays FALSE and handoff=true: the concurrency group must NOT cancel
// this run, because the successor is the one that decides when we step aside
// (after it has published itself). A panel-driven "заменить" still cancels.
const handoffDispatch = async () => {
  const env = runnerEnv();
  if (!env.actions) return { ok: false, error: 'не на Actions-раннере' };
  if (!env.workflowFile) return { ok: false, error: 'неизвестен workflow-файл' };
  const token = runnerToken();
  if (!token) return { ok: false, error: 'нет токена для запуска' };
  const r = await ghApi('POST', `${GITHUB_BASE(env.repo)}/actions/workflows/${env.workflowFile}/dispatches`, token, {
    ref: env.ref,
    inputs: {
      os: process.platform === 'win32' ? 'windows' : 'linux',
      label: process.env.HUB_LABEL || 'hub',
      token: process.env.HUB_TOKEN || '',
      gh_token: token,
      replace: false,
      handoff: true,
      handoff_from: process.env.GITHUB_RUN_ID || ''
    }
  });
  if (r.status < 200 || r.status >= 300) {
    return { ok: false, error: `GitHub ${r.status}${r.j && r.j.message ? ' ' + r.j.message : ''}` };
  }
  handoffLog(`successor dispatched (${env.workflowFile}, run of ${thisRunId()})`);
  return { ok: true, runId: thisRunId(), url: '' };
};

const thisRunId = () => String(process.env.GITHUB_RUN_ID || '');

// ── step 3: did the successor really show up? ──
// The session descriptor is owned by the newest run (publish_session.sh keeps
// startedAt and refuses older runs), so a different, live runId there IS the
// successor - and it is also what the panel switches to.
const handoffSuccessor = async () => {
  const token = runnerToken();
  if (!token || !process.env.GITHUB_REPOSITORY) return null;
  let d = null;
  for (const name of [`live/session-${HANDOFF_SLOT}.json`, `session-${HANDOFF_SLOT}.json`]) {
    const r = await ghApi('GET', `${GITHUB_BASE(process.env.GITHUB_REPOSITORY)}/contents/${name}?ref=session-state&t=${Date.now()}`, token);
    if (r.status !== 200 || !r.j || !r.j.content) continue;
    try { d = JSON.parse(Buffer.from(String(r.j.content).replace(/\n/g, ''), 'base64').toString('utf8')); } catch { d = null; }
    if (d) break;
  }
  if (!d) return null;
  if (!d || d.state === 'ended') return null;
  if (String(d.runId || '') === thisRunId() || !d.runId) return null;
  if (!d.startedAt || Date.parse(d.startedAt) <= sessionClock().startedMs) return null;
  return d;
};

// ── step 4: this runner steps aside ──
const handoffStepAside = async () => {
  handoffLog('the successor is live - this runner is stepping aside');
  try { fs.writeFileSync(path.join(LOG_DIR, 'handoff-done'), String(Date.now())); } catch {}
  await handoffPublishStatus(true);
  handoffLog('exiting in 2s; the panel follows the new runner');
  setTimeout(() => process.exit(0), 2000);
};

// ── the watchdog ──
const handoffRunSave = async () => {
  handoffLog('saving before the handover');
  await handoffPublishStatus(true);
  const r = await handoffSave();
  if (r.ok) { handoff.saveOk(); handoffLog('save ok - countdown armed'); }
  else { handoff.saveFail(new Error(r.error)); handoffLog('save FAILED - staying alive: ' + r.error); }
  handoffStatusDirty = true;
  await handoffPublishStatus(true);
};

const handoffRunDispatch = async () => {
  await handoffPublishStatus(true);
  const r = await handoffDispatch();
  if (r.ok) handoff.dispatchOk({ runId: r.runId, url: r.url });
  else { handoff.dispatchFail(new Error(r.error)); handoffLog('dispatch FAILED - staying alive: ' + r.error); }
  handoffStatusDirty = true;
  await handoffPublishStatus(true);
};

const handoffTick = async () => {
  if (!handoff || handoffBusy) return;
  if (!handoffCapability().available) return;
  handoffBusy = true;
  try {
    // While we wait for the successor, the only thing worth doing is looking
    // for it: the module's tick cannot know about the network.
    if (handoff.state === 'standby') {
      const next = await handoffSuccessor();
      if (next) {
        handoff.successorSeen(next.runId, next.url || next.hubUrl || '');
        handoffStatusDirty = true;
        await handoffPublishStatus(true);
        await handoffStepAside();
        return;
      }
    }
    const action = handoff.tick();
    if (action && action.type === 'save') {
      handoffLog(`save requested${action.reason ? ' (' + action.reason + ')' : ''}`);
      await handoffRunSave();
    } else if (action && action.type === 'dispatch') {
      handoffLog('countdown is over - launching the successor');
      await handoffRunDispatch();
    }
    if (handoff.state === 'stopping') { await handoffStepAside(); return; }
    await handoffPublishStatus(false);
  } catch (e) {
    handoffLog('tick failed: ' + e.message);
  } finally {
    handoffBusy = false;
  }
};

// The relay itself, with the limits that were saved last time.
handoff = createHandoff({ startedAtMs: sessionClock().startedMs, policy: handoffPolicy });
setInterval(handoffTick, HANDOFF_TICK_MS).unref();

// Load the global limits at boot; a failure only costs the defaults.
handoffReadDoc().then(({ doc, where }) => {
  if (doc && doc.policy) {
    handoffPolicy = normalizePolicy(doc.policy);
    handoff.setPolicy(handoffPolicy);
    handoffSavedIn = where === 'repo' ? 'repo' : 'local';
    handoffLog(`limits loaded from ${where}: ${JSON.stringify(handoffPolicy)}`);
  } else if (where === 'local' || where === 'repo') {
    handoffSavedIn = where;
  }
  handoffStatusDirty = true;
}).catch(() => {});

app.get('/api/handoff', (req, res) => {
  res.json({ success: true, capability: handoffCapability(), policy: handoff.policy, status: handoffStatusBody() });
});

// The limits are GLOBAL: they are written to the control repo, so the runner
// that takes over next already knows them before the panel is opened.
app.post('/api/handoff/policy', express.json({ limit: '32kb' }), async (req, res) => {
  try {
    const policy = handoff.setPolicy((req.body && req.body.policy) || req.body || {});
    handoffPolicy = policy;
    // The status travels with the policy in the same write: the panel reads one
    // file, and a freshly created handoff.json should not look "empty".
    const saved = await handoffWriteDoc({ policy, status: handoffStatusBody() });
    handoffStatusDirty = false;
    handoffStatusAt = Date.now();
    res.json({ success: !!saved.ok, savedIn: saved.ok ? saved.where : 'local', error: saved.error || '', policy, status: handoffStatusBody() });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post('/api/handoff/start', async (req, res) => {
  const cap = handoffCapability();
  if (!cap.available) return res.json({ success: false, ...cap, status: handoffStatusBody() });
  const action = handoff.request('manual');
  handoffStatusDirty = true;
  const started = !!(action && action.type === 'save');
  // The save takes minutes (backup + push); answer at once and let the UI watch
  // /api/handoff instead of holding the request open.
  if (started) handoffRunSave().catch(e => handoffLog('manual save failed: ' + e.message));
  res.json({ success: true, started, status: handoffStatusBody() });
});

app.post('/api/handoff/continue', async (req, res) => {
  const r = handoff.continueWork();
  handoffStatusDirty = true;
  await handoffPublishStatus(true);
  res.json({ success: true, cancelled: r.cancelled, status: handoffStatusBody() });
});


// Repo discovery (declared BEFORE GIT_ROOT below: the GIT_ROOT IIFE runs at
// module load and calls it - a const declared later is in the temporal dead
// zone there, and the server died at startup with
// "Cannot access 'repoCandidates' before initialization" on any machine
// without GITHUB_WORKSPACE in the environment, i.e. every local run).
const repoCandidates = () => {
  const found = [];
  const walk = (dir, depth) => {
    if (depth > 3 || found.length) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (!e.isDirectory() || e.name.startsWith('.') || e.name === 'node_modules' || e.name === 'actions-runner') continue;
      if (fs.existsSync(path.join(dir, e.name, '.git'))) {
        found.push(path.join(dir, e.name));
        return;
      }
      if (depth < 3) walk(path.join(dir, e.name), depth + 1);
    }
  };
  walk(WORK_DIR, 1);
  return found;
};

// This repository root: the runner checkout (workspace/fork) when on Actions,
// otherwise the first repo discovered in the work dir.
const GIT_ROOT = (() => {
  if (process.env.GITHUB_WORKSPACE) {
    const p = path.join(process.env.GITHUB_WORKSPACE, 'fork');
    if (fs.existsSync(path.join(p, '.git'))) return p;
    const cands = (() => { const f = []; const w = dir => { let e; try { e = fs.readdirSync(w, { withFileTypes: true }); } catch { return; } for (const x of e) { if (!x.isDirectory() || x.name === 'node_modules' || x.name === 'actions-runner') continue; if (fs.existsSync(path.join(w, x.name, '.git'))) { f.push(path.join(w, x.name)); return; } } }; w(process.env.GITHUB_WORKSPACE); return f; })();
    if (cands[0]) return cands[0];
  }
  const cands = repoCandidates() || [];
  return cands[0] || WORK_DIR;
})();

const gitRun = (repo, args, pre = []) => new Promise((resolve) => {
  const out = [];
  const child = spawn('git', [...pre, ...args], { cwd: repo, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', d => out.push(String(d)));
  child.stderr.on('data', d => out.push(String(d)));
  child.on('close', () => resolve(out.join('').trimEnd()));
  child.on('error', () => resolve(''));
});

const gitFmAuth = process.env.GH_TOKEN ? ['-c', 'credential.username=x-access-token',
  '-c', 'credential.helper=!f() { echo "username=x-access-token"; echo "password=$GH_TOKEN"; }; f'] : [];
const gitFmDefaultMsg = () => {
  const d = new Date(); const p = n => String(n).padStart(2, '0');
  return 'обновление ' + p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
};
const gitFmEnsureIdent = async (repo) => {
  if (!(await gitRun(repo, ['config', 'user.name'])).trim()) await gitRun(repo, ['config', 'user.name', 'NPM Hub']);
  if (!(await gitRun(repo, ['config', 'user.email'])).trim()) await gitRun(repo, ['config', 'user.email', 'hub@local']);
};
const gitFmPush = (repo, branch) => new Promise((resolve) => {
  let out = '';
  const child = spawn('git', [...gitFmAuth, 'push', 'origin', 'HEAD:' + branch], { cwd: repo, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', d => { out += String(d); });
  child.stderr.on('data', d => { out += String(d); });
  child.on('close', code => resolve({ code, out: out.trim() }));
  child.on('error', e => resolve({ code: 1, out: 'не удалось запустить git: ' + (e && e.message || '') }));
});
app.post('/api/git/fm', express.json(), async (req, res) => {
  const { path: dir, action, message, branch, remote } = req.body || {};
  try {
    if (!dir || !dir.startsWith('/') || !fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
      return res.json({ success: false, error: 'папки на сервере нет: ' + dir });
    }
    const repoRoot = findRepoRoot(dir);
    const isRepo = !!repoRoot;
    const msg = (message && String(message).trim()) || gitFmDefaultMsg();
    if (action === 'init') {
      if (isRepo) return res.json({ success: false, error: 'это уже git-репозиторий — просто коммить' });
      await gitRun(dir, ['init', '-b', 'main']);
      if (!fs.existsSync(path.join(dir, '.git'))) await gitRun(dir, ['init']);
      await gitFmEnsureIdent(dir);
      await gitRun(dir, ['add', '-A']);
      const out = await gitRun(dir, ['commit', '-m', msg]);
      if (out && /fatal|error/i.test(out)) return res.json({ success: false, error: out });
      return res.json({ success: true, out: out || ('репозиторий создан · коммит: ' + msg), committed: true, branch: 'main' });
    }
    if (action === 'commit') {
      if (!isRepo) return res.json({ success: false, needInit: true, error: 'это ещё не репозиторий — создай его кнопкой ниже' });
      await gitFmEnsureIdent(repoRoot);
      const changed = await gitRun(repoRoot, ['status', '--porcelain']);
      if (!changed.trim()) return res.json({ success: true, committed: false, out: 'Коммитить нечего — рабочее дерево чистое' });
      await gitRun(repoRoot, ['add', '-A']);
      const out = await gitRun(repoRoot, ['commit', '-m', msg]);
      if (out && /fatal|error/i.test(out)) return res.json({ success: false, error: out });
      return res.json({ success: true, out: out || ('коммит: ' + msg), committed: true, branch: (await gitRun(repoRoot, ['rev-parse', '--abbrev-ref', 'HEAD'])).trim() || 'main' });
    }
    if (action === 'push') {
      if (!isRepo) return res.json({ success: false, needInit: true, error: 'это ещё не репозиторий — создай его кнопкой ниже' });
      await gitFmEnsureIdent(repoRoot);
      const changed = await gitRun(repoRoot, ['status', '--porcelain']);
      if (changed.trim()) {
        await gitRun(repoRoot, ['add', '-A']);
        const c = await gitRun(repoRoot, ['commit', '-m', msg]);
        if (c && /fatal|error/i.test(c)) return res.json({ success: false, error: c });
      }
      const cur = (await gitRun(repoRoot, ['rev-parse', '--abbrev-ref', 'HEAD'])).trim() || 'main';
      const target = (branch && String(branch).trim()) || cur;
      const origin = (await gitRun(repoRoot, ['remote'])).trim().split(/\s+/)[0] || '';
      if (!origin) {
        const url = (remote && String(remote).trim()) || '';
        if (!url) return res.json({ success: false, needRemote: true, error: 'Нет origin — укажи URL репозитория, например https://github.com/user/repo.git' });
        await gitRun(repoRoot, ['remote', 'add', 'origin', url]);
      }
      const p = await gitFmPush(repoRoot, target);
      if (p.code !== 0) return res.json({ success: false, error: p.out || ('push отклонён (код ' + p.code + ')') });
      return res.json({ success: true, committed: true, branch: target, out: p.out && !/everything up-to-date/i.test(p.out) ? p.out : ('запушено в ветку ' + target) });
    }
    return res.json({ success: false, error: 'неизвестное действие: ' + action });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

const findRepoRoot = (p) => {
  if (!p || !fs.existsSync(p) || !fs.statSync(p).isDirectory()) return null;
  let cur = p;
  while (cur !== '/') {
    if (fs.existsSync(path.join(cur, '.git'))) return cur;
    const next = path.dirname(cur);
    if (next === cur) break;
    cur = next;
  }
  return null;
};

const resolveRepo = async (p) => {
  const found = findRepoRoot(p);
  if (found) return found;
  const cands = repoCandidates();
  return cands[0] || null;
};

app.get('/api/git/repos', (req, res) => {
  try {
    const repos = repoCandidates();
    res.json({ success: true, repos });
  } catch { res.json({ success: true, repos: [] }); }
});

app.get('/api/git/status', async (req, res) => {
  try {
    const repo = await resolveRepo(req.query.path);
    if (!repo) return res.json({ success: false, error: 'репозиторий не найден: нужна папка с .git' });
    const [branch, porcelain, branchLine, lastCommit] = await Promise.all([
      gitRun(repo, ['rev-parse', '--abbrev-ref', 'HEAD']),
      gitRun(repo, ['status', '--porcelain=v1']),
      gitRun(repo, ['status', '-sb']),
      gitRun(repo, ['log', '-1', '--format=%h %s (%ar)'])
    ]);
    const ahead = +(branchLine.match(/ahead (\d+)/) || [])[1] || 0;
    const behind = +(branchLine.match(/behind (\d+)/) || [])[1] || 0;
    const files = porcelain ? porcelain.split('\n').filter(Boolean).map(l => ({ code: l.slice(0, 2), path: l.slice(3) })) : [];
    res.json({ success: true, repo, branch, ahead, behind, lastCommit: lastCommit || null, files, dirty: files.length > 0 });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.get('/api/git/diff', async (req, res) => {
  try {
    const repo = await resolveRepo(req.query.path);
    if (!repo) return res.json({ success: false, error: 'репозиторий не найден: нужна папка с .git' });
    const [unstaged, staged] = await Promise.all([gitRun(repo, ['diff']), gitRun(repo, ['diff', '--cached'])]);
    const diff = (staged ? '─── СТЕЙДЖЕД ───\n' + staged + '\n\n' : '') + unstaged;
    res.json({ success: true, repo, diff: diff.trim() || '' });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.get('/api/git/log', async (req, res) => {
  try {
    const repo = await resolveRepo(req.query.path);
    if (!repo) return res.json({ success: false, error: 'репозиторий не найден: нужна папка с .git' });
    const n = Math.min(50, parseInt(req.query.n || '20', 10) || 20);
    const log = await gitRun(repo, ['log', '-' + n, '--oneline', '--decorate']);
    res.json({ success: true, repo, log });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── PULSE AUDIO ───
const { exec: _exec } = require('child_process');
const shTail = (file, lines = 3) => new Promise((resolve) => {
  _exec(`tail -n ${lines} ${JSON.stringify(file)} 2>/dev/null | tr '\n' ' '`, { timeout: 4000 }, (err, stdout) => resolve(String(stdout || '').trim().slice(0, 300)));
});
const pulseRun = (cmd) => new Promise((resolve) => {
  _exec(cmd, { timeout: 5000 }, (err, stdout, stderr) => {
    resolve({ ok: !err, out: (stdout || '').trim(), err: (stderr || '').trim() });
  });
});

app.get('/api/pulse/status', async (req, res) => {
  try {
    const st = await pulseRun('pulseaudio --check 2>&1; echo $?');
    const running = st.out.endsWith('0');
    let sinks = [], sources = [];
    if (running) {
      const ls = await pulseRun('pactl list sinks short 2>/dev/null');
      if (ls.ok && ls.out) sinks = ls.out.split('\n').filter(Boolean).map(l => l.split('\t')[1] || l);
      const src = await pulseRun('pactl list sources short 2>/dev/null');
      if (src.ok && src.out) sources = src.out.split('\n').filter(Boolean).map(l => l.split('\t')[1] || l);
    }
    res.json({ running, sinks, sources });
  } catch { res.json({ running: false, sinks: [], sources: [] }); }
});

app.post('/api/pulse/start', async (req, res) => {
  try {
    await pulseRun('pulseaudio --start --disallow-exit --exit-idle-time=-1 2>&1');
    res.json({ ok: true });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

app.post('/api/pulse/stop', async (req, res) => {
  try {
    await pulseRun('pulseaudio --kill 2>&1');
    res.json({ ok: true });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

app.post('/api/pulse/volume', express.json(), async (req, res) => {
  try {
    const vol = Math.max(0, Math.min(100, parseInt(req.body.volume || 80, 10)));
    await pulseRun(`pactl set-sink-volume @DEFAULT_SINK@ ${vol}% 2>&1`);
    res.json({ ok: true, volume: vol });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

app.post('/api/pulse/mute', async (req, res) => {
  try {
    await pulseRun('pactl set-sink-mute @DEFAULT_SINK@ toggle 2>&1');
    const st = await pulseRun('pactl get-sink-mute @DEFAULT_SINK@ 2>/dev/null');
    res.json({ ok: true, muted: st.out.includes('yes') });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

app.get('/api/pulse/sinks', async (req, res) => {
  try {
    const ls = await pulseRun('pactl list sinks 2>/dev/null');
    const sinks = [];
    if (ls.ok && ls.out) {
      const blocks = ls.out.split('\n\n');
      for (const block of blocks) {
        const nameMatch = block.match(/Name:\s+(.+)/);
        const descMatch = block.match(/Description:\s+(.+)/);
        const volMatch = block.match(/Volume:\s+.+?(\d+)%/);
        const muteMatch = block.match(/Mute:\s+(yes|no)/);
        if (nameMatch) {
          sinks.push({
            name: nameMatch[1].trim(),
            description: descMatch ? descMatch[1].trim() : '',
            volume: volMatch ? parseInt(volMatch[1]) : 0,
            muted: muteMatch ? muteMatch[1] === 'yes' : false
          });
        }
      }
    }
    res.json({ success: true, sinks });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── WEBSOCKET / PTY ───
// Sessions survive a dropped connection: losing the phone does NOT kill the
// terminal. The PTY keeps running in the background, its output is buffered,
// and any client that returns with the same sessionId resumes the live
// terminal instead of starting a new one. Sessions end only when the process
// exits on its own, the user sends `kill`, or the runner itself stops.
//
// On Linux/macOS sessions run inside a detached `tmux` server. tmux outlives
// this node process, so a restart of the hub does NOT reset running sessions:
// their output keeps streaming into a log file, and clients reconnecting with
// the same sessionId pick up exactly where they left off. On Windows (no tmux)
// we fall back to node-pty sessions that live inside this process.
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

// ─── REMOTE DESKTOP AUDIO ───────────────────────────────────────────────────
// VNC/noVNC transports pixels and input, not the sound produced by Chromium.
// Capture the PulseAudio default sink monitor and stream it to the browser page
// over a same-origin WebSocket. The default codec is Opus (via the pure-JS
// opusscript encoder), one 20 ms frame per binary message; a browser that
// cannot decode Opus (no WebCodecs) asks for `?codec=pcm` and gets raw PCM.
// This is deliberately separate from the VNC socket: video remains VNC, audio
// remains an ordinary browser audio stream and works on phones too.
const audioWss = new WebSocketServer({ noServer: true });
const audioRate = (req) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    const def = Number(process.env.HUB_AUDIO_RATE) || 22050;
    const n = Number(u.searchParams.get('rate') || def);
    return Math.max(8000, Math.min(96000, Number.isFinite(n) ? Math.round(n) : def));
  } catch { return 22050; }
};
// Stereo doubles the raw-PCM bill for a phone that usually listens through a
// single speaker. HUB_AUDIO_CHANNELS=1 (or ?channels=1) halves it again.
const audioChannels = (req) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    const def = Number(process.env.HUB_AUDIO_CHANNELS) || 2;
    return Number(u.searchParams.get('channels') || def) === 1 ? 1 : 2;
  } catch { return 2; }
};
const ensureBrowserAudioSink = async () => {
  const ls = await pulseRun('pactl list short sinks 2>/dev/null');
  if (!/\tbrowser_youtube(?:\.\d+)?\t/.test(String(ls.out || ''))) {
    await pulseRun('pactl load-module module-null-sink sink_name=browser_youtube sink_properties=device.description=Hub-browser_youtube 2>/dev/null || true');
  }
  // Route the Chromium launched by this hub to the sink whose monitor we
  // stream. A null sink is intentional: the phone is the real speaker.
  await pulseRun('pactl set-default-sink browser_youtube 2>/dev/null || true');
};
const audioSource = async () => {
  const d = await pulseRun('pactl get-default-sink 2>/dev/null');
  const sink = String(d.out || '').trim().split(/\s+/)[0] || 'auto_null';
  return sink + '.monitor';
};
audioWss.on('connection', async (ws, req) => {
  let rec = null;
  let closed = false;
  let pendingAudio = Buffer.alloc(0);
  let channels = 2;
  let codec = 'pcm';        // negotiated below: 'opus' when the client can decode
  let opusEnc = null;       // OpusScript encoder while codec === 'opus'
  let opusFrameSamples = 0; // samples per channel in one 20 ms Opus frame
  let opusFrameBytes = 0;
  const AUDIO_PACKET = 8192; // ~46 ms at 22.05 kHz stereo s16le: one cheap WS packet
  // Silence gate: an idle remote sink streams pure zeros. Pushing those keeps
  // the phone's radio and decoder busy for nothing and drains the battery
  // during background listening. Let the tail through, then throttle to one
  // keep-alive packet every few seconds so the tunnel never drops the socket.
  let silentRun = 0;
  let lastSentAt = Date.now();
  const SILENT_MAX = Number(process.env.HUB_AUDIO_SILENT_PACKETS) || 32;
  const isSilent = (buf) => {
    for (let i = 0; i + 1 < buf.length; i += 2) {
      const s = buf.readInt16LE(i);
      if (s > 24 || s < -24) return false;
    }
    return true;
  };
  const sendAudio = (force = false) => {
    const frame = channels * 2;
    while (!closed && ws.readyState === 1 &&
      (pendingAudio.length >= AUDIO_PACKET || (force && pendingAudio.length >= frame))) {
      let n = pendingAudio.length >= AUDIO_PACKET ? AUDIO_PACKET : pendingAudio.length - (pendingAudio.length % frame);
      if (n < frame) break;
      const packet = pendingAudio.subarray(0, n);
      pendingAudio = pendingAudio.subarray(n);
      if (isSilent(packet)) {
        silentRun++;
        if (silentRun > SILENT_MAX && Date.now() - lastSentAt < 4000) continue;
      } else {
        silentRun = 0;
      }
      lastSentAt = Date.now();
      try { ws.send(packet, { binary: true }); } catch { stop(); break; }
    }
  };
  // One WS binary message = exactly one Opus frame (20 ms). The client decodes
  // each message with WebCodecs and schedules it on the audio clock, so a late
  // packet becomes a tiny gap at most instead of the old ScriptProcessor
  // underrun (which zero-filled the whole output buffer = "резкая тишина").
  const sendOpus = () => {
    while (!closed && ws.readyState === 1 && pendingAudio.length >= opusFrameBytes) {
      const frame = pendingAudio.subarray(0, opusFrameBytes);
      pendingAudio = pendingAudio.subarray(opusFrameBytes);
      if (isSilent(frame)) {
        silentRun++;
        if (silentRun > SILENT_MAX && Date.now() - lastSentAt < 4000) continue;
      } else {
        silentRun = 0;
      }
      let packet = null;
      try { packet = opusEnc.encode(frame, opusFrameSamples); } catch { continue; }
      if (!packet || !packet.length) continue;
      lastSentAt = Date.now();
      try { ws.send(Buffer.from(packet), { binary: true }); } catch { stop(); break; }
    }
  };
  const stop = () => {
    if (closed) return;
    closed = true;
    pendingAudio = Buffer.alloc(0);
    try { if (rec && rec.stdout) rec.stdout.destroy(); } catch {}
    try { if (rec) rec.kill('SIGTERM'); } catch {}
    try { if (opusEnc) opusEnc.delete(); } catch {}
    opusEnc = null;
  };
  ws.on('close', stop);
  ws.on('error', stop);
  try {
    const rate = audioRate(req);
    channels = audioChannels(req);
    let want = 'opus';
    try {
      const u = new URL(req.url, 'http://localhost');
      want = String(u.searchParams.get('codec') || process.env.HUB_AUDIO_CODEC || 'opus').toLowerCase();
    } catch {}
    // Opus only accepts 8/12/16/24/48 kHz, so snap the capture rate to 48 kHz
    // when needed. A 20 ms frame at 48 kHz mono is ~60 bytes (~24 kbps).
    let captureRate = rate;
    if (want === 'opus' && OpusScript) {
      if (![8000, 12000, 16000, 24000, 48000].includes(captureRate)) captureRate = 48000;
      opusFrameSamples = Math.round(captureRate / 50);
      opusFrameBytes = opusFrameSamples * channels * 2;
      try {
        opusEnc = new OpusScript(captureRate, channels, OpusScript.Application.AUDIO);
        const bitrate = Number(process.env.HUB_OPUS_BITRATE) || (channels === 1 ? 24000 : 48000);
        try { opusEnc.encoderCTL(4002, bitrate); } catch {} // OPUS_SET_BITRATE
        codec = 'opus';
      } catch { opusEnc = null; codec = 'pcm'; }
    }
    const bin = await pulseRun('command -v parec 2>/dev/null || command -v pacat 2>/dev/null');
    const recorder = String(bin.out || '').trim().split(/\s+/)[0];
    if (!recorder) {
      ws.send(JSON.stringify({ type: 'error', error: 'parec не установлен (нужен пакет pulseaudio-utils)' }));
      return stop();
    }
    const source = await audioSource();
    const recordArgs = /pacat(?:\.exe)?$/.test(recorder) ? ['--record'] : [];
    rec = spawn(recorder, recordArgs.concat([
      '--device=' + source,
      '--format=s16le', '--rate=' + captureRate, '--channels=' + channels,
      codec === 'opus' ? '--latency-msec=20' : '--latency-msec=40'
    ]), { stdio: ['ignore', 'pipe', 'pipe'], env: process.env });
    rec.stdout.on('data', (chunk) => {
      if (closed || !chunk.length) return;
      // parec can emit tiny 4–几十-byte chunks when the sink is resampled.
      // Sending each one separately starves the phone's main thread and makes
      // both audio and VNC video stutter. Coalesce into whole packets.
      pendingAudio = Buffer.concat([pendingAudio, chunk]);
      if (codec === 'opus') sendOpus(); else sendAudio(false);
    });
    rec.on('error', (e) => {
      if (!closed && ws.readyState === 1) {
        try { ws.send(JSON.stringify({ type: 'error', error: e.message })); } catch {}
      }
      stop();
    });
    rec.on('exit', (code) => {
      if (codec === 'opus') sendOpus(); else sendAudio(true);
      if (!closed && code && ws.readyState === 1) {
        try { ws.send(JSON.stringify({ type: 'error', error: 'аудиозахват завершился: ' + code })); } catch {}
      }
      if (!closed) stop();
    });
    if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'ready', rate: captureRate, channels, source, codec, frameMs: codec === 'opus' ? 20 : 0 }));
  } catch (e) {
    if (ws.readyState === 1) {
      try { ws.send(JSON.stringify({ type: 'error', error: e.message })); } catch {}
    }
    stop();
  }
});
server.on('upgrade', (req, socket, head) => {
  let u;
  try { u = new URL(req.url, 'http://' + (req.headers.host || 'localhost')); }
  catch { try { socket.destroy(); } catch {} return; }
  if (u.pathname !== '/ws/audio') return;
  try {
    audioWss.handleUpgrade(req, socket, head, (ws) => audioWss.emit('connection', ws, req));
  } catch (e) {
    console.log('  ⚠ audio upgrade: ' + e.message);
    try { socket.destroy(); } catch {}
  }
});

// Paths owned by their own upgrade handlers below (cloud phone VNC + the
// always-on desktop). Handling the same socket twice makes ws throw
// «server.handleUpgrade() was called more than once» — and that crash took the
// whole hub down, so the list is shared and every handler is guarded.
const WS_CLAIMED = new Set(['/ws/audio', '/ws/vnc', '/ws/desktop', '/novnc/ws/desktop', '/websockify', '/novnc/websockify']);
server.on('upgrade', (req, socket, head) => {
  // Route the single 'upgrade' event: /ws → PTY, others → their own blocks.
  let pathname = '';
  try { pathname = new URL(req.url, 'http://' + (req.headers.host || 'localhost')).pathname; }
  catch { return; }
  if (WS_CLAIMED.has(pathname.replace(/\/+$/, ''))) return;
  try {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
  } catch (e) {
    console.log('  ⚠ ws upgrade: ' + e.message);
    try { socket.destroy(); } catch {}
  }
});
const sessions = new Map(); // sessionId -> { id, pty?, tmux?, cwd, toolId, clients:Set, output, resumed, offset, logPath, poller? }

const TMUX_PREFIX = 'npmhub-';
const PTY_DIR = path.join(TMP_DIR, 'pty');
// Session descriptors are durable; PTY logs remain temporary because they can
// grow without bound. The descriptor is enough to recreate OpenCode in the
// same repository after a fresh runner starts.
const SESSION_DIR = path.join(DATA_DIR, 'sessions');
try { fs.mkdirSync(PTY_DIR, { recursive: true }); fs.mkdirSync(SESSION_DIR, { recursive: true }); } catch {}

// Check on demand: the keepalive may install tmux after this module starts.
const tmuxHas = () => {
  try { require('child_process').execSync('which tmux', { stdio: 'ignore', timeout: 3000 }); return true; }
  catch { return false; }
};

const safeSessionName = id => TMUX_PREFIX + String(id).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
const sessionLogPath = id => path.join(PTY_DIR, safeSessionName(id) + '.log');
const sessionMetaPath = id => path.join(SESSION_DIR, safeSessionName(id) + '.meta.json');
const legacySessionMetaPath = id => path.join(PTY_DIR, safeSessionName(id) + '.meta.json');

// Keep project identity beside the tmux session. cwd alone is not enough for
// a cloned/local repo because the UI needs to know which unfinished worktree
// belongs to which agent after a hub restart.
const repoContext = (dir) => {
  let p = dir;
  try { p = path.resolve(String(dir || HOME)); } catch { return null; }
  for (let i = 0; i < 32 && p; i++) {
    if (fs.existsSync(path.join(p, '.git'))) {
      const run = (args) => {
        try { return require('child_process').execFileSync('git', ['-C', p, ...args], { encoding: 'utf8', timeout: 2500 }).trim(); }
        catch { return ''; }
      };
      const status = run(['status', '--short']);
      return {
        path: p,
        name: path.basename(p),
        remote: run(['config', '--get', 'remote.origin.url']) || null,
        branch: run(['rev-parse', '--abbrev-ref', 'HEAD']) || null,
        head: run(['rev-parse', 'HEAD']) || null,
        dirty: Boolean(status),
        status: status.slice(0, 20000)
      };
    }
    const next = path.dirname(p);
    if (next === p) break;
    p = next;
  }
  return null;
};
const currentTmuxCwd = (session) => {
  if (!session || !session.tmux) return session && session.cwd;
  const r = tmuxRun(['display-message', '-p', '-t', safeSessionName(session.id), '#{pane_current_path}'], 2000);
  const cwd = String(r.stdout || '').trim();
  return cwd && fs.existsSync(cwd) ? cwd : session.cwd;
};

// A tiny `.json` sidecar per session remembers display info, cwd, project and
// emulator so a hub restart can bring back the exact unfinished worktree.
const writeSessionMeta = (session) => {
  try {
    session.repo = session.repo || repoContext(session.cwd);
    session.emulator = session.emulator || getDefaultEmulator();
    session.phoneRunner = session.phoneRunner || getDefaultPhoneRunner();
    fs.writeFileSync(sessionMetaPath(session.id), JSON.stringify({
      id: session.id, cwd: session.cwd, toolId: session.toolId,
      toolCmd: session.toolCmd || null, autoRestore: session.autoRestore !== false,
      toolName: session.toolName || 'Terminal', color: session.color || '#58a6ff',
      icon: session.icon || '>_', created: session.created || Date.now(),
      emulator: session.emulator,
      phoneRunner: session.phoneRunner,
      repoPath: session.repo && session.repo.path,
      repoName: session.repo && session.repo.name,
      repoRemote: session.repo && session.repo.remote,
      repoBranch: session.repo && session.repo.branch,
      repoHead: session.repo && session.repo.head,
      repoDirty: !!(session.repo && session.repo.dirty),
      repoStatus: session.repo && session.repo.status || ''
    }));
  } catch {}
};
// Repo "identity" = the stable fields that pin a session to a worktree. The
// mutable `status` snapshot is deliberately excluded: git status changes on
// every keystroke/worktree touch, so comparing it would rewrite the sidecar on
// every /api/sessions poll for any dirty repo.
const repoIdentity = (r) => r ?
  [r.path, r.name, r.remote, r.branch, r.head, !!r.dirty].join('\u0000') : null;
const syncTmuxSession = (session) => {
  const cwd = currentTmuxCwd(session);
  const nextRepo = repoContext(cwd || session.cwd);
  const oldRepo = session.repo || null;
  const repoChanged = repoIdentity(oldRepo) !== repoIdentity(nextRepo);
  if ((cwd && cwd !== session.cwd) || repoChanged) {
    if (cwd) session.cwd = cwd;
    session.repo = nextRepo;
    writeSessionMeta(session);
  }
  return session;
};
const deleteSessionMeta = (id) => {
  for (const p of [sessionMetaPath(id), legacySessionMetaPath(id)]) {
    try { fs.unlinkSync(p); } catch {}
  }
};
const readSessionMeta = (id) => {
  for (const p of [sessionMetaPath(id), legacySessionMetaPath(id)]) {
    try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
    catch {}
  }
  return null;
};

// A GitHub runner can come back with the same repo at a different absolute
// workspace path. Prefer the old cwd when it still exists, otherwise resolve
// the saved repository identity against the durable hub-work directory.
const resolveRestoredCwd = (meta) => {
  const wantedRemote = meta && meta.repoRemote;
  let hubRepos = [];
  try {
    hubRepos = fs.readdirSync(WORK_DIR, { withFileTypes: true })
      .filter(e => e.isDirectory())
      .map(e => path.join(WORK_DIR, e.name, 'code'));
  } catch {}
  const candidates = [...hubRepos, meta && meta.repoPath, meta && meta.cwd,
    WORK_DIR, meta && meta.repoName && path.join(WORK_DIR, meta.repoName, 'code'),
    meta && meta.repoName && path.join(HOME, meta.repoName), HOME].filter(Boolean);
  let first = null;
  for (const candidate of candidates) {
    try {
      const resolved = path.resolve(String(candidate));
      if (!fs.statSync(resolved).isDirectory()) continue;
      if (!first) first = resolved;
      if (!wantedRemote) return resolved;
      const repo = repoContext(resolved);
      if (repo && repo.remote === wantedRemote) return resolved;
    } catch {}
  }
  return wantedRemote ? null : first;
};

const tmuxRun = (args, timeout, input) => {
  try { return require('child_process').spawnSync('tmux', args, { stdio: 'pipe', timeout: timeout || 5000, encoding: 'utf8', input }); }
  catch { return { status: 1, stdout: '', stderr: '' }; }
};
const tmuxSessionEmulator = (id) => {
  const r = tmuxRun(['show-environment', '-t', safeSessionName(id), 'ANDROID_AVD'], 2000);
  const match = String(r.stdout || '').match(/^ANDROID_AVD=(.+)$/m);
  return cleanEmulatorName(match && match[1]);
};
const commandForTool = (tool, savedMeta) => {
  if (tool && tool.id === 'opencode') return `${tool.cmd} --continue`;
  return (savedMeta && savedMeta.toolCmd) || (tool && tool.cmd !== '_terminal' ? tool.cmd : null);
};

const tmuxSessionAlive = id => tmuxRun(['has-session', '-t', safeSessionName(id)], 2000).status === 0;

const tmuxReadLog = (session) => {
  try {
    const size = fs.statSync(session.logPath).size;
    if (size > session.offset) {
      const fd = fs.openSync(session.logPath, 'r');
      const buf = Buffer.alloc(size - session.offset);
      fs.readSync(fd, buf, 0, buf.length, session.offset);
      fs.closeSync(fd);
      session.offset = size;
      const data = buf.toString('utf8');
      session.output = (session.output + data).slice(-SESSION_OUTPUT_CAP);
      ptySend(session, { type: 'output', id: session.id, data });
    }
    return true;
  } catch { return false; }
};

const tmuxStartPoller = (session) => {
  if (session.poller) return;
  session.poller = setInterval(() => {
    if (session.clients.size === 0) return; // nothing to stream to, tmux keeps logging
    const alive = tmuxSessionAlive(session.id);
    tmuxReadLog(session);
    if (!alive) {
      tmuxReadLog(session); // flush whatever was logged last
      clearInterval(session.poller);
      session.poller = null;
      ptySend(session, { type: 'exit', id: session.id, code: 0 });
      try { fs.unlinkSync(session.logPath); } catch {}
      deleteSessionMeta(session.id);
      sessions.delete(session.id);
    }
  }, 120);
};

const ensureTmuxPipe = (session) => {
  const cmd = `cat >> ${JSON.stringify(session.logPath)}`;
  tmuxRun(['pipe-pane', '-t', safeSessionName(session.id), cmd], 3000);
  tmuxStartPoller(session);
};

const stopTmuxPollers = () => {
  sessions.forEach(s => { if (s.poller) { clearInterval(s.poller); s.poller = null; } });
};

const ptySend = (session, message) => {
  const payload = JSON.stringify(message);
  for (const client of [...session.clients]) {
    if (client.readyState !== 1) { session.clients.delete(client); continue; }
    try { client.send(payload); }
    catch { session.clients.delete(client); }
  }
};

// Агент (opencode и др.) может умереть сам: упёрся в лимит модели, ошибка
// провайдера. На pty-пути (Windows / без tmux) вместе с ним падает и оболочка,
// и сессия удаляется — клиент дальше шлёт ввод в пустоту, терминал выглядит
// «замороженным» и «не даёт нажать». Как в tmux (там остаётся живой bash),
// поднимаем свежую оболочку в той же сессии, чтобы экран не был мёртвым.
const respawnToolShell = (session) => {
  if (!session || session.tmux || !session.toolCmd || session._respawned) return;
  session._respawned = true;
  const isWin = process.platform === 'win32';
  const shell = isWin ? (process.env.COMSPEC || 'cmd.exe') : (process.env.SHELL || '/bin/sh');
  try {
    const p = pty.spawn(shell, [], {
      name: 'xterm-256color',
      cols: (session.pty && session.pty.cols) || 120,
      rows: (session.pty && session.pty.rows) || 30,
      cwd: session.cwd,
      env: { ...process.env, TERM: 'xterm-256color', OPENROUTER_API_KEY: modelManager.getKeyForProvider('openrouter'), MODEL: modelManager.getSelectedModel(), OPENROUTER_BASE_URL: 'https://openrouter.ai/api/v1' }
    });
    session.pty = p;
    const cdCmd = isWin ? `cd /d "${session.cwd}"` : `cd "${session.cwd}"`;
    p.write(cdCmd + '\r');
    ptySend(session, { type: 'output', id: session.id,
      data: '\r\n\x1b[33m[Агент завершился — оболочка запущена заново. Нажми ⟲, чтобы перезапустить агента]\x1b[0m\r\n' });
    p.onData((data) => {
      session.output = (session.output + data).slice(-SESSION_OUTPUT_CAP);
      ptySend(session, { type: 'output', id: session.id, data });
    });
    p.onExit(({ exitCode }) => {
      ptySend(session, { type: 'exit', id: session.id, code: exitCode });
      deleteSessionMeta(session.id);
      sessions.delete(session.id);
    });
  } catch (err) {
    ptySend(session, { type: 'error', id: session.id, error: err.message });
    try { session.pty && session.pty.write('\r'); } catch {}
    deleteSessionMeta(session.id);
    sessions.delete(session.id);
  }
};

const attachPtyClient = (session, ws) => {
  session.clients.add(ws);
  session.lastLeave = 0;
  ws.send(JSON.stringify({ type: 'opened', id: session.id, resumed: session.resumed }));
  // Replay the scrollback in chunks, not one multi-MB WS frame: a single
  // huge frame is buffered by mobile browsers / tunnels and the terminal
  // appears to load only a fragment before it freezes. 64KB per message with
  // a micro-break lets the client render progressively and stay responsive.
  if (session.output) {
    const out = session.output;
    let pos = 0;
    const step = () => {
      if (ws.readyState !== 1 || pos >= out.length) return;
      const part = out.slice(pos, pos + SESSION_OUTPUT_CHUNK);
      pos += part.length;
      ws.send(JSON.stringify({ type: 'output', id: session.id, data: part, replay: true }));
      if (pos < out.length) setTimeout(step, 25);
    };
    step();
  }
};

const detachPtyClient = (session, ws) => {
  if (!session) return;
  session.clients.delete(ws);
  if (session.clients.size === 0) session.lastLeave = Date.now();
};

// Reconnect path: a hub restart (or server swap) does not kill tmux sessions.
// Rebuild the in-memory record from the surviving tmux session + its log file.
const reviveTmuxSession = (id) => {
  if (!tmuxSessionAlive(id)) return null;
  const logPath = sessionLogPath(id);
  const offset = (() => { try { return fs.statSync(logPath).size; } catch { return 0; } })();
  const meta = readSessionMeta(id) || {};
  const session = { id, tmux: true, cwd: resolveRestoredCwd(meta) || meta.cwd || meta.repoPath || null,
    repo: meta.repoPath ? { path: meta.repoPath, name: meta.repoName, remote: meta.repoRemote,
      branch: meta.repoBranch, head: meta.repoHead, dirty: !!meta.repoDirty, status: meta.repoStatus || '' } : null,
    emulator: meta.emulator || tmuxSessionEmulator(id) || getDefaultEmulator(),
    phoneRunner: meta.phoneRunner || getDefaultPhoneRunner(), toolId: meta.toolId || null,
    toolCmd: meta.toolCmd || null, autoRestore: meta.autoRestore !== false,
    toolName: meta.toolName, color: meta.color, icon: meta.icon, created: meta.created || Date.now(),
    clients: new Set(), output: '', resumed: true, offset: 0, logPath, poller: null, lastLeave: 0 };
  sessions.set(id, session);
  // Backfill metadata for sessions created before project/emulator persistence
  // existed. No clone is made and the tmux process is not restarted.
  writeSessionMeta(session);
  ensureTmuxPipe(session);
  if (offset > 0) { // replay everything tmux already had
    try {
      const got = fs.readFileSync(logPath, 'utf8');
      session.output = got.slice(-SESSION_OUTPUT_CAP);
      session.offset = offset;
    } catch {}
  }
  return session;
};

const createTmuxSession = (id, opts, ws) => {
  const name = safeSessionName(id);
  const logPath = sessionLogPath(id);
  try { fs.unlinkSync(logPath); } catch {}
  const r = tmuxRun(['new-session', '-d', '-s', name, '-x', String(opts.cols || 120), '-y', String(opts.rows || 30), '-c', opts.cwd], 8000);
  // A reused id must never silently spawn a SECOND tmux session under the same
  // name: the watchdog restart wiped our in-memory record, the clone in tmux
  // survived, and only the revive step missed it. Re-checking here collapses
  // the copy instead of stacking tabs that all claim one id.
  if (r.status !== 0) {
    const alive = tmuxHas() && tmuxSessionAlive(id);
    const revived = alive ? reviveTmuxSession(id) : null;
    if (revived) return revived;
    ws.send(JSON.stringify({ type: 'error', error: (r.stderr || 'tmux failed').trim() })); return null;
  }
  const session = { id, tmux: true, cwd: opts.cwd, repo: repoContext(opts.cwd),
    emulator: cleanEmulatorName(opts.emulator) || getDefaultEmulator(),
    phoneRunner: cleanEmulatorName(opts.phoneRunner) || getDefaultPhoneRunner(),
    toolId: opts.toolId, toolCmd: opts.toolCmd || null, autoRestore: opts.autoRestore !== false,
    toolName: opts.toolName, color: opts.color,
    icon: opts.icon, created: Date.now(), clients: new Set(), output: '', resumed: false,
    offset: 0, logPath, poller: null, lastLeave: 0 };
  sessions.set(id, session);
  // Pin the selected emulator in tmux as well as in the sidecar. This lets a
  // legacy session recover its original choice even if the global default has
  // changed since that session was opened.
  tmuxRun(['set-environment', '-t', name, 'ANDROID_AVD', session.emulator], 3000);
  writeSessionMeta(session);
  ensureTmuxPipe(session);
  const shell = process.env.SHELL || '/bin/bash';
  tmuxRun(['send-keys', '-t', name, `export TERM=xterm-256color; cd ${JSON.stringify(opts.cwd)}`, 'Enter'], 3000);
  if (opts.toolCmd) tmuxRun(['send-keys', '-t', name, opts.toolCmd, 'Enter'], 3000);
  // Auto-approve: after the agent starts, send /autoon if the setting is on.
  if (opts.toolCmd && AGENT_SUPPORTS_SLASH.has(opts.toolId)) {
    try { if (loadState().autoApprove) tmuxRun(['send-keys', '-t', name, '/autoon', 'Enter'], 3000); } catch {}
  }
  return session;
};

// Terminate a session for good. Called when a client closes a tab: merely
// detaching left the tmux session alive, /api/sessions re-attached it on every
// reload, and closed tabs kept multiplying. Handles both an in-memory record
// and a session that only survives as tmux after a hub restart.
const killServerSession = (id) => {
  const s = sessions.get(id);
  if (s) {
    if (s.poller) { clearInterval(s.poller); s.poller = null; }
    if (s.pty) { try { s.pty.kill('SIGTERM'); } catch {} }
    try { if (s.logPath) fs.unlinkSync(s.logPath); } catch {}
  }
  if (tmuxHas()) { try { tmuxRun(['kill-session', '-t', safeSessionName(id)], 3000); } catch {} }
  deleteSessionMeta(id);
  sessions.delete(id);
  return !!s;
};

// Feed client keystrokes into the tmux pane byte-for-byte. Using load-buffer +
// paste-buffer keeps arbitrary UTF-8/escape bytes intact (paste-buffer sends
// them as terminal input, Enter/newline included). Rapid typing arrives as a
// burst of tiny WS messages; if we pumped every one through spawnSync the
// event loop (and with it every other client + the audio/video bridges) would
// stutter — the "keyboard lag" the phone users see. Coalesce a ~30ms burst
// into ONE tmux write.
const tmuxInputBuf = new Map(); // id -> { pending, timer, tries }
const tmuxInputFlush = (id) => {
  const item = tmuxInputBuf.get(id);
  if (!item) return;
  tmuxInputBuf.delete(id);
  const { pending } = item;
  if (!pending) return;
  const name = safeSessionName(id);
  const bufName = 'npmhub_io_' + Date.now() + '_' + Math.floor(Math.random() * 1e6);
  // load-buffer/paste-buffer из stdin: большой вставленный текст (десятки КБ)
  // прогоняется через spawnSync. Таймаут должен пережить такую запись, а при
  // сбое ввод нельзя терять молча — откладываем и повторим чуть позже.
  let r;
  try { r = tmuxRun(['load-buffer', '-b', bufName, '-'], 10000, pending); } catch (e) { r = { status: null }; }
  if (r && r.status === 0) {
    try { tmuxRun(['paste-buffer', '-b', bufName, '-t', name, '-d'], 10000); } catch {}
  } else {
    item.pending = pending;
    item.tries = (item.tries || 0) + 1;
    if (item.tries < 3) {
      item.timer = setTimeout(() => tmuxInputFlush(id), 500);
      tmuxInputBuf.set(id, item);
    }
  }
};
const tmuxInput = (id, data) => {
  if (typeof data !== 'string' || !data) return;
  const item = tmuxInputBuf.get(id) || { pending: '', timer: null };
  if (item.timer) clearTimeout(item.timer);
  item.pending += data;
  // Escape hatch: a monster paste must not wait for the debounce indefinitely.
  if (item.pending.length > 16384) { tmuxInputFlush(id); return; }
  item.timer = setTimeout(() => tmuxInputFlush(id), 30);
  tmuxInputBuf.set(id, item);
};

// Reschedule all tmux pollers to only run while a client is attached, so idle
// sessions do not busy-poll forever while still logging via pipe-pane.
const tmuxWake = (session) => { if (session.tmux && session.clients.size > 0) tmuxStartPoller(session); };

wss.on('connection', (ws) => {
  let session = null;
  // Liveness is activity-based (see the heartbeat below): the client sends an
  // application-level {type:'ping'} every 15s while alive, and data frames
  // travel through proxies/tunnels that do NOT relay WebSocket control frames.
  ws.lastSeen = Date.now();
  // A phone/network drop can emit `error` before `close`. Without a listener
  // Node treats that event as uncaught and takes down the entire hub, which
  // disconnects every terminal tab at once. Detach only this client; the tmux
  // session keeps running and the browser can attach again with the same id.
  ws.on('error', () => {
    if (session) detachPtyClient(session, ws);
  });

  ws.on('message', (raw) => {
    ws.lastSeen = Date.now();
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {
      case 'open': {
        const id = msg.sessionId || ('term_' + Date.now());
        const savedMeta = readSessionMeta(id);
        const existing = sessions.get(id);
        if (existing && (!existing.tmux || tmuxSessionAlive(id))) {
          session = existing;
          session.resumed = true;
          attachPtyClient(session, ws);
          tmuxWake(session);
          return;
        }
        if (existing) {
          try { fs.unlinkSync(existing.logPath); } catch {}
          deleteSessionMeta(id);
          sessions.delete(id); // tmux session died while we were detached
        }
        // A session may exist in tmux but not in our (possibly restarted) memory.
        if (tmuxHas()) {
          const revived = reviveTmuxSession(id);
          if (revived) {
            session = revived;
            attachPtyClient(session, ws);
            tmuxWake(session);
            return;
          }
        }
        const tool = TOOLS.find(t => t.id === (msg.toolId || (savedMeta && savedMeta.toolId)));
        const isWin = process.platform === 'win32';
        const shell = isWin ? (process.env.COMSPEC || 'cmd.exe') : (process.env.SHELL || '/bin/sh');
        let cwd = msg.cwd || msg.repoPath || (savedMeta && resolveRestoredCwd(savedMeta)) || HOME;
        try {
          if (!fs.statSync(cwd).isDirectory()) throw new Error('cwd missing');
        } catch {
          try { cwd = msg.repoPath && fs.statSync(msg.repoPath).isDirectory() ? msg.repoPath : HOME; }
          catch { cwd = HOME; }
        }

        const metaColor = tool ? tool.color : '#58a6ff';
        const metaIcon = tool ? tool.icon : '>_';
        const metaName = tool ? tool.name : 'Terminal';
        const toolCmd = commandForTool(tool, savedMeta);

        try {
          if (tmuxHas() && !isWin) {

            // ❗ tmux requires a login shell name (argv[0]) to start bash as an
            // interactive shell; new-session already does that. Nothing more needed.
            session = createTmuxSession(id, { cwd, cols: msg.cols, rows: msg.rows, toolId: tool ? tool.id : null, toolName: metaName, color: metaColor, icon: metaIcon,
              emulator: msg.emulator || (savedMeta && savedMeta.emulator), phoneRunner: msg.phoneRunner || (savedMeta && savedMeta.phoneRunner),
              toolCmd,
              autoRestore: savedMeta ? savedMeta.autoRestore !== false : tool?.id === 'opencode' }, ws);
          } else {
            const p = pty.spawn(shell, [], {
              name: 'xterm-256color',
              cols: msg.cols || 120,
              rows: msg.rows || 30,
              cwd: cwd,
              env: { ...process.env, TERM: 'xterm-256color', OPENROUTER_API_KEY: modelManager.getKeyForProvider('openrouter'), MODEL: modelManager.getSelectedModel(), OPENROUTER_BASE_URL: 'https://openrouter.ai/api/v1' }
            });
            session = { id, pty: p, cwd, emulator: cleanEmulatorName(msg.emulator) || getDefaultEmulator(),
              phoneRunner: cleanEmulatorName(msg.phoneRunner) || getDefaultPhoneRunner(), toolId: tool ? tool.id : null,
              toolCmd,
              autoRestore: savedMeta ? savedMeta.autoRestore !== false : tool?.id === 'opencode',
              toolName: metaName, color: metaColor, icon: metaIcon, created: Date.now(), clients: new Set(), output: '', resumed: false, lastLeave: 0 };
            sessions.set(id, session);
            writeSessionMeta(session);

            const cdCmd = isWin ? `cd /d "${cwd}"` : `cd "${cwd}"`;
            p.write(cdCmd + '\r');
            if (toolCmd && toolCmd !== '_terminal') {
              setTimeout(() => { p.write(toolCmd + '\r'); }, 200);
              // Auto-approve: if the setting is on, send /autoon after the agent is ready.
              if (tool && AGENT_SUPPORTS_SLASH.has(tool.id)) {
                try { if (loadState().autoApprove) setTimeout(() => { p.write('/autoon\r'); }, 1000); } catch {}
              }
            }

            p.onData((data) => {
              session.output = (session.output + data).slice(-SESSION_OUTPUT_CAP);
              ptySend(session, { type: 'output', id: session.id, data });
            });
            p.onExit(({ exitCode }) => {
              respawnToolShell(session);
              if (session.pty !== p) return;
              ptySend(session, { type: 'exit', id: session.id, code: exitCode });
              deleteSessionMeta(session.id);
              sessions.delete(session.id);
            });
          }
          if (session) attachPtyClient(session, ws);
        } catch (err) { ws.send(JSON.stringify({ type: 'error', error: err.message })); }
        return;
      }
      case 'input': {
        if (!session) return;
        // Typing is the clearest possible sign the user is still here: it resets
        // the idle clock and cancels a pending handover countdown.
        if (handoff) handoff.noteActivity();
        if (session.tmux) { tmuxInput(session.id, msg.data); return; }
        // Большой вставленный текст: пишем в PTY кусками — node-pty/OS-buffer
        // спокойнее воспринимают серию умеренных write, чем один мегабайт.
        const d = String(msg.data || '');
        if (d.length <= 16384) { session.pty.write(d); return; }
        for (let i = 0; i < d.length; i += 16384) session.pty.write(d.slice(i, i + 16384));
        return;
      }
      case 'resize': {
        if (!session || !msg.cols || !msg.rows) return;
        if (session.tmux) { tmuxRun(['resize-window', '-t', safeSessionName(session.id), '-x', String(msg.cols), '-y', String(msg.rows)], 3000); return; }
        session.pty.resize(msg.cols, msg.rows);
        return;
      }
      case 'ping': { ws.send(JSON.stringify({ type: 'pong', t: Date.now() })); return; }
      case 'kill': {
        if (!session) return;
        if (session.tmux) {
          const target = session;
          try { tmuxRun(['send-keys', '-t', safeSessionName(target.id), 'C-c'], 2000); } catch {}
          setTimeout(() => {
            tmuxRun(['kill-session', '-t', safeSessionName(target.id)], 2000);
            try { fs.unlinkSync(target.logPath); } catch {}
            deleteSessionMeta(target.id);
            sessions.delete(target.id);
          }, 400);
          session = null;
          return;
        }
        if (process.platform === 'win32') {
          session.pty.write('\x03');
        } else {
          session.pty.kill(msg.signal || 'SIGINT');
        }
        return;
      }
      case 'close': { detachPtyClient(session, ws); return; }
    }
  });
  ws.on('close', () => {
    if (session && session.clients) {
      detachPtyClient(session, ws);
      // Halt tmux polling while unattached; pipe-pane keeps writing the log.
      if (session.tmux && session.clients.size === 0 && session.poller) {
        clearInterval(session.poller);
        session.poller = null;
      }
    }
  });
});
wss.on('error', err => {
  // WebSocket errors belong to one client; never let a broken mobile radio
  // connection become an uncaught process-level exception.
  console.log('  ⚠ terminal websocket: ' + (err.message || err));
});

// Heartbeat: reap clients that died without a close frame (mobile radio drops,
// tunnel flaps). Liveness is activity-based on purpose: every live client sends
// an application-level {type:'ping'} every 15s, and data frames travel through
// proxies and tunnels that do NOT relay WebSocket control frames. A heartbeat
// that depended on protocol-level ping/pong therefore terminated perfectly
// healthy sockets at random intervals — the «обрыв соединения» users saw — so
// we instead reap only a socket that has been silent for well over two minutes.
setInterval(() => {
  const now = Date.now();
  for (const ws of wss.clients) {
    if (now - (ws.lastSeen || now) > 120000) {
      try { ws.terminate(); } catch {}
    }
  }
}, 30000);

// Stale sessions: when a phone panel (or a desktop tab) is killed by the OS /
// force-stopped / loses radio before its /api/sessions/:id/kill lands, the
// tmux session lives on and every /api/sessions poll revives it — so old
// 'Zen Panel' tabs accumulate forever. Reap sessions that have had zero
// clients for a long stretch; the two live sessions the user keeps open stay
// untouched (they have attached clients).
const SESSIONS_IDLE_REAP_MS = 15 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const s of [...sessions.values()]) {
    if (s.clients.size > 0) continue;
    const since = s.lastLeave || s.created || 0;
    if (since && now - since > SESSIONS_IDLE_REAP_MS) killServerSession(s.id);
  }
}, 60000);

// ─── GET /api/sessions — живые серверные сессии ───
// Используется standalone терминалом (/term): показывает, что можно
// подхватить после перезагрузки страницы или с другого устройства.
app.get('/api/sessions', (req, res) => {
  const list = [];
  // A detached tmux session can be killed outside the hub. Prune its in-memory
  // record before listing, otherwise every reconnect would resurrect a stale
  // tab forever (the mobile drawer then showed nameless/undefined sessions).
  for (const s of [...sessions.values()]) {
    if (s.tmux && !tmuxSessionAlive(s.id)) {
      if (s.poller) { clearInterval(s.poller); s.poller = null; }
      try { fs.unlinkSync(s.logPath); } catch {}
      deleteSessionMeta(s.id);
      sessions.delete(s.id);
    }
  }
  const push = (s) => {
    if (s.tmux) syncTmuxSession(s);
    const repo = s.repo || repoContext(s.cwd);
    list.push({
      id: s.id, cwd: s.cwd || null, repoPath: repo && repo.path || null,
      repoName: repo && repo.name || null, repoRemote: repo && repo.remote || null,
      repoBranch: repo && repo.branch || null, repoHead: repo && repo.head || null,
      repoDirty: !!(repo && repo.dirty), repoStatus: repo && repo.status || '',
      emulator: s.emulator || getDefaultEmulator(), phoneRunner: s.phoneRunner || getDefaultPhoneRunner(),
      toolId: s.toolId || null, toolName: s.toolName || 'Terminal',
      color: s.color || '#58a6ff', icon: s.icon || '>_',
      autoRestore: s.autoRestore !== false, resumed: !!s.resumed, tmux: !!s.tmux,
      clients: s.clients ? s.clients.size : 0, created: s.created || 0
    });
  };
  for (const s of sessions.values()) push(s);
  // Sessions that survived a hub restart still exist as tmux sessions — list
  // them too, reviving their in-memory record so a reconnect replays output.
  if (tmuxHas()) {
    try {
      const r = require('child_process').execSync('tmux list-sessions', { stdio: 'pipe', timeout: 3000, encoding: 'utf8' });
      const seen = new Set(sessions.keys());
      for (const line of r.split('\n')) {
        const name = (line.split(':')[0] || '').trim();
        if (!name.startsWith(TMUX_PREFIX)) continue;
        const id = name.slice(TMUX_PREFIX.length);
        if (seen.has(id)) continue;
        const revived = reviveTmuxSession(id);
        if (revived) push(revived);
      }
    } catch {}
  }
  // A fresh runner has no tmux processes, but durable OpenCode descriptors
  // survive in ~/.npm-hub/sessions and are included so a new browser can
  // recreate them automatically in the restored repository.
  try {
    const listed = new Set(list.map(s => String(s.id)));
    for (const file of fs.readdirSync(SESSION_DIR)) {
      if (!file.endsWith('.meta.json')) continue;
      const meta = readSessionMeta(file.slice(0, -'.meta.json'.length).replace(/^npmhub-/, ''));
      if (!meta || meta.autoRestore === false || !meta.id || listed.has(String(meta.id))) continue;
      const cwd = resolveRestoredCwd(meta);
      if (!cwd) continue;
      list.push({
        id: meta.id, cwd, repoPath: meta.repoPath || cwd,
        repoName: meta.repoName || null, repoRemote: meta.repoRemote || null,
        repoBranch: meta.repoBranch || null, repoHead: meta.repoHead || null,
        repoDirty: !!meta.repoDirty, repoStatus: meta.repoStatus || '',
        emulator: meta.emulator || getDefaultEmulator(),
        phoneRunner: meta.phoneRunner || getDefaultPhoneRunner(),
        toolId: meta.toolId || 'opencode', toolName: meta.toolName || 'OpenCode',
        color: meta.color || '#00d4aa', icon: meta.icon || 'OC',
        autoRestore: true, restore: true, resumed: false, tmux: false, clients: 0,
        created: meta.created || 0
      });
      listed.add(String(meta.id));
    }
  } catch {}
  list.sort((a, b) => (b.created || 0) - (a.created || 0));
  res.json({ success: true, sessions: list });
});

// Closing a tab ends its session even if the tab's socket is mid-reconnect, so
// the kill is also available over plain HTTP.
app.post('/api/sessions/:id/kill', (req, res) => {
  const id = String(req.params.id || '');
  if (!/^term_[0-9]+$/.test(id)) return res.status(400).json({ success: false, error: 'bad session id' });
  killServerSession(id);
  res.json({ success: true });
});

// Manual update from GitHub: pull main, then exit so the workflow keep-alive
// loop restarts the hub on the new code. tmux sessions and the tunnel live
// outside this process, so they survive the restart untouched.
const gitQ = (args) => new Promise((resolve) => {
  const out = [];
  const child = spawn('git', args, { cwd: GIT_ROOT, stdio: ['ignore', 'pipe', 'pipe'], timeout: 30000 });
  child.stdout.on('data', d => out.push(String(d)));
  child.stderr.on('data', () => {});
  child.on('close', (code) => resolve({ code, out: out.join('').trimEnd() }));
  child.on('error', () => resolve({ code: -1, out: '' }));
});

const GIT_BRANCH = (process.env.GITHUB_REF || '').replace(/^refs\/heads\//, '') || 'main';

// The updater pulls new commits, but package.json can gain a dependency (e.g.
// opusscript). Reconcile node_modules before restarting, otherwise the new code
// silently falls back (no Opus) until the next full workflow run.
const npmQ = (args) => new Promise((resolve) => {
  const child = spawn('npm', args, { cwd: path.join(__dirname, '..'), stdio: ['ignore', 'pipe', 'pipe'], timeout: 180000 });
  child.on('close', (code) => resolve({ code }));
  child.on('error', () => resolve({ code: -1 }));
});

app.get('/api/update', async (req, res) => {
  const { code, out } = await gitQ(['fetch', 'origin', GIT_BRANCH]);
  if (code !== 0) return res.json({ success: false, error: 'fetch не удался: git exited ' + code + ' — ' + out.slice(0, 300) });
  const head = (await gitQ(['rev-parse', 'HEAD'])).out;
  const remote = (await gitQ(['rev-parse', `origin/${GIT_BRANCH}`])).out;
  const behindN = (await gitQ(['rev-list', '--count', `${head}..origin/${GIT_BRANCH}`])).out || '0';
  const localSha = (await gitQ(['rev-parse', '--short', 'HEAD'])).out;
  const remoteSha = (await gitQ(['rev-parse', '--short', `origin/${GIT_BRANCH}`])).out;
  res.json({
    success: true, branch: GIT_BRANCH,
    current: localSha, latest: remoteSha, same: head === remote,
    behind: parseInt(behindN, 10) || 0,
    version: hubBuildInfo().version || ''
  });
});

app.post('/api/update', async (req, res) => {
  const check = await gitQ(['fetch', 'origin', GIT_BRANCH]);
  if (check.code !== 0) return res.json({ success: false, error: 'fetch не удался: ' + check.out.slice(0, 300) });
  const head = (await gitQ(['rev-parse', 'HEAD'])).out;
  const remote = (await gitQ(['rev-parse', `origin/${GIT_BRANCH}`])).out;
  const behindN = parseInt((await gitQ(['rev-list', '--count', `${head}..origin/${GIT_BRANCH}`])).out, 10) || 0;
  if (head === remote) {
    return res.json({ success: true, updated: false, behind: 0, message: 'уже на последней версии' });
  }
  // Accept local uncommitted changes rather than nuking them: -X theirs keeps
  // our work while still pulling the upstream snapshot. If that is impossible
  // (merge conflict), fall back to a hard reset — a runner checkout is
  // disposable anyway.
  const pull = await gitQ(['pull', '--no-edit', '--no-rebase', '--strategy-option', 'theirs', 'origin', GIT_BRANCH]);
  if (pull.code !== 0) {
    const junk = await gitQ(['reset', '--hard', `origin/${GIT_BRANCH}`]);
    if (junk.code !== 0) return res.json({ success: false, error: 'pull и reset не удались: ' + pull.out.slice(0, 300) });
  }
  const newSha = (await gitQ(['rev-parse', '--short', 'HEAD'])).out;
  console.log(`[updater] pulled ${head.slice(0, 7)}..${newSha} (${behindN} commits); restarting hub`);
  res.json({ success: true, updated: true, behind: behindN, current: newSha, restarting: true });
  // Install any newly added dependency (keeps node_modules, unlike npm ci) and
  // only then exit: the workflow keep-alive loop relaunches us on the new code.
  (async () => {
    try {
      const r = await npmQ(['install', '--omit=dev', '--no-audit', '--no-fund']);
      console.log(`[updater] npm install ${r.code === 0 ? 'ok' : 'failed (' + r.code + ')'}`);
    } catch (e) { console.log('[updater] npm install error: ' + e.message); }
    try { server.close(); } catch (e) {}
    process.exit(0);
  })();
});

// ─── CLOUD PHONE (Android emulator + VNC) ───
// The phone runs on its OWN runner (android-cloud-phone repo, cloud-phone.yml
// workflow, dedicated self-hosted runner labelled `emulator`). That runner
// installs everything itself on every start (install_deps.sh), boots the
// Android emulator and serves noVNC on a cloudflared tunnel. The hub only:
//   - dispatches the workflow (start/stop) via the GitHub API,
//   - reads the live URL from the android-cloud-phone `session-state` branch
//     (session-phone.json) so the panel knows what to open.
// A local fallback (`PHONE_REPO=` empty or control.sh present) still works for
// a phone sharing the hub's own runner.
const PHONE_DIR = path.join(__dirname, '..', 'public', 'novnc');
const PHONE_ROOT = process.env.PHONE_ROOT || path.join(HOME, 'android-cloud-phone');
const PHONE_VNC_PORT = 5900;
const PHONE_ADB_PORT = 5555;
const PHONE_NO_VNC_PORT = 6080;
const PHONE_CTL = process.env.PHONE_CTL || path.join(PHONE_ROOT, 'scripts', 'control.sh');
const PHONE_REPO = (process.env.PHONE_REPO || 'sj0404-collab/android-cloud-phone').trim();
const PHONE_WF = 'cloud-phone.yml';
const phoneToken = () => runnerToken();

app.use('/phone', express.static(PHONE_DIR, { fallthrough: false }));
app.get('/phone', (req, res) => res.redirect('/phone/vnc.html'));
app.get('/phone/', (req, res) => res.redirect('/phone/vnc.html'));

const remotePhoneAvailable = () => Boolean(PHONE_REPO && phoneToken());

// Raw GitHub dispatch — POST /repos/{repo}/actions/workflows/{wf}/dispatches.
const dispatchPhone = (command, browserUrl) => new Promise(async (resolve) => {
  const token = phoneToken();
  if (!remotePhoneAvailable()) return resolve({ ok: false, out: 'нет GH_TOKEN / PHONE_REPO для remote-телефона' });
  try {
    const inputs = { command, runner: getDefaultPhoneRunner() };
    if (browserUrl) inputs.browser_url = browserUrl;
    const url = `${GITHUB_BASE(PHONE_REPO)}/actions/workflows/${PHONE_WF}/dispatches`;
    const r = await ghApi('POST', url, token, {
      ref: 'main',
      inputs
    });
    if (r.status >= 200 && r.status < 300) return resolve({ ok: true, out: `workflow ${command} dispatched` });
    resolve({ ok: false, out: `dispatch ${command} failed (${r.status}): ${JSON.stringify(r.j || r.error || '')}` });
  } catch (e) { resolve({ ok: false, out: String(e.message || e) }); }
});

const dispatchPhoneBrowser = (url) => dispatchPhone('start', url);

// Read session-phone.json from the android-cloud-phone session-state branch.
const phoneRemoteStatus = async () => {
  const token = phoneToken();
  if (!token) return { url: null, raw: null };
  try {
    const url = `${GITHUB_BASE(PHONE_REPO)}/contents/session-phone.json?ref=session-state`;
    const r = await ghApi('GET', url, token);
    if (r.status !== 200 || !r.j || !r.j.content) return { url: null, raw: null };
    let text = '';
    try { text = Buffer.from(r.j.content, 'base64').toString('utf8'); } catch { return { url: null, raw: null }; }
    const d = JSON.parse(text);
    const live = d && d.state !== 'ended';
    return {
      url: live ? (d.url || d.rawUrl || null) : null,
      raw: d
    };
  } catch { return { url: null, raw: null }; }
};

const phoneLocalStatus = async () => {
  const [vnc, adb, ctl] = await Promise.all([
    phonePortOpen(PHONE_VNC_PORT),
    phonePortOpen(PHONE_ADB_PORT),
    phoneCtrl('status', 8000).catch(e => ({ ok: false, out: String(e.message || e) }))
  ]);
  return { vnc, adb, control: ctl };
};

const phoneCtrl = (sub, timeoutMs = 90000, extraEnv = {}) => new Promise((resolve) => {
  try {
    const p = spawn('bash', [PHONE_CTL, sub], { stdio: ['ignore', 'pipe', 'pipe'], env: { ...process.env, ...extraEnv } });
    let out = '';
    const timer = setTimeout(() => { try { p.kill(); } catch {} }, timeoutMs);
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => out += d);
    p.on('error', e => { clearTimeout(timer); resolve({ ok: false, out: String(e.message || e) }); });
    p.on('close', code => { clearTimeout(timer); resolve({ ok: code === 0, out: out.trim() }); });
  } catch (e) { resolve({ ok: false, out: String(e.message || e) }); }
});

const phonePortOpen = (port, timeoutMs = 1200) => new Promise((resolve) => {
  const s = net.connect(port, '127.0.0.1');
  const t = setTimeout(() => { try { s.destroy(); } catch {} resolve(false); }, timeoutMs);
  s.on('connect', () => { clearTimeout(t); s.destroy(); resolve(true); });
  s.on('error', () => { clearTimeout(t); resolve(false); });
});

const phoneStatus = async () => {
  if (remotePhoneAvailable()) {
    const s = await phoneRemoteStatus();
    // Tunnel first, raw runner URL second, local /phone fallback last.
    const url = s.url;
    return {
      running: Boolean(url || s.raw && s.raw.state === 'live'),
      remote: true, url,
      raw: s.raw,
      noVncPort: PHONE_NO_VNC_PORT,
      defaultEmulator: getDefaultEmulator(), phoneRunner: getDefaultPhoneRunner(),
      adb: Boolean(s.raw && s.raw.adbPort),
      control: { ok: true, out: s.raw && s.raw.state === 'live' ? 'remote: live' : 'remote: idle' }
    };
  }
  const s = await phoneLocalStatus();
  return {
    running: s.vnc, adb: s.adb,
    remote: false, url: null,
    noVncPort: PHONE_NO_VNC_PORT,
    defaultEmulator: getDefaultEmulator(), phoneRunner: getDefaultPhoneRunner(),
    control: s.control
  };
};

app.get('/api/phone/status', async (req, res) => {
  try { res.json(await phoneStatus()); } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/phone/start', async (req, res) => {
  try {
    const requestedEmulator = cleanEmulatorName(req.body && (req.body.emulator || req.body.avd));
    const requestedRunner = cleanEmulatorName(req.body && req.body.runner);
    if (requestedEmulator) setDefaultEmulator(requestedEmulator);
    if (requestedRunner) setDefaultPhoneRunner(requestedRunner);
    const emulator = getDefaultEmulator();
    if (remotePhoneAvailable()) {
      const r = await dispatchPhone('start');
      return res.json({ ok: r.ok, message: r.out, remote: true, emulator });
    }
    const r = await phoneCtrl('start', 90000, { ANDROID_AVD: emulator });
    res.json({ ok: r.ok, message: r.out, remote: false, emulator });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/phone/stop', async (req, res) => {
  try {
    if (remotePhoneAvailable()) {
      const r = await dispatchPhone('stop');
      return res.json({ ok: r.ok, message: r.out, remote: true });
    }
    const r = await phoneCtrl('stop');
    res.json({ ok: r.ok, message: r.out, remote: false });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// Open a URL in the emulator's browser (Kiwi Chrome / default browser via
// the VIEW intent). The page itself is shown through the same noVNC iframe
// (/phone/vnc.html), so the UI just switches tabs to the phone view.
const PHONE_ADB = () => {
  const sdk = process.env.ANDROID_SDK_ROOT || '/usr/local/lib/android/sdk';
  return path.join(sdk, 'platform-tools', 'adb');
};

const phoneAdb = (args, timeoutMs = 15000) => new Promise((resolve) => {
  const adb = PHONE_ADB();
  if (!fs.existsSync(adb)) return resolve({ ok: false, out: 'adb not found: ' + adb });
  try {
    const p = spawn(adb, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    const timer = setTimeout(() => { try { p.kill(); } catch {} }, timeoutMs);
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => out += d);
    p.on('error', e => { clearTimeout(timer); resolve({ ok: false, out: String(e.message || e) }); });
    p.on('close', code => { clearTimeout(timer); resolve({ ok: code === 0, out: out.trim() }); });
  } catch (e) { resolve({ ok: false, out: String(e.message || e) }); }
});

const phoneEnsureBrowser = async () => {
  // Modern emulator images ship Browser (AOSP). Kiwi is optional; whatever
  // handles the VIEW intent is fine — we only need it to open a URL.
  await phoneAdb(['shell', 'getprop', 'sys.boot_completed']).catch(() => {});
};

app.post('/api/phone/browser', async (req, res) => {
  try {
    const url = String((req.body && req.body.url) || '').trim();
    if (!url || !/^https?:\/\/\S+$/i.test(url)) {
      return res.status(400).json({ ok: false, error: 'bad url: ' + url });
    }
    if (remotePhoneAvailable()) {
      // Phone lives on another runner: hand the URL to that runner, which
      // opens it in the emulator browser after boot (cloud-phone.yml).
      const st = await phoneRemoteStatus();
      if (!(st.raw && st.raw.state === 'live')) {
        return res.json({ ok: false, info: 'телефон не запущен — сначала «▶ Старт»' });
      }
      const r = await dispatchPhoneBrowser(url);
      return res.json({ ok: r.ok, message: r.out, remote: true, url });
    }
    await phoneEnsureBrowser();
    const r = await phoneAdb([
      'shell', 'am', 'start',
      '-a', 'android.intent.action.VIEW',
      '-d', url
    ]);
    res.json({ ok: r.ok, message: r.out || 'opened: ' + url });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ─── LINUX DESKTOP VNC (parallel runner) ───
// The hub.yml `vnc` job runs a headless Linux desktop (openbox + xterm + Mesa)
// on a second runner and publishes its noVNC address to session-vnc.json on the
// session-state branch of this repo. The hub only reads that file and hands the
// address to the panel's «Linux screen» button — same pattern as the phone.
const VNC_REPO = (process.env.VNC_REPO || process.env.GITHUB_REPOSITORY || 'sj0404-collab/zen-panel').trim();

const vncRemoteStatus = async () => {
  const token = runnerToken();
  if (!token) return { url: null, raw: null };
  try {
    const url = `${GITHUB_BASE(VNC_REPO)}/contents/session-vnc.json?ref=session-state`;
    const r = await ghApi('GET', url, token);
    if (r.status !== 200 || !r.j || !r.j.content) return { url: null, raw: null };
    let text = '';
    try { text = Buffer.from(r.j.content, 'base64').toString('utf8'); } catch { return { url: null, raw: null }; }
    const d = JSON.parse(text);
    const url2 = d && d.state !== 'ended' ? (d.url || d.novncUrl || null) : null;
    return { url: url2, raw: d };
  } catch { return { url: null, raw: null }; }
};

const vncStatus = async () => {
  // Local screen first: the hub's OWN runner is the desktop that the panel's
  // 'Go · 🖥' actually paints into (DISPLAY=:99 on this machine), it lives on
  // the hub origin (no iframe/tunnel games) and vnc-keepalive heals it. The
  // URL the `vnc` job published is only a fallback - it may belong to another
  // runner of the same cluster, where nothing the hub launches can be seen.
  let local = { url: null, ready: false };
  try { if (vncKeeper) local = await vncKeeper.localStatus(); } catch {}
  if (local.url) {
    return { running: true, url: local.url, remote: false, source: 'local', raw: null, keepalive: vncKeeper ? vncKeeper.status() : null };
  }
  // Свой экран ещё поднимается (ставятся пакеты / стартует x11vnc) — чужой
  // раннер в это время показывать нельзя: наш «Go · 🖥» рисует только на этом
  // раннере, и пользователь видел ровно это — «запущен · другой раннер» +
  // чёрный экран. Ждём свой; удалённый берём только как последнюю надежду.
  if (local.pending) {
    return {
      running: false, url: null, remote: false, source: 'local-pending', raw: null,
      pending: true, installing: local.installing || [],
      keepalive: vncKeeper ? vncKeeper.status() : null
    };
  }
  const s = await vncRemoteStatus();
  const url = s.url;
  return {
    running: Boolean(url || s.raw && s.raw.state === 'live'),
    url,
    remote: true,
    source: url ? 'remote' : 'none',
    raw: s.raw,
    local: local,
    keepalive: vncKeeper ? vncKeeper.status() : null
  };
};

// Diagnostics + manual repair of the always-on desktop (see src/vnc-keepalive.js)
app.get('/api/vnc/keepalive', async (req, res) => {
  try {
    const st = vncKeeper ? vncKeeper.status() : { enabled: false, note: 'keepalive не подключён' };
    const local = vncKeeper ? await vncKeeper.localStatus() : { url: null };
    res.json({ ok: true, keepalive: st, local });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/vnc/keepalive', async (req, res) => {
  if (!vncKeeper) return res.json({ ok: false, error: 'keepalive не подключён' });
  const action = (req.body && req.body.action) || 'repair';
  try {
    const ok = action === 'rebuild' ? await vncKeeper.ensureNow() : await vncKeeper.repair('запрос панели');
    res.json({ ok: true, action, done: ok, keepalive: vncKeeper.status() });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get('/api/vnc/status', async (req, res) => {
  try { res.json(await vncStatus()); } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// If the desktop is live, mirror its noVNC page behind the hub's own origin so
// the panel can embed it in an iframe even through the hub's tunnel.
app.get('/desktop-vnc', async (req, res) => {
  try {
    const s = await vncStatus();
    if (!s.url) return res.status(404).send('VNC desktop is not running');
    res.redirect(s.url);
  } catch (e) { res.status(500).send(String(e.message || e)); }
});

// WebSocket VNC proxy: /ws/vnc  →  tcp://127.0.0.1:5900
// noVNC connects to  ws(s)://<hub-host>:<hub-port>/ws/vnc  over the hub's own
// origin (works through the hub tunnel too, WS is same-origin relative).
// eslint-disable-next-line no-unused-vars
// WebSocket VNC proxy: /ws/vnc  →  tcp://127.0.0.1:5900
// One ws server per http server would fight over the 'upgrade' event, so
// use noServer:true + our own upgrade listener for the VNC path.
const vncWss = new WebSocketServer({ noServer: true });
server.on('upgrade', (req, socket, head) => {
  let u;
  try { u = new URL(req.url, 'http://' + (req.headers.host || 'localhost')); }
  catch { return; }
  if (u.pathname !== '/ws/vnc') return; // let the main /ws WSS handle it
  try {
  vncWss.handleUpgrade(req, socket, head, (ws) => {
    const tcp = net.connect(PHONE_VNC_PORT, '127.0.0.1');
    const destroy = () => { try { tcp.destroy(); } catch {} try { ws.terminate(); } catch {} };
    tcp.on('error', () => destroy());
    tcp.on('data', (d) => { if (ws.readyState === 1) ws.send(d, { binary: true }); });
    ws.on('message', (d) => { try { tcp.write(d); } catch {} });
    ws.on('close', () => destroy());
    ws.on('error', () => destroy());
    vncWss.emit('connection', ws, req);
  });
  } catch (e) {
    console.log('  ⚠ phone-vnc upgrade: ' + e.message);
    try { socket.destroy(); } catch {}
  }
});

// ─── LINUX DESKTOP: run apps on the VNC desktop ───
// POST /api/linux/run  { action: 'browser'|'phone'|'terminal', url? }
// Launches apps inside the Linux VNC desktop (DISPLAY=:99) so the user sees
// them through the noVNC iframe — no HTML site iframes needed.
app.post('/api/linux/run', express.json(), async (req, res) => {
  const { action, url } = req.body || {};
  const display = process.env.VNC_DISPLAY || ':99';
  // Дисплей не обязан быть :99 — socket проверяем по номеру из VNC_DISPLAY
  const dispNum = display.replace(/^:/, '');
  const hasXvfb = fs.existsSync(`/tmp/.X11-unix/X${dispNum}`);
  if (!hasXvfb) return res.json({ ok: false, error: 'Linux VNC desktop не запущен на этом раннере (нет X11 display)' });

  // ВАЖНО: DISPLAY нужно именно ЭКСПОРТИРОВАТЬ. Раньше строка собиралась как
  // `DISPLAY=:99 <команда>`, и переменная попадала только в первое присваивание
  // (BROWSER_BIN=...), а сам chromium запускался уже без DISPLAY → «Missing X
  // server or $DISPLAY» в логе и ни одного окна: так и выглядел сломанный
  // «Go · 🖥».
  const runOnDisplay = (cmd, timeoutMs = 8000) => new Promise((resolve) => {
    try {
      const p = _exec(`export DISPLAY=${display}; ${cmd}`, { timeout: timeoutMs }, (err, stdout, stderr) => {
        resolve({ ok: !err, out: (stdout || '').trim(), err: (stderr || '').trim() });
      });
    } catch (e) { resolve({ ok: false, error: e.message }); }
  });

  try {
    switch (action) {
      case 'browser': {
        if (!url) return res.json({ ok: false, error: 'url required' });
        const escaped = String(url).replace(/'/g, "'\\''");
        const vertical = req.body.vertical || req.body.orient==='vertical' || /youtube.*shorts|m\.youtube|vertical/i.test(url);
        const isYoutube = /youtube\.com|youtu\.be/i.test(url);
        // PulseAudio со звуком: проверяем и стартуем если упал
        try {
          await ensureBrowserAudioSink();
        } catch {}
        try {
          const chk = await pulseRun('pulseaudio --check 2>&1; echo $?');
          if (!chk.out || !chk.out.trim().endsWith('0')) {
            await pulseRun('pulseaudio --start --disallow-exit --exit-idle-time=-1 2>&1');
            await pulseRun('pactl set-sink-volume @DEFAULT_SINK@ 90% 2>/dev/null || true');
            console.log('  🔊 PulseAudio auto-started for browser');
          }
        } catch {}
        // Вертикальный ютуб: узкое окно 412×915 (как Pixel), горизонтальный 1280×720
        const winSize = vertical ? '412,915' : '1280,720';
        // С телефона окно открываем размером с экран телефона и в левом верхнем
        // углу стола: телефон показывает стол крупно (1:1), поэтому такое окно
        // занимает у него весь экран — «рабочий стол» = браузер, а не полоска.
        const mobile = !!(req.body.mobile || req.body.window === 'phone');
        const mobileWin = '420,900';
        // Профиль браузера — в домашней папке, а НЕ в /tmp: YouTube на
        // датацентровом IP показывает «Sign in to confirm you're not a bot»,
        // и после входа сессия должна переживать перезапуск хаба (в /tmp её
        // снесло бы первым же обновлением). На своём раннере ~ сохраняется.
        const profileRoot = path.join(DATA_DIR, 'chrome-profile');
        try { fs.mkdirSync(profileRoot, { recursive: true }); } catch {}
        // Keep Google Chrome and Chromium in different profiles. The old
        // shared profile could leave a Chromium process alive; then starting
        // Chrome only sent the URL to that old process and the codec problem
        // silently returned. Chrome profiles also need their own first-run
        // state, so we can skip the Terms/Welcome window below.
        const googleAvailable = ['/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
          '/usr/local/bin/google-chrome', '/usr/local/bin/google-chrome-stable'].some(fs.existsSync);
        const browserProfile = googleAvailable ? 'google' : 'chromium';
        const userData = path.join(profileRoot, browserProfile, vertical ? 'vertical' : 'normal');
        // Хром с поддержкой звука и автоплея
        // Флаги под headless-VNC: без них Chromium считает окно на Xvfb
        // «перекрытым/фоновым» и душит рендер и медиа — видео в YouTube просто
        // не идёт, а картинка обновляется рывками. Список --disable-features
        // слит в один: второй флаг перекрывает первый.
        // Do not pass --disable-gpu here: it made the video decoder available but
        // forced every frame's composition/rasterization onto the CPU. On Xvfb
        // there is no physical GPU, so use Chrome's SwiftShader GPU process;
        // this is still much faster than a fully disabled GPU and keeps the
        // accelerated video path alive.
        const chromeFlags = `--no-sandbox --test-type --autoplay-policy=no-user-gesture-required`
          + ` --use-gl=angle --use-angle=gl --ignore-gpu-blocklist --enable-gpu-rasterization --enable-oop-rasterization`
          + ` --disable-features=PreloadMediaEngagementData,AutoplayIgnoreWebAudio,CalculateNativeWinOcclusion,MediaEngagementBypassAutoplayPolicies`
          + ` --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-background-timer-throttling`
          + ` --use-fake-ui-for-media-stream`
          + ` --enable-accelerated-video-decode --disable-frame-rate-limit`
          + ` --window-size=${mobile ? mobileWin : winSize} --window-position=${mobile ? '0,0' : '20,20'} --user-data-dir=${userData} --no-first-run --no-default-browser-check --disable-signin-promo --disable-infobars --disable-dev-shm-usage`;
        // Мобильный user-agent для вертикального ютуба (чтобы открылся m.youtube.com/shorts)
        // Default UA is a tablet so sites serve touch-friendly video pages;
        // vertical/Shorts gets a phone UA. This is intentional for the remote
        // screen: the user controls Chrome from a phone/tablet, not a desktop.
        const uaFlag = vertical
          ? `--user-agent='Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36'`
          : `--user-agent='Mozilla/5.0 (Linux; Android 14; Pixel Tablet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36'`;
        // Бинарь ищем на месте: на раннере может быть chromium, chromium-browser,
        // google-chrome или google-chrome-stable — раньше здесь был жёстко
        // забит chromium-browser, и «Go · 🖥» молча не открывал ничего.
        // Prefer Google Chrome: the runner's Chromium build can lack H.264/AAC
        // codecs, so a video page showed its controls but ended with
        // NotSupportedError and generated no PulseAudio sink input at all.
        // Chrome is installed on GitHub runners and carries the media codecs.
        const binPick = `BROWSER_BIN=$(command -v google-chrome-stable || command -v google-chrome || command -v chromium || command -v chromium-browser || true); if [ -z "$BROWSER_BIN" ]; then exit 3; fi`;
        // Браузер пишет свой вывод в лог: без него «не открылось» невозможно
        // объяснить, а именно так и выглядел сломанный «Go · 🖥».
        const blog = path.join(LOG_DIR, 'browser.log');
        const launch = (extraFlags) => runOnDisplay(
          `${binPick}; LIBGL_ALWAYS_SOFTWARE=1 MESA_LOADER_DRIVER_OVERRIDE=llvmpipe GALLIUM_DRIVER=llvmpipe EGL_PLATFORM=x11 PULSE_SINK=browser_youtube setsid nohup "$BROWSER_BIN" ${chromeFlags} ${extraFlags} '${escaped}' >>${JSON.stringify(blog)} 2>&1 & sleep 3; `
          + `pgrep -f "$(basename "$BROWSER_BIN")" | head -1`, 12000);
        let r = await launch(uaFlag);
        let started = Boolean(r.out && /^\d+$/m.test(r.out));
        if (!started) { r = await launch(''); started = Boolean(r.out && /^\d+$/m.test(r.out)); }
        if (!started) {
          r = await runOnDisplay(`(command -v firefox >/dev/null 2>&1 && setsid nohup firefox '${escaped}' >/dev/null 2>&1 &) || (setsid nohup xdg-open '${escaped}' >/dev/null 2>&1 &); sleep 3; pgrep -f firefox | head -1`, 12000);
          started = Boolean(r.out && /^\d+$/m.test(r.out));
        }
        if (!started) {
          const tail = await shTail(blog, 3);
          return res.json({ ok: false, error: 'браузер не запустился (' + (r.err || 'нет процесса').slice(0, 120) + '): ' + tail });
        }
        // Иконки рабочего стола (idesk) — окна поверх всех: без этого шага
        // свежее окно браузера оказывалось «под» иконками, и на экране
        // телефона это выглядело как наложенный поверх страницы рабочий стол.
        try { setTimeout(() => { try { require('./vnc-keepalive').lowerDesktopIcons(); } catch {} }, 1500); } catch {}
        // Громкость на макс и снять mute чтобы ютуб был слышен
        try { await pulseRun('pactl set-sink-mute @DEFAULT_SINK@ 0 2>/dev/null || true'); await pulseRun('pactl set-sink-volume @DEFAULT_SINK@ 90% 2>/dev/null || true'); } catch {}
        return res.json({ ok: true, message: `Браузер запущен${vertical?' (вертикально)':''}: ${url} — звук вкл.`, vertical, winSize });
      }
      case 'phone': {
        // Try to start Android emulator on the local display
        const sdk = process.env.ANDROID_SDK_ROOT || '/usr/local/lib/android/sdk';
        const emulator = path.join(sdk, 'emulator', 'emulator');
        const requestedAvd = cleanEmulatorName(req.body.emulator || req.body.avd);
        const avd = requestedAvd ? (setDefaultEmulator(requestedAvd) || getDefaultEmulator()) : getDefaultEmulator();
        if (fs.existsSync(emulator)) {
          await runOnDisplay(`ANDROID_AVD=${avd} ${emulator} -avd ${avd} -no-window -no-audio &`, 3000);
          return res.json({ ok: true, message: `Эмулятор ${avd} запускается...`, emulator: avd });
        }
        // Fallback: try the cloud-phone workflow dispatch
        if (remotePhoneAvailable()) {
          const r = await dispatchPhone('start');
          return res.json({ ok: r.ok, message: r.out, remote: true });
        }
        return res.json({ ok: false, error: 'Android SDK не найден на этом раннере' });
      }
      case 'terminal': {
        await runOnDisplay(`xterm -geometry 120x30+100+100 &`, 3000);
        try { require('./vnc-keepalive').lowerDesktopIcons(); } catch {}
        return res.json({ ok: true, message: 'Терминал открыт на рабочем столе' });
      }
      case 'files': {
        // Через обёртку: pcmanfm на этом раннере показывает пустой диалог
        // «Desktop manager is not active» — на телефоне это чужое окно поверх
        // стола. Обёртка поднимает менеджер и сразу гасит диалог.
        let launched = false;
        try {
          const ka = require('./vnc-keepalive');
          const launcher = await ka.ensureFilesLauncher();
          if (launcher) {
            await runOnDisplay(`setsid nohup ${JSON.stringify(launcher)} "$HOME/hub-work" >/dev/null 2>&1 &`, 3000);
            launched = true;
          }
        } catch {}
        if (!launched) await runOnDisplay(`(pcmanfm || nautilus || xdg-open ~/hub-work) &`, 3000);
        try { setTimeout(() => { try { require('./vnc-keepalive').dismissStrayDialogs(); } catch {} }, 5000); } catch {}
        try { require('./vnc-keepalive').lowerDesktopIcons(); } catch {}
        return res.json({ ok: true, message: 'Файловый менеджер открыт' });
      }
      default:
        return res.json({ ok: false, error: 'unknown action: ' + action });
    }
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

// ─── CHROME PROFILE: persist Google account across restarts ───
const CHROME_PROFILE_ROOT = path.join(DATA_DIR, 'chrome-profile');
app.get('/api/chrome/profile/status', (req, res) => {
  try {
    const googleProfile = path.join(CHROME_PROFILE_ROOT, 'google');
    const chromiumProfile = path.join(CHROME_PROFILE_ROOT, 'chromium');
    const hasGoogle = fs.existsSync(googleProfile) && fs.readdirSync(googleProfile).length > 0;
    const hasChromium = fs.existsSync(chromiumProfile) && fs.readdirSync(chromiumProfile).length > 0;
    res.json({ success: true, exists: hasGoogle || hasChromium, google: hasGoogle, chromium: hasChromium });
  } catch (e) { res.json({ success: false, error: e.message }); }
});
app.post('/api/chrome/profile/clear', (req, res) => {
  try {
    const googleProfile = path.join(CHROME_PROFILE_ROOT, 'google');
    const chromiumProfile = path.join(CHROME_PROFILE_ROOT, 'chromium');
    if (fs.existsSync(googleProfile)) fs.rmSync(googleProfile, { recursive: true, force: true });
    if (fs.existsSync(chromiumProfile)) fs.rmSync(chromiumProfile, { recursive: true, force: true });
    res.json({ success: true, message: 'Профиль Chrome очищен' });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ─── OCR + SCREENSHOT для TTS/чтения в фоне ───
const ocrRun = (cmd) => new Promise((resolve)=>{
  // Здесь был ПОВТОРНЫЙ require, который доставал из child_process свойство с
  // именем _exec — такого свойства у модуля нет, и /api/ocr вместе с
  // /api/screenshot падали с «_exec is not a function»: читалка TTS/OCR на
  // «Экране» не работала вообще. Хелпер _exec уже объявлен выше в модуле
  // (переименование exec при разрушении объекта), берём его оттуда.
  _exec(cmd, {timeout: 15000}, (err, stdout, stderr)=>{
    resolve({ok: !err, out: (stdout||'').trim(), err: (stderr||'').trim()});
  });
});
app.post('/api/ocr', express.json(), async (req,res)=>{
  const display = process.env.VNC_DISPLAY || ':99';
  const hasX = require('fs').existsSync('/tmp/.X11-unix/X99') || require('fs').existsSync('/tmp/.X11-lock');
  if(!hasX) return res.json({ok:false, error:'VNC desktop не запущен'});
  const tmpPng = '/tmp/ocr_'+Date.now()+'.png';
  try{
    // 1) Скриншот
    let cap = await ocrRun(`DISPLAY=${display} import -window root ${tmpPng} 2>&1`);
    if(!require('fs').existsSync(tmpPng)){
      cap = await ocrRun(`DISPLAY=${display} scrot ${tmpPng} 2>&1`);
    }
    if(!require('fs').existsSync(tmpPng)){
      cap = await ocrRun(`DISPLAY=${display} xwd -root -silent -out /tmp/ocr.xwd 2>&1 && convert /tmp/ocr.xwd ${tmpPng} 2>&1`);
    }
    if(!require('fs').existsSync(tmpPng)) return res.json({ok:false, error:'Не удалось сделать скриншот: '+cap.err});
    // 2) OCR
    let ocr = await ocrRun(`tesseract ${tmpPng} stdout -l rus+eng --psm 6 2>&1`);
    if(!ocr.ok || !ocr.out || ocr.out.includes('Error')){
      ocr = await ocrRun(`tesseract ${tmpPng} stdout -l eng --psm 6 2>&1`);
    }
    // Если tesseract не установлен
    if(ocr.out.includes('not found') || ocr.out.includes('command not found')){
      return res.json({ok:false, error:'tesseract не установлен на раннере. Установи: sudo apt-get install -y tesseract-ocr tesseract-ocr-rus imagemagick scrot'});
    }
    const text = ocr.out.trim().slice(0,6000);
    try{ require('fs').unlinkSync(tmpPng); }catch{}
    try{ require('fs').unlinkSync('/tmp/ocr.xwd'); }catch{}
    if(!text) return res.json({ok:false, error:'OCR не нашёл текст'});
    res.json({ok:true, text});
  }catch(e){
    res.json({ok:false, error:e.message});
  }
});
app.get('/api/screenshot', async (req,res)=>{
  const display = process.env.VNC_DISPLAY || ':99';
  const tmpPng = '/tmp/shot_'+Date.now()+'.png';
  try{
    let cap = await ocrRun(`DISPLAY=${display} import -window root ${tmpPng} 2>&1`);
    if(!require('fs').existsSync(tmpPng)) cap = await ocrRun(`DISPLAY=${display} scrot ${tmpPng} 2>&1`);
    if(!require('fs').existsSync(tmpPng)) return res.status(404).send('no screenshot');
    res.sendFile(tmpPng, ()=>{ try{require('fs').unlinkSync(tmpPng);}catch{} });
  }catch(e){ res.status(500).send(e.message); }
});

// ─── GITHUB: browse repos, contents, commits, workflows, builds ───
// All endpoints use GH_TOKEN to call the GitHub REST API directly.
// Provides full repo browsing for the linked GitHub account.
const ghHeaders = () => ({
  Authorization: `Bearer ${runnerToken()}`,
  Accept: 'application/vnd.github+json',
  'User-Agent': 'zen-panel-hub',
  'X-GitHub-Api-Version': '2022-11-28'
});

// GET /api/gh/repos — all repos for the authenticated user
app.get('/api/gh/repos', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.json({ success: true, repos: [] });
  try {
    const page = parseInt(req.query.page || '1', 10);
    const perPage = Math.min(100, parseInt(req.query.per_page || '50', 10));
    const r = await fetch(
      `https://api.github.com/user/repos?per_page=${perPage}&page=${page}&sort=updated&affiliation=owner,collaborator,organization_member`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.json({ success: false, error: `GitHub API ${r.status}` });
    const repos = await r.json();
    res.json({
      success: true,
      repos: repos.map(r => ({
        full_name: r.full_name,
        private: !!r.private,
        description: r.description || '',
        default_branch: r.default_branch,
        updated_at: r.updated_at,
        pushed_at: r.pushed_at,
        language: r.language,
        html_url: r.html_url,
        stargazers_count: r.stargazers_count,
        forks_count: r.forks_count,
        open_issues_count: r.open_issues_count,
        size: r.size,
        topics: r.topics || []
      })),
      page, perPage
    });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Manifests describe a repo's workspace so CLI agents know exactly where to
// work (clone, tmp, branch) and are told to never touch the OS /tmp.
const manifestFor = (fullName, repoDir, targetDir, tmpDir, ref) => `# Репозиторий: ${fullName}

Рабочая папка этого репозитория на раннере. Всё лежит на виду —
никакие файлы не прячутся в системном /tmp.

- **Клон (работай здесь):** ${targetDir}
- **Ветка:** ${ref || 'main'}
- **Только твои временные файлы (сборки, кеши, артефакты):** ${tmpDir}
- **Манифест:** ${path.join(targetDir, 'MANIFEST.md')}

## Правила для CLI-агентов
1. НИКОГДА не создавай файлы в /tmp или os.tmpdir() — это не твоя папка.
2. Временные файлы создавай ТОЛЬКО в ${tmpDir}.
3. Исходники и изменения делай в ${targetDir}; пуши в git оттуда.
4. GitHub-токен доступен в переменной окружения $GH_TOKEN — никогда не выводи
   и не логируй его значение.
5. Готовые сборки/артефакты клади в ${tmpDir} — их видно вкладкой «Файлы».
`;
const writeRepoManifest = (fullName, repoDir, targetDir, tmpDir, ref, manifestDir = targetDir) => {
  fs.mkdirSync(tmpDir, { recursive: true });
  const manifestPath = path.join(manifestDir, 'MANIFEST.md');
  let current = '';
  try { current = fs.readFileSync(manifestPath, 'utf8'); } catch {}
  if (!current || current.includes('Рабочая папка этого репозитория на раннере')) {
    fs.writeFileSync(manifestPath, manifestFor(fullName, repoDir, targetDir, tmpDir, ref));
  }
};
const githubDefaultBranch = async (fullName) => {
  try {
    const r = await fetch(`https://api.github.com/repos/${fullName}`, { headers: ghHeaders() });
    if (!r.ok) return null;
    const d = await r.json();
    return typeof d.default_branch === 'string' && d.default_branch ? d.default_branch : null;
  } catch { return null; }
};
const gitBranch = (dir) => {
  try { return require('child_process').execFileSync('git', ['-C', dir, 'branch', '--show-current'], { encoding: 'utf8', timeout: 2500 }).trim() || null; }
  catch { return null; }
};
const gitRemote = (dir) => {
  try { return require('child_process').execFileSync('git', ['-C', dir, 'remote', 'get-url', 'origin'], { encoding: 'utf8', timeout: 2500 }).trim() || null; }
  catch { return null; }
};
const configureCloneCredentials = (dir, token) => new Promise((resolve) => {
  const child = spawn('git', ['config', 'credential.helper', '!f() { echo "username=x-access-token"; echo "password=$GH_TOKEN"; }; f'], {
    cwd: dir, env: { ...process.env, GH_TOKEN: token }
  });
  child.on('close', code => resolve(code === 0));
  child.on('error', () => resolve(false));
});

// POST /api/gh/clone — clone a repo into hub-work using the linked GH_TOKEN
app.post('/api/gh/clone', express.json(), async (req, res) => {
  const token = runnerToken();
  if (!token) return res.json({ success: false, error: 'нет GH_TOKEN — привяжи токен в настройках' });
  const { full_name, branch } = req.body;
  if (!full_name || !/^[^/]+\/[^/]+$/.test(full_name)) {
    return res.json({ success: false, error: 'укажи full_name (user/repo)' });
  }
  const repoName = path.basename(full_name.split('/').pop());
  if (!repoName || repoName === '.' || repoName === '..') {
    return res.json({ success: false, error: 'некорректное имя репозитория' });
  }
  const repoDir = path.join(WORK_DIR, repoName);
  const targetDir = path.join(repoDir, 'code');
  const tmpDir = path.join(repoDir, 'tmp');
  const requestedRef = typeof branch === 'string' ? branch.trim() : '';
  const ref = requestedRef || await githubDefaultBranch(full_name) || 'main';
  const cleanUrl = `https://github.com/${full_name}.git`;
  const gitEnv = { ...process.env, GH_TOKEN: token };
  const gitAuth = ['-c', 'credential.username=x-access-token',
    '-c', 'credential.helper=!f() { echo "username=x-access-token"; echo "password=$GH_TOKEN"; }; f'];
  const runGit = (args, cwd) => new Promise((resolve, reject) => {
    const child = spawn('git', args, { cwd, env: gitEnv, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    child.stdout.on('data', d => { out += String(d); });
    child.stderr.on('data', d => { out += String(d); });
    child.on('close', code => code === 0 ? resolve(out.trim()) : reject(new Error(out)));
    child.on('error', reject);
  });
  const writeManifest = () => writeRepoManifest(full_name, repoDir, targetDir, tmpDir, gitBranch(targetDir) || ref);
  const isRepo = () => {
    try { return fs.existsSync(path.join(targetDir, '.git')) && require('child_process').execFileSync('git', ['-C', targetDir, 'rev-parse', '--git-dir'], { stdio: 'ignore', timeout: 2500 }); }
    catch { return false; }
  };
  if (isRepo()) {
    const remote = gitRemote(targetDir);
    const match = remote && remote.match(/github\.com[:/]([^/]+\/[^/]+?)(?:\.git)?$/i);
    if (match && match[1].toLowerCase() !== full_name.toLowerCase()) {
      return res.json({ success: false, error: 'путь уже содержит другой репозиторий: ' + targetDir });
    }
    try {
      await runGit(['pull'], targetDir);
      writeManifest();
      return res.json({ success: true, path: targetDir, pulled: true });
    } catch (e) {
      writeManifest();
      return res.json({ success: true, path: targetDir, pulled: false, pullError: e.message });
    }
  }
  if (fs.existsSync(targetDir)) {
    let entries;
    try { entries = fs.readdirSync(targetDir); }
    catch { return res.json({ success: false, error: 'путь клона занят файлом: ' + targetDir }); }
    if (entries.length) return res.json({ success: false, error: 'папка клона уже занята: ' + targetDir });
    fs.rmdirSync(targetDir);
  }
  fs.mkdirSync(repoDir, { recursive: true });
  const clone = async (args) => {
    const staging = `${targetDir}.staging-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    try {
      await runGit([...gitAuth, 'clone', ...args, cleanUrl, staging], WORK_DIR);
      if (!fs.existsSync(path.join(staging, '.git'))) throw new Error('clone прошёл, но .git не найден');
      if (!await configureCloneCredentials(staging, token)) throw new Error('не удалось настроить git-аутентификацию');
      writeRepoManifest(full_name, repoDir, targetDir, tmpDir, gitBranch(staging) || ref, staging);
      fs.renameSync(staging, targetDir);
    } catch (e) {
      try { fs.rmSync(staging, { recursive: true, force: true }); } catch {}
      throw e;
    }
  };
  try {
    await clone(['--depth', '1', '-b', ref]);
  } catch (e) {
    try {
      await clone(['--depth', '1']);
    } catch (e2) {
      return res.json({ success: false, error: 'clone не удался: ' + (e2.message || e.message) });
    }
  }
  writeManifest();
  res.json({ success: true, path: targetDir });
});

// GET /api/gh/token-status — check if a GitHub token is available
app.get('/api/gh/token-status', (req, res) => {
  const token = runnerToken();
  res.json({ success: true, hasToken: !!token, masked: token ? token.slice(0, 6) + '...' + token.slice(-4) : '' });
});

// DELETE /api/gh/delete-repo — delete a repo from the linked account
app.post('/api/gh/delete-repo', express.json(), async (req, res) => {
  const token = runnerToken();
  if (!token) return res.json({ success: false, error: 'нет GH_TOKEN' });
  const { full_name } = req.body;
  if (!full_name || !full_name.includes('/')) return res.json({ success: false, error: 'укажи full_name' });
  try {
    const r = await fetch(`https://api.github.com/repos/${full_name}`, {
      method: 'DELETE',
      headers: ghHeaders()
    });
    if (r.status === 204) return res.json({ success: true });
    const txt = await r.text().catch(() => '');
    res.json({ success: false, error: `GitHub ${r.status}: ${txt.slice(0, 200)}` });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// DELETE /api/gh/delete-file — delete a file in a repo
app.post('/api/gh/delete-file', express.json(), async (req, res) => {
  const token = runnerToken();
  if (!token) return res.json({ success: false, error: 'нет GH_TOKEN' });
  const { full_name, path: filePath, message, branch } = req.body;
  if (!full_name || !filePath) return res.json({ success: false, error: 'укажи full_name и path' });
  try {
    // Get file sha first
    const getUrl = `https://api.github.com/repos/${full_name}/contents/${encodeURI(filePath)}${branch ? '?ref=' + encodeURIComponent(branch) : ''}`;
    const getR = await fetch(getUrl, { headers: ghHeaders() });
    if (!getR.ok) return res.json({ success: false, error: `файл не найден: GitHub ${getR.status}` });
    const fileData = await getR.json();
    const sha = fileData.sha;
    // Delete
    const delUrl = `https://api.github.com/repos/${full_name}/contents/${encodeURI(filePath)}`;
    const body = { message: message || `delete ${filePath}`, sha, branch: branch || undefined };
    const delR = await fetch(delUrl, {
      method: 'DELETE',
      headers: { ...ghHeaders(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (delR.ok || delR.status === 204) return res.json({ success: true });
    const txt = await delR.text().catch(() => '');
    res.json({ success: false, error: `GitHub ${delR.status}: ${txt.slice(0, 200)}` });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// GET /api/gh/download-repo?full_name=user/repo&ref=main — download repo as zip
app.get('/api/gh/download-repo', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'нет GH_TOKEN' });
  const fullName = req.query.full_name;
  const ref = req.query.ref || '';
  if (!fullName) return res.status(400).json({ error: 'укажи full_name' });
  try {
    const url = `https://api.github.com/repos/${fullName}/zipball${ref ? '?ref=' + encodeURIComponent(ref) : ''}`;
    const r = await fetch(url, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'User-Agent': 'zen-panel-hub' },
      redirect: 'manual'
    });
    // Follow redirect manually to get the actual download
    if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
      const r2 = await fetch(r.headers.get('location'), {
        headers: { Authorization: `Bearer ${token}`, 'User-Agent': 'zen-panel-hub' }
      });
      if (r2.ok) {
        const ct = r2.headers.get('content-type') || 'application/zip';
        const cd = r2.headers.get('content-disposition') || cdHeader('attachment', fullName.split('/').pop() + '.zip');
        res.setHeader('Content-Type', ct);
        res.setHeader('Content-Disposition', cd);
        const buf = Buffer.from(await r2.arrayBuffer());
        res.end(buf);
        return;
      }
    }
    if (r.ok) {
      const ct = r.headers.get('content-type') || 'application/zip';
      const cd = r.headers.get('content-disposition') || cdHeader('attachment', fullName.split('/').pop() + '.zip');
      res.setHeader('Content-Type', ct);
      res.setHeader('Content-Disposition', cd);
      const buf = Buffer.from(await r.arrayBuffer());
      res.end(buf);
      return;
    }
    res.status(r.status).json({ error: `GitHub ${r.status}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/download-release-asset — download a specific release asset or source archive
// ?full_name=user/repo&tag=v1.0&asset_id=123  or  ?full_name=user/repo&tag=v1.0&asset_name=app.apk
// If no asset_id/name → downloads source tarball
app.get('/api/gh/download-release-asset', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'нет GH_TOKEN' });
  const { full_name, tag, asset_id, asset_name } = req.query;
  if (!full_name || !tag) return res.status(400).json({ error: 'укажи full_name и tag' });
  try {
    // If asset_id or asset_name given → find and download the asset
    if (asset_id || asset_name) {
      const relsR = await fetch(`https://api.github.com/repos/${full_name}/releases/tags/${encodeURIComponent(tag)}`, { headers: ghHeaders() });
      if (!relsR.ok) return res.status(relsR.status).json({ error: `релиз не найден: ${relsR.status}` });
      const rel = await relsR.json();
      let asset = null;
      if (asset_id) asset = (rel.assets || []).find(a => String(a.id) === String(asset_id));
      else if (asset_name) asset = (rel.assets || []).find(a => a.name === asset_name);
      if (!asset) return res.status(404).json({ error: 'asset не найден' });
      // Download asset
      const dlR = await fetch(asset.url, {
        headers: { Authorization: `Bearer ${token}`, Accept: 'application/octet-stream', 'User-Agent': 'zen-panel-hub' },
        redirect: 'manual'
      });
      if (dlR.status >= 300 && dlR.status < 400 && dlR.headers.get('location')) {
        const r2 = await fetch(dlR.headers.get('location'), { headers: { 'User-Agent': 'zen-panel-hub' } });
        if (r2.ok) {
          res.setHeader('Content-Type', r2.headers.get('content-type') || 'application/octet-stream');
          res.setHeader('Content-Disposition', cdHeader('attachment', asset.name));
          const buf = Buffer.from(await r2.arrayBuffer());
          res.end(buf);
          return;
        }
      }
      if (dlR.ok) {
        res.setHeader('Content-Type', dlR.headers.get('content-type') || 'application/octet-stream');
        res.setHeader('Content-Disposition', cdHeader('attachment', asset.name));
        const buf = Buffer.from(await dlR.arrayBuffer());
        res.end(buf);
        return;
      }
      return res.status(dlR.status).json({ error: `GitHub ${dlR.status}` });
    }
    // No asset specified → download source tarball
    const url = `https://api.github.com/repos/${full_name}/tarball/${encodeURIComponent(tag)}`;
    const r = await fetch(url, {
      headers: { ...ghHeaders(), Accept: 'application/vnd.github+json' },
      redirect: 'manual'
    });
    if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
      const r2 = await fetch(r.headers.get('location'), { headers: { 'User-Agent': 'zen-panel-hub' } });
      if (r2.ok) {
        res.setHeader('Content-Type', r2.headers.get('content-type') || 'application/gzip');
        res.setHeader('Content-Disposition', cdHeader('attachment', full_name.split('/').pop() + '-' + tag + '.tar.gz'));
        const buf = Buffer.from(await r2.arrayBuffer());
        res.end(buf);
        return;
      }
    }
    if (r.ok) {
      res.setHeader('Content-Type', r.headers.get('content-type') || 'application/gzip');
      res.setHeader('Content-Disposition', cdHeader('attachment', full_name.split('/').pop() + '-' + tag + '.tar.gz'));
      const buf = Buffer.from(await r.arrayBuffer());
      res.end(buf);
      return;
    }
    res.status(r.status).json({ error: `GitHub ${r.status}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/download-file — download any file from a repo by path+ref
// ?full_name=user/repo&path=src/main.js&ref=main
app.get('/api/gh/download-file', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'нет GH_TOKEN' });
  const { full_name, path: filePath, ref } = req.query;
  if (!full_name || !filePath) return res.status(400).json({ error: 'укажи full_name и path' });
  try {
    const q = `?ref=${encodeURIComponent(ref || 'main')}`;
    const r = await fetch(`https://api.github.com/repos/${full_name}/contents/${encodeURI(filePath)}${q}`, {
      headers: { ...ghHeaders(), Accept: 'application/vnd.github.raw' },
      redirect: 'manual'
    });
    if (r.status >= 300 && r.status < 400 && r.headers.get('location')) {
      const r2 = await fetch(r.headers.get('location'), { headers: { 'User-Agent': 'zen-panel-hub' } });
      if (r2.ok) {
        const fname = filePath.split('/').pop();
        res.setHeader('Content-Type', r2.headers.get('content-type') || 'application/octet-stream');
        res.setHeader('Content-Disposition', cdHeader('attachment', fname));
        const buf = Buffer.from(await r2.arrayBuffer());
        res.end(buf);
        return;
      }
    }
    if (r.ok) {
      const fname = filePath.split('/').pop();
      res.setHeader('Content-Type', r.headers.get('content-type') || 'application/octet-stream');
      res.setHeader('Content-Disposition', cdHeader('attachment', fname));
      const buf = Buffer.from(await r.arrayBuffer());
      res.end(buf);
      return;
    }
    res.status(r.status).json({ error: `GitHub ${r.status}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo — repo info
app.get('/api/gh/repos/:owner/:repo', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const d = await r.json();
    res.json({
      full_name: d.full_name, private: d.private, description: d.description,
      default_branch: d.default_branch, html_url: d.html_url,
      pushed_at: d.pushed_at, language: d.language,
      stargazers_count: d.stargazers_count, forks_count: d.forks_count,
      open_issues_count: d.open_issues_count, size: d.size,
      topics: d.topics || [], license: d.license && d.license.spdx_id
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/contents?path=&ref= — browse file tree
app.get('/api/gh/repos/:owner/:repo/contents', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const p = req.query.path || '';
    const ref = req.query.ref || '';
    const q = `?ref=${encodeURIComponent(ref)}`;
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURI(p)}${ref ? q : ''}`;
    const r = await fetch(url, { headers: ghHeaders() });
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    const items = Array.isArray(data) ? data : [data];
    res.json({
      items: items.map(it => ({
        name: it.name, path: it.path, type: it.type,
        size: it.size, sha: it.sha, download_url: it.download_url
      })),
      path: p, repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/commits — list recent commits
app.get('/api/gh/repos/:owner/:repo/commits', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const perPage = Math.min(100, parseInt(req.query.per_page || '20', 10));
    const path = req.query.path || '';
    let url = `https://api.github.com/repos/${owner}/${repo}/commits?per_page=${perPage}`;
    if (path) url += `&path=${encodeURIComponent(path)}`;
    const r = await fetch(url, { headers: ghHeaders() });
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      commits: (Array.isArray(data) ? data : []).map(c => ({
        sha: c.sha && c.sha.slice(0, 7),
        message: (c.commit && c.commit.message || '').split('\n')[0],
        author: c.commit && c.commit.author && c.commit.author.name,
        date: c.commit && c.commit.author && c.commit.author.date,
        html_url: c.html_url
      })),
      repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/branches — list branches
app.get('/api/gh/repos/:owner/:repo/branches', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/branches?per_page=50`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      branches: data.map(b => ({ name: b.name, sha: b.commit && b.commit.sha })),
      repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/workflows — list workflows
app.get('/api/gh/repos/:owner/:repo/workflows', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/actions/workflows?per_page=30`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      workflows: (data.workflows || []).map(w => ({
        id: w.id, name: w.name, path: w.path, state: w.state,
        updated_at: w.updated_at, html_url: w.html_url
      })),
      repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/runs — list recent workflow runs
app.get('/api/gh/repos/:owner/:repo/runs', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const perPage = Math.min(100, parseInt(req.query.per_page || '20', 10));
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/actions/runs?per_page=${perPage}`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      runs: (data.workflow_runs || []).map(r => ({
        id: r.id, name: r.name, status: r.status, conclusion: r.conclusion,
        html_url: r.html_url, created_at: r.created_at,
        run_number: r.run_number, head_branch: r.head_branch
      })),
      repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/runs/:runId/artifacts — list artifacts for a run
app.get('/api/gh/repos/:owner/:repo/runs/:runId/artifacts', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo, runId } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/actions/runs/${runId}/artifacts`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      artifacts: (data.artifacts || []).map(a => ({
        id: a.id, name: a.name, size_in_bytes: a.size_in_bytes,
        created_at: a.created_at, expired: a.expired,
        archive_download_url: a.archive_download_url
      })),
      repo: `${owner}/${repo}`, runId
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/artifacts/:id/download — download artifact
// Proxies the GitHub artifact download URL through the hub server so the
// user's device can download the build artifact without CORS issues.
app.get('/api/gh/repos/:owner/:repo/artifacts/:id/download', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo, id } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/actions/artifacts/${id}/zip`,
      { headers: ghHeaders(), redirect: 'follow' }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', cdHeader('attachment', 'artifact-' + id + '.zip'));
    const buffer = await r.arrayBuffer();
    res.send(Buffer.from(buffer));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/gh/repos/:owner/:repo/releases — list releases
app.get('/api/gh/repos/:owner/:repo/releases', async (req, res) => {
  const token = runnerToken();
  if (!token) return res.status(401).json({ error: 'no GH_TOKEN' });
  try {
    const { owner, repo } = req.params;
    const r = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/releases?per_page=10`,
      { headers: ghHeaders() }
    );
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    const data = await r.json();
    res.json({
      releases: (Array.isArray(data) ? data : []).map(rel => ({
        tag_name: rel.tag_name, name: rel.name, created_at: rel.created_at,
        html_url: rel.html_url, draft: rel.draft, prerelease: rel.prerelease,
        assets: (rel.assets || []).map(a => ({
          id: a.id, name: a.name, size: a.size, browser_download_url: a.browser_download_url,
          content_type: a.content_type
        }))
      })),
      repo: `${owner}/${repo}`
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── TUNNEL STATE ───
// A quick-tunnel URL is ephemeral. Keep its lifecycle separate from the
// public state so a dead cloudflared process can never leave a clickable URL
// behind (that stale URL is what produces Cloudflare Error 1033).
let tunnelInfo = null; // { state, url, type, error, startedAt, retryAt }
let activeTunnel = null; // { close, onExit, isAlive, healthCheck }
let tunnelRestartTimer = null;
let tunnelHealthTimer = null;
let tunnelStopped = false;
let tunnelFailure = 0;

function stopManagedTunnel() {
  tunnelStopped = true;
  if (tunnelRestartTimer) clearTimeout(tunnelRestartTimer);
  if (tunnelHealthTimer) clearInterval(tunnelHealthTimer);
  tunnelRestartTimer = null;
  tunnelHealthTimer = null;
  if (activeTunnel && activeTunnel.close) {
    try { activeTunnel.close(); } catch {}
  }
  activeTunnel = null;
}

function startManagedTunnel(port, type) {
  tunnelStopped = false;
  tunnelFailure = 0;
  const launch = async () => {
    if (tunnelStopped) return;
    const startedAt = new Date().toISOString();
    tunnelInfo = { state: 'starting', url: null, type, error: null, startedAt, retryAt: null };
    console.log(`  🔗 Starting ${type} tunnel (the URL is withheld until it passes a health check)...`);
    let result;
    try {
      result = await startTunnel(port, type);
    } catch (e) {
      result = { error: e.message };
    }
    if (tunnelStopped) {
      if (result && result.close) result.close();
      return;
    }
    if (!result || !result.url) {
      tunnelFailure += 1;
      const delay = Math.min(30000, 3000 * tunnelFailure);
      const error = (result && result.error) || 'tunnel did not start';
      tunnelInfo = {
        state: 'error', url: null, type, error, startedAt,
        retryAt: new Date(Date.now() + delay).toISOString()
      };
      console.log(`  ❌ Tunnel error: ${error}`);
      console.log(`  🔁 Retrying tunnel in ${Math.ceil(delay / 1000)}s.`);
      tunnelRestartTimer = setTimeout(() => { tunnelRestartTimer = null; launch(); }, delay);
      return;
    }

    tunnelFailure = 0;
    activeTunnel = result;
    tunnelInfo = {
      state: 'ready', url: result.url, type: result.type || type,
      error: null, startedAt, retryAt: null
    };
    console.log(`  🌐 Public:  ${result.url}`);
    console.log(`  📋 Type:    ${result.type || type}`);

    const reconnect = reason => {
      if (tunnelStopped || tunnelRestartTimer) return;
      if (tunnelHealthTimer) clearInterval(tunnelHealthTimer);
      tunnelHealthTimer = null;
      activeTunnel = null;
      const delay = 3000;
      tunnelInfo = {
        state: 'reconnecting', url: null, type: result.type || type,
        error: reason, startedAt, retryAt: new Date(Date.now() + delay).toISOString()
      };
      console.log(`  ⚠ ${reason}; hiding the stale URL and reopening it.`);
      tunnelRestartTimer = setTimeout(() => { tunnelRestartTimer = null; launch(); }, delay);
    };

    // A connector can remain as a process while its edge connection is lost.
    // Process liveness alone is therefore insufficient to prevent Error 1033.
    if (typeof result.healthCheck === 'function') {
      tunnelHealthTimer = setInterval(async () => {
        if (tunnelStopped || activeTunnel !== result) return;
        try {
          const health = await result.healthCheck();
          if (!health || !health.ok) {
            try { result.close(); } catch {}
            reconnect(`public tunnel health check failed${health && health.status ? ` (HTTP ${health.status})` : ''}`);
          }
        } catch (e) {
          try { result.close(); } catch {}
          reconnect(`public tunnel health check failed (${e.message})`);
        }
      }, 30000);
      tunnelHealthTimer.unref?.();
    }

    if (typeof result.onExit === 'function') {
      result.onExit(info => {
        if (tunnelStopped || info.intentional) return;
        reconnect(`connector exited${info.code == null ? '' : ` (code ${info.code})`}`);
      });
    }
  };
  launch();
}

// ─── START ───
// One attempt at a time: each listen() call stacks its own 'listening'
// callback on the shared server object, so a failed attempt left its callback
// attached and the successful retry fired BOTH onReady(oldPort) and
// onReady(newPort) - measured: double startup banner, and in --tunnel mode
// that would open two tunnels. Remove the previous attempt's listeners before
// retrying.
function tryListen(port, onReady) {
  const ready = () => onReady(port, server);
  const onError = (err) => {
    if (err.code === 'EADDRINUSE') {
      if (process.env.HUB_PORT_STRICT === '1') {
        console.error(`  ❌ Port ${port} is already in use; refusing to start a second hub.`);
        process.exit(1);
      }
      const next = Number(port) + 1;
      console.log(`  ⚠ Port ${port} is busy, trying ${next}...`);
      server.removeListener('listening', ready);
      server.removeListener('error', onError);
      tryListen(next, onReady);
    } else {
      console.error(`  ❌ Server error: ${err.message}`);
      process.exit(1);
    }
  };
  server.once('listening', ready);
  server.on('error', onError);
  server.listen(port, HOST);
}

function onReady(actualPort) {
  // Update PORT global for all routes/display
  process.env.PORT = actualPort;

  const nets = os.networkInterfaces();
  const allIPs = [];
  for (const [name, iface] of Object.entries(nets)) {
    for (const cfg of iface) {
      if (cfg.family === 'IPv4' && !cfg.internal) {
        allIPs.push({ name, ip: cfg.address });
      }
    }
  }
  console.log(`\n  ◆ NPM Hub running on port ${actualPort}:`);
  console.log(`    Local:   http://localhost:${actualPort}`);
  if (HOST_ALIAS && hostAliasInstalled) console.log(`    Alias:   http://${HOST_ALIAS}:${actualPort}  (via /etc/hosts, LAN only)`);
  if (allIPs.length > 0) {
    console.log(`    Network:`);
    for (const { name, ip } of allIPs) {
      console.log(`      ${ip}:${actualPort}  (${name})`);
    }
  }

  // Tunnel mode
  const tunnelType = process.argv.find(a => a.startsWith('--tunnel='))?.split('=')[1]
    || (process.argv.includes('--tunnel') ? process.argv[process.argv.indexOf('--tunnel') + 1] : null);

  if (tunnelType) {
    startManagedTunnel(actualPort, tunnelType);
  } else {
    console.log('');
  }

  try { require('child_process').exec(`start http://localhost:${actualPort}`); } catch {}

  // Keep a readable copy of the opencode chat history in ~/.local/share/
  // opencode/history/ (a stable dir outside /tmp, which the OS may clean at
  // any moment) — run once at startup, then daily while the hub lives.
  // PUBLISH=1 + GH_TOKEN pushes a bundle to the session-state branch too.
  const backupHistory = (first) => {
    const { spawn } = require('child_process');
    const script = path.join(__dirname, '..', '..', 'tools', 'backup-chat-history.sh');
    if (!fs.existsSync(script)) return;
    const child = spawn('bash', [script], {
      env: { ...process.env, PUBLISH: '1' },
      stdio: ['ignore', 'ignore', 'pipe']
    });
    child.on('error', () => {});
    if (first) console.log('  💾 Chat-history backup scheduled (daily).');
  };
  backupHistory(true);
  setInterval(() => backupHistory(false), 24 * 60 * 60 * 1000);
}

// ─── ALWAYS-ON DESKTOP ───
// The screen must be there before anyone asks for it: vnc-keepalive starts the
// Xvfb/openbox/x11vnc/websockify stack on THIS runner, proxies it under
// /novnc + /ws/desktop, paints the wallpaper/shortcuts and repairs it every
// 15 s. Started before the listener so the proxy is registered on `server`.
let vncKeeper = null;
try {
  vncKeeper = require('./vnc-keepalive').start({
    repoRoot: GIT_ROOT,
    app,
    server,
    port: PORT,
    log: (m) => console.log('  🖥 ' + m)
  });
  console.log('  🖥 Always-on desktop: ' + JSON.stringify(vncKeeper.status().note));
} catch (e) {
  console.log('  🖥 vnc-keepalive не запустился: ' + e.message);
}

// Best-effort local DNS alias (HOST_ALIAS): must be in place before the first
// /api/info|networks probes and before onReady decides what to advertise.
if (HOST_ALIAS) ensureHostAlias().then(() => tryListen(PORT, onReady));
else tryListen(PORT, onReady);

// ─── TUNNEL API ───
app.get('/api/tunnel', (req, res) => {
  if (tunnelInfo && tunnelInfo.state === 'ready' && tunnelInfo.url) {
    res.json({
      success: true,
      status: 'ready',
      url: tunnelInfo.url,
      type: tunnelInfo.type,
      startedAt: tunnelInfo.startedAt
    });
  } else {
    res.json({
      success: false,
      status: (tunnelInfo && tunnelInfo.state) || 'disabled',
      url: null,
      type: (tunnelInfo && tunnelInfo.type) || null,
      error: (tunnelInfo && tunnelInfo.error) || null,
      retryAt: (tunnelInfo && tunnelInfo.retryAt) || null
    });
  }
});

// ─── PULSE AUDIO AUTO-START ───
(async () => {
  try {
    const check = await pulseRun('pulseaudio --check 2>&1; echo $?');
    if (!check.out.endsWith('0')) {
      console.log('  🔊 Starting PulseAudio daemon...');
      await pulseRun('pulseaudio --start --disallow-exit --exit-idle-time=-1 2>&1');
      console.log('  🔊 PulseAudio started');
    } else {
      console.log('  🔊 PulseAudio already running');
      await pulseRun('pactl set-exit-idle-time -1 2>/dev/null');
    }
    // Create virtual sinks only when absent: repeated hub restarts must not
    // stack browser_youtube.2/.3 and their old loopbacks.
    let sinkList = await pulseRun('pactl list short sinks 2>/dev/null');
    for (const name of ['cloud_phone', 'browser_youtube']) {
      if (!new RegExp('\\t' + name + '(?:\\.\\d+)?\\t').test(String(sinkList.out || ''))) {
        await pulseRun(`pactl load-module module-null-sink sink_name=${name} sink_properties=device.description="Hub-${name}" 2>/dev/null || true`);
        sinkList = await pulseRun('pactl list short sinks 2>/dev/null');
      }
    }
    // Remove duplicate null-sink modules left by older hub restarts. Pulse
    // silently renames a second sink to browser_youtube.2, so checking only
    // the sink list is not enough; keep the first module for each base name.
    let mods = await pulseRun('pactl list short modules 2>/dev/null');
    const keptNull = new Set();
    for (const line of String(mods.out || '').split('\n')) {
      const m = line.trim().match(/^(\d+)\s+module-null-sink\s+(.+)$/);
      const nm = m && m[2].match(/(?:^|\s)sink_name=(cloud_phone|browser_youtube)(?:\s|$)/);
      if (m && nm) {
        if (keptNull.has(nm[1])) await pulseRun('pactl unload-module ' + m[1] + ' 2>/dev/null || true');
        else keptNull.add(nm[1]);
      }
    }
    // Remove every loopback owned by the previous audio implementation. Its
    // browser_youtube.monitor -> browser_youtube path fed audio back into the
    // same sink, causing hiss/stutter and audio that continued after video end.
    mods = await pulseRun('pactl list short modules 2>/dev/null');
    for (const line of String(mods.out || '').split('\n')) {
      const m = line.trim().match(/^(\d+)\s+module-loopback\s/);
      if (m) await pulseRun('pactl unload-module ' + m[1] + ' 2>/dev/null || true');
    }
    await pulseRun('pactl set-default-sink browser_youtube 2>/dev/null || true');
    // The phone receives browser_youtube.monitor directly; do not loop it back.
    await pulseRun('pactl load-module module-loopback source=cloud_phone.monitor sink=auto_null 2>/dev/null || true');
    console.log('  🔊 Virtual audio sinks ready: cloud_phone, browser_youtube');
  } catch {}
})();

const shutdown = () => {
  stopTmuxPollers();
  stopManagedTunnel();
  sessions.forEach(s => { if (s.pty) { try { s.pty.kill(); } catch {} } });
  server.close(() => process.exit(0));
  // server.close waits for long-lived WebSockets. Do not keep a runner alive
  // forever just because a phone disappeared without closing its socket.
  setTimeout(() => process.exit(0), 2000).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
