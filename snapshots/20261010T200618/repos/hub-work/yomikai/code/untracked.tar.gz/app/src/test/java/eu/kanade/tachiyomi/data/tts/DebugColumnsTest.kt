package eu.kanade.tachiyomi.data.tts

import mihon.domain.ocr.model.OcrBoundingBox
import org.junit.jupiter.api.Test

class DebugColumnsTest {
    @Test
    fun debug() {
        val lines = listOf(
            AutoReadEngine.Line("L1", OcrBoundingBox(0.05f, 0.02f, 0.35f, 0.09f)),
            AutoReadEngine.Line("L2", OcrBoundingBox(0.05f, 0.10f, 0.35f, 0.17f)),
            AutoReadEngine.Line("L3", OcrBoundingBox(0.05f, 0.18f, 0.35f, 0.25f)),
            AutoReadEngine.Line("R1", OcrBoundingBox(0.55f, 0.02f, 0.90f, 0.09f)),
            AutoReadEngine.Line("R2", OcrBoundingBox(0.55f, 0.10f, 0.90f, 0.17f)),
            AutoReadEngine.Line("R3", OcrBoundingBox(0.55f, 0.18f, 0.90f, 0.25f)),
        )
        // Прямой вызов приватной функции через reflection не сработает (companion),
        // поэтому повторяем её условия здесь шаг за шагом.
        val sorted = lines.sortedWith(compareBy<AutoReadEngine.Line> { it.boundingBox.left }.thenBy { it.boundingBox.top })
        val columns = mutableListOf<MutableList<AutoReadEngine.Line>>()
        var columnLeft = 0f
        var columnRight = 0f
        for (line in sorted) {
            val box = line.boundingBox
            val current = columns.lastOrNull()
            val overlap = if (current == null) 0f else {
                val inter = minOf(box.right, columnRight) - maxOf(box.left, columnLeft)
                val minW = minOf(box.right - box.left, columnRight - columnLeft)
                if (minW <= 0f) 0f else inter.coerceAtLeast(0f) / minW
            }
            val newCol = current == null || overlap >= 0.3f || box.left > columnRight + 0.04f
            println("line=${line.text} col=[$columnLeft,$columnRight] overlap=$overlap newCol=$newCol")
            if (newCol) {
                columns += mutableListOf(line)
                columnLeft = box.left
                columnRight = box.right
            } else {
                current += line
                columnLeft = minOf(columnLeft, box.left)
                columnRight = maxOf(columnRight, box.right)
            }
        }
        println("columns=" + columns.map { c -> c.map { it.text } })
    }
}
