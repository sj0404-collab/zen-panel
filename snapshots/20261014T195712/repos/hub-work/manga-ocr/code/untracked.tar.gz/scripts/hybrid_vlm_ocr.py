#!/usr/bin/env python3
"""Hybrid VLM OCR — streaming, offline, low-RAM.

A single engine that fuses the project's *tiny* OCR pieces into one hybrid:

  vision   : a text detector + recognizer — Tesseract TSV (`rus`) and, when
             available, RapidOCR (PP-OCRv5 `eslav`, ONNX). No weights are
             downloaded at run time; everything is read from local caches.
  language : a compact Russian word/character model that only *ranks* the
             candidate readings an engine already produced. It never rewrites
             or invents text — output stays verbatim (same rule as the rest of
             this repo).
  fusion   : several preprocessing/PSM configs per page; lines from all
             configs/engines are clustered by spatial overlap (IoU) and the
             best-scoring verbatim line wins.

It runs one page at a time (low RAM), never touches the network, and streams
results as they are read, so it can consume a live pipe of frames:

  # a fixed list of pages, streamed as each page is finished
  printf '%s\n' pages/*.jpg | python hybrid_vlm_ocr.py --stdin

  # live JPEG frames straight out of a video / camera, offline
  ffmpeg -i clip.mp4 -f image2pipe -vcodec mjpeg - | \
      python hybrid_vlm_ocr.py --stdin-frames --emit line --ndjson

  # watch a folder and read new scans as they land
  python hybrid_vlm_ocr.py --watch pages/

Model footprint (the 5–20 MB budget): Tesseract's `rus` fast model is ~4 MB;
`osd` (~10 MB) is only loaded for the optional `--osd` PSM 12 config, so the
default profile stays well under the ceiling. `--max-model-mb` enforces it.

Usage:
  python hybrid_vlm_ocr.py [options] [image|dir ...]
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

IMG_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff")

# ---------------------------------------------------------------------------
# Compact Russian language model (ranking only, no corrections).
# A small set of the most frequent Russian words plus character classes. Kept
# deliberately tiny (<10 KB) so the whole engine honours the 5–20 MB budget.
# ---------------------------------------------------------------------------
COMMON_WORDS = frozenset(
    """
    и в не на я что он с а как это по но к у из за то все она так
    же вы бы от о мне меня ты мы вас нас них ему ей их когда где тут
    там уже ещё еще лишь ведь вот да нет ну ах ох эх ой ага да
    что-то как-то кто-то где-то когда-то почему-то
    мой моя моё мое мои твой твоя твои наш наша наши ваш ваша ваши
    его её ее их свой своя свои
    этот эта эти тот та те такой такая такие сам сама сами
    быть есть был была было были буду будешь будет будем будете будут
    могу можешь может можем можете могут мог могла могли
    хочу хочешь хочет хотим хотите хотят
    знаю знаешь знает знаем знаете знают
    вижу видишь видит видим видите видят
    говорю говоришь говорит говорим говорите говорят сказать сказал
    идти иду идёшь идет идем идете идут пришёл пришел
    делать делаю делаешь делает делаем делаете делают сделать сделал
    думать думаю думаешь думает думаем думаете думают
    дать даю даешь дает даем даете дают дал
    взять беру берешь берет берем берете берут взял
    надо нужно можно нельзя должен должна должны
    очень too просто just теперь сейчас потом опять снова
    здесь здесь там куда откуда почему зачем
    если чтобы хотя или али либо
    был ли бы
    один одна одно раз два три
    человек люди девушка парень мужчина женщина
    мама папа мать отец сын дочь брат сестра друг подруга
    господин госпожа сэр мисс
    бог господь
    """.split()
)

CYR_LOWER = set("абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
CYR_UPPER = set("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ")
LATIN = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
PUNCT = set(".,:;!?…—–-«»\"'()[]{}/*+=\\<>|_~`@#$%^&")


def lm_score(text: str) -> float:
    """Plausibility of a line in [0, 1]. Ranks readings; never edits them."""
    tokens = [t for t in text.replace("\n", " ").split() if t]
    if not tokens:
        return 0.0
    total = 0.0
    for tok in tokens:
        core = tok.strip(".,:;!?…—–-«»\"'()[]{}")
        if not core:
            total += 0.4
            continue
        low = core.lower()
        if low in COMMON_WORDS:
            total += 1.0
            continue
        has_cyr = any(c in CYR_LOWER or c in CYR_UPPER for c in core)
        has_lat = any(c in LATIN for c in core)
        has_dig = any(c.isdigit() for c in core)
        if has_cyr and has_lat:
            total += 0.15          # script mixing is a common OCR glitch
        elif has_cyr and len(core) >= 2:
            total += 0.7
        elif has_cyr:
            total += 0.25
        elif has_dig and not has_lat:
            total += 0.5
        else:
            total += 0.2
    return total / len(tokens)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------
@dataclass
class Line:
    left: int
    top: int
    width: int
    height: int
    text: str
    conf: float

    @property
    def box(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.left + self.width, self.top + self.height)

    def score(self, lm_weight: float) -> float:
        conf = max(0.0, self.conf) / 100.0
        return (1.0 - lm_weight) * conf + lm_weight * lm_score(self.text)


@dataclass
class PageResult:
    engine: str
    lines: list[Line]
    seconds: float
    raw_text: str = ""
    meta: dict = field(default_factory=dict)


def iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    iw, ih = max(0, ix1 - ix0), max(0, iy1 - iy0)
    inter = iw * ih
    if not inter:
        return 0.0
    ua = (ax1 - ax0) * (ay1 - ay0) + (bx1 - bx0) * (by1 - by0) - inter
    return inter / ua if ua else 0.0


# ---------------------------------------------------------------------------
# Preprocessing (optional ImageMagick, no Python imaging deps required)
# ---------------------------------------------------------------------------
class Pre:
    MAX_DIM = 2500  # cap so phone screenshots aren't upscaled into seconds-long runs

    def __init__(self, convert: str | None):
        self.convert = convert
        self._dims: dict[str, tuple[int, int] | None] = {}

    def dimensions(self, src: str) -> tuple[int, int] | None:
        if src in self._dims:
            return self._dims[src]
        dims = None
        if self.convert:
            try:
                out = subprocess.run(
                    [self.convert, src, "-format", "%w %h", "info:"],
                    capture_output=True, text=True, timeout=30,
                )
                w, h = out.stdout.split()
                dims = (int(w), int(h))
            except Exception:  # noqa: BLE001
                dims = None
        self._dims[src] = dims
        return dims

    def effective_factor(self, src: str, factor: float) -> float:
        dims = self.dimensions(src)
        if not dims:
            return factor
        longest = max(dims)
        while factor > 1.0 and longest * factor > self.MAX_DIM:
            factor = round(factor - 0.5, 2)
        return max(factor, 1.0)

    def upscale(self, src: str, factor: float, spool: Path) -> tuple[str, float]:
        factor = self.effective_factor(src, factor)
        if factor <= 1.0 or not self.convert:
            return src, 1.0
        dst = spool / f"up{int(factor * 100)}.png"
        cmd = [
            self.convert, src, "-colorspace", "Gray",
            "-resize", f"{int(factor * 100)}%", str(dst),
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=120)
            return str(dst), factor
        except Exception:  # noqa: BLE001
            return src, 1.0


# ---------------------------------------------------------------------------
# Tesseract engine
# ---------------------------------------------------------------------------
def find_tesseract(explicit: str | None) -> str:
    if explicit and Path(explicit).exists():
        return explicit
    if env := os.environ.get("TESSERACT_CMD"):
        return env
    if found := shutil.which("tesseract"):
        return found
    for c in (
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    ):
        if Path(c).exists():
            return c
    raise FileNotFoundError("tesseract binary not found")


def find_tessdata(explicit: str | None) -> str | None:
    if explicit and Path(explicit).is_dir():
        return explicit
    if env := os.environ.get("TESSDATA_PREFIX"):
        return env
    for c in (
        "/usr/share/tesseract-ocr/5/tessdata",
        "/usr/share/tesseract-ocr/4.00/tessdata",
        "/usr/share/tessdata",
        "/usr/local/share/tessdata",
    ):
        if Path(c).is_dir():
            return c
    return None


def _join_words(words: list[tuple[str, float]]) -> str:
    parts: list[str] = []
    for text, _ in words:
        if not parts:
            parts.append(text)
            continue
        prev = parts[-1]
        if text and text[0] in ",.:;!?…»)]}":
            parts[-1] = prev + text
        elif prev and prev[-1] in "«([{":
            parts[-1] = prev + text
        elif prev.endswith("-"):
            parts[-1] = prev + text
        else:
            parts.append(" " + text)
    return "".join(parts).strip()


class TesseractEngine:
    name = "tesseract"

    def __init__(self, binary: str, tessdata: str | None, lang: str):
        self.binary = binary
        self.tessdata = tessdata
        self.lang = lang
        self._cache: dict[str, list[Line]] = {}

    def model_files(self) -> list[Path]:
        out: list[Path] = []
        if self.tessdata:
            for code in (self.lang, "osd"):
                p = Path(self.tessdata) / f"{code}.traineddata"
                if p.exists():
                    out.append(p)
        return out

    def ocr(self, image: str, psm: int, spool: Path) -> PageResult:
        t0 = time.time()
        # Options must precede the output-config name (`tsv`), otherwise Tesseract
        # treats `--tessdata-dir` as a config file and fails to load the language.
        cmd = [self.binary, image, "stdout", "-l", self.lang, "--psm", str(psm)]
        if self.tessdata:
            cmd += ["--tessdata-dir", self.tessdata]
        cmd.append("tsv")
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if proc.returncode != 0:
            raise RuntimeError(f"tesseract failed: {proc.stderr.strip()[:200]}")
        lines, raw = self._parse_tsv(proc.stdout)
        return PageResult(self.name, lines, time.time() - t0, raw_text=raw)

    @staticmethod
    def _parse_tsv(tsv: str) -> tuple[list[Line], str]:
        groups: dict[tuple, list[tuple[str, float, int, int, int, int]]] = {}
        order: list[tuple] = []
        for row in tsv.splitlines()[1:]:
            f = row.split("\t")
            if len(f) < 12:
                continue
            try:
                level = int(f[0])
            except ValueError:
                continue
            if level != 5:
                continue
            text = f[11]
            if not text.strip():
                continue
            key = (f[1], f[2], f[3], f[4])
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(
                (text, float(f[10]), int(f[6]), int(f[7]), int(f[8]), int(f[9]))
            )
        lines: list[Line] = []
        for key in order:
            words = groups[key]
            xs0 = min(w[2] for w in words)
            ys0 = min(w[3] for w in words)
            xs1 = max(w[2] + w[4] for w in words)
            ys1 = max(w[3] + w[5] for w in words)
            confs = [w[1] for w in words if w[1] >= 0]
            conf = sum(confs) / len(confs) if confs else 0.0
            text = _join_words([(w[0], w[1]) for w in words])
            if text:
                lines.append(Line(xs0, ys0, xs1 - xs0, ys1 - ys0, text, conf))
        raw = "\n".join(ln.text for ln in lines)
        return lines, raw


# ---------------------------------------------------------------------------
# RapidOCR engine (optional; only used if the package is already installed)
# ---------------------------------------------------------------------------
class RapidEngine:
    name = "rapidocr"

    def __init__(self, lang: str):
        from rapidocr import LangRec, ModelType, OCRVersion, RapidOCR

        self._ocr = RapidOCR(
            params={
                "Rec.lang_type": LangRec(lang),
                "Rec.ocr_version": OCRVersion.PPOCRV5,
                "Rec.model_type": ModelType.MOBILE,
                "Det.ocr_version": OCRVersion.PPOCRV5,
                "Det.model_type": ModelType.MOBILE,
                "Global.log_level": "error",
            }
        )

    def model_files(self) -> list[Path]:
        out: list[Path] = []
        for root in (
            Path.home() / ".cache" / "rapidocr",
            Path.home() / ".rapidocr",
        ):
            if root.is_dir():
                out.extend(root.rglob("*.onnx"))
        return out

    def ocr(self, image: str, psm: int, spool: Path) -> PageResult:
        t0 = time.time()
        res = self._ocr(image)
        lines: list[Line] = []
        boxes = getattr(res, "boxes", None)
        txts = getattr(res, "txts", None) or ()
        scores = getattr(res, "scores", None) or ()
        for i, text in enumerate(txts):
            if not text or not text.strip():
                continue
            box = boxes[i] if boxes is not None and i < len(boxes) else None
            conf = float(scores[i]) * 100 if i < len(scores) else 0.0
            if box is not None:
                arr = list(box)
                xs = [float(p[0]) for p in arr]
                ys = [float(p[1]) for p in arr]
                x0, y0 = int(min(xs)), int(min(ys))
                w, h = int(max(xs) - x0), int(max(ys) - y0)
            else:
                x0 = y0 = 0
                w = h = 1
            lines.append(Line(x0, y0, w, h, text, conf))
        return PageResult(self.name, lines, time.time() - t0,
                          raw_text="\n".join(l.text for l in lines))


# ---------------------------------------------------------------------------
# Text detectors (language-agnostic vision front-end)
#
# These turn a page into line quads; the *recognizer* (Tesseract rus here) then
# reads each crop.  The detector is what makes the hybrid layout-aware: manga
# pages are read bubble-by-bubble instead of relying on Tesseract's own
# (weaker) page layout analysis.  Two ncnn back-ends, both DBNet-style:
#   ppocrv5  PP-OCRv5 mobile det   ~2.4 MB  -> fits the 5-20 MB budget
#   yakuyomi joyeli/yakuyomi DBNet ~153 MB  -> higher recall, over budget
# ---------------------------------------------------------------------------
def _deps():
    import numpy as np  # noqa: PLC0415
    import cv2  # noqa: PLC0415
    return np, cv2


class TextDetector:
    name = "none"
    psm = 6  # PSM used to read each detected block

    def model_files(self) -> list[Path]:
        return []

    def detect(self, path: str):
        return []


class PpOcrV5Detector(TextDetector):
    """PP-OCRv5 mobile DBNet (ncnn-assets). in0 RGB, out0 sigmoid prob map."""

    name = "ppocrv5"

    def __init__(self, model_dir: str, threads: int = 4,
                 thresh: float = 0.3, box_thresh: float = 0.6,
                 unclip: float = 1.5, min_size: float = 3.0):
        import ncnn  # noqa: PLC0415
        self.ncnn = ncnn
        self.dir = Path(model_dir)
        self.param = self.dir / "PP_OCRv5_mobile_det.ncnn.param"
        self.bin = self.dir / "PP_OCRv5_mobile_det.ncnn.bin"
        self.thresh, self.box_thresh = thresh, box_thresh
        self.unclip, self.min_size = unclip, min_size
        self.net = ncnn.Net()
        # fp16 storage makes this det output noisy (thousands of tiny false
        # components); keep fp32 for a clean probability map.
        self.net.opt.use_fp16_storage = False
        self.net.opt.num_threads = threads
        self.net.load_param(str(self.param))
        self.net.load_model(str(self.bin))

    def model_files(self):
        return [p for p in (self.param, self.bin) if p.exists()]

    def detect(self, path: str):
        np, cv2 = _deps()
        img = cv2.imread(path)
        if img is None:
            return []
        h, w = img.shape[:2]
        ratio = max(736 / min(h, w), 1.0)
        nw, nh = round(w * ratio), round(h * ratio)
        nw += (32 - nw % 32) % 32
        nh += (32 - nh % 32) % 32
        resized = cv2.resize(img, (nw, nh))
        blob = resized.astype(np.float32) / 255.0
        blob = (blob - np.array([0.485, 0.456, 0.406], np.float32)) / \
            np.array([0.229, 0.224, 0.225], np.float32)
        chw = np.ascontiguousarray(blob.transpose(2, 0, 1))
        ex = self.net.create_extractor()
        ex.input("in0", self.ncnn.Mat(chw))
        _, out = ex.extract("out0")
        prob = np.array(out).reshape(nh, nw)
        return [q / ratio for q in
                self._postprocess(prob, np, cv2, nw, nh, ratio)]

    def _postprocess(self, prob, np, cv2, nw, nh, ratio):
        bins = (prob > self.thresh).astype(np.uint8)
        contours, _ = cv2.findContours(bins, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        quads = []
        for c in contours:
            if len(c) < 4:
                continue
            (cx, cy), (bw, bh), ang = cv2.minAreaRect(c)
            if min(bw, bh) < self.min_size:
                continue
            pts = cv2.boxPoints(((cx, cy), (bw, bh), ang)).astype(np.float32)
            x0 = max(int(pts[:, 0].min()), 0)
            x1 = min(int(pts[:, 0].max()) + 1, nw)
            y0 = max(int(pts[:, 1].min()), 0)
            y1 = min(int(pts[:, 1].max()) + 1, nh)
            if x1 <= x0 or y1 <= y0 or prob[y0:y1, x0:x1].mean() < self.box_thresh:
                continue
            d = bw * bh * self.unclip / (2.0 * (bw + bh))
            center = pts.mean(0)
            vec = pts - center
            norm = np.linalg.norm(vec, axis=1, keepdims=True) + 1e-6
            quads.append((pts + d * vec / norm).astype(np.float32))
        return quads


class YakuyomiDetector(TextDetector):
    """joyeli/yakuyomi-engine DBNet (ResNet backbone). in0 RGB, out0 raw logits."""

    name = "yakuyomi"

    def __init__(self, model_dir: str, threads: int = 4, input_side: int = 1024,
                 pad_mult: int = 256, bin_th: float = 0.5, box_th: float = 0.7,
                 unclip: float = 2.3, min_side: float = 3.0):
        import ncnn  # noqa: PLC0415
        self.ncnn = ncnn
        self.dir = Path(model_dir)
        self.param = self.dir / "dbnet_detect.ncnn.param"
        self.bin = self.dir / "dbnet_detect.ncnn.bin"
        self.input_side, self.pad_mult = input_side, pad_mult
        self.bin_th, self.box_th = bin_th, box_th
        self.unclip, self.min_side = unclip, min_side
        self.net = ncnn.Net()
        self.net.opt.use_fp16_storage = True
        self.net.opt.num_threads = threads
        self.net.load_param(str(self.param))
        self.net.load_model(str(self.bin))

    def model_files(self):
        return [p for p in (self.param, self.bin) if p.exists()]

    def detect(self, path: str):
        np, cv2 = _deps()
        img = cv2.imread(path)
        if img is None:
            return []
        h, w = img.shape[:2]
        ratio = self.input_side / max(w, h)
        tw, th = max(1, round(w * ratio)), max(1, round(h * ratio))
        inw = tw + (self.pad_mult - tw % self.pad_mult) % self.pad_mult
        inh = th + (self.pad_mult - th % self.pad_mult) % self.pad_mult
        rgb = cv2.cvtColor(cv2.resize(img, (tw, th)), cv2.COLOR_BGR2RGB).astype(np.float32)
        canvas = np.zeros((inh, inw, 3), np.float32)
        canvas[:th, :tw] = rgb
        chw = np.ascontiguousarray(canvas.transpose(2, 0, 1) / 127.5 - 1.0)
        ex = self.net.create_extractor()
        ex.input("in0", self.ncnn.Mat(chw))
        _, out = ex.extract("out0")
        logits = np.array(out)[0]
        prob = 1.0 / (1.0 + np.exp(-logits))
        mask = (prob > self.bin_th).astype(np.uint8)
        n, labels, _, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        quads = []
        for lab in range(1, n):
            comp = labels == lab
            if float(prob[comp].mean()) < self.box_th:
                continue
            ys, xs = np.nonzero(comp)
            pts = np.column_stack([xs, ys]).astype(np.float32)
            (cx, cy), (rw, rh), ang = cv2.minAreaRect(pts)
            if min(rw, rh) < self.min_side:
                continue
            d = rw * rh * self.unclip / (2.0 * (rw + rh))
            box = cv2.boxPoints(((cx, cy), (rw + 2 * d, rh + 2 * d), ang))
            quads.append(np.clip(box / ratio, [0, 0], [w - 1, h - 1]).astype(np.float32))
        return quads


DETECTORS = {"ppocrv5": PpOcrV5Detector, "yakuyomi": YakuyomiDetector}


def build_detector(args):
    if args.detector == "none":
        return TextDetector()
    if args.detector == "rapidocr":
        return TextDetector()  # rapidocr path keeps its own built-in detector
    cls = DETECTORS.get(args.detector)
    if cls is None:
        sys.exit(f"[x] unknown detector {args.detector!r}")
    model_dir = args.det_model_dir
    if not model_dir:
        sys.exit(f"[x] --detector {args.detector} needs --det-model-dir")
    try:
        det = cls(model_dir)
    except ImportError as exc:
        sys.exit(f"[x] --detector {args.detector} needs ncnn/numpy/opencv: {exc}")
    det.psm = args.det_psm
    return det


# ---------------------------------------------------------------------------
# Fusion
# ---------------------------------------------------------------------------
def fuse(results: list[PageResult], lm_weight: float, iou_thresh: float = 0.3) -> list[Line]:
    """Cluster lines by overlap across configs/engines; keep the best verbatim."""
    clusters: list[dict] = []
    for res in results:
        for ln in res.lines:
            placed = False
            for cl in clusters:
                if iou(ln.box, cl["box"]) >= iou_thresh:
                    cl["cands"].append(ln)
                    if ln.score(lm_weight) > cl["cands"][0].score(lm_weight):
                        cl["cands"][0] = ln
                        cl["box"] = ln.box
                    placed = True
                    break
            if not placed:
                clusters.append({"box": ln.box, "cands": [ln]})
    best = [cl["cands"][0] for cl in clusters]
    best.sort(key=lambda l: (l.top, l.left))
    return best


# ---------------------------------------------------------------------------
# Engine assembly + model budget
# ---------------------------------------------------------------------------
PROFILES = {
    # (resize_factor, psm)
    "fast": [(1.0, 3)],
    "balanced": [(1.0, 3), (2.0, 3), (2.0, 6)],
    "quality": [(1.0, 3), (2.0, 3), (3.0, 3), (2.0, 6), (2.0, 11)],
}


def build_engines(args) -> tuple[list, list[tuple[float, int]], Pre, object]:
    configs = list(PROFILES[args.profile])
    if args.osd:
        configs.append((2.0, 12))

    tess_bin = find_tesseract(args.tess_cmd)
    tessdata = find_tessdata(args.tessdata)
    engines: list = [TesseractEngine(tess_bin, tessdata, args.lang)]

    if args.rapidocr and args.profile != "fast":
        try:
            engines.append(RapidEngine(args.rec_lang))
        except Exception as exc:  # noqa: BLE001
            print(f"[w] rapidocr unavailable ({type(exc).__name__}: {exc})", file=sys.stderr)

    detector = build_detector(args)

    # Model budget check
    total = sum(f.stat().st_size for e in engines for f in e.model_files())
    total += sum(f.stat().st_size for f in detector.model_files())
    mb = total / (1024 * 1024)
    if args.max_model_mb and mb > args.max_model_mb:
        sys.exit(
            f"[x] model footprint {mb:.1f} MB exceeds --max-model-mb "
            f"{args.max_model_mb} (use --profile fast / drop --rapidocr / "
            f"--detector ppocrv5 instead of yakuyomi)"
        )
    det = detector.name if detector.name != "none" else "-"
    print(f"[i] engines: {', '.join(e.name for e in engines)} | "
          f"detector: {det} | models: {mb:.1f} MB | configs: {len(configs)}",
          file=sys.stderr)

    pre = Pre(shutil.which("convert") or shutil.which("magick"))
    return engines, configs, pre, detector


# ---------------------------------------------------------------------------
# One-page OCR with fusion
# ---------------------------------------------------------------------------
def recognize_page(path: str, engines, configs, pre: Pre, spool: Path,
                   lm_weight: float, detector=None, crop_scale: float = 1.0
                   ) -> tuple[list[Line], float]:
    if detector is not None and detector.name != "none":
        return recognize_page_det(path, engines, configs, pre, spool,
                                  lm_weight, detector, crop_scale)
    t0 = time.time()
    results: list[PageResult] = []
    # Collapse duplicate configs after the per-image resize cap (e.g. 2x and 3x
    # both clamp to 1.5x on a large screenshot) so we don't pay for them twice.
    seen: set[tuple[float, int]] = set()
    effective: list[tuple[float, int]] = []
    for factor, psm in configs:
        key = (pre.effective_factor(path, factor), psm)
        if key not in seen:
            seen.add(key)
            effective.append(key)
    for factor, psm in effective:
        src, eff = pre.upscale(path, factor, spool)
        factor = eff
        for eng in engines:
            try:
                res = eng.ocr(src, psm, spool)
            except Exception as exc:  # noqa: BLE001
                print(f"[w] {eng.name} {os.path.basename(path)} psm{psm}: "
                      f"{type(exc).__name__}: {exc}", file=sys.stderr)
                continue
            # Normalise boxes back to the original page so lines from the
            # different resize configs share one coordinate space and can be
            # clustered by overlap in fuse().
            if factor > 1.0:
                for ln in res.lines:
                    ln.left = int(round(ln.left / factor))
                    ln.top = int(round(ln.top / factor))
                    ln.width = int(round(ln.width / factor))
                    ln.height = int(round(ln.height / factor))
            results.append(res)
    if len(results) == 1:
        return results[0].lines, time.time() - t0
    return fuse(results, lm_weight), time.time() - t0


def recognize_page_det(path: str, engines, configs, pre: Pre, spool: Path,
                       lm_weight: float, detector, crop_scale: float
                       ) -> tuple[list[Line], float]:
    """Detector-first path: locate text blocks, then read each block.

    Detected line quads are merged into blocks (same column, small vertical
    gap) and each block is cropped, upscaled and handed to the recognizer as a
    whole.  That keeps Tesseract's language/word context, which is what makes
    this beat per-line cropping, while the ncnn detector still owns the
    layout/segmentation work.
    """
    np, cv2 = _deps()
    t0 = time.time()
    results: list[PageResult] = []
    seen: set[float] = set()
    for factor, _psm in configs:
        seen.add(pre.effective_factor(path, factor))
    for factor in sorted(seen):
        src, eff = pre.upscale(path, factor, spool)
        img = cv2.imread(src)
        if img is None:
            continue
        quads = detector.detect(src)
        blocks = _group_quads(quads, np)
        lines: list[Line] = []
        for bi, (x0, y0, x1, y1) in enumerate(blocks):
            pad = 4
            cx0 = max(int(x0) - pad, 0)
            cy0 = max(int(y0) - pad, 0)
            cx1 = min(int(x1) + pad + 1, img.shape[1])
            cy1 = min(int(y1) + pad + 1, img.shape[0])
            crop = img[cy0:cy1, cx0:cx1]
            if crop.size == 0:
                continue
            scale = min(4.0, max(1.0, 64.0 / max(crop.shape[0], 1))) * crop_scale
            if abs(scale - 1.0) > 1e-3:
                crop = cv2.resize(crop, None, fx=scale, fy=scale,
                                  interpolation=cv2.INTER_CUBIC)
            crop_path = spool / f"block_{int(eff * 100)}_{bi}.png"
            cv2.imwrite(str(crop_path), crop)
            best: PageResult | None = None
            for eng in engines:
                try:
                    res = eng.ocr(str(crop_path), detector.psm, spool)
                except Exception as exc:  # noqa: BLE001
                    print(f"[w] {eng.name} {os.path.basename(path)} block{bi}: "
                          f"{type(exc).__name__}: {exc}", file=sys.stderr)
                    continue
                score = (sum(ln.score(lm_weight) for ln in res.lines)
                         / max(len(res.lines), 1))
                if best is None or score > (
                        sum(ln.score(lm_weight) for ln in best.lines)
                        / max(len(best.lines), 1)):
                    best = res
            if best is None:
                continue
            for ln in best.lines:
                lines.append(Line(
                    int(ln.left / scale / eff) + int(cx0 / eff),
                    int(ln.top / scale / eff) + int(cy0 / eff),
                    max(int(ln.width / scale / eff), 1),
                    max(int(ln.height / scale / eff), 1),
                    ln.text, ln.conf))
        results.append(PageResult(f"{detector.name}+{engines[0].name}", lines,
                                  time.time() - t0))
    if not results:
        return [], time.time() - t0
    if len(results) == 1:
        return results[0].lines, time.time() - t0
    return fuse(results, lm_weight), time.time() - t0


def _group_quads(quads, np, v_gap: float = 2.5, h_overlap: float = -0.1):
    """Merge nearby line quads into reading blocks (same column, small gap)."""
    boxes = []
    for q in quads:
        pts = np.asarray(q, np.float32)
        boxes.append([float(pts[:, 0].min()), float(pts[:, 1].min()),
                      float(pts[:, 0].max()), float(pts[:, 1].max())])
    boxes.sort(key=lambda b: (b[1], b[0]))
    groups: list[list[float]] = []
    for b in boxes:
        for g in groups:
            ox = min(b[2], g[2]) - max(b[0], g[0])
            gap = b[1] - g[3]
            minw = max(min(b[2] - b[0], g[2] - g[0]), 1.0)
            minh = max(min(b[3] - b[1], g[3] - g[1]), 1.0)
            if ox > h_overlap * minw and gap < v_gap * minh:
                g[0] = min(g[0], b[0])
                g[1] = min(g[1], b[1])
                g[2] = max(g[2], b[2])
                g[3] = max(g[3], b[3])
                break
        else:
            groups.append(list(b))
    return [tuple(g) for g in groups]
def iter_sources(args):
    for item in args.inputs:
        p = Path(item)
        if p.is_dir():
            yield from _iter_dir(p, args.recursive)
        elif p.exists():
            yield str(p)
        else:
            for g in sorted(glob.glob(item)):
                yield g


def _iter_dir(p: Path, recursive: bool) -> list[str]:
    pattern = "**/*" if recursive else "*"
    return sorted(
        str(f) for f in p.glob(pattern)
        if f.is_file() and f.suffix.lower() in IMG_EXT
    )


def iter_stdin_list():
    for raw in sys.stdin:
        line = raw.strip()
        if line and not line.startswith("#"):
            yield line


def iter_stdin_frames(spool: Path):
    """Read length-prefixed raw image frames: <u32 little-endian length><bytes>."""
    stream = sys.stdin.buffer
    idx = 0
    while True:
        hdr = stream.read(4)
        if len(hdr) < 4:
            return
        (size,) = struct.unpack("<I", hdr)
        data = stream.read(size)
        if len(data) < size:
            return
        idx += 1
        frame = spool / f"frame{idx:06d}.img"
        frame.write_bytes(data)
        yield str(frame)


def iter_watch(directory: str, interval: float, recursive: bool):
    seen: set[str] = set()
    yield from _drain_watch(directory, recursive, seen)
    while True:
        time.sleep(interval)
        yield from _drain_watch(directory, recursive, seen)


def _drain_watch(directory: str, recursive: bool, seen: set[str]):
    for f in _iter_dir(Path(directory), recursive):
        if f not in seen:
            seen.add(f)
            yield f


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
def emit_page(src: str, lines: list[Line], dt: float, args, out) -> None:
    text = "\n".join(ln.text for ln in lines)
    if args.format == "ndjson":
        rec = {
            "source": os.path.basename(src),
            "seconds": round(dt, 2),
            "text": text,
            "lines": [
                {"text": ln.text, "conf": round(ln.conf, 1), "box": list(ln.box)}
                for ln in lines
            ],
        }
        out.write(json.dumps(rec, ensure_ascii=False) + "\n")
    else:
        out.write(f"===== {os.path.basename(src)} ({dt:.1f}s) =====\n{text}\n\n")
    out.flush()


def emit_line(src: str, ln: Line, out) -> None:
    if args.format == "ndjson":
        rec = {
            "source": os.path.basename(src),
            "text": ln.text,
            "conf": round(ln.conf, 1),
            "box": list(ln.box),
        }
        out.write(json.dumps(rec, ensure_ascii=False) + "\n")
    else:
        out.write(f"[{os.path.basename(src)}] {ln.text}\n")
    out.flush()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description="Hybrid VLM OCR: streaming, offline, low-RAM")
    ap.add_argument("inputs", nargs="*", help="image files, dirs or globs")
    ap.add_argument("--stdin", action="store_true", help="read image paths from stdin")
    ap.add_argument("--stdin-frames", action="store_true",
                    help="read length-prefixed raw frames from stdin")
    ap.add_argument("--watch", metavar="DIR", help="watch a directory for new scans")
    ap.add_argument("--watch-interval", type=float, default=1.0)
    ap.add_argument("-r", "--recursive", action="store_true")
    ap.add_argument("--profile", choices=sorted(PROFILES), default="fast")
    ap.add_argument("--emit", choices=("page", "line"), default="page")
    ap.add_argument("--format", choices=("text", "ndjson"), default="text")
    ap.add_argument("-o", "--out", help="output file (default: stdout)")
    ap.add_argument("--lang", default="rus")
    ap.add_argument("--rec-lang", default="eslav", help="RapidOCR recognizer language")
    ap.add_argument("--rapidocr", action="store_true",
                    help="add RapidOCR vision engine (if installed)")
    ap.add_argument("--detector", choices=("none", "ppocrv5", "yakuyomi"),
                    default="none",
                    help="ncnn text detector front-end; lines are warped and read "
                         "per-crop (ppocrv5 ~2.4 MB fits the budget, yakuyomi ~153 MB)")
    ap.add_argument("--det-model-dir", default=None,
                    help="dir with the detector .ncnn.param/.bin files")
    ap.add_argument("--det-psm", type=int, default=6,
                    help="Tesseract PSM used to read each detected block (default 6)")
    ap.add_argument("--crop-scale", type=float, default=1.0,
                    help="extra multiplier on top of auto line-crop upscaling")
    ap.add_argument("--osd", action="store_true", help="add PSM 12 (loads osd model)")
    ap.add_argument("--tess-cmd", default=None)
    ap.add_argument("--tessdata", default=None)
    ap.add_argument("--lm-weight", type=float, default=0.35,
                    help="weight of the language model in line ranking")
    ap.add_argument("--max-model-mb", type=float, default=20.0,
                    help="abort if local model weights exceed this (default 20)")
    ap.add_argument("--spool", default=None,
                    help="dir for temp frames/preprocessed pages")
    args = ap.parse_args()

    spool = Path(args.spool) if args.spool else Path(tempfile.gettempdir()) / "hybrid_vlm_ocr"
    spool.mkdir(parents=True, exist_ok=True)

    engines, configs, pre, detector = build_engines(args)

    if args.stdin_frames:
        srcs = iter_stdin_frames(spool)
    elif args.stdin:
        srcs = iter_stdin_list()
    elif args.watch:
        srcs = iter_watch(args.watch, args.watch_interval, args.recursive)
    else:
        srcs = iter_sources(args)
        # materialise plain file inputs so the budget/logic runs before OCR
        srcs = list(srcs)

    out = open(args.out, "w", encoding="utf-8") if args.out else sys.stdout
    n = 0
    try:
        for src in srcs:
            if not src or not os.path.exists(src):
                print(f"[w] skip missing: {src}", file=sys.stderr)
                continue
            lines, dt = recognize_page(src, engines, configs, pre, spool,
                                       args.lm_weight, detector, args.crop_scale)
            n += 1
            if args.emit == "line":
                for ln in lines:
                    emit_line(src, ln, out)
            else:
                emit_page(src, lines, dt, args, out)
                print(f"[{n}] {os.path.basename(src)} {dt:.1f}s "
                      f"{len(lines)} lines", file=sys.stderr)
    except KeyboardInterrupt:
        print("\n[i] interrupted", file=sys.stderr)
    finally:
        if out is not sys.stdout:
            out.close()
    print(f"[i] done, {n} page(s)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
