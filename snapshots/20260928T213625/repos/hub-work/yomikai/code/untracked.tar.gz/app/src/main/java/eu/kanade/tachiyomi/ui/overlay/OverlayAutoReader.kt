package eu.kanade.tachiyomi.ui.overlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import eu.kanade.tachiyomi.data.tts.TtsSpeaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import mihon.data.ocr.OcrPlugins
import mihon.domain.ocr.model.OcrImage
import mihon.domain.ocr.repository.OcrRepository
import mihon.domain.ocr.service.OcrPreferences
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Чтение рамки поверх чужого приложения.
 *
 * Цикл: снять кадр области → распознать → озвучить → дождаться конца
 * речи → отправить свайп → повторить.
 *
 * Скролл наш собственный, а не приложения: приложение может вообще не
 * иметь прокрутки или листать по-своему, поэтому продвижение выполняется
 * жестом через [OverlayGestureService].
 */
class OverlayAutoReader(
    private val context: Context,
    private val capture: OverlayCaptureEngine,
) {
    private val prefs: OcrPreferences by lazy { Injekt.get() }

    /** Сколько ждать конца речи перед прокруткой, мс. */
    private val pauseAfterSpeechMs: Long get() = prefs.overlayReadPause().get().coerceIn(0, 10_000).toLong()

    /** Столько ждём после свайпа, пока приложение перерисует кадр. */
    private val settleAfterScrollMs: Long get() = prefs.overlayScrollSettle().get().coerceIn(200, 5_000).toLong()

    private val scrollDistance: Float
        get() = prefs.overlayScrollStep().get().coerceIn(10, 90) / 100f

    /**
     * Движок оверлея.
     *
     * Переключатель «свои / как в читалке»: выключенный берёт движок
     * читалки, включённый — отдельный для оверлея. Раньше выбора не было
     * вовсе, и оверлей не распознавал ничего, так что вопрос «какие
     * настройки» был без предмета.
     */
    private fun engineModel(): mihon.domain.ocr.model.OcrModel =
        if (prefs.overlayOwnEngine().get()) {
            prefs.appOcrEngine().get()
        } else {
            prefs.ocrModel().get()
        }

    fun engineTitle(): String = OcrPlugins.byModel(engineModel()).title

    /**
     * Один кадр области, распознанный в текст.
     *
     * @return текст или null, если кадр не удалось снять/прочитать
     */
    suspend fun readOnce(region: Rect): String? = withContext(Dispatchers.IO) {
        val bmp = runCatching { capture.capture(region) }.getOrNull() ?: return@withContext null
        try {
            val pixels = IntArray(bmp.width * bmp.height)
            bmp.getPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            val image = OcrImage(bmp.width, bmp.height, pixels)
            Injekt.get<OcrRepository>().recognizeText(image)
                .trim()
                .takeIf { it.isNotBlank() }
        } catch (e: Exception) {
            Log.e(TAG, "overlay read failed", e)
            null
        } finally {
            if (!bmp.isRecycled) bmp.recycle()
        }
    }

    /**
     * Запускает цикл чтения.
     *
     * @param onPage сообщает, что распознан новый экран (для панели оверлея)
     * @param onNote сообщает, что делает цикл (для панели оверлея)
     * @return задача цикла — её отмена останавливает чтение
     */
    fun start(
        scope: CoroutineScope,
        region: Rect,
        onPage: (String) -> Unit = {},
        onNote: (String) -> Unit = {},
    ): Job = scope.launch {
        var lastText: String? = null
        var repeats = 0
        onNote("Чтение начато · ${engineTitle()}")

        while (isActive) {
            val text = readOnce(region)
            if (text == null) {
                onNote("Не удалось прочитать кадр")
                // Кадр может не успеть прогрузиться; ждать и пробовать
                // снова вхолостую только жжёт батарею.
                delay(RETRY_DELAY_MS)
                continue
            }

            // Один и тот же текст после прокрутки означает, что приложение
            // не пролистнулось: озвучивать его второй раз бессмысленно, и
            // цикл ушёл бы в бесконечный повтор одного и того же.
            if (text == lastText) {
                repeats++
                if (repeats >= MAX_REPEATS) {
                    onNote("Приложение не пролистывается — остановлено")
                    return@launch
                }
            } else {
                repeats = 0
                lastText = text
                onPage(text)
                speakAndWait(text)
            }

            val scrolled = swipe(region)
            if (!scrolled) {
                onNote(
                    if (OverlayGestureService.isEnabled()) {
                        "Свайп не прошёл"
                    } else {
                        "Включи Службу доступности, чтобы листать самому"
                    },
                )
                return@launch
            }
            delay(settleAfterScrollMs)
        }
    }

    /**
     * Озвучивает и ждёт конца речи, затем паузу.
     *
     * `TtsSpeaker` не отдаёт «прочитано» промисом, но сообщает состояние
     * через колбэк: [onState] приходит false, когда речь закончилась.
     */
    private suspend fun speakAndWait(text: String) {
        val done = kotlinx.coroutines.CompletableDeferred<Unit>()
        var started = false
        TtsSpeaker.speak(context, text) { speaking ->
            if (speaking) {
                started = true
            } else if (started) {
                done.complete(Unit)
            }
        }
        // Если движок не сообщил о начале (например, голос не найден),
        // ждать завершения бессмысленно — цикл обязан идти дальше.
        if (!started) {
            delay(NO_SPEECH_GRACE_MS)
            return
        }
        withTimeoutOrNull(MAX_SPEECH_MS) { done.await() }
        if (coroutineContext.isActive && pauseAfterSpeechMs > 0) delay(pauseAfterSpeechMs)
    }

    /** Свайп по центру области: вперёд. */
    private fun swipe(region: Rect): Boolean {
        val dy = (region.height() * scrollDistance).toInt()
        if (dy < 1) return false
        return OverlayGestureService.swipe(
            fromX = region.centerX(),
            fromY = region.centerY() + dy,
            toX = region.centerX(),
            toY = region.centerY() - dy,
        )
    }

    companion object {
        private const val TAG = "OverlayAutoReader"
        private const val RETRY_DELAY_MS = 900L

        /** Сколько ждать, если движок вообще не начал говорить. */
        private const val NO_SPEECH_GRACE_MS = 300L

        /** Потолок одной реплики: иначе зависший движок стопорит цикл. */
        private const val MAX_SPEECH_MS = 5 * 60_000L

        /** Сколько одинаковых кадров подряд считаем «не пролисталось». */
        private const val MAX_REPEATS = 2
    }
}
