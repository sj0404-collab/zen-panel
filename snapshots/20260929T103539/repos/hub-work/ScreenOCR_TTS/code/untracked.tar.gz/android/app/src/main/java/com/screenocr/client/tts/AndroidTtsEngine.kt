package com.screenocr.client.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class AndroidTtsEngine(
    context: Context,
    private val listener: SpeechListener,
) : SpeechEngine {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private val utteranceCounter = AtomicLong()

    @Volatile
    private var ready = false

    override val isReady: Boolean get() = ready

    init {
        tts = TextToSpeech(appContext) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) {
                ready = false
                listener.onReady(false)
                return@TextToSpeech
            }
            ready = true
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = listener.onStarted()

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == lastUtteranceId) listener.onFinished()
                }

                @Deprecated("Обязательный член API до API 33")
                override fun onError(utteranceId: String?) = listener.onFailed("Ошибка озвучки")

                override fun onError(utteranceId: String?, errorCode: Int) = listener.onFailed(errorCodeMessage(errorCode))
            })
            listener.onReady(true)
        }
    }

    @Volatile
    private var lastUtteranceId: String? = null

    override fun speak(text: String, language: String) {
        val engine = tts
        if (engine == null || !ready) {
            listener.onFailed("Синтезатор речи не готов")
            return
        }
        val parts = SpeechText.chunks(text)
        if (parts.isEmpty()) {
            listener.onFailed("Нет текста для озвучки")
            return
        }
        TtsVoiceSelector.select(voices(), language)?.let { selected ->
            engine.getVoice(selected.id)?.let { engine.voice = it }
        } ?: run {
            engine.language = Locale.forLanguageTag(TtsVoiceSelector.localeTagFor(language))
        }
        parts.forEachIndexed { index, part ->
            val id = "screenocr-${utteranceCounter.incrementAndGet()}"
            if (index == parts.lastIndex) lastUtteranceId = id
            val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            engine.speak(part, mode, null, id)
        }
    }

    override fun stop() {
        tts?.stop()
    }

    override fun shutdown() {
        ready = false
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun voices(): List<TtsVoice> = tts?.voices.orEmpty().map { it.toCandidate() }

    private fun Voice.toCandidate() = TtsVoice(
        id = id,
        locale = locale.toLanguageTag(),
        name = name ?: "",
        requiresNetwork = !isNetworkConnectionRequired.not(),
    )

    private fun errorCodeMessage(code: Int): String = when (code) {
        TextToSpeech.ERROR_CLIENT -> "Ошибка клиента TTS"
        TextToSpeech.ERROR_NETWORK, TextToSpeech.ERROR_NETWORK_TIMEOUT -> "Голос недоступен по сети"
        TextToSpeech.ERROR_NOT_SUPPORTED -> "Язык не поддерживается"
        else -> "Ошибка синтеза речи: $code"
    }
}
