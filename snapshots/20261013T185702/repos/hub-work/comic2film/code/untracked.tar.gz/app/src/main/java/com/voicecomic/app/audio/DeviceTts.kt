package com.voicecomic.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * Озвучка системным движком Android (android.speech.tts.TextToSpeech).
 *
 * Особенности, из-за которых это не одна строчка:
 *  - инициализация асинхронная → ждём готовности с таймаутом, не блокируя запуск;
 *  - [TextToSpeech.synthesizeToFile] отдаёт результат через глобальный
 *    UtteranceProgressListener, поэтому синтез сериализован мьютексом;
 *  - движок может не уметь писать файл — тогда честно возвращаем false,
 *    вызывающий код делает повтор/фолбэк.
 */
class DeviceTts(context: Context) {

    private val appContext = context.applicationContext
    private val initLock = Any()
    private val mutex = Mutex()

    @Volatile
    private var engine: TextToSpeech? = null

    @Volatile
    private var ready = false

    @Volatile
    private var failed = false

    private var initLatch: CountDownLatch? = null

    /** true, если движок инициализирован (без ожидания). */
    val isReady: Boolean get() = ready

    /** Инициализирует движок один раз. false — если системного TTS нет или он не поднялся. */
    suspend fun ensureReady(timeoutMs: Long = 12_000): Boolean = withContext(Dispatchers.IO) {
        if (ready) return@withContext true
        if (failed) return@withContext false
        synchronized(initLock) {
            if (ready) return@synchronized true
            if (failed) return@synchronized false
            if (engine == null) {
                val latch = CountDownLatch(1)
                initLatch = latch
                try {
                    val tts = TextToSpeech(appContext) { status ->
                        if (status == TextToSpeech.SUCCESS) ready = true else failed = true
                        initLatch?.countDown()
                    }
                    engine = tts
                } catch (t: Throwable) {
                    failed = true
                    return@synchronized false
                }
                try {
                    latch.await(timeoutMs, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
                if (!ready) failed = true
            }
        }
        ready
    }

    /** Голоса устройства, локальные — первыми. Побочный эффект: наполняет [VoiceCatalog]. */
    suspend fun catalog(): List<VoiceCatalog.Voice> {
        if (!ensureReady()) return emptyList()
        val tts = engine ?: return emptyList()
        val raw = runCatching { tts.voices }.getOrNull().orEmpty()
        val mapped = raw
            .sortedBy { it.isNetworkConnectionRequired }
            .mapNotNull { v ->
                val name = v.name ?: return@mapNotNull null
                val loc = v.locale ?: return@mapNotNull null
                VoiceCatalog.Voice(name, VoiceCatalog.normLocale(loc.toLanguageTag()), VoiceCatalog.genderForName(name))
            }
            .distinctBy { it.id }
            .sortedWith(compareBy({ it.lang }, { it.id }))
        VoiceCatalog.setDevice(mapped)
        return mapped
    }

    /**
     * Пишет озвучку в [out] (обычно WAV). Голос [voiceName] — имя из [catalog],
     * null/неизвестное имя → голос движка по умолчанию.
     */
    suspend fun synthesizeToFile(
        text: String,
        voiceName: String?,
        pitch: Float,
        rate: Float,
        out: File
    ): Boolean {
        if (text.isBlank()) return false
        if (!ensureReady()) return false
        val tts = engine ?: return false
        return mutex.withLock {
            withContext(Dispatchers.IO) {
                runCatching {
                    out.parentFile?.mkdirs()
                    out.delete()
                    tts.setPitch(pitch.coerceIn(0.25f, 4f))
                    tts.setSpeechRate(rate.coerceIn(0.25f, 4f))
                    pickVoice(voiceName)?.let { v -> runCatching { tts.voice = v } }
                    val utteranceId = "voicecomic_" + System.nanoTime()
                    suspendCancellableCoroutine { cont ->
                        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(id: String?) = Unit

                            override fun onDone(id: String?) {
                                if (cont.isActive) cont.resume(true)
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(id: String?) {
                                if (cont.isActive) cont.resume(false)
                            }

                            override fun onError(id: String?, errorCode: Int) {
                                if (cont.isActive) cont.resume(false)
                            }
                        })
                        val res = tts.synthesizeToFile(text, null, out, utteranceId)
                        if (res != TextToSpeech.SUCCESS && cont.isActive) cont.resume(false)
                    }
                }.getOrDefault(false)
            }
        }
    }

    private fun pickVoice(name: String?): Voice? {
        if (name.isNullOrBlank()) return null
        val all = runCatching { engine?.voices }.getOrNull().orEmpty()
        return all.firstOrNull { it.name == name }
    }

    fun shutdown() {
        runCatching { engine?.stop() }
        runCatching { engine?.shutdown() }
        engine = null
        ready = false
        failed = false
        VoiceCatalog.setDevice(emptyList())
    }

    companion object {
        /**
         * Высота из слайдера (-40..40 Hz) → множитель TextToSpeech.setPitch.
         * 0 → 1.0, -40 → 0.6, +40 → 1.4.
         */
        fun pitchFactor(pitchNum: Int): Float = (1.0 + pitchNum / 100.0).toFloat()

        /** Темп из слайдера (-50..100 %) → множитель setSpeechRate. */
        fun rateFactor(rateNum: Int): Float = (1.0 + rateNum / 100.0).toFloat()
    }
}
