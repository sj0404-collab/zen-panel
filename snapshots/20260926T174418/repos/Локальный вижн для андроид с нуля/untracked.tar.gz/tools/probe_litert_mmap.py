"""Decisive test: does LiteRT's CompiledModel keep the model in a mapping?

Same 138 MB two-sector artifact as build_probe_tflite.py, loaded through the
CompiledModel API (the one the LiteRT docs recommend and the one we would use
on Android), with per-signature invocation standing in for per-sector.

This is the assumption the whole design rests on. ORT was measured copying the
file; tf.lite.Interpreter was measured copying the file too. If this copies as
well, single-file-with-closed-sectors is off the table and the model has to be
split per sector after all.
"""

import os
import sys

import numpy as np


def rss_mb():
    for line in open("/proc/self/status"):
        if line.startswith("VmRSS:"):
            return int(line.split()[1]) * 1024 / 1e6
    return 0.0


def mapped_mb(path):
    """Resident bytes backed by the model file itself, per /proc/self/smaps."""
    real = os.path.realpath(path)
    total = 0.0
    owner = None
    with open("/proc/self/smaps") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 6 and "-" in parts[0] and ":" not in parts[0]:
                owner = parts[5]
            elif line.startswith("Rss:") and owner == real:
                total += int(parts[1]) * 1024 / 1e6
    return total


def main(path="build/probe.tflite", dim=1024):
    from ai_edge_litert.compiled_model import CompiledModel, Options
    from ai_edge_litert.environment import Environment, EnvironmentOptions

    size = os.path.getsize(path) / 1e6
    print(f"file {size:.1f} MB, 2 sectors, via CompiledModel.from_file\n")
    print(f"  {'step':22s} {'RSS':>9s} {'file-resident':>14s} {'RSS delta':>10s}")

    r0 = rss_mb()
    # A capsule of 0 is rejected; passing None lets the binding create a
    # valid default environment.
    model = CompiledModel.from_file(path)
    r1 = rss_mb()
    print(f"  {'load':22s} {r1:9.1f} {mapped_mb(path):14.1f} {r1-r0:10.1f}")

    sigs = model.get_signature_list()
    print(f"  signatures: {list(sigs)}")

    x = np.random.rand(1, dim).astype(np.float32)
    prev = r1
    for name in list(sigs) + [list(sigs)[0]]:
        idx = model.get_signature_index(name) if hasattr(model, "get_signature_index") else 0
        in_name = sigs[name]["inputs"][0]
        buf = model.create_input_buffer_by_name(name, in_name)
        model.run_by_index(idx, [buf], [])
        cur = rss_mb()
        print(f"  {'open ' + name:22s} {cur:9.1f} {mapped_mb(path):14.1f} {cur-prev:10.1f}")
        prev = cur
    model.close()
    return size


if __name__ == "__main__":
    main(*sys.argv[1:])
