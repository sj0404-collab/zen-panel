// Does the classic TFLite C++ API keep a closed sector out of RAM?
//
// This is the one path all three convenience APIs refuse to take:
//   ORT                              copies the file
//   tf.lite.Interpreter(model_path)  copies the file
//   CompiledModel.from_file          copies the file
//
// MMAPAllocation + BuildFromAllocation is the manual opt-in: weight tensors
// point straight into the mapping, so untouched sectors are never faulted in.
// If the deltas below rise only when a subgraph runs, the design holds.
#include <sys/mman.h>
#include <unistd.h>

#include <cstdio>
#include <fstream>
#include <memory>
#include <string>

#include "tensorflow/lite/interpreter.h"
#include "tensorflow/lite/kernels/register.h"
#include "tensorflow/lite/model_builder.h"
#include "tensorflow/lite/util.h"

namespace {

std::string SmapsFor(const std::string& path) {
  char resolved[4096];
  const char* real = realpath(path.c_str(), resolved) ? resolved : path.c_str();
  std::ifstream in("/proc/self/smaps");
  std::string line, owner;
  double total_kb = 0;
  while (std::getline(in, line)) {
    auto sp = line.find(' ');
    if (sp != std::string::npos && line.find('-') < sp) {
      auto rest = line.rfind(' ');
      owner = (rest != std::string::npos && rest > sp) ? line.substr(rest + 1) : "";
    } else if (line.rfind("Rss:", 0) == 0 && owner == real) {
      total_kb += atof(line.c_str() + 4);
    }
  }
  char buf[64];
  snprintf(buf, sizeof(buf), "%.1f", total_kb / 1024.0);
  return buf;
}

double RssMb() {
  std::ifstream in("/proc/self/status");
  std::string line;
  while (std::getline(in, line)) {
    if (line.rfind("VmRSS:", 0) == 0) return atof(line.c_str() + 6) / 1024.0;
  }
  return 0;
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    fprintf(stderr, "usage: %s model.tflite [subgraph ...]\n", argv[0]);
    return 2;
  }
  const std::string path = argv[1];
  printf("mmap supported: %s\n",
         tflite::MMAPAllocation::IsSupported() ? "yes" : "NO");

  double r0 = RssMb();
  // The manual opt-in. Nothing in the Python or CompiledModel paths does this.
  auto allocation = std::make_unique<tflite::MMAPAllocation>(
      path.c_str(), tflite::DefaultErrorReporter(), /*mmap_flags=*/0);
  if (!allocation->MappedFile()) {
    fprintf(stderr, "mmap failed for %s\n", path.c_str());
    return 1;
  }
  auto model = tflite::FlatBufferModel::BuildFromAllocation(
      std::move(allocation), tflite::DefaultErrorReporter());

  tflite::ops::builtin::BuiltinOpResolver resolver;
  std::unique_ptr<tflite::Interpreter> interpreter;
  tflite::InterpreterBuilder(*model, resolver)(&interpreter);
  interpreter->SetNumThreads(2);
  if (interpreter->AllocateTensors() != kTfLiteOk) {
    fprintf(stderr, "AllocateTensors failed\n");
    return 1;
  }
  double r1 = RssMb();
  printf("subgraphs: %zu\n", interpreter->subgraphs().size());
  printf("%-22s %9s %14s %10s\n", "step", "RSS", "file-resident", "delta");
  printf("%-22s %9.1f %14s %10.1f\n", "load", r1, SmapsFor(path).c_str(),
         r1 - r0);

  for (int i = 2; i < argc; ++i) {
    const int idx = atoi(argv[i]);
    if (idx >= static_cast<int>(interpreter->subgraphs().size())) continue;
    auto* sub = interpreter->subgraph(idx);
    if (sub->Invoke() != kTfLiteOk) {
      fprintf(stderr, "subgraph %d invoke failed\n", idx);
      return 1;
    }
    const double r = RssMb();
    printf("%-22s %9.1f %14s %10.1f\n",
           ("run subgraph " + std::to_string(idx)).c_str(), r,
           SmapsFor(path).c_str(), r - r1);
    r1 = r;
  }
  return 0;
}
