"""Quantize the single-file model to int8 and check what it costs in accuracy.

Weight-only int8 is the right first target on a 2 GB phone: the resident cost
drops 4x, and activations stay fp32 so there is no representative dataset to
curate for every sector. Full integer quantization would be the next step, but
it is where universal models usually fall apart, and we would rather find that
out on the skeleton than after training.

Per-channel scales on the big matmuls, per-tensor elsewhere. Weights for
sectors we do not touch are still quantized, because quantization is a
property of the file, not of the current task.
"""

import sys

import numpy as np
import onnx
from onnx import TensorProto, helper, numpy_helper

from export.single_file import export_single

# Subgraphs (our If-branches) need their own weight sets scaled.
SUBGRAPHS = ("gen_then",)


def quantize_weights(model, bits=8):
    """Weight-only symmetric int8 with a DQ node in front of every consumer."""
    qmax = 2 ** (bits - 1) - 1
    graph = model.graph
    inits = {i.name: i for i in graph.initializer}

    quantize_targets = {}
    for node in graph.node:
        if node.op_type not in ("MatMul", "Conv", "Gemm"):
            continue
        for slot in node.input:
            init = inits.get(slot)
            if init is None or init.data_type != TensorProto.FLOAT:
                continue
            quantize_targets[slot] = node.op_type

    new_inits, dq_nodes, dq_names = [], [], {}
    for i, init in enumerate(graph.initializer):
        if init.name not in quantize_targets:
            new_inits.append(init)
            continue
        arr = numpy_helper.to_array(init).astype(np.float32)
        if arr.ndim == 2:
            # Per output channel: axis 0 is what the matmul reduces over, and
            # a 1-D scale with axis=0 broadcasts back across the rows.
            amax = np.max(np.abs(arr), axis=0, keepdims=True)
        else:
            amax = np.abs(arr).max().reshape(1)
        scale = np.where(amax > 0, amax / qmax, 1.0).astype(np.float32)

        q = np.clip(np.rint(arr / scale), -qmax - 1, qmax).astype(np.int8)
        qname = f"{init.name}_q"
        dqname = f"{init.name}_dq"
        new_inits.append(numpy_helper.from_array(q, qname))
        new_inits.append(numpy_helper.from_array(
            scale.reshape(-1).astype(np.float32), f"{qname}_scale"))
        dq = helper.make_node("DequantizeLinear", [qname, f"{qname}_scale"],
                              [dqname], name=f"dq_{i}")
        dq_nodes.append(dq)
        dq_names[init.name] = dqname

    for node in graph.node:
        for slot, new in dq_names.items():
            for k, name in enumerate(node.input):
                if name == slot:
                    node.input[k] = new

    # Subgraph initializers live in the same list once spliced, so the pass
    # above already covers them. Insert the DQ nodes at the front, which is
    # safe: they only depend on initializers.
    del graph.initializer[:]
    graph.initializer.extend(new_inits)
    nodes = list(dq_nodes) + list(graph.node)
    del graph.node[:]
    graph.node.extend(nodes)
    return len(dq_nodes)


def quantize_subgraphs(model, bits=8):
    """The If-branches are separate graphs; scale their initializers too."""
    qmax = 2 ** (bits - 1) - 1
    count = 0
    for attr in model.graph.node:
        for key in ("then_branch", "else_branch"):
            if not hasattr(attr, key):
                continue
            sub = getattr(attr, key)
            for init in sub.initializer:
                if init.data_type != TensorProto.FLOAT or init.name == "zero_shape":
                    continue
                arr = numpy_helper.to_array(init).astype(np.float32)
                flat = arr.reshape(-1, 1) if arr.ndim >= 2 else arr.reshape(1, -1)
                amax = np.abs(flat).max()
                scale = np.float32(amax / qmax if amax > 0 else 1.0)
                q = np.clip(np.rint(arr / scale), -qmax - 1, qmax).astype(np.int8)
                init.data = q.tobytes()
                init.data_type = TensorProto.INT8
                count += 1
    return count


def report(path, before):
    model = onnx.load(path)
    total = sum(numpy_helper.to_array(i).nbytes for i in model.graph.initializer)
    print(f"  file {before/1e6:.1f} MB fp32 -> {total/1e6:.1f} MB of quantized "
          f"initializers")
    return total


def main(preset="omni-t", out=None):
    import os
    out = out or f"build/{preset}.int8.onnx"
    model, torch_model = export_single(preset)
    before = sum(numpy_helper.to_array(i).nbytes
                 for i in model.graph.initializer)
    n = quantize_weights(model)
    print(f"  quantized {n} weight tensors in the main graph")
    onnx.checker.check_model(model, full_check=True)
    onnx.save(model, out)
    total = report(out, before)
    print(f"  -> {out}")
    return total


if __name__ == "__main__":
    main(*sys.argv[1:])
