/**
 * Исходник service worker для Нуар-Дет.
 *
 * Игра целиком процедурная: внешних картинок и звуков нет, весь статический
 * набор — index.html, пара JS-чанков и иконки. Поэтому достаточно один раз
 * закэшировать их при установке, и дальше приложение открывается без сети.
 *
 * В шаблон подставляются: имя кэша, список файлов и документ для офлайна.
 * Плейсхолдеры вида __CACHE_NAME__ заменяются плагином tools/pwa-plugin.js.
 */
export function swSource({ cacheName, precache, offlineDoc }) {
  return `// Нуар-Дет — service worker. Файл генерируется на сборке, не править руками.
const CACHE = ${JSON.stringify(cacheName)};
const PRECACHE = ${JSON.stringify(precache)};
const OFFLINE_DOC = ${JSON.stringify(offlineDoc)};

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // cache.addAll откатывает всё прекеширование при первом же сбое, поэтому
    // кладём файлы поштучно: недоступный сейчас файл добьём позже.
    await Promise.all(PRECACHE.map(async (path) => {
      try {
        const res = await fetch(new Request(path, { cache: 'reload' }));
        if (res && res.ok) await cache.put(path, res);
      } catch (e) {
        // Первая установка офлайн: приложение просто не обновится, но и не сломается.
      }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (event.data === 'skip-waiting') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  // Голос берётся с внешних адресов (Google Translate, локальный relay).
  // Их не кэшируем и не перехватываем: без сети они всё равно недоступны,
  // а VoiceEngine умеет откатываться на Web Speech и на процедурный звук.
  if (url.origin !== self.location.origin) return;

  // Навигация: сначала сеть, чтобы подхватить новую сборку, при ошибке — офлайн.
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const fresh = await fetch(req);
        if (fresh && fresh.ok) {
          const cache = await caches.open(CACHE);
          cache.put(OFFLINE_DOC, fresh.clone());
        }
        return fresh;
      } catch (e) {
        const cache = await caches.open(CACHE);
        return (await cache.match(OFFLINE_DOC)) || Response.error();
      }
    })());
    return;
  }

  // Статика: у собранных файлов хеш в имени, они неизменяемы — сначала кэш.
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const hit = await cache.match(req);
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && res.ok && res.type === 'basic') cache.put(req, res.clone());
      return res;
    } catch (e) {
      return Response.error();
    }
  })());
});
`;
}
