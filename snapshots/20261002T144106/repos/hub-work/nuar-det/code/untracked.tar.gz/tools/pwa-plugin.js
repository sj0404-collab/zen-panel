import { createHash } from 'node:crypto';
import { readdirSync, statSync, writeFileSync } from 'node:fs';
import { join, posix, relative, sep } from 'node:path';
import { swSource } from './sw-template.js';

/** Рекурсивно перечисляет файлы каталога. Отсутствующий каталог — не ошибка. */
function listFiles(dir) {
  const out = [];
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) out.push(...listFiles(full));
    else if (statSync(full).isFile()) out.push(full);
  }
  return out;
}

// Всё, что не должно попасть в офлайн-кэш: sourcemap'ы, сам service worker,
// APK (1.6 МБ, качается по запросу) и version.json (его читает нативная
// оболочка, и закешированная копия только задержала бы проверку обновлений).
// pages.yml кладёт последние два в dist уже после сборки, но список
// зафиксирован явно — чтобы случайная перестановка шагов не начала
// кэшировать мегабайтный бинарник.
const NEVER_PRECACHE = new Set(['sw.js', 'version.json', 'nuar-det.apk']);

/**
 * Плагин PWA без внешних зависимостей: после записи бандла выкладывает sw.js
 * с точным списком прекешируемых файлов.
 *
 * Почему не vite-plugin-pwa: приложению нужен ровно один статический набор
 * без workbox-рантайма, а имена чанков с хешами известны только на выходе.
 * Свой плагин даёт предсказуемый SW и не тянет в бандл лишние ~10 KB.
 *
 * Список берём из реально записанного outDir, а не из хука generateBundle:
 * index.html порождается плагином vite:build-html позже, и на generateBundle
 * его ещё нет — из-за чего в прекеш попадал бы пустой документ.
 */
function pwaPlugin() {
  return {
    name: 'nuardet-pwa',

    apply: 'build',

    writeBundle(options, bundle) {
      const outDir = options.dir ?? 'dist';

      const precache = listFiles(outDir)
        .map((full) => relative(outDir, full).split(sep).join(posix.sep))
        .filter((name) => !name.endsWith('.map') && !NEVER_PRECACHE.has(name))
        .sort();

      if (!precache.includes('index.html')) {
        this.error('PWA: index.html не найден в сборке — офлайн не заработает.');
      }

      // Имя кэша привязано к содержимому списка: файлы изменились — кэш новый,
      // и activate честно удаляет предыдущий.
      const hash = createHash('sha256').update(precache.join('\n')).digest('hex').slice(0, 12);

      const source = swSource({
        cacheName: `nuar-det-${hash}`,
        precache,
        offlineDoc: 'index.html',
      });

      writeFileSync(join(outDir, 'sw.js'), source, 'utf8');
      this.warn(`PWA: sw.js, ${precache.length} файлов в прекеше (${precache.join(', ')})`);
    },
  };
}

export default pwaPlugin;
