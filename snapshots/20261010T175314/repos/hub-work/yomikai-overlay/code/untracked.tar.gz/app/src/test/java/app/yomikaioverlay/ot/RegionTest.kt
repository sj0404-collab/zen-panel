package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Пресеты и геометрия рамки: регрессия на баг «reg_preset затирался на custom»,
 * из-за которого пресеты «Верхняя половина»/«Центральная половина» были
 * недостижимы, и на инверсию сторон при перетаскивании ручек.
 */
class RegionTest {

    @Test
    fun `nextPreset cycles all four presets`() {
        assertEquals(Region.PRESET_FULL, Region.nextPreset(Region.PRESET_BOTTOM))
        assertEquals(Region.PRESET_TOP, Region.nextPreset(Region.PRESET_FULL))
        assertEquals(Region.PRESET_CENTER, Region.nextPreset(Region.PRESET_TOP))
        assertEquals(Region.PRESET_BOTTOM, Region.nextPreset(Region.PRESET_CENTER))
    }

    @Test
    fun `nextPreset from custom or garbage restarts at bottom`() {
        assertEquals(Region.PRESET_BOTTOM, Region.nextPreset(Region.PRESET_CUSTOM))
        assertEquals(Region.PRESET_BOTTOM, Region.nextPreset("tesseract-legacy"))
        assertEquals(Region.PRESET_BOTTOM, Region.nextPreset(null))
    }

    @Test
    fun `normalizePreset keeps only known ids`() {
        assertEquals(Region.PRESET_TOP, Region.normalizePreset(Region.PRESET_TOP))
        assertEquals(Region.PRESET_CUSTOM, Region.normalizePreset(Region.PRESET_CUSTOM))
        assertEquals(Region.PRESET_BOTTOM, Region.normalizePreset("fullscreen-v99"))
        assertEquals(Region.PRESET_BOTTOM, Region.normalizePreset(null))
    }

    @Test
    fun `rectFor matches expected shares of screen`() {
        val w = 1000
        val h = 2000
        assertEquals(Region.Box(0, 0, 1000, 2000), Region.rectFor(Region.PRESET_FULL, w, h))
        assertEquals(Region.Box(0, 0, 1000, 1000), Region.rectFor(Region.PRESET_TOP, w, h))
        assertEquals(Region.Box(0, 500, 1000, 1500), Region.rectFor(Region.PRESET_CENTER, w, h))
        // bottom == DEFAULT_RATIOS
        assertEquals(
            Region.Box(25, 1100, 975, 1960),
            Region.rectFor(Region.PRESET_BOTTOM, w, h),
        )
    }

    @Test
    fun `label is human readable per preset`() {
        assertEquals("Весь экран", Region.label(Region.PRESET_FULL))
        assertEquals("Верхняя половина", Region.label(Region.PRESET_TOP))
        assertEquals("Центральная половина", Region.label(Region.PRESET_CENTER))
        assertEquals("Нижняя половина", Region.label(Region.PRESET_BOTTOM))
        assertEquals("Своя рамка", Region.label(Region.PRESET_CUSTOM))
    }

    @Test
    fun `box survives ratio round trip`() {
        // степени двойки — round trip точен без плавающих поправок
        val box = Region.Box(256, 128, 768, 512)
        val r = Region.ratiosOf(box, 1024, 1024)
        val back = Region.boxFromRatios(r[0], r[1], r[2], r[3], 1024, 1024)
        assertEquals(box, back)
    }

    @Test
    fun `boxFromRatios tolerates garbage ratios`() {
        val box = Region.boxFromRatios(-5f, 2f, 0.5f, 0.25f, 1000, 2000)
        assertTrue("left must be >= 0", box.left >= 0)
        assertTrue("top must be < bottom", box.top < box.bottom)
        assertTrue("right within screen", box.right <= 1000)
        assertTrue("bottom within screen", box.bottom <= 2000)
    }

    @Test
    fun `clamp keeps box inside screen with min size`() {
        val s = Region.clamp(Region.Box(-500, -500, 50, 50), 1000, 2000, 80, 80)
        assertTrue(s.left >= 0 && s.top >= 0)
        assertTrue(s.right <= 1000 && s.bottom <= 2000)
        assertTrue(s.width >= 80)
        assertTrue(s.height >= 80)
    }

    @Test
    fun `clamp never inverts sides`() {
        // тащим левую грань далеко за правую
        val s = Region.clamp(Region.Box(900, 100, 980, 300), 1000, 2000, 80, 80)
        assertTrue("left must stay left of right", s.left < s.right)
        assertTrue(s.width >= 80)
    }

    @Test
    fun `clamp moves whole box back inside screen`() {
        val s = Region.clamp(Region.Box(950, 1900, 1050, 2100), 1000, 2000, 80, 80)
        assertEquals(920, s.left)
        assertEquals(1000, s.right)
        assertEquals(2000, s.bottom)
    }

    @Test
    fun `clamp survives screen smaller than minimum`() {
        val s = Region.clamp(Region.Box(-50, -50, 500, 500), 300, 300, 400, 400)
        assertTrue(s.left >= 0 && s.top >= 0)
        assertTrue(s.right <= 300 && s.bottom <= 300)
        assertTrue(s.width > 0 && s.height > 0)
    }
}
