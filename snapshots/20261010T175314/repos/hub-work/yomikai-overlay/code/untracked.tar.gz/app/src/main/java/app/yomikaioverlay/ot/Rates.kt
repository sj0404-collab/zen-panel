package app.yomikaioverlay.ot

import kotlin.math.roundToInt

/**
 * Скорость озвучки: шаг 25%, диапазон 50…200%. Чистые функции, чтобы
 * MainActivity и панель оверлея считали одинаково (и без Android).
 */
object Rates {
    const val MIN = 0.5f
    const val MAX = 2.0f
    const val STEP = 0.25f

    /** Приводит значение к сетке шагов 25% внутри [MIN]..[MAX]. */
    fun clamp(rate: Float): Float {
        val snapped = if (Math.abs(rate - 1.0f) < 0.01f) 1.0f else rate
        val stepped = Math.round(snapped / STEP) * STEP
        return (stepped.coerceIn(MIN, MAX) * 100f).roundToInt() / 100f
    }

    /** Сдвиг на [delta] с приведением к сетке. */
    fun step(current: Float, delta: Float): Float = clamp(current + delta)

    /** Перебор по кругу: 1.0 → 1.25 → … → 2.0 → 0.5 → 0.75 → 1.0. */
    fun nextCycle(current: Float): Float {
        var r = clamp(current) + STEP
        if (r > MAX) r = MIN
        return clamp(r)
    }

    /** Проценты для подписи: 1.0 → «100%». */
    fun percent(rate: Float): Int = (clamp(rate) * 100).roundToInt()
}
