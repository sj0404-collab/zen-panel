package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Бесплатный шлюз перевода: пустой输入 не должен уходить в сеть,
 * а translate всегда возвращает строку (старый контракт для UI).
 */
class MangaTranslatorServiceTest {

    @Test
    fun `blank input never touches network`() {
        assertEquals("", MangaTranslatorService.translate(""))
        assertEquals("", MangaTranslatorService.translate("   "))
    }

    @Test
    fun `translateOrNull returns null for blank input`() {
        assertEquals(null, MangaTranslatorService.translateOrNull(""))
    }
}
