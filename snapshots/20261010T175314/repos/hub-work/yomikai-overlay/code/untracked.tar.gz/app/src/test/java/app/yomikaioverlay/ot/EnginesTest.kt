package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Единый каталог движков: перебор, легаси-алиасы, признаки ключа. */
class EnginesTest {

    @Test
    fun `next cycles all four engines`() {
        assertEquals(Engines.ZEN, Engines.next(Engines.LENS))
        assertEquals(Engines.GOOGLE_AI, Engines.next(Engines.ZEN))
        assertEquals(Engines.OPENROUTER, Engines.next(Engines.GOOGLE_AI))
        assertEquals(Engines.LENS, Engines.next(Engines.OPENROUTER))
    }

    @Test
    fun `normalize maps legacy offline engines to lens`() {
        assertEquals(Engines.LENS, Engines.normalize("local_cyrillic"))
        assertEquals(Engines.LENS, Engines.normalize("tesseract"))
        assertEquals(Engines.LENS, Engines.normalize(""))
        assertEquals(Engines.LENS, Engines.normalize(null))
        assertEquals(Engines.ZEN, Engines.normalize(Engines.ZEN))
    }

    @Test
    fun `title is stable and non empty`() {
        assertEquals("Google Lens (онлайн)", Engines.title(Engines.LENS))
        assertEquals("Zen Free (онлайн, без ключа)", Engines.title(Engines.ZEN))
        assertEquals("Google AI Gemini Vision", Engines.title(Engines.GOOGLE_AI))
        assertEquals("OpenRouter Vision", Engines.title(Engines.OPENROUTER))
        assertEquals("Google Lens (онлайн)", Engines.title("legacy-offline"))
    }

    @Test
    fun `only key engines require api key`() {
        assertFalse(Engines.needsKey(Engines.LENS))
        assertFalse(Engines.needsKey(Engines.ZEN))
        assertTrue(Engines.needsKey(Engines.GOOGLE_AI))
        assertTrue(Engines.needsKey(Engines.OPENROUTER))
    }

    @Test
    fun `subtitle mentions fallback for zen`() {
        assertTrue(Engines.subtitle(Engines.ZEN).contains("Lens"))
    }
}
