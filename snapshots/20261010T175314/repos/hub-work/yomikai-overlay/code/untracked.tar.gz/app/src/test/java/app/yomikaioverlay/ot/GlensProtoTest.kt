package app.yomikaioverlay.ot

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Ручной протобуф Google Lens: writer/reader должны быть обратно совместимы,
 * а запрос — нести картинку, размеры и русскую локаль клиента.
 */
class GlensProtoTest {

    @Test
    fun `writer and reader round trip all used field kinds`() {
        val bytes = ProtoWriter().apply {
            writeMessage(1) {
                it.writeString(1, "ru")
                it.writeMessage(2) { i2 -> i2.writeInt32(1, 42) }
            }
            writeUInt64(2, 987_654_321L)
            writeBytes(3, byteArrayOf(0, 1, 2, 3))
        }.toByteArray()

        val r = ProtoReader(bytes)
        val t1 = r.readTag()!!
        assertEquals(1, t1 ushr 3)
        val msg = ProtoReader(r.readBytes())

        val s1 = msg.readTag()!!
        assertEquals(1, s1 ushr 3)
        assertEquals("ru", msg.readString())

        val s2 = msg.readTag()!!
        assertEquals(2, s2 ushr 3)
        val inner = ProtoReader(msg.readBytes())
        val s3 = inner.readTag()!!
        assertEquals(1, s3 ushr 3)
        assertEquals(42, inner.readVarint32())

        val t2 = r.readTag()!!
        assertEquals(2, t2 ushr 3)
        assertEquals(987_654_321L, r.readVarint32()!!.toLong())

        val t3 = r.readTag()!!
        assertEquals(3, t3 ushr 3)
        assertArrayEquals(byteArrayOf(0, 1, 2, 3), r.readBytes())
    }

    @Test
    fun `request payload carries png and dimensions`() {
        val png = byteArrayOf(9, 8, 7, 6, 5, 4, 3, 2, 1)
        val payload = GlensOcrEngine().buildRequestPayload(png, 800, 600)

        val top = ProtoReader(payload)
        val tag = top.readTag()!!
        assertEquals(1, tag ushr 3)
        assertEquals(2, tag and 0x7) // length-delimited

        val req = ProtoReader(top.readBytes())
        var pngOut: ByteArray? = null
        var width = -1
        var height = -1
        var contextSeen = false
        var clientLang = ""
        while (req.hasRemaining()) {
            val t = req.readTag() ?: break
            val f = t ushr 3
            when {
                f == 1 -> { // objects_request_context
                    contextSeen = true
                    val ctx = ProtoReader(req.readBytes())
                    while (ctx.hasRemaining()) {
                        val tc = ctx.readTag() ?: break
                        if ((tc ushr 3) == 4) {
                            val cc = ProtoReader(ctx.readBytes())
                            while (cc.hasRemaining()) {
                                val tcc = cc.readTag() ?: break
                                if ((tcc ushr 3) == 4) { // locale_context
                                    val lc = ProtoReader(cc.readBytes())
                                    val tl = lc.readTag()!!
                                    assertEquals(1, tl ushr 3)
                                    clientLang = lc.readString()
                                } else cc.skipField(tcc and 0x7)
                            }
                        } else ctx.skipField(tc and 0x7)
                    }
                }
                f == 3 -> { // image_data
                    val img = ProtoReader(req.readBytes())
                    while (img.hasRemaining()) {
                        val ti = img.readTag() ?: break
                        when (ti ushr 3) {
                            1 -> { // payload message
                                val pl = ProtoReader(img.readBytes())
                                val tp = pl.readTag()!!
                                assertEquals(1, tp ushr 3)
                                pngOut = pl.readBytes()
                            }
                            3 -> { // dimensions
                                val dm = ProtoReader(img.readBytes())
                                val tw = dm.readTag()!!
                                assertEquals(1, tw ushr 3)
                                width = dm.readVarint32()!!
                                val th = dm.readTag()!!
                                assertEquals(2, th ushr 3)
                                height = dm.readVarint32()!!
                            }
                            else -> img.skipField(ti and 0x7)
                        }
                    }
                }
                else -> req.skipField(t and 0x7)
            }
        }
        assertTrue("objects_request_context missing", contextSeen)
        assertEquals("ru", clientLang)
        assertArrayEquals("png bytes must survive the encode", png, pngOut)
        assertEquals(800, width)
        assertEquals(600, height)
    }
}
