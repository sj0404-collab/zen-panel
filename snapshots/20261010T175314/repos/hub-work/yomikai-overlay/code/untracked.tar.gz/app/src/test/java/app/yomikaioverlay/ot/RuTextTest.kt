package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Чистка ответов LLM: код-блоки, латиница в русском тексте, мусорные приписки. */
class RuTextTest {

    @Test
    fun `strips code fences`() {
        val out = RuText.clean("```\nТекст\n```")
        assertFalse(out.contains("```"))
        assertTrue(out.contains("Текст"))
    }

    @Test
    fun `drops leading chatty prefixes`() {
        assertEquals("Привет", RuText.clean("Here is: Привет"))
        assertEquals("Привет", RuText.clean("Перевод: Привет"))
    }

    @Test
    fun `replaces yo with e`() {
        assertEquals("Елка", RuText.clean("Ёлка"))
    }

    @Test
    fun `drops latin words from mostly cyrillic lines`() {
        val out = RuText.clean("Привет мир Hello world")
        assertTrue(out.contains("Привет"))
        assertTrue(out.contains("мир"))
        assertFalse(out.contains("Hello"))
    }

    @Test
    fun `keeps short words of any script`() {
        val out = RuText.clean("ID OK да")
        assertTrue(out.contains("ID"))
        assertTrue(out.contains("OK"))
    }

    @Test
    fun `collapses spaces and drops blank lines`() {
        val out = RuText.clean("Привет    мир\n\n\nКак   дела")
        assertEquals("Привет мир\nКак дела", out)
    }
}
