package app.yomikaioverlay.ot

/**
 * Единый источник правды по OCR-движкам: порядок перебора, легаси-алиасы,
 * человекочитаемые названия и признак «нужен ключ». Раньше эта логика
 * дублировалась в MainActivity и OverlayService и могла разъехаться.
 */
object Engines {
    const val LENS = "lens"
    const val ZEN = "zen"
    const val GOOGLE_AI = "googleai"
    const val OPENROUTER = "openrouter"

    /** Порядок перебора движка по тапу. */
    val CYCLE = listOf(LENS, ZEN, GOOGLE_AI, OPENROUTER)

    /** Следующий движок по кругу. */
    fun next(current: String?): String {
        val i = CYCLE.indexOf(current)
        return if (i < 0) CYCLE[0] else CYCLE[(i + 1) % CYCLE.size]
    }

    /**
     * Приводит id к поддерживаемому: старые оффлайн-движки (tesseract/модели)
     * и мусор из префов схлопываются к бесключевому Lens.
     */
    fun normalize(id: String?): String = if (CYCLE.contains(id)) id!! else LENS

    /** Короткое название для кнопок. */
    fun title(id: String?): String = when (normalize(id)) {
        ZEN -> "Zen Free (онлайн, без ключа)"
        GOOGLE_AI -> "Google AI Gemini Vision"
        OPENROUTER -> "OpenRouter Vision"
        else -> "Google Lens (онлайн)"
    }

    /** Подпись-пояснение под названием. */
    fun subtitle(id: String?): String = when (normalize(id)) {
        ZEN -> "бесплатный ИИ-хаб, фолбэк — Lens"
        GOOGLE_AI -> "gemini, строгий OCR (ключ)"
        OPENROUTER -> "vision-модели через OpenRouter (ключ)"
        else -> "бесключевой endpoint — самый простой"
    }

    /** Нужен ли пользовательский API-ключ. */
    fun needsKey(id: String?): Boolean = when (normalize(id)) {
        GOOGLE_AI, OPENROUTER -> true
        else -> false
    }
}
