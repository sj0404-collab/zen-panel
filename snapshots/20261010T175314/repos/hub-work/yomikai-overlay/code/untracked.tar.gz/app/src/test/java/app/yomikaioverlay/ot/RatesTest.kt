package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Скорость озвучки: сетка 25%, диапазон 50…200%. */
class RatesTest {

    @Test
    fun `clamp snaps to 25 percent grid`() {
        assertEquals(1.0f, Rates.clamp(0.99f), 0.001f)
        assertEquals(1.25f, Rates.clamp(1.3f), 0.001f)
        assertEquals(0.5f, Rates.clamp(0.1f), 0.001f)
        assertEquals(2.0f, Rates.clamp(5.0f), 0.001f)
    }

    @Test
    fun `step never leaves range`() {
        assertEquals(1.25f, Rates.step(1.0f, Rates.STEP), 0.001f)
        assertEquals(2.0f, Rates.step(2.0f, Rates.STEP), 0.001f) // потолок
        assertEquals(0.5f, Rates.step(0.5f, -Rates.STEP), 0.001f) // пол
        assertEquals(2.0f, Rates.step(2.0f, 0.0f), 0.001f)
    }

    @Test
    fun `cycle covers whole range and wraps`() {
        var r = 1.0f
        val seen = LinkedHashSet<Float>()
        repeat(8) {
            r = Rates.nextCycle(r)
            seen.add(r)
        }
        assertTrue(seen.containsAll(listOf(1.25f, 1.5f, 1.75f, 2.0f, 0.5f, 0.75f)))
        assertEquals(1.0f, Rates.nextCycle(0.75f), 0.001f)
    }

    @Test
    fun `percent matches stored rate`() {
        assertEquals(100, Rates.percent(1.0f))
        assertEquals(150, Rates.percent(1.5f))
        assertEquals(50, Rates.percent(0.5f))
    }
}
