package app.yomikaioverlay.ot

/**
 * Пресеты OCR-рамки и безопасная геометрия: чистые функции над размерами
 * экрана (без Android-типов), чтобы логику можно было покрыть юнит-тестами.
 *
 * Все координаты — в пикселях экрана, рамка всегда остаётся внутри экрана
 * и не выворачивается наизнанку при перетаскивании ручек.
 */
object Region {
    const val PRESET_BOTTOM = "bottom"
    const val PRESET_FULL = "full"
    const val PRESET_TOP = "top"
    const val PRESET_CENTER = "center"
    const val PRESET_CUSTOM = "custom"

    /** Порядок перебора пресетов по тапу. */
    val CYCLE = listOf(PRESET_BOTTOM, PRESET_FULL, PRESET_TOP, PRESET_CENTER)

    /** Рамка «Нижняя половина» — дефолт при первом запуске. */
    val DEFAULT_RATIOS = floatArrayOf(0.025f, 0.55f, 0.975f, 0.98f)

    /** Прямоугольник в пикселях (замена android.graphics.Rect для чистых функций). */
    data class Box(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
    ) {
        val width: Int get() = right - left
        val height: Int get() = bottom - top
    }

    /** Следующий пресет по кругу. Неизвестное/своя рамка → «Нижняя половина». */
    fun nextPreset(current: String?): String {
        val i = CYCLE.indexOf(current)
        return if (i < 0) PRESET_BOTTOM else CYCLE[(i + 1) % CYCLE.size]
    }

    /** Любая строка из префов → валидный id пресета (custom сохраняется). */
    fun normalizePreset(preset: String?): String = when (preset) {
        in CYCLE -> preset!!
        PRESET_CUSTOM -> PRESET_CUSTOM
        else -> PRESET_BOTTOM
    }

    /** Рамка пресета в пикселях экрана [w]x[h]. */
    fun rectFor(preset: String?, w: Int, h: Int): Box {
        val ww = w.coerceAtLeast(1)
        val hh = h.coerceAtLeast(1)
        return when (preset) {
            PRESET_FULL -> Box(0, 0, ww, hh)
            PRESET_TOP -> Box(0, 0, ww, hh / 2)
            PRESET_CENTER -> Box(0, (hh * 0.25f).toInt(), ww, (hh * 0.75f).toInt())
            else -> Box(
                (ww * 0.025f).toInt(),
                (hh * 0.55f).toInt(),
                (ww * 0.975f).toInt(),
                (hh * 0.98f).toInt(),
            )
        }
    }

    /** Человекочитаемое имя пресета. */
    fun label(preset: String?): String = when (preset) {
        PRESET_FULL -> "Весь экран"
        PRESET_TOP -> "Верхняя половина"
        PRESET_CENTER -> "Центральная половина"
        PRESET_BOTTOM -> "Нижняя половина"
        else -> "Своя рамка"
    }

    /** Доли (l, t, r, b) рамки на экране [w]x[h]. */
    fun ratiosOf(box: Box, w: Int, h: Int): FloatArray {
        val ww = w.coerceAtLeast(1).toFloat()
        val hh = h.coerceAtLeast(1).toFloat()
        return floatArrayOf(
            box.left / ww, box.top / hh, box.right / ww, box.bottom / hh,
        )
    }

    /** Рамка из долей (l, t, r, b) на экране [w]x[h]. */
    fun boxFromRatios(l: Float, t: Float, r: Float, b: Float, w: Int, h: Int): Box {
        val ww = w.coerceAtLeast(1)
        val hh = h.coerceAtLeast(1)
        val left = (ww * l.coerceIn(0f, 1f)).toInt().coerceIn(0, ww - 1)
        var right = (ww * r.coerceIn(0f, 1f)).toInt().coerceIn(0, ww)
        if (right <= left) right = (left + 1).coerceAtMost(ww)
        val top = (hh * t.coerceIn(0f, 1f)).toInt().coerceIn(0, hh - 1)
        var bottom = (hh * b.coerceIn(0f, 1f)).toInt().coerceIn(0, hh)
        if (bottom <= top) bottom = (top + 1).coerceAtMost(hh)
        return Box(left, top, right, bottom)
    }

    /**
     * Приводит рамку к экрану [w]x[h] и минимальному размеру [minW]x[minH]
     * без инверсии сторон: при перетаскивании ручки/рамки результат всегда
     * остаётся валидным прямоугольником внутри экрана.
     */
    fun clamp(box: Box, w: Int, h: Int, minW: Int, minH: Int): Box {
        val ww = w.coerceAtLeast(1)
        val hh = h.coerceAtLeast(1)
        val minWidth = minW.coerceIn(1, ww)
        val minHeight = minH.coerceIn(1, hh)
        var left = box.left.coerceIn(0, ww - minWidth)
        var right = box.right.coerceIn(left + minWidth, ww)
        var top = box.top.coerceIn(0, hh - minHeight)
        var bottom = box.bottom.coerceIn(top + minHeight, hh)
        // Страхование от инверсии при экране меньше минимальной рамки.
        if (right - left < minWidth) {
            right = (left + minWidth).coerceAtMost(ww)
            left = (right - minWidth).coerceAtLeast(0)
        }
        if (bottom - top < minHeight) {
            bottom = (top + minHeight).coerceAtMost(hh)
            top = (bottom - minHeight).coerceAtLeast(0)
        }
        return Box(left, top, right, bottom)
    }
}
