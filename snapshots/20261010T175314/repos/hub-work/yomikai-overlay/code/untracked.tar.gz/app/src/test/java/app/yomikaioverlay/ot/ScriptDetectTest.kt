package app.yomikaioverlay.ot

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Детект кириллицы: от него зависит, включать ли перевод перед озвучкой
 * (латиница → русский) или читать как есть.
 */
class ScriptDetectTest {

    @Test
    fun `pure cyrillic is cyrillic`() {
        assertTrue(ScriptDetect.isMostlyCyrillic("Привет, как дела?"))
        assertTrue(ScriptDetect.isMostlyCyrillic("Ёжик ёж"))
    }

    @Test
    fun `pure latin is not cyrillic`() {
        assertFalse(ScriptDetect.isMostlyCyrillic("Hello world"))
        assertFalse(ScriptDetect.isMostlyCyrillic("TEXT 123"))
    }

    @Test
    fun `empty and non letters are not cyrillic`() {
        assertFalse(ScriptDetect.isMostlyCyrillic(""))
        assertFalse(ScriptDetect.isMostlyCyrillic("123 456"))
        assertFalse(ScriptDetect.isMostlyCyrillic("日本語のテキスト"))
    }

    @Test
    fun `mixed goes by majority`() {
        assertTrue(ScriptDetect.isMostlyCyrillic("Привет OK"))
        assertFalse(ScriptDetect.isMostlyCyrillic("OK Привет"))
    }

    @Test
    fun `preferRu mirrors isMostlyCyrillic`() {
        assertTrue(ScriptDetect.preferRu("да"))
        assertFalse(ScriptDetect.preferRu("yes"))
    }
}
