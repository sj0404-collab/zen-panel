package dev.pocketrun.agent.opencode

import dev.pocketrun.core.Workspace
import dev.pocketrun.runtime.js.JsRuntime
import dev.pocketrun.runtime.npm.NpxRuntime
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class TrProbeTest {
    @get:Rule val tmp = TemporaryFolder()

    @Test fun probe() {
        val ws = Workspace.at(tmp.newFolder())
        val dir = File(ws.root, "p").apply { mkdirs() }
        val boot = listOf(File("src/main/assets/node/boot.js"), File("app/src/main/assets/node/boot.js"))
            .firstOrNull { it.isFile }?.readText() ?: error("no boot.js")
        val js = JsRuntime(boot, ws, maxRunMs = 10_000)
        val shell = MiniShell(ws, js, NpxRuntime(js, ws))
        for (cmd in listOf(
            "echo a_b_c | sed 's/_/-/g'",
            "printf 'one\\ntwo\\n' | sed '/two/d'",
            "echo abc | sed 'y/abc/ABC/'",
            "echo aaa bbb ccc | tr -s ' '",
            "echo ab | tr a-z b",
            "echo abcccd | tr a b",
            "printf 'a b\\nc d\\n' | awk '{print \$1, \$2}'",
        )) {
            val r = shell.execute(cmd, dir, 20_000)
            println("PROBE [$cmd] exit=${r.exitCode} out=${r.output.replace("\n", "\\n")}")
        }
        File(dir, "a.txt").writeText("")
        println("PROBE [file a.txt] " + shell.execute("file a.txt", dir, 20_000).output.trim())
    }
}
