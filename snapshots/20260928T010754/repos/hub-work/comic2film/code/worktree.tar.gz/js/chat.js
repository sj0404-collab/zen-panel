/* Чат с ИИ: сессии, сообщения, файловые вложения (без лимитов). */

import { idbGet, idbSet, chatGetSessions, chatSetSessions, chatGetMessages, chatSetMessages, chatDelSession, KEY_SETTINGS } from './store.js';
import { provider, chat, chatWithImage, modelMeta } from './ai.js';
import { openModelPicker } from './modelsui.js';

const LS_CURRENT = 'chat:current';
const MAX_COPY = 12;
const MAX_ATTACH_BYTES = 400 * 1024;   // текст, который влезет в контекст
const MAX_TOTAL_CHARS = 24000;        // общий лимит на текст из вложений

const $ = (id) => document.getElementById(id);
let sessions = [];
let currentId = null;
let messages = [];
let attachments = []; // { file, name, type, dataURL? }
let asking = false;

export async function initChat() {
  sessions = await chatGetSessions();
  currentId = (await idbGet(LS_CURRENT)) || null;
  if (!currentId || !sessions.find(s => s.id === currentId)) {
    currentId = sessions[0] ? sessions[0].id : null;
  }
  if (currentId) { await loadMessages(); } else { currentId = newChat(); await loadMessages(); }
  renderModelButton();
  renderSessions();
  renderMessages();
  wireChat();
}

function newChat() {
  const s = { id: 's' + Date.now(), title: 'Сессия ' + new Date().toLocaleString('ru', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }), ts: Date.now() };
  sessions.unshift(s);
  persistSessions();
  return s.id;
}

async function persistSessions() {
  await chatSetSessions(sessions);
  if (currentId) await idbSet(LS_CURRENT, currentId);
}

async function loadMessages() {
  messages = await chatGetMessages(currentId);
}

async function persistMessages() {
  await chatSetMessages(currentId, messages);
}

let S = {}; // текущие настройки (обновляются из app.js)

/* Кнопка-пикер модели чата (вместо огромного списка «все провайдеры × все модели»). */
function renderModelButton() {
  const btn = $('btnChatPickModel');
  if (!btn) return;
  const pid = S.ai || 'pollinations';
  const p = provider(pid);
  const mid = S.aimodel || (p.models[0] ? p.models[0].id : 'openai');
  const mt = modelMeta(pid, mid);
  btn.textContent = '🔍 ' + (mt.nokey ? '🆓 ' : '') + (mt.label || mid) + ' — ' + mt.providerName;
  btn.style.overflow = 'hidden';
  btn.style.textOverflow = 'ellipsis';
  btn.style.maxWidth = '70vw';
  btn.title = (mt.free ? 'Бесплатно' : 'Платно') + (mt.vision ? ' · vision' : '') + ' · ' + pid + ' / ' + mid;
}

function renderSessions() {
  const sel = $('chat-sessions');
  if (!sel) return;
  sel.replaceChildren();
  for (const s of sessions) {
    const o = document.createElement('option');
    o.value = s.id;
    o.textContent = s.title;
    o.selected = s.id === currentId;
    sel.appendChild(o);
  }
  const empty = $('chat-empty');
  if (empty) empty.classList.toggle('hidden', messages.length > 0);
}

function renderMessages() {
  const box = $('chat-messages');
  const empty = $('chat-empty');
  if (!box) return;
  box.replaceChildren();
  if (messages.length === 0) { if (empty) empty.classList.remove('hidden'); return; }
  if (empty) empty.classList.add('hidden');
  messages.forEach((m, i) => {
    const d = document.createElement('div');
    d.className = 'msg ' + (m.role === 'user' ? 'user' : m.role === 'err' ? 'err' : 'ai');
    if (m.typing) d.classList.add('typing');
    let h = '<span class="who">' + (m.role === 'user' ? 'Вы' : m.role === 'err' ? 'Ошибка' : 'ИИ') + '</span>';
    if (m.files && m.files.length && m.role === 'user') {
      for (const f of m.files) {
        if (f.dataURL) {
          h += '<img class="att" src="' + f.dataURL + '" alt="…">';
        } else {
          h += '<span class="attfile">📎 ' + escapeHtml(f.name) + ' · ' + fmtSize(f.size) + '</span>';
        }
      }
    }
    if (i === messages.length - 1 && messages[messages.length - 1].typing && !m.content) {
      // пусто пока печатает
    }
    h += '<div>' + escapeHtml(m.content || (m.typing ? '…' : '')) + '</div>';
    if (m.content && m.role === 'ai' && m.content.length > 60) h += '<span class="mtime">' + new Date(m.ts).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' }) + '</span>';
    d.innerHTML = h;
    box.appendChild(d);
  });
  box.scrollTop = box.scrollHeight;
}

function resolveModel() {
  return { provider: S.ai, model: S.aimodel };
}

async function ask() {
  if (asking) return;
  const input = $('chat-input');
  const text = (input ? input.value : '').trim();
  if (!text && !attachments.length) return;
  asking = true;
  if (input) input.value = '';
  const files = attachments.splice(0);
  renderAttachments();
  const userMsg = { role: 'user', content: text, files, ts: Date.now() };
  messages.push(userMsg);
  await persistMessages();
  renderMessages();
  const typing = { role: 'ai', typing: true, ts: Date.now() };
  messages.push(typing);
  renderMessages();
  try {
    const { provider: pid, model: mid } = resolveModel();
    const chatSettings = { ...S, ai: pid, aimodel: mid };
    const history = messages.filter(m => !m.typing && m.role !== 'err' && m.role !== 'system')
      .filter((m, i, arr) => i >= Math.max(0, arr.length - MAX_COPY));
    const sys = messages.find(m => m.role === 'system');
    const systemPrompt = 'Ты — помощник пользователя приложения VoiceComic (комиксы → озвученное видео). Отвечай по-русски, коротко и по делу. Пользователь может присылать изображения и файлы: изображения разбирай как страницы манги/комикса, текстовые файлы прочитывай и комментируй.';
    void sys;
    const files = userMsg.files || [];
    const images = files.filter(f => f.dataURL);

    // Текстовые вложения раньше показывались в чате, но модели НЕ уходили:
    // системный промпт обещал «текстовые файлы прочитывай», а приходил
    // только текст сообщения. Теперь содержимое читается и прикладывается.
    const texts = [];
    let skipped = 0;
    for (const f of files) {
      if (f.dataURL) continue;
      if (!f.text) {
        const t = await readAttachmentText(f);
        if (t) f.text = t; else { skipped++; continue; }
      }
      texts.push(`--- файл «${f.name}» ---\n${f.text}`);
    }
    const attachBlock = texts.length
      ? '\n\n[Содержимое приложенных файлов]\n' + texts.join('\n\n').slice(0, MAX_TOTAL_CHARS)
      : '';

    const turn = (m) => ({ role: m.role, content: m.content });
    const userTurn = { role: 'user', content: (text || '(без текста)') + attachBlock };
    const hist = history.filter(m => m !== userMsg).map(turn);
    let answer;
    if (images.length) {
      answer = await chatWithImage(chatSettings, [
        { role: 'system', content: systemPrompt },
        ...hist,
        userTurn,
      ], images[0].dataURL);
    } else {
      answer = await chat(chatSettings, [
        { role: 'system', content: systemPrompt },
        ...hist,
        userTurn,
      ]);
    }
    if (skipped) console.warn('не удалось прочитать вложений: ' + skipped);
    messages = messages.filter(m => m !== typing);
    messages.push({ role: 'ai', content: String(answer), ts: Date.now() });
    const title = (text || (files[0] && files[0].name) || 'Сессия').trim().slice(0, 40);
    if (currentId && sessions.find(sp => sp.id === currentId)) {
      const sp = sessions.find(x => x.id === currentId);
      if (sp.title.startsWith('Сессия ') || !sp.title) { sp.title = title; sp.ts = Date.now(); }
      sessions.sort((a, b) => b.ts - a.ts);
      await persistSessions();
      renderSessions();
    }
  } catch (e) {
    messages = messages.filter(m => m !== typing);
    messages.push({ role: 'err', content: 'Ошибка: ' + (e.message || e), ts: Date.now() });
    console.error(e);
  }
  asking = false;
  await persistMessages();
  renderMessages();
}

function renderAttachments() {
  const box = $('chat-attachments');
  if (!box) return;
  box.replaceChildren();
  attachments.forEach((a, i) => {
    const s = document.createElement('span');
    s.className = 'att';
    s.textContent = '📎 ' + a.name + ' · ' + fmtSize(a.size);
    const x = document.createElement('button');
    x.className = 'btn mini';
    x.style.padding = '0 6px';
    x.textContent = '✕';
    x.addEventListener('click', () => { attachments.splice(i, 1); renderAttachments(); });
    s.appendChild(x);
    box.appendChild(s);
  });
}

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' МБ' : n > 1024 ? Math.round(n / 1024) + ' КБ' : n + ' Б'; }

/* Прочитать текстовое вложение, чтобы отправить его модели.
 * Всё, что не текст (картинки, аудио, бинарники), отсекается по типу/размеру. */
const TEXTY = /^(text\/|application\/(json|xml|javascript|x-yaml|yaml|toml|sql|graphql))/;
async function readAttachmentText(f) {
  try {
    if (typeof f.type === 'string' && f.type && !TEXTY.test(f.type)) return '';
    if (!f.file || f.size > MAX_ATTACH_BYTES) return '';
    const t = await f.file.text();
    if (!t || /[\x00-\x08\x0e-\x1f]/.test(t.slice(0, 512))) return ''; // бинарник без MIME
    return t.slice(0, MAX_ATTACH_BYTES);
  } catch (e) {
    return '';
  }
}

function wireChat() {
  const input = $('chat-input');
  const send = $('btnChatSend');
  const del = $('btnChatDel');
  const file = $('chat-file');
  const sessionsSel = $('chat-sessions');
  const modelBtn = $('btnChatPickModel');
  const btnNew = $('btnChatNew');

  if (send) send.addEventListener('click', () => ask());
  if (input) input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(); }
  });
  if (modelBtn) modelBtn.addEventListener('click', () => {
    if (asking) return;
    openModelPicker({
      settings: S || {},
      onSelect: async (pid, mid) => {
        S = { ...S, ai: pid, aimodel: mid };
        renderModelButton();
        try {
          await idbSet(KEY_SETTINGS, S);
        } catch (e) { console.warn(e); }
        if (window.onSettingsChanged) window.onSettingsChanged(S);
      },
    });
  });
  if (file) file.addEventListener('change', () => {
    for (const f of file.files) {
      if (!attachments.find(a => a.file === f)) {
        const a = { file: f, name: f.name, size: f.size, type: f.type };
        if (f.type.startsWith('image/')) {
          const rd = new FileReader();
          rd.onload = () => { a.dataURL = rd.result; };
          rd.readAsDataURL(f);
        }
        attachments.push(a);
      }
    }
    file.value = '';
    renderAttachments();
  });
  if (sessionsSel) sessionsSel.addEventListener('change', async () => {
    currentId = sessionsSel.value;
    await persistSessions();
    await loadMessages();
    renderSessions();
    renderMessages();
  });
  if (btnNew) btnNew.addEventListener('click', async () => {
    currentId = newChat();
    await persistSessions();
    await loadMessages();
    renderSessions();
    renderMessages();
  });
  if (del) del.addEventListener('click', async () => {
    if (!currentId) return;
    if (!confirm('Удалить текущую сессию чата?')) return;
    await chatDelSession(currentId);
    const list = sessions.filter(s => s.id !== currentId);
    sessions = list;
    currentId = list[0] ? list[0].id : (newChat(), currentId);
    if (!list[0]) { currentId = sessions[0].id; }
    await persistSessions();
    await loadMessages();
    renderSessions();
    renderMessages();
  });
}

/* вызывается из app.js при старте и при изменении настроек */
export function setChatSettings(s) { S = s || {}; renderModelButton(); }

export const chatApi = { initChat, renderAttachments, setChatSettings };