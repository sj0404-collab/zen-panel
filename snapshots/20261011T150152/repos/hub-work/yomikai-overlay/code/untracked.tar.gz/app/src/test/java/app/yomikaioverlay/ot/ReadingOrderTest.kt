package app.yomikaioverlay.ot

import android.graphics.Rect
import org.junit.Assert.assertEquals
import org.junit.Test

class ReadingOrderTest {

    // Сетка 2×2: два блока сверху и два снизу.
    private val tl = Rect(10, 10, 100, 50)
    private val tr = Rect(120, 10, 210, 50)
    private val bl = Rect(10, 60, 100, 100)
    private val br = Rect(120, 60, 210, 100)
    private val grid = listOf(tl, tr, bl, br)

    /** Rect.equals в юнит-тестах — заглушка, сравниваем по координатам. */
    private fun keys(rects: List<Rect>): List<String> =
        rects.map { "${it.left},${it.top},${it.right},${it.bottom}" }

    private fun key(r: Rect): String = "${r.left},${r.top},${r.right},${r.bottom}"

    @Test fun `normalize пустой mode даёт AUTO`() {
        assertEquals(ReadingOrder.DEFAULT, ReadingOrder.normalize(null))
        assertEquals(ReadingOrder.DEFAULT, ReadingOrder.normalize("banana"))
    }

    @Test fun `ltr читает строки сверху вниз, внутри слева направо`() {
        assertEquals(keys(listOf(tl, tr, bl, br)), keys(ReadingOrder.order(grid, ReadingOrder.LTR)))
    }

    @Test fun `rtl внутри строки справа налево`() {
        assertEquals(keys(listOf(tr, tl, br, bl)), keys(ReadingOrder.order(grid, ReadingOrder.RTL)))
    }

    @Test fun `bottom_up идёт снизу вверх`() {
        assertEquals(keys(listOf(bl, br, tl, tr)), keys(ReadingOrder.order(grid, ReadingOrder.BOTTOM_UP)))
    }

    @Test fun `vertical читает правую колонку сверху вниз, затем левую`() {
        assertEquals(keys(listOf(tr, br, tl, bl)), keys(ReadingOrder.order(grid, ReadingOrder.VERTICAL)))
    }

    @Test fun `auto без изменений`() {
        assertEquals(keys(grid), keys(ReadingOrder.order(grid, ReadingOrder.AUTO)))
    }

    @Test fun `перетасовка входного порядка не влияет на ltr`() {
        val shuffled = listOf(br, tl, bl, tr)
        assertEquals(keys(listOf(tl, tr, bl, br)), keys(ReadingOrder.order(shuffled, ReadingOrder.LTR)))
    }

    @Test fun `vertical — правая колонка первой`() {
        // Два блока в правой колонке (сверху и снизу) и один в левой.
        val rightTop = Rect(200, 10, 300, 60)
        val rightBottom = Rect(200, 70, 300, 120)
        val left = Rect(10, 10, 110, 60)
        val ordered = ReadingOrder.order(listOf(left, rightBottom, rightTop), ReadingOrder.VERTICAL)
        assertEquals(keys(listOf(rightTop, rightBottom, left)), keys(ordered))
    }

    @Test fun `next по кругу`() {
        assertEquals(ReadingOrder.LTR, ReadingOrder.next(ReadingOrder.AUTO))
        assertEquals(ReadingOrder.AUTO, ReadingOrder.next(ReadingOrder.BOTTOM_UP))
    }

    @Test fun `short и label не пустые`() {
        for (m in ReadingOrder.MODES) {
            assertEquals(true, ReadingOrder.label(m).isNotBlank())
            assertEquals(true, ReadingOrder.short(m).isNotBlank())
        }
    }
}