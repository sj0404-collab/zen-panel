package app.yomikaioverlay.ot

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

data class LayoutBlock(val text: String, val rect: Rect)

/**
 * Гибридная пометка: ML Kit даёт координаты блоков текста (рамки + номера +
 * порядок чтения), а сам распознанный текст для озвучки/перевода остаётся
 * онлайн (Lens/Zen) — поэтому покоординатная часть может жить на устройстве.
 *
 * Если Play Services / ML-модель недоступны — [isAvailable] == false и оверлей
 * работает как раньше, без рамок и номеров.
 */
class LayoutOcr {
    private var recognizer: TextRecognizer? = createClient()

    val isAvailable: Boolean get() = recognizer != null

    /** Синхронно (worker-поток): блоки с координатами в пикселях битмапа. */
    fun blocks(bitmap: Bitmap): List<LayoutBlock> {
        val rec = recognizer ?: return emptyList()
        val latch = CountDownLatch(1)
        var result: com.google.mlkit.vision.text.Text? = null
        var failed = false
        try {
            val task = rec.process(InputImage.fromBitmap(bitmap, 0))
            task.addOnSuccessListener { r -> result = r; latch.countDown() }
            task.addOnFailureListener { _ -> failed = true; latch.countDown() }
        } catch (e: Throwable) {
            failed = true
            latch.countDown()
        }
        try { latch.await(15, TimeUnit.SECONDS) } catch (e: InterruptedException) { }
        if (failed || result == null) {
            recognizer = null
            return emptyList()
        }
        return result.textBlocks.mapNotNull { b ->
            val box = b.boundingBox ?: return@mapNotNull null
            LayoutBlock(b.text, box)
        }
    }

    fun close() {
        try { recognizer?.close() } catch (e: Throwable) { }
        recognizer = null
    }

    private companion object {
        fun createClient(): TextRecognizer? = try {
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        } catch (e: Throwable) {
            null
        }
    }
}