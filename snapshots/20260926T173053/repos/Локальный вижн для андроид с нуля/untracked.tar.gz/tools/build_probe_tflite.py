"""Does LiteRT page a closed sector, or copy the whole file the way ORT does?

Builds ONE .tflite holding two independent sectors as two subgraphs under two
signatures, each with its own ~100 MB int8 weight block. Then measures how
much of the file is actually resident after opening sector A only.

  ORT behaviour    -> whole file copied at load, opening A pages in nothing
  mmap behaviour   -> load is cheap, file-resident grows sector by sector

The merge is done by hand on the flatbuffer because TFLite has no converter
for "two models in one file", and that is precisely the shape the project
needs: sectors closed by default inside a single artifact.
"""

import os
import sys

import flatbuffers
import numpy as np
from tensorflow.lite.python import schema_py_generated as schema_fb

DIM = 1024
DEPTH = 64
SECTORS = ("sector_a", "sector_b")


def rss_mb():
    for line in open("/proc/self/status"):
        if line.startswith("VmRSS:"):
            return int(line.split()[1]) * 1024 / 1e6
    return 0.0


def mapped_mb(path):
    """Resident bytes backed by the model file, read from smaps."""
    real = os.path.realpath(path)
    total = 0.0
    owner = None
    with open("/proc/self/smaps") as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 6 and "-" in parts[0] and ":" not in parts[0]:
                owner = parts[5]
            elif line.startswith("Rss:") and owner == real:
                total += int(parts[1]) * 1024 / 1e6
    return total


def convert_tower(tag):
    import tensorflow as tf

    layers = [tf.keras.layers.Input(shape=(DIM,))]
    layers += [tf.keras.layers.Dense(DIM, activation="relu") for _ in range(DEPTH)]
    layers += [tf.keras.layers.Dense(DIM)]
    model = tf.keras.Sequential(layers)
    model(np.zeros((1, DIM), np.float32))

    conv = tf.lite.TFLiteConverter.from_keras_model(model)
    # Dynamic range: int8 weights, float activations. No representative
    # dataset needed, and weight residency is what we are measuring.
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    blob = conv.convert()
    return blob


def load_modelt(blob):
    obj = schema_fb.Model.GetRootAsModel(blob, 0)
    try:
        return schema_fb.ModelT.InitFromObj(obj, 0)
    except TypeError:
        return schema_fb.ModelT.InitFromObj(obj)


def remap_buffers(graph, offset):
    """Shift every buffer index in a subgraph by `offset`.

    TFLite tensors point at `buffers[buffer]`, so a second subgraph's indices
    must be moved past the first subgraph's buffers. Index 0 is the
    conventional empty buffer and is not shifted.
    """
    if offset == 0:
        return
    for t in graph.tensors:
        if t.buffer > 0:
            t.buffer += offset


def merge(parts, path, names):
    m0 = load_modelt(parts[0])
    merged = schema_fb.ModelT()
    merged.version = 3
    merged.description = b"omni sector probe"
    merged.operatorCodes = m0.operatorCodes
    merged.buffers = list(m0.buffers)
    merged.subgraphs = [m0.subgraphs[0]]

    for part in parts[1:]:
        m = load_modelt(part)
        # Past the first subgraph's buffers, leaving index 0 unshifted since
        # it is the conventional empty buffer.
        offset = len(merged.buffers) - 1
        remap_buffers(m.subgraphs[0], offset)
        merged.buffers = merged.buffers + list(m.buffers[1:])
        merged.subgraphs.append(m.subgraphs[0])

    # One signature per sector, each pinned to its own subgraph. This is the
    # flatbuffer equivalent of the ONNX If-branches.
    sigs = []
    for i, name in enumerate(names):
        sig = schema_fb.SignatureDefT()
        sig.signatureKey = name
        sig.subgraphIndex = i
        graph = merged.subgraphs[i]
        # subgraph.inputs/outputs hold indices into subgraph.tensors
        in_name = graph.tensors[graph.inputs[0]].name
        out_name = graph.tensors[graph.outputs[0]].name
        sig.inputs = [schema_fb.TensorMapT(in_name, 0)]
        sig.outputs = [schema_fb.TensorMapT(out_name, 0)]
        sigs.append(sig)
    merged.signatureDefs = sigs

    builder = flatbuffers.Builder(1 << 20)
    builder.Finish(merged.Pack(builder), file_identifier=b"TFL3")
    blob = bytes(builder.Output())
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(blob)
    return path


def main(path="build/probe.tflite"):
    print("converting towers ...")
    parts = []
    for name in SECTORS:
        blob = convert_tower(name)
        parts.append(blob)
        print(f"  {name}: {len(blob)/1e6:.1f} MB")

    merge(parts, path, SECTORS)
    size = os.path.getsize(path) / 1e6
    print(f"  one file, {len(parts)} subgraphs: {size:.1f} MB -> {path}")

    import tensorflow as tf
    print()
    print("  step                RSS      file-resident")
    r0 = rss_mb()
    it = tf.lite.Interpreter(model_path=path)
    it.allocate_tensors()
    r1 = rss_mb()
    print(f"  load            {r1:8.1f} {mapped_mb(path):14.1f}   (+{r1-r0:.1f} RSS)")

    x = np.random.rand(1, DIM).astype(np.float32)
    sigs = it.get_signature_list()
    print(f"  signatures: {list(sigs)}")
    order = [SECTORS[0], SECTORS[1], SECTORS[0]]
    prev = r1
    for name in order:
        feed = {sigs[name]["inputs"][0]: x}
        it.get_signature_runner(name)(**feed)
        cur = rss_mb()
        print(f"  open {name:9s} {cur:8.1f} {mapped_mb(path):14.1f}   (+{cur-prev:.1f} RSS)")
        prev = cur
    print()
    print("  A single file-resident figure for the whole run means the")
    print("  runtime copied everything at load. Rising per open means the")
    print("  mapping is being paged on demand.")
    return size


if __name__ == "__main__":
    main(*sys.argv[1:])
