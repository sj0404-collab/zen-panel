#!/usr/bin/env python3
"""Проверка бесшовности клипов в glTF (без внешних зависимостей).

Идея: у бесшовного цикла шаг «последний кадр → первый кадр» должен быть
не больше обычного шага между соседними кадрами. Если цикл «прыгает» на
стыке, этот шаг выделяется в разы.

usage: python3 tools/check_loops.py public/models/detective.glb [...]
"""
import json
import math
import struct
import sys

COMP = {5120: ('b', 1), 5121: ('B', 1), 5122: ('h', 2), 5123: ('H', 2),
        5125: ('I', 4), 5126: ('f', 4)}
NCOMP = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def load(path):
    data = open(path, 'rb').read()
    if data[:4] != b'glTF':
        raise SystemExit('%s: не GLB' % path)
    js = None
    binary = b''
    off = 12  # заголовок GLB
    while off + 8 <= len(data):
        clen, ctype = struct.unpack_from('<II', data, off)
        chunk = data[off + 8:off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk.decode('utf-8'))
        elif ctype == 0x004E4942:
            binary = chunk
        off += 8 + clen + ((4 - clen % 4) % 4)
    if js is None:
        raise SystemExit('%s: нет JSON-чанка' % path)
    return js, binary


def read_accessor(js, data, idx):
    acc = js['accessors'][idx]
    n = NCOMP[acc['type']]
    fmt, size = COMP[acc['componentType']]
    count = acc['count']
    out = []
    bv = js['bufferViews'][acc['bufferView']]
    base = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    stride = bv.get('byteStride') or size * n
    for i in range(count):
        o = base + i * stride
        out.append(struct.unpack_from('<' + fmt * n, data, o))
    return out


def quat_angle(a, b):
    d = abs(sum(x * y for x, y in zip(a, b)))
    return 2 * math.acos(min(1.0, d))


def check(path):
    js, data = load(path)
    print('== %s: %d клип(ов), %d узлов' % (path, len(js.get('animations', [])),
                                            len(js.get('nodes', []))))
    worst_total = 0.0
    for anim in js.get('animations', []):
        seam_max, step_avg, bad = 0.0, 0.0, []
        for ch in anim['channels']:
            node = js['nodes'][ch['target']['node']].get('name', '?')
            path_ = ch['target']['path']
            if path_ == 'weights':
                continue
            times = read_accessor(js, data, anim['samplers'][ch['sampler']]['input'])
            vals = read_accessor(js, data, anim['samplers'][ch['sampler']]['output'])
            m = min(len(times), len(vals))
            if m < 3:
                continue
            if path_ == 'rotation':
                d = [quat_angle(vals[i], vals[i + 1]) for i in range(m - 1)]
                seam = quat_angle(vals[-1], vals[0])
            else:
                d = [math.dist(vals[i], vals[i + 1]) for i in range(m - 1)]
                seam = math.dist(vals[-1], vals[0])
            avg = sum(d) / len(d) if d else 0.0
            step_avg = max(step_avg, avg)
            if seam > seam_max:
                seam_max = seam
            if avg > 1e-6 and seam > 3.0 * avg:
                bad.append('%s.%s seam=%.4f avg=%.4f' % (node, path_, seam, avg))
        flag = 'OK  ' if not bad else 'JUMP'
        print('   %s %-10s кадров=%-4d seam_max=%.4f  max_step=%.4f' %
              (flag, anim.get('name'), m if anim.get('channels') else 0, seam_max, step_avg))
        for b in bad[:6]:
            print('        -> ' + b)
        worst_total += len(bad)
    return worst_total


if __name__ == '__main__':
    paths = sys.argv[1:] or ['public/models/detective.glb']
    total = sum(check(p) for p in paths)
    print('ИТОГО скачков на стыках цикла: %d' % total)
    sys.exit(0)
