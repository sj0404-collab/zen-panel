package dev.pocketrun.agent

import com.sun.net.httpserver.HttpServer
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.InetSocketAddress
import java.util.ArrayDeque
import java.util.concurrent.Executors

/**
 * The chat client against a local OpenAI-compatible server: SSE streams
 * (including tool calls that arrive in pieces), plain JSON answers from servers
 * that ignore `stream`, an empty stream that must fall back to a plain request,
 * cancellation between chunks and errors that must not kill the turn silently.
 */
class LlmClientTest {

    private class Resp(val contentType: String, val body: String, val status: Int = 200)

    private fun client(port: Int) = LlmClient(AgentSettings.Config("http://127.0.0.1:$port/v1", "", "test-model"))

    private fun messages(text: String = "привет") = JSONArray()
        .put(JSONObject().put("role", "system").put("content", "system"))
        .put(JSONObject().put("role", "user").put("content", text))

    /** Serves [responses] in order; the last one repeats when the queue runs dry. */
    private fun serve(responses: List<Resp>): Pair<Int, () -> Unit> {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val queue = ArrayDeque(responses)
        server.createContext("/v1/chat/completions") { exchange ->
            exchange.requestBody.use { it.readBytes() }
            val resp = synchronized(queue) { if (queue.size > 1) queue.removeFirst() else queue.first() }
            val bytes = resp.body.toByteArray(Charsets.UTF_8)
            exchange.responseHeaders.add("Content-Type", resp.contentType)
            if (resp.status == 401) {
                exchange.sendResponseHeaders(resp.status, -1)
                exchange.close()
                return@createContext
            }
            exchange.sendResponseHeaders(resp.status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.executor = Executors.newSingleThreadExecutor { r -> Thread(r, "fake-llm").apply { isDaemon = true } }
        server.start()
        return server.address.port to { server.stop(0) }
    }

    private fun sse(vararg chunks: JSONObject): String =
        chunks.joinToString("") { "data: $it\n\n" } + "data: [DONE]\n\n"

    private fun delta(content: String) = JSONObject()
        .put("choices", JSONArray().put(JSONObject().put("index", 0).put("delta", JSONObject().put("content", content))))

    private fun toolDelta(index: Int, id: String?, name: String?, args: String?) = JSONObject().put(
        "choices",
        JSONArray().put(
            JSONObject().put(
                "index", 0,
                "delta", JSONObject().put(
                    "tool_calls",
                    JSONArray().put(
                        JSONObject().put("index", index).apply {
                            if (id != null) put("id", id)
                            put(
                                "function",
                                JSONObject().apply {
                                    if (name != null) put("name", name)
                                    if (args != null) put("arguments", args)
                                },
                            )
                        },
                    ),
                ),
            ),
        ),
    )

    @Test
    fun plainJsonAnswerIsParsed() {
        val (port, stop) = serve(
            listOf(Resp("application/json", """{"choices":[{"message":{"role":"assistant","content":"обычный ответ"}}]}""")),
        )
        try {
            val r = client(port).chat(messages(), null)
            assertEquals("обычный ответ", r.content)
            assertTrue(r.toolCalls.isEmpty())
        } finally {
            stop()
        }
    }

    @Test
    fun sseTextAndToolCallsAreAssembled() {
        val (port, stop) = serve(
            listOf(
                Resp(
                    "text/event-stream",
                    sse(
                        delta("При"),
                        delta("вет, "),
                        delta("всё сделано."),
                        toolDelta(0, "call_1", "bash", """{"command":""""),
                        toolDelta(0, null, null, """echo hi"}"""),
                    ),
                ),
            ),
        )
        try {
            val r = client(port).chat(messages(), null)
            assertEquals("Привет, всё сделано.", r.content)
            assertEquals(1, r.toolCalls.size)
            assertEquals("call_1", r.toolCalls[0].id)
            assertEquals("bash", r.toolCalls[0].name)
            assertEquals("""{"command":"echo hi"}""", r.toolCalls[0].arguments)
        } finally {
            stop()
        }
    }

    @Test
    fun parallelToolCallsKeepTheirOrder() {
        val (port, stop) = serve(
            listOf(
                Resp(
                    "text/event-stream",
                    sse(
                        toolDelta(0, "a", "read", """{"filePath":"a.txt"}"""),
                        toolDelta(1, "b", "read", """{"filePath":"b.txt"}"""),
                    ),
                ),
            ),
        )
        try {
            val r = client(port).chat(messages(), null)
            assertEquals(listOf("a", "b"), r.toolCalls.map { it.id })
            assertEquals(listOf("read", "read"), r.toolCalls.map { it.name })
        } finally {
            stop()
        }
    }

    @Test
    fun emptyStreamFallsBackToAPlainRequest() {
        val (port, stop) = serve(
            listOf(
                Resp("text/event-stream", "data: [DONE]\n\n"),
                Resp("application/json", """{"choices":[{"message":{"content":"со второго раза"}}]}"""),
            ),
        )
        try {
            assertEquals("со второго раза", client(port).chat(messages(), null).content)
        } finally {
            stop()
        }
    }

    @Test
    fun errorInsideTheStreamIsReported() {
        val err = JSONObject().put("error", JSONObject().put("message", "model is overloaded"))
        val (port, stop) = serve(listOf(Resp("text/event-stream", sse(err))))
        try {
            client(port).chat(messages(), null)
            fail("ожидалась ошибка модели")
        } catch (e: LlmClient.LlmException) {
            assertTrue(e.message.orEmpty(), e.message.orEmpty().contains("model is overloaded"))
        } finally {
            stop()
        }
    }

    @Test
    fun reasoningOnlyAnswerBecomesContent() {
        val chunk = JSONObject().put(
            "choices",
            JSONArray().put(
                JSONObject().put("index", 0).put("delta", JSONObject().put("reasoning_content", "думаю…")),
            ),
        )
        val (port, stop) = serve(listOf(Resp("text/event-stream", sse(chunk))))
        try {
            assertEquals("думаю…", client(port).chat(messages(), null).content)
        } finally {
            stop()
        }
    }

    @Test
    fun cancellationBeforeTheRequestDoesNothing() {
        val (port, stop) = serve(listOf(Resp("text/event-stream", sse(delta("неважно")))))
        try {
            val e = runCatching { client(port).chat(messages(), null, isCancelled = { true }) }.exceptionOrNull()
            assertTrue("ожидалась отмена, а получили $e", e is LlmClient.LlmException)
            assertEquals(LlmClient.CANCELLED, e?.message)
        } finally {
            stop()
        }
    }

    @Test
    fun cancellationBetweenChunksStopsTheStream() {
        // The server keeps the stream open long after the client gave up.
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/v1/chat/completions") { exchange ->
            exchange.requestBody.use { it.readBytes() }
            exchange.responseHeaders.add("Content-Type", "text/event-stream")
            exchange.sendResponseHeaders(200, 0) // chunked
            exchange.responseBody.use { out ->
                out.write("data: ${delta("начало")}\n\n".toByteArray())
                out.flush()
                Thread.sleep(1_000)
                runCatching { out.write("data: [DONE]\n\n".toByteArray()) }
            }
        }
        server.executor = Executors.newSingleThreadExecutor { r -> Thread(r, "fake-llm-slow").apply { isDaemon = true } }
        server.start()
        try {
            var seen = 0
            val e = runCatching {
                client(server.address.port).chat(messages(), null, isCancelled = { seen > 0 }) { seen++ }
            }.exceptionOrNull()
            assertTrue("ожидалась отмена, а получили $e", e is LlmClient.LlmException)
            assertEquals(LlmClient.CANCELLED, e?.message)
            assertEquals(1, seen)
        } finally {
            server.stop(0)
        }
    }

    @Test
    fun rejectedKeyIsNotRetriedAndNamesTheStatus() {
        val (port, stop) = serve(listOf(Resp("application/json", """{"error":{"message":"bad key"}}""", status = 401)))
        try {
            val e = runCatching { client(port).chat(messages(), null) }.exceptionOrNull()
            assertTrue("$e", e is LlmClient.LlmException)
            assertTrue(e!!.message.orEmpty(), e.message.orEmpty().contains("401"))
        } finally {
            stop()
        }
    }
}
