import { chromium } from 'playwright-core'
const browser = await chromium.launch({ executablePath:'/usr/bin/chromium',
  args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']})
const page = await browser.newPage({ viewport:{width:320,height:400}, deviceScaleFactor:1 })
const out={}
for (const url of process.argv.slice(2)) {
  await page.goto(url, { waitUntil:'load', timeout:60000 })
  await page.waitForFunction('window.__ready===true',null,{timeout:120000})
  out[url.split('?')[1]] = await page.evaluate(() => {
    const r = window.__r3f_scene
    const sms=[]; r.traverse(o=>{ if(o.isSkinnedMesh) sms.push(o) })
    const sm=sms[0]
    const sk=sm.skeleton
    // which bone objects does the SKELETON reference vs what is in the graph?
    const skBones=sk.bones
    // find skinnedmesh that actually drives skinning for a body part
    const bone = skBones.find(b=>b.name==='shin.L') || skBones[10]
    const boneInGraph = (()=>{let f=r; while(f){const hit=f.getObjectByName?.(bone.name); if(hit) return hit; f=f.parent} return null})()
    return {
      nSkin:sms.length,
      skelSharedByAllSkins: sms.every(m=>m.skeleton===sk),
      boneName: bone.name,
      boneQuatInSkeleton:[bone.quaternion.x,bone.quaternion.y,bone.quaternion.z,bone.quaternion.w].map(v=>+v.toFixed(4)),
      boneMW_y: +bone.matrixWorld.elements[13].toFixed(4),
      boneInGraph: !!boneInGraph,
      boneInGraphQuat: boneInGraph?[boneInGraph.quaternion.x,boneInGraph.quaternion.y,boneInGraph.quaternion.z,boneInGraph.quaternion.w].map(v=>+v.toFixed(4)):null,
      boneInGraphIsSkelBone: boneInGraph===bone,
    }
  })
}
console.log(JSON.stringify(out,null,1))
await browser.close()
