#!/usr/bin/env python3
"""Hybrid VLM OCR — streaming, offline, low-RAM.

A single engine that fuses the project's *tiny* OCR pieces into one hybrid:

  vision   : a text detector + recognizer — Tesseract TSV (`rus`) and, when
             available, RapidOCR (PP-OCRv5 `eslav`, ONNX). No weights are
             downloaded at run time; everything is read from local caches.
  language : a compact Russian word/character model that only *ranks* the
             candidate readings an engine already produced. It never rewrites
             or invents text — output stays verbatim (same rule as the rest of
             this repo).
  fusion   : several preprocessing/PSM configs per page; lines from all
             configs/engines are clustered by spatial overlap (IoU) and the
             best-scoring verbatim line wins.

It runs one page at a time (low RAM), never touches the network, and streams
results as they are read, so it can consume a live pipe of frames:

  # a fixed list of pages, streamed as each page is finished
  printf '%s\n' pages/*.jpg | python hybrid_vlm_ocr.py --stdin

  # live JPEG frames straight out of a video / camera, offline
  ffmpeg -i clip.mp4 -f image2pipe -vcodec mjpeg - | \
      python hybrid_vlm_ocr.py --stdin-frames --emit line --ndjson

  # watch a folder and read new scans as they land
  python hybrid_vlm_ocr.py --watch pages/

Model footprint (the 5–20 MB budget): Tesseract's `rus` fast model is ~4 MB;
`osd` (~10 MB) is only loaded for the optional `--osd` PSM 12 config, so the
default profile stays well under the ceiling. `--max-model-mb` enforces it.

Usage:
  python hybrid_vlm_ocr.py [options] [image|dir ...]
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

IMG_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff")

# ---------------------------------------------------------------------------
# Compact Russian language model (ranking only, no corrections).
# A small set of the most frequent Russian words plus character classes. Kept
# deliberately tiny (<10 KB) so the whole engine honours the 5–20 MB budget.
# ---------------------------------------------------------------------------
COMMON_WORDS = frozenset(
    """
    и в не на я что он с а как это по но к у из за то все она так
    же вы бы от о мне меня ты мы вас нас них ему ей их когда где тут
    там уже ещё еще лишь ведь вот да нет ну ах ох эх ой ага да
    что-то как-то кто-то где-то когда-то почему-то
    мой моя моё мое мои твой твоя твои наш наша наши ваш ваша ваши
    его её ее их свой своя свои
    этот эта эти тот та те такой такая такие сам сама сами
    быть есть был была было были буду будешь будет будем будете будут
    могу можешь может можем можете могут мог могла могли
    хочу хочешь хочет хотим хотите хотят
    знаю знаешь знает знаем знаете знают
    вижу видишь видит видим видите видят
    говорю говоришь говорит говорим говорите говорят сказать сказал
    идти иду идёшь идет идем идете идут пришёл пришел
    делать делаю делаешь делает делаем делаете делают сделать сделал
    думать думаю думаешь думает думаем думаете думают
    дать даю даешь дает даем даете дают дал
    взять беру берешь берет берем берете берут взял
    надо нужно можно нельзя должен должна должны
    очень too просто just теперь сейчас потом опять снова
    здесь здесь там куда откуда почему зачем
    если чтобы хотя или али либо
    был ли бы
    один одна одно раз два три
    человек люди девушка парень мужчина женщина
    мама папа мать отец сын дочь брат сестра друг подруга
    господин госпожа сэр мисс
    бог господь
    """.split()
)

CYR_LOWER = set("абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
CYR_UPPER = set("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ")
LATIN = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
PUNCT = set(".,:;!?…—–-«»\"'()[]{}/*+=\\<>|_~`@#$%^&")


def lm_score(text: str) -> float:
    """Plausibility of a line in [0, 1]. Ranks readings; never edits them."""
    tokens = [t for t in text.replace("\n", " ").split() if t]
    if not tokens:
        return 0.0
    total = 0.0
    for tok in tokens:
        core = tok.strip(".,:;!?…—–-«»\"'()[]{}")
        if not core:
            total += 0.4
            continue
        low = core.lower()
        if low in COMMON_WORDS:
            total += 1.0
            continue
        has_cyr = any(c in CYR_LOWER or c in CYR_UPPER for c in core)
        has_lat = any(c in LATIN for c in core)
        has_dig = any(c.isdigit() for c in core)
        if has_cyr and has_lat:
            total += 0.15          # script mixing is a common OCR glitch
        elif has_cyr and len(core) >= 2:
            total += 0.7
        elif has_cyr:
            total += 0.25
        elif has_dig and not has_lat:
            total += 0.5
        else:
            total += 0.2
    return total / len(tokens)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------
@dataclass
class Line:
    left: int
    top: int
    width: int
    height: int
    text: str
    conf: float

    @property
    def box(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.left + self.width, self.top + self.height)

    def score(self, lm_weight: float) -> float:
        conf = max(0.0, self.conf) / 100.0
        return (1.0 - lm_weight) * conf + lm_weight * lm_score(self.text)


@dataclass
class PageResult:
    engine: str
    lines: list[Line]
    seconds: float
    raw_text: str = ""
    meta: dict = field(default_factory=dict)


def iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    iw, ih = max(0, ix1 - ix0), max(0, iy1 - iy0)
    inter = iw * ih
    if not inter:
        return 0.0
    ua = (ax1 - ax0) * (ay1 - ay0) + (bx1 - bx0) * (by1 - by0) - inter
    return inter / ua if ua else 0.0


# ---------------------------------------------------------------------------
# Preprocessing (optional ImageMagick, no Python imaging deps required)
# ---------------------------------------------------------------------------
class Pre:
    def __init__(self, convert: str | None):
        self.convert = convert

    def upscale(self, src: str, factor: float, spool: Path) -> str:
        if factor <= 1.0 or not self.convert:
            return src
        dst = spool / f"up{int(factor * 100)}.png"
        cmd = [
            self.convert, src, "-colorspace", "Gray",
            "-resize", f"{int(factor * 100)}%", str(dst),
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=120)
            return str(dst)
        except Exception:  # noqa: BLE001
            return src


# ---------------------------------------------------------------------------
# Tesseract engine
# ---------------------------------------------------------------------------
def find_tesseract(explicit: str | None) -> str:
    if explicit and Path(explicit).exists():
        return explicit
    if env := os.environ.get("TESSERACT_CMD"):
        return env
    if found := shutil.which("tesseract"):
        return found
    for c in (
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    ):
        if Path(c).exists():
            return c
    raise FileNotFoundError("tesseract binary not found")


def find_tessdata(explicit: str | None) -> str | None:
    if explicit and Path(explicit).is_dir():
        return explicit
    if env := os.environ.get("TESSDATA_PREFIX"):
        return env
    for c in (
        "/usr/share/tesseract-ocr/5/tessdata",
        "/usr/share/tesseract-ocr/4.00/tessdata",
        "/usr/share/tessdata",
        "/usr/local/share/tessdata",
    ):
        if Path(c).is_dir():
            return c
    return None


def _join_words(words: list[tuple[str, float]]) -> str:
    parts: list[str] = []
    for text, _ in words:
        if not parts:
            parts.append(text)
            continue
        prev = parts[-1]
        if text and text[0] in ",.:;!?…»)]}":
            parts[-1] = prev + text
        elif prev and prev[-1] in "«([{":
            parts[-1] = prev + text
        elif prev.endswith("-"):
            parts[-1] = prev + text
        else:
            parts.append(" " + text)
    return "".join(parts).strip()


class TesseractEngine:
    name = "tesseract"

    def __init__(self, binary: str, tessdata: str | None, lang: str):
        self.binary = binary
        self.tessdata = tessdata
        self.lang = lang
        self._cache: dict[str, list[Line]] = {}

    def model_files(self) -> list[Path]:
        out: list[Path] = []
        if self.tessdata:
            for code in (self.lang, "osd"):
                p = Path(self.tessdata) / f"{code}.traineddata"
                if p.exists():
                    out.append(p)
        return out

    def ocr(self, image: str, psm: int, spool: Path) -> PageResult:
        t0 = time.time()
        cmd = [self.binary, image, "stdout", "-l", self.lang, "--psm", str(psm), "tsv"]
        if self.tessdata:
            cmd += ["--tessdata-dir", self.tessdata]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if proc.returncode != 0:
            raise RuntimeError(f"tesseract failed: {proc.stderr.strip()[:200]}")
        lines, raw = self._parse_tsv(proc.stdout)
        return PageResult(self.name, lines, time.time() - t0, raw_text=raw)

    @staticmethod
    def _parse_tsv(tsv: str) -> tuple[list[Line], str]:
        groups: dict[tuple, list[tuple[str, float, int, int, int, int]]] = {}
        order: list[tuple] = []
        for row in tsv.splitlines()[1:]:
            f = row.split("\t")
            if len(f) < 12:
                continue
            try:
                level = int(f[0])
            except ValueError:
                continue
            if level != 5:
                continue
            text = f[11]
            if not text.strip():
                continue
            key = (f[1], f[2], f[3], f[4])
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(
                (text, float(f[10]), int(f[6]), int(f[7]), int(f[8]), int(f[9]))
            )
        lines: list[Line] = []
        for key in order:
            words = groups[key]
            xs0 = min(w[2] for w in words)
            ys0 = min(w[3] for w in words)
            xs1 = max(w[2] + w[4] for w in words)
            ys1 = max(w[3] + w[5] for w in words)
            confs = [w[1] for w in words if w[1] >= 0]
            conf = sum(confs) / len(confs) if confs else 0.0
            text = _join_words([(w[0], w[1]) for w in words])
            if text:
                lines.append(Line(xs0, ys0, xs1 - xs0, ys1 - ys0, text, conf))
        raw = "\n".join(ln.text for ln in lines)
        return lines, raw


# ---------------------------------------------------------------------------
# RapidOCR engine (optional; only used if the package is already installed)
# ---------------------------------------------------------------------------
class RapidEngine:
    name = "rapidocr"

    def __init__(self, lang: str):
        from rapidocr import LangRec, ModelType, OCRVersion, RapidOCR

        self._ocr = RapidOCR(
            params={
                "Rec.lang_type": LangRec(lang),
                "Rec.ocr_version": OCRVersion.PPOCRV5,
                "Rec.model_type": ModelType.MOBILE,
                "Det.ocr_version": OCRVersion.PPOCRV5,
                "Det.model_type": ModelType.MOBILE,
                "Global.log_level": "error",
            }
        )

    def model_files(self) -> list[Path]:
        out: list[Path] = []
        for root in (
            Path.home() / ".cache" / "rapidocr",
            Path.home() / ".rapidocr",
        ):
            if root.is_dir():
                out.extend(root.rglob("*.onnx"))
        return out

    def ocr(self, image: str, psm: int, spool: Path) -> PageResult:
        t0 = time.time()
        res = self._ocr(image)
        lines: list[Line] = []
        boxes = getattr(res, "boxes", None)
        txts = getattr(res, "txts", None) or ()
        scores = getattr(res, "scores", None) or ()
        for i, text in enumerate(txts):
            if not text or not text.strip():
                continue
            box = boxes[i] if boxes is not None and i < len(boxes) else None
            conf = float(scores[i]) * 100 if i < len(scores) else 0.0
            if box is not None:
                arr = list(box)
                xs = [float(p[0]) for p in arr]
                ys = [float(p[1]) for p in arr]
                x0, y0 = int(min(xs)), int(min(ys))
                w, h = int(max(xs) - x0), int(max(ys) - y0)
            else:
                x0 = y0 = 0
                w = h = 1
            lines.append(Line(x0, y0, w, h, text, conf))
        return PageResult(self.name, lines, time.time() - t0,
                          raw_text="\n".join(l.text for l in lines))


# ---------------------------------------------------------------------------
# Fusion
# ---------------------------------------------------------------------------
def fuse(results: list[PageResult], lm_weight: float, iou_thresh: float = 0.3) -> list[Line]:
    """Cluster lines by overlap across configs/engines; keep the best verbatim."""
    clusters: list[dict] = []
    for res in results:
        for ln in res.lines:
            placed = False
            for cl in clusters:
                if iou(ln.box, cl["box"]) >= iou_thresh:
                    cl["cands"].append(ln)
                    if ln.score(lm_weight) > cl["cands"][0].score(lm_weight):
                        cl["cands"][0] = ln
                        cl["box"] = ln.box
                    placed = True
                    break
            if not placed:
                clusters.append({"box": ln.box, "cands": [ln]})
    best = [cl["cands"][0] for cl in clusters]
    best.sort(key=lambda l: (l.top, l.left))
    return best


# ---------------------------------------------------------------------------
# Engine assembly + model budget
# ---------------------------------------------------------------------------
PROFILES = {
    # (resize_factor, psm)
    "fast": [(1.0, 3)],
    "balanced": [(1.0, 3), (2.0, 3), (2.0, 6)],
    "quality": [(1.0, 3), (2.0, 3), (3.0, 3), (2.0, 6), (2.0, 11)],
}


def build_engines(args) -> tuple[list, list[tuple[float, int]], Pre]:
    configs = list(PROFILES[args.profile])
    if args.osd:
        configs.append((2.0, 12))

    tess_bin = find_tesseract(args.tess_cmd)
    tessdata = find_tessdata(args.tessdata)
    engines: list = [TesseractEngine(tess_bin, tessdata, args.lang)]

    if args.rapidocr and args.profile != "fast":
        try:
            engines.append(RapidEngine(args.rec_lang))
        except Exception as exc:  # noqa: BLE001
            print(f"[w] rapidocr unavailable ({type(exc).__name__}: {exc})", file=sys.stderr)

    # Model budget check
    total = sum(f.stat().st_size for e in engines for f in e.model_files())
    mb = total / (1024 * 1024)
    if args.max_model_mb and mb > args.max_model_mb:
        sys.exit(
            f"[x] model footprint {mb:.1f} MB exceeds --max-model-mb "
            f"{args.max_model_mb} (use --profile fast / drop --rapidocr)"
        )
    print(f"[i] engines: {', '.join(e.name for e in engines)} | "
          f"models: {mb:.1f} MB | configs: {len(configs)}", file=sys.stderr)

    pre = Pre(shutil.which("convert") or shutil.which("magick"))
    return engines, configs, pre


# ---------------------------------------------------------------------------
# One-page OCR with fusion
# ---------------------------------------------------------------------------
def recognize_page(path: str, engines, configs, pre: Pre, spool: Path,
                   lm_weight: float) -> tuple[list[Line], float]:
    t0 = time.time()
    results: list[PageResult] = []
    for factor, psm in configs:
        src = pre.upscale(path, factor, spool)
        for eng in engines:
            try:
                results.append(eng.ocr(src, psm, spool))
            except Exception as exc:  # noqa: BLE001
                print(f"[w] {eng.name} {os.path.basename(path)} psm{psm}: "
                      f"{type(exc).__name__}: {exc}", file=sys.stderr)
    if len(results) == 1:
        return results[0].lines, time.time() - t0
    return fuse(results, lm_weight), time.time() - t0


# ---------------------------------------------------------------------------
# Source iteration (files / dirs / stdin list / stdin frames / watch)
# ---------------------------------------------------------------------------
def iter_sources(args):
    for item in args.inputs:
        p = Path(item)
        if p.is_dir():
            yield from _iter_dir(p, args.recursive)
        elif p.exists():
            yield str(p)
        else:
            for g in sorted(glob.glob(item)):
                yield g


def _iter_dir(p: Path, recursive: bool) -> list[str]:
    pattern = "**/*" if recursive else "*"
    return sorted(
        str(f) for f in p.glob(pattern)
        if f.is_file() and f.suffix.lower() in IMG_EXT
    )


def iter_stdin_list():
    for raw in sys.stdin:
        line = raw.strip()
        if line and not line.startswith("#"):
            yield line


def iter_stdin_frames(spool: Path):
    """Read length-prefixed raw image frames: <u32 little-endian length><bytes>."""
    stream = sys.stdin.buffer
    idx = 0
    while True:
        hdr = stream.read(4)
        if len(hdr) < 4:
            return
        (size,) = struct.unpack("<I", hdr)
        data = stream.read(size)
        if len(data) < size:
            return
        idx += 1
        frame = spool / f"frame{idx:06d}.img"
        frame.write_bytes(data)
        yield str(frame)


def iter_watch(directory: str, interval: float, recursive: bool):
    seen: set[str] = set()
    yield from _drain_watch(directory, recursive, seen)
    while True:
        time.sleep(interval)
        yield from _drain_watch(directory, recursive, seen)


def _drain_watch(directory: str, recursive: bool, seen: set[str]):
    for f in _iter_dir(Path(directory), recursive):
        if f not in seen:
            seen.add(f)
            yield f


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
def emit_page(src: str, lines: list[Line], dt: float, args, out) -> None:
    text = "\n".join(ln.text for ln in lines)
    if args.format == "ndjson":
        rec = {
            "source": os.path.basename(src),
            "seconds": round(dt, 2),
            "text": text,
            "lines": [
                {"text": ln.text, "conf": round(ln.conf, 1), "box": list(ln.box)}
                for ln in lines
            ],
        }
        out.write(json.dumps(rec, ensure_ascii=False) + "\n")
    else:
        out.write(f"===== {os.path.basename(src)} ({dt:.1f}s) =====\n{text}\n\n")
    out.flush()


def emit_line(src: str, ln: Line, out) -> None:
    if args.format == "ndjson":
        rec = {
            "source": os.path.basename(src),
            "text": ln.text,
            "conf": round(ln.conf, 1),
            "box": list(ln.box),
        }
        out.write(json.dumps(rec, ensure_ascii=False) + "\n")
    else:
        out.write(f"[{os.path.basename(src)}] {ln.text}\n")
    out.flush()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description="Hybrid VLM OCR: streaming, offline, low-RAM")
    ap.add_argument("inputs", nargs="*", help="image files, dirs or globs")
    ap.add_argument("--stdin", action="store_true", help="read image paths from stdin")
    ap.add_argument("--stdin-frames", action="store_true",
                    help="read length-prefixed raw frames from stdin")
    ap.add_argument("--watch", metavar="DIR", help="watch a directory for new scans")
    ap.add_argument("--watch-interval", type=float, default=1.0)
    ap.add_argument("-r", "--recursive", action="store_true")
    ap.add_argument("--profile", choices=sorted(PROFILES), default="fast")
    ap.add_argument("--emit", choices=("page", "line"), default="page")
    ap.add_argument("--format", choices=("text", "ndjson"), default="text")
    ap.add_argument("-o", "--out", help="output file (default: stdout)")
    ap.add_argument("--lang", default="rus")
    ap.add_argument("--rec-lang", default="eslav", help="RapidOCR recognizer language")
    ap.add_argument("--rapidocr", action="store_true",
                    help="add RapidOCR vision engine (if installed)")
    ap.add_argument("--osd", action="store_true", help="add PSM 12 (loads osd model)")
    ap.add_argument("--tess-cmd", default=None)
    ap.add_argument("--tessdata", default=None)
    ap.add_argument("--lm-weight", type=float, default=0.35,
                    help="weight of the language model in line ranking")
    ap.add_argument("--max-model-mb", type=float, default=20.0,
                    help="abort if local model weights exceed this (default 20)")
    ap.add_argument("--spool", default=None,
                    help="dir for temp frames/preprocessed pages")
    args = ap.parse_args()

    spool = Path(args.spool) if args.spool else Path(tempfile.gettempdir()) / "hybrid_vlm_ocr"
    spool.mkdir(parents=True, exist_ok=True)

    engines, configs, pre = build_engines(args)

    if args.stdin_frames:
        srcs = iter_stdin_frames(spool)
    elif args.stdin:
        srcs = iter_stdin_list()
    elif args.watch:
        srcs = iter_watch(args.watch, args.watch_interval, args.recursive)
    else:
        srcs = iter_sources(args)
        # materialise plain file inputs so the budget/logic runs before OCR
        srcs = list(srcs)

    out = open(args.out, "w", encoding="utf-8") if args.out else sys.stdout
    n = 0
    try:
        for src in srcs:
            if not src or not os.path.exists(src):
                print(f"[w] skip missing: {src}", file=sys.stderr)
                continue
            lines, dt = recognize_page(src, engines, configs, pre, spool, args.lm_weight)
            n += 1
            if args.emit == "line":
                for ln in lines:
                    emit_line(src, ln, out)
            else:
                emit_page(src, lines, dt, args, out)
                print(f"[{n}] {os.path.basename(src)} {dt:.1f}s "
                      f"{len(lines)} lines", file=sys.stderr)
    except KeyboardInterrupt:
        print("\n[i] interrupted", file=sys.stderr)
    finally:
        if out is not sys.stdout:
            out.close()
    print(f"[i] done, {n} page(s)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
