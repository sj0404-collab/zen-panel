#!/usr/bin/env python3
"""OCR with Occular-OCR (DBNet + SVTR + Russian n-gram beam LM).

Russian-first document OCR, ONNX Runtime on CPU. Raw verbatim output.

Speed: pages are OCR'd in parallel with a process pool (the ONNX detector/recognizer
release the GIL, so processes scale better than intra-op threads). The DBNet detector
input is a fixed 1280x1280 canvas; shrinking it (OCCULAR_DET_VAL, default 1152) is the
main speed lever -- it cuts detector time ~2x with almost no loss on manga lettering,
and even removes some low-res speckle "garbage" regions.

Env knobs:
  OCCULAR_DET_VAL  detector long side in px (default 1152; 1280 = package canonical)
  OCCULAR_WORKERS  parallel page workers   (default min(4, cpu_count))
  OCCULAR_THREADS  intra-op threads (default 1 when parallel, else cpu_count)
  OCCULAR_LM       0 to disable the beam+LM decode (faster, lower quality)
  OCCULAR_DEVICE   "cuda" to run on GPU (forces OCCULAR_WORKERS=1)

Usage:
  python occular_ocr.py <pages_dir> <out.txt> [n_pages]
"""
import glob
import multiprocessing as mp
import os
import sys
import time

PAGES = sys.argv[1] if len(sys.argv) > 1 else "pages"
OUT = sys.argv[2] if len(sys.argv) > 2 else "occular.txt"
N = int(sys.argv[3]) if len(sys.argv) > 3 else 63

DEVICE = os.environ.get("OCCULAR_DEVICE", "cpu").lower()
GPU = DEVICE == "cuda"
DET_VAL = int(os.environ.get("OCCULAR_DET_VAL", "1152"))
USE_LM = os.environ.get("OCCULAR_LM", "1") != "0"
CPUS = os.cpu_count() or 1
WORKERS = int(os.environ.get("OCCULAR_WORKERS", str(min(4, CPUS))))
if GPU:
    WORKERS = 1
THREADS = int(os.environ.get("OCCULAR_THREADS", "1" if WORKERS > 1 else str(CPUS)))

_pipe = None


def _init_worker():
    global _pipe
    import occular.dbnet_detector_onnx as _dbnet
    _dbnet.VAL = DET_VAL
    from occular import OCRPipeline, Settings
    _pipe = OCRPipeline(Settings(gpu=GPU, lm=USE_LM, num_threads=THREADS))


def _run_page(path):
    t0 = time.time()
    try:
        lines = [ln.get("text", "") for ln in _pipe.process_image(path) if ln.get("text")]
        txt = "\n".join(lines)
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    return path, time.time() - t0, txt


def main():
    pages = sorted(
        p for p in glob.glob(os.path.join(PAGES, "*"))
        if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
    )[:N]
    print(f"[i] {len(pages)} pages, workers={WORKERS}, threads={THREADS}, "
          f"det_val={DET_VAL}, lm={USE_LM}", flush=True)

    if WORKERS <= 1:
        _init_worker()
    t_start = time.time()
    pool = ctx = None
    if WORKERS > 1:
        ctx = mp.get_context("spawn")
        pool = ctx.Pool(WORKERS, initializer=_init_worker)

    try:
        with open(OUT, "w", encoding="utf-8") as out:
            it = pool.imap(_run_page, pages) if pool else (_run_page(p) for p in pages)
            for i, (path, dt, txt) in enumerate(it, 1):
                out.write(f"===== {os.path.basename(path)} ({dt:.1f}s) =====\n{txt}\n\n")
                out.flush()
                print(f"[{i}/{len(pages)}] {os.path.basename(path)} {dt:.1f}s", flush=True)
    finally:
        if pool:
            pool.close()
            pool.join()
    wall = time.time() - t_start
    print(f"[i] done in {wall:.1f}s ({wall / max(1, len(pages)):.2f}s/page "
          f"effective, workers={WORKERS})", flush=True)


if __name__ == "__main__":
    main()
