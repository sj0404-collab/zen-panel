package com.winwasm64.vpn

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Журнал VPN: что включилось, какие приложения куда подключались, через какой профиль, ошибки прокси.
 * Кольцевой буфер в памяти + сохранение в «Загрузки/OmniBrowser-logs».
 */
object VpnLog {
    private const val MAX = 2000
    private val lines = ArrayDeque<String>()
    private val labels = ConcurrentHashMap<String, String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private var appContext: Context? = null

    @Volatile
    var version: Int = 0
        private set

    fun init(ctx: Context) {
        if (appContext == null) appContext = ctx.applicationContext
    }

    fun i(tag: String, msg: String) = add("ℹ", tag, msg)
    fun ok(tag: String, msg: String) = add("✅", tag, msg)
    fun w(tag: String, msg: String) = add("⚠", tag, msg)
    fun e(tag: String, msg: String) = add("❌", tag, msg)

    /** Соединение приложения через VPN: куда, через какой профиль, сколько заняло, ошибка. */
    private class Rep(var firstAt: Long, var count: Int)
    private val repeats = java.util.concurrent.ConcurrentHashMap<String, Rep>()
    private val okRepeats = java.util.concurrent.ConcurrentHashMap<String, Rep>()

    fun conn(pkg: String?, host: String, port: Int, profile: String, ms: Long, err: String?, rxBytes: Long = -1L) {
        val who = label(pkg)
        var dur = if (ms >= 1000) String.format(java.util.Locale.US, "%.1f с", ms / 1000.0) else "$ms мс"
        // v4.4.4: объём и средняя скорость приёма по соединению — видно, какие соединения «ползут»
        if (rxBytes > 0) {
            val vol = if (rxBytes >= 1048576) String.format(java.util.Locale.US, "%.1f МБ", rxBytes / 1048576.0) else String.format(java.util.Locale.US, "%.0f КБ", rxBytes / 1024.0)
            dur += " · ↓$vol" + (if (ms >= 2000) String.format(java.util.Locale.US, " (%.0f КБ/с)", rxBytes / 1024.0 / (ms / 1000.0)) else "")
        }
        if (err == null) {
            // v4.4.1: одинаковые успешные соединения (YouTube открывает десятки к googlevideo) — не чаще раза в 5 с
            val okKey = "ok|$who|$host:$port"
            val nowOk = System.currentTimeMillis()
            val prev = okRepeats[okKey]
            if (prev != null && nowOk - prev.firstAt < 5_000L) { prev.count++; return }
            val extra = if (prev != null && prev.count > 0) " (+${prev.count} похожих за ${(nowOk - prev.firstAt) / 1000} с)" else ""
            okRepeats[okKey] = Rep(nowOk, 0)
            add("📱", "Прил", "$who → $host:$port · профиль $profile · длилось $dur$extra"); return
        }
        // v4.2.17: одинаковые ошибки одного приложения к одному адресату — не чаще раза в 15 с, остальные считаем
        val key = "$who|$host:$port|${err.substringBefore(" (")}"
        val now = System.currentTimeMillis()
        val rep = repeats[key]
        if (rep != null && now - rep.firstAt < 15_000L) {
            rep.count++
            return
        }
        val suffix = if (rep != null && rep.count > 1) " (повторялось ×${rep.count} за ${(now - rep.firstAt) / 1000} с)" else ""
        repeats[key] = Rep(now, 1)
        if (repeats.size > 400) repeats.entries.removeIf { now - it.value.firstAt > 60_000L }
        add("❌", "Прил", "$who → $host:$port · профиль $profile · ошибка: $err$suffix")
    }

    fun label(pkg: String?): String {
        if (pkg.isNullOrBlank()) return "приложение"
        labels[pkg]?.let { return it }
        val name = try {
            val pm = appContext!!.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg
        }
        labels[pkg] = name
        return name
    }

    fun appList(pkgs: Collection<String>): String {
        if (pkgs.isEmpty()) return "список пуст"
        val shown = pkgs.take(6).joinToString(", ") { label(it) }
        return if (pkgs.size > 6) "$shown и ещё ${pkgs.size - 6}" else shown
    }

    @Synchronized
    private fun add(level: String, tag: String, msg: String) {
        lines.addLast("${fmt.format(Date())} $level [$tag] $msg")
        while (lines.size > MAX) lines.removeFirst()
        version++
    }

    /** filter: null — всё, "err" — ошибки и предупреждения, иначе тег ("Прил", "Браузер", "Туннель", "Сервис"). */
    @Synchronized
    fun snapshot(filter: String?): List<String> = when (filter) {
        null -> lines.toList()
        "err" -> lines.filter { it.contains("❌") || it.contains("⚠") }
        else -> lines.filter { it.contains("[$filter]") }
    }

    @Synchronized
    fun clear() {
        lines.clear()
        version++
    }

    fun text(filter: String?): String = snapshot(filter).joinToString("\n")

    /** Сохраняет журнал в «Загрузки/OmniBrowser-logs». Возвращает путь для показа или null. */
    fun saveToDownloads(ctx: Context): String? {
        val name = "omnibrowser_vpn_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val data = ("OmniBrowser VPN — журнал\n" + text(null) + "\n").toByteArray(Charsets.UTF_8)
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/OmniBrowser-logs")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) } ?: return null
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "OmniBrowser-logs")
                dir.mkdirs()
                File(dir, name).writeBytes(data)
            }
            "Загрузки/OmniBrowser-logs/$name"
        } catch (_: Exception) {
            null
        }
    }
}
