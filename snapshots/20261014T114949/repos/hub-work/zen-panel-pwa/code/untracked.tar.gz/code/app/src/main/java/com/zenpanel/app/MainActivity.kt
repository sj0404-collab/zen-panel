package com.zenpanel.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zenpanel.app.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var store: PanelStore

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                postNotification(getString(R.string.notify_enabled_body))
            } else {
                toast(getString(R.string.notify_permission_denied))
            }
        }

    private val connectivityManager by lazy {
        getSystemService(ConnectivityManager::class.java)
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = runOnUiThread { updateStatus(true) }
        override fun onLost(network: Network) = runOnUiThread { updateStatus(isOnline()) }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) =
            runOnUiThread { updateStatus(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = PanelStore(this)
        Notifications.ensureChannel(this)

        binding.buttonSearch.setOnClickListener { runSearch() }
        binding.buttonTestNotification.setOnClickListener { requestNotification() }
        binding.buttonLaunchExtension.setOnClickListener { launchExtension() }
        binding.buttonBrowsec.setOnClickListener { toggleBrowsec() }
        binding.buttonClearLog.setOnClickListener {
            store.clearTraffic()
            renderTraffic()
        }

        updateStatus(isOnline())
        renderBrowsec()
        renderTraffic()
    }

    override fun onStart() {
        super.onStart()
        connectivityManager?.registerDefaultNetworkCallback(networkCallback)
    }

    override fun onStop() {
        super.onStop()
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (_: IllegalArgumentException) {
            // Callback was not registered.
        }
    }

    private fun isOnline(): Boolean {
        val cm = connectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateStatus(online: Boolean) {
        binding.textStatus.text =
            getString(if (online) R.string.status_online else R.string.status_offline)
        binding.textStatus.setTextColor(
            ContextCompat.getColor(this, if (online) R.color.status_online else R.color.status_offline)
        )
    }

    private fun runSearch() {
        val query = binding.inputSearch.text?.toString()?.trim().orEmpty()
        if (query.isEmpty()) return
        val url = "https://www.google.com/search?q=" + Uri.encode(query)
        store.logTraffic("${timeFormat.format(Date())}  ←  $query")
        renderTraffic()
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        binding.inputSearch.setText("")
    }

    private fun requestNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            postNotification(getString(R.string.notify_enabled_body))
        }
    }

    private fun postNotification(body: String) {
        Notifications.show(this, getString(R.string.app_name), body)
    }

    private fun launchExtension() {
        startActivity(Intent(this, ExtensionActivity::class.java))
    }

    private fun toggleBrowsec() {
        store.browsecEnabled = !store.browsecEnabled
        renderBrowsec()
        val state = if (store.browsecEnabled) R.string.browsec_on else R.string.browsec_off
        toast(getString(state))
    }

    private fun renderBrowsec() {
        val enabled = store.browsecEnabled
        binding.textBrowsecStatus.text =
            getString(if (enabled) R.string.browsec_on else R.string.browsec_off)
        binding.textBrowsecStatus.setTextColor(
            ContextCompat.getColor(this, if (enabled) R.color.status_online else R.color.text_muted)
        )
    }

    private fun renderTraffic() {
        val log = store.trafficLog
        binding.textTraffic.text =
            if (log.isEmpty()) getString(R.string.traffic_empty) else log.joinToString("\n")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
