#!/usr/bin/env python3
"""OCR with RapidOCR (ONNX PP-OCRv5, East-Slavic recognizer).

RapidOCR is the ONNX-runtime port of PaddleOCR; this uses the same
`eslav_PP-OCRv5_mobile_rec` weights as scripts/eslav_ocr.py but without
PaddlePaddle. Raw verbatim output.

Usage:
  python rapidocr_ocr.py <pages_dir> <out.txt> [n_pages]
"""
import glob
import os
import sys
import time

from rapidocr import LangRec, ModelType, OCRVersion, RapidOCR

PAGES = sys.argv[1]
OUT = sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 63
LANG = os.environ.get("RAPIDOCR_LANG", "eslav")

_params = {
    "Rec.lang_type": LangRec(LANG),
    "Rec.ocr_version": OCRVersion.PPOCRV5,
    "Rec.model_type": ModelType.MOBILE,
    "Det.ocr_version": OCRVersion.PPOCRV5,
    "Det.model_type": ModelType.MOBILE,
    "Global.log_level": "error",
}
engine = RapidOCR(params=_params)

pages = sorted(
    p for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    t0 = time.time()
    try:
        res = engine(p)
        txt = "\n".join(res.txts or ())
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n{txt}\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
