#!/usr/bin/env python3
"""OCR with Surya (classic detection + recognition; 90+ languages, incl. ru).

Uses the Segformer line detector plus the Surya recognition model. Raw
verbatim output (Surya may emit `<br>` tags between lines within one block).

Usage:
  python surya_ocr.py <pages_dir> <out.txt> [n_pages]
"""
import glob
import os
import sys
import time

import torch
from PIL import Image
from surya.detection import DetectionPredictor
from surya.foundation import FoundationPredictor
from surya.recognition import RecognitionPredictor

PAGES = sys.argv[1]
OUT = sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 63
DEVICE = os.environ.get("SURYA_DEVICE") or ("cuda" if torch.cuda.is_available() else "cpu")

foundation = FoundationPredictor(device=DEVICE)
recognition = RecognitionPredictor(foundation)
detection = DetectionPredictor()

pages = sorted(
    p for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    img = Image.open(p).convert("RGB")
    t0 = time.time()
    try:
        res = recognition([img], det_predictor=detection)[0]
        txt = "\n".join(tl.text for tl in res.text_lines)
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n{txt}\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
