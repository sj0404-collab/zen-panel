#!/usr/bin/env python3
"""OCR with Occular-OCR (DBNet + SVTR + Russian n-gram beam LM).

Russian-first document OCR, ONNX Runtime on CPU. Raw verbatim output.

Usage:
  python occular_ocr.py <pages_dir> <out.txt> [n_pages]
"""
import glob
import os
import sys
import time

from occular import OCRPipeline, Settings

PAGES = sys.argv[1]
OUT = sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 63
DEVICE = os.environ.get("OCCULAR_DEVICE", "cpu")

pipe = OCRPipeline(Settings(gpu=(DEVICE == "cuda"), lm=True))

pages = sorted(
    p for p in glob.glob(os.path.join(PAGES, "*"))
    if p.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
)[:N]
out = open(OUT, "w", encoding="utf-8")
for i, p in enumerate(pages, 1):
    t0 = time.time()
    try:
        lines = [ln.get("text", "") for ln in pipe.process_image(p) if ln.get("text")]
        txt = "\n".join(lines)
    except Exception as exc:  # noqa: BLE001
        txt = f"<ERROR {type(exc).__name__}: {exc}>"
    dt = time.time() - t0
    print(f"[{i}/{len(pages)}] {os.path.basename(p)} {dt:.1f}s", flush=True)
    out.write(f"===== {os.path.basename(p)} ({dt:.1f}s) =====\n{txt}\n\n")
    out.flush()
out.close()
print("[i] done", flush=True)
