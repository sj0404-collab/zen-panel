package com.voicecomic.app

import com.voicecomic.app.ai.AgentClient
import com.voicecomic.app.ai.AiClient
import com.voicecomic.app.ai.Msg
import com.voicecomic.app.data.Settings
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Три бага, найденных при переносе веб-правок в натив (2.0.3):
 * вложенные картинки не доходили до модели, картинки дублировались на
 * каждый ход истории, а цикл инструментов для Responses-моделей терял
 * связь вызов↔результат.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AgentPayloadTest {

    private val IMG = "data:image/png;base64,iVBORw0KGgo="

    private fun settings() = Settings(ai = "openai", aimodel = "gpt-4o-mini", key = "k")

    private fun call(id: String, name: String, args: String) = buildJsonObject {
        put("id", id)
        put("type", "function")
        putJsonObject("function") {
            put("name", name)
            put("arguments", args)
        }
    }

    // ---------- 1. вложения доходят до модели ----------

    /**
     * Раньше Agent.run принимал images, подменял ею текст и ни разу не
     * передавал в client.turn — у всех четырёх провайдеров вложение исчезало.
     */
    @Test
    fun imagesSurviveIntoEveryProvider() {
        val msgs = listOf(Msg("system", "система"), Msg("user", "что на картинке?"))

        val responses = AgentClient.responsesInput(msgs, listOf(IMG))
        assertEquals(1, responses.imageCount())

        val gemini = AgentClient.geminiContents(msgs, listOf(IMG))
        assertEquals(1, gemini.inlineDataCount())

        val anthropic = AgentClient.anthropicMessages(msgs, listOf(IMG))
        assertEquals(1, anthropic.imageBlockCount())

        val openAi = AiClient.buildOpenAiBody(settings(), msgs, false, listOf(IMG), false)
        assertEquals(1, openAi.imageUrlCount())
    }

    @Test
    fun imagesWithoutAttachmentsKeepPlainTextContent() {
        val msgs = listOf(Msg("user", "привет"))
        assertEquals(0, AgentClient.responsesInput(msgs, emptyList()).imageCount())
        assertEquals(
            "привет",
            (AiClient.buildOpenAiBody(settings(), msgs, false, emptyList(), false)["messages"] as JsonArray)
                .jsonArray[0].jsonObject["content"].jsonPrimitive.content
        )
    }

    // ---------- 2. картинка прикреплена к своему ходу, а не к каждому ----------

    @Test
    fun openAiAttachesImageToLastUserTurnOnly() {
        val msgs = listOf(
            Msg("user", "первый вопрос"),
            Msg("assistant", "первый ответ"),
            Msg("user", "а это что?"),
            Msg("assistant", ""),
            Msg("user", "и картинка")
        )
        val messages = (AiClient.buildOpenAiBody(settings(), msgs, false, listOf(IMG), false)["messages"] as JsonArray).jsonArray
        val users = messages.map { it.jsonObject }.filter { it["role"]!!.jsonPrimitive.content == "user" }

        // три хода пользователя — картинка одна, в последнем
        assertEquals(3, users.size)
        assertEquals(0, users[0].imageUrlCount())
        assertEquals(0, users[1].imageUrlCount())
        assertEquals(1, users[2].imageUrlCount())
        // предыдущие ходы остались текстом, а не превратились в content-массивы
        assertTrue(messages[0].jsonObject["content"] is kotlinx.serialization.json.JsonPrimitive)
    }

    @Test
    fun responsesAndGeminiAttachImageToLastUserTurnOnly() {
        val msgs = listOf(
            Msg("user", "первый вопрос"),
            Msg("assistant", "ответ"),
            Msg("user", "и картинка")
        )
        assertEquals(1, AgentClient.responsesInput(msgs, listOf(IMG)).imageCount())
        assertEquals(1, AgentClient.geminiContents(msgs, listOf(IMG)).inlineDataCount())
        assertEquals(1, AgentClient.anthropicMessages(msgs, listOf(IMG)).imageBlockCount())
    }

    @Test
    fun severalImagesAllLandOnTheLastTurn() {
        val msgs = listOf(Msg("user", "что там?"), Msg("assistant", "ок"), Msg("user", "и ещё"))
        val imgs = listOf(IMG, "data:image/jpeg;base64,/9j/4AAQ")
        val messages = (AiClient.buildOpenAiBody(settings(), msgs, false, imgs, false)["messages"] as JsonArray).jsonArray
        assertEquals(2, messages.jsonArray.last().jsonObject.imageUrlCount())
        assertEquals(0, messages.jsonArray.first().jsonObject.imageUrlCount())
    }

    // ---------- 3. цикл инструментов для Responses ----------

    /**
     * Ключевой регресс: раньше и вызов, и результат уходили в input как
     * user-текст, а tool_calls ассистентского хода выбрасывались. Модель не
     * видела, что инструмент вызывался, и повторяла вызов.
     */
    @Test
    fun responsesEmitsFunctionCallAndOutputItems() {
        val msgs = listOf(
            Msg("user", "список файлов"),
            Msg("assistant", "", "", listOf(call("call_a", "ls", """{"path":"/tmp"}"""))),
            Msg("tool", "a.txt\nb.txt", "call_a")
        )
        val input = AgentClient.responsesInput(msgs)
        val items = input.jsonArray.map { it.jsonObject }

        val fnCall = items.first { it["type"]!!.jsonPrimitive.content == "function_call" }
        assertEquals("call_a", fnCall["call_id"]!!.jsonPrimitive.content)
        assertEquals("ls", fnCall["name"]!!.jsonPrimitive.content)
        assertEquals("""{"path":"/tmp"}""", fnCall["arguments"]!!.jsonPrimitive.content)

        val fnOut = items.first { it["type"]!!.jsonPrimitive.content == "function_call_output" }
        assertEquals("call_a", fnOut["call_id"]!!.jsonPrimitive.content)
        assertEquals("a.txt\nb.txt", fnOut["output"]!!.jsonPrimitive.content)

        // главное: в input больше нет прозаического user-текста про инструмент
        val texts = items.filter { it["type"]!!.jsonPrimitive.content == "message" }
            .flatMap { (it["content"] as JsonArray).jsonArray }
            .map { it.jsonObject["text"]!!.jsonPrimitive.content }
        assertTrue("результат инструмента не должен приходить как реплика пользователя",
            texts.none { it.contains("Результат инструмента") })
    }

    @Test
    fun severalToolCallsInOneTurnAllSurvive() {
        val calls = listOf(call("call_1", "read", """{"filePath":"a.md"}"""), call("call_2", "read", """{"filePath":"b.md"}"""))
        val msgs = listOf(
            Msg("user", "прочитай оба"),
            Msg("assistant", "читаю", "", calls),
            Msg("tool", "A", "call_1"),
            Msg("tool", "B", "call_2")
        )
        val items = AgentClient.responsesInput(msgs).jsonArray.map { it.jsonObject }

        assertEquals(2, items.count { it["type"]!!.jsonPrimitive.content == "function_call" })
        assertEquals(2, items.count { it["type"]!!.jsonPrimitive.content == "function_call_output" })
        // вызовы идут подряд, до результатов — так ждёт Responses
        assertEquals("function_call", items[1]["type"]!!.jsonPrimitive.content)
        assertEquals("function_call", items[2]["type"]!!.jsonPrimitive.content)
        assertEquals(listOf("A", "B"), items.drop(3).map { it["output"]!!.jsonPrimitive.content })
    }

    @Test
    fun assistantReasoningTextIsKeptAlongsideToolCalls() {
        val msgs = listOf(
            Msg("user", "что делать?"),
            Msg("assistant", "сейчас посмотрю", "", listOf(call("call_a", "read", """{"filePath":"a.md"}"""))),
            Msg("tool", "текст файла", "call_a")
        )
        val items = AgentClient.responsesInput(msgs).jsonArray.map { it.jsonObject }
        val message = items.first { it["type"]!!.jsonPrimitive.content == "message" && it["role"]!!.jsonPrimitive.content == "assistant" }
        val part = (message["content"] as JsonArray).jsonArray[0].jsonObject
        assertEquals("output_text", part["type"]!!.jsonPrimitive.content)
        assertEquals("сейчас посмотрю", part["text"]!!.jsonPrimitive.content)
    }

    /** Без текста ассистентский message-item не добавляется — пустой content ломает API. */
    @Test
    fun blankAssistantTextProducesNoEmptyMessageItem() {
        val msgs = listOf(
            Msg("user", "список"),
            Msg("assistant", "", "", listOf(call("call_a", "ls", "{}"))),
            Msg("tool", "ok", "call_a")
        )
        val items = AgentClient.responsesInput(msgs).jsonArray.map { it.jsonObject }
        assertTrue(items.none { it["type"]!!.jsonPrimitive.content == "message" && it["role"]!!.jsonPrimitive.content == "assistant" })
        assertEquals(1, items.count { it["type"]!!.jsonPrimitive.content == "function_call" })
    }

    /** function_call принимается и в плоском виде — обёртка не обязательна. */
    @Test
    fun flatFunctionCallShapeIsAccepted() {
        val flat = buildJsonObject {
            put("type", "function_call")
            put("call_id", "call_z")
            put("name", "bash")
            put("arguments", """{"command":"ls"}""")
        }
        val msgs = listOf(Msg("user", "выполни"), Msg("assistant", "", "", listOf(flat)), Msg("tool", "ok", "call_z"))
        val item = AgentClient.responsesInput(msgs).jsonArray.map { it.jsonObject }
            .first { it["type"]!!.jsonPrimitive.content == "function_call" }
        assertEquals("call_z", item["call_id"]!!.jsonPrimitive.content)
        assertEquals("bash", item["name"]!!.jsonPrimitive.content)
        assertEquals("""{"command":"ls"}""", item["arguments"]!!.jsonPrimitive.content)
    }

    // ---------- счётчики по типам частей ----------

    private fun JsonArray.imageCount(): Int = countItems("input_image")

    private fun JsonObject.imageUrlCount(): Int = parts().count { it["type"]?.jsonPrimitive?.content == "image_url" }

    private fun JsonObject.inlineDataCount(): Int = parts().count { it.containsKey("inline_data") }

    private fun JsonObject.imageBlockCount(): Int = parts().count { it["type"]?.jsonPrimitive?.content == "image" }

    private fun JsonObject.parts(): List<JsonObject> = (this["content"] as? JsonArray ?: this["parts"] as? JsonArray ?: buildJsonArray { })
        .jsonArray.map { it.jsonObject }

    private fun JsonArray.countItems(type: String): Int {
        val direct = count { it.jsonObject["type"]?.jsonPrimitive?.content == type }
        val nested = sumOf { el ->
            (el.jsonObject["content"] as? JsonArray)?.jsonArray?.count { it.jsonObject["type"]?.jsonPrimitive?.content == type } ?: 0
        }
        return direct + nested
    }
}
