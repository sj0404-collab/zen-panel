package app.yomikaioverlay.ot

/**
 * Автосубтитры: сам листать новеллу (тапать «дальше») или подождать.
 *
 * На странице повествования на экране один-два блока текста — можно тапать.
 * На экране выбора реплик блоков несколько, они одинаковой ширины и короткие —
 * тапать нельзя, это сбросит выбор, поэтому ждём следующего шага игрока.
 *
 * Чистая логика (без Android) — покрыта юнит-тестами.
 */
object AutoPilot {

    /** Что делать после озвучки. */
    const val TAP = "tap"      // новелла: двигаем сюжет
    const val WAIT = "wait"    // выбор реплик: ждём решения игрока

    class Block(val width: Int, val height: Int)

    /** Порог «меню»: столько широких низких строк считаем экраном выбора. */
    private const val CHOICE_MIN = 3
    private const val WIDE_RATIO = 0.5        // от самой широкой колонки
    private const val SHORT_OF_SCREEN = 0.14  // строка-реплика не выше 14% экрана

    /**
     * [screenHeight] обязателен: строка реплики короткая сама по себе, а не
     * «короткая относительно соседей» — иначе экран целиком из коротких строк
     * (обычный абзац по 4 слова) приняли бы за меню выбора.
     */
    fun decision(blocks: List<Block>, screenHeight: Int): String {
        if (blocks.isEmpty()) return WAIT

        val widest = blocks.maxOf { it.width }
        val h = screenHeight.coerceAtLeast(1)

        val menuish = blocks.count {
            it.width >= (widest * WIDE_RATIO).toInt() &&
                it.height.toFloat() / h <= SHORT_OF_SCREEN
        }

        return if (menuish >= CHOICE_MIN) WAIT else TAP
    }
}
