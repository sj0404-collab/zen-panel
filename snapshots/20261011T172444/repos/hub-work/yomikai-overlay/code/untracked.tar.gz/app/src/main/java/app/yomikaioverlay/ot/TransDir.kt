package app.yomikaioverlay.ot

/**
 * Направление перевода: игра может быть на английском (переводим на русский),
 * новелла — на русском (переводим на английский).
 */
object TransDir {
    const val AUTO = "auto"   // определяем по алфавиту: латиница → русский
    const val EN2RU = "en2ru"
    const val RU2EN = "ru2en"

    val MODES = listOf(AUTO, EN2RU, RU2EN)

    fun normalize(dir: String?): String = if (dir != null && dir in MODES) dir else AUTO

    fun next(dir: String?): String {
        val l = MODES
        return l[(l.indexOf(normalize(dir)) + 1) % l.size]
    }

    fun label(dir: String?): String = when (normalize(dir)) {
        EN2RU -> "Англ → Рус"
        RU2EN -> "Рус → Англ"
        else -> "Авто (по алфавиту)"
    }

    fun short(dir: String?): String = when (normalize(dir)) {
        EN2RU -> "EN→RU"
        RU2EN -> "RU→EN"
        else -> "Авто"
    }

    /**
     * Нужно ли переводить текст [text] при направлении [dir].
     * AUTO: латиница → русский, кириллица → английский.
     */
    fun shouldTranslate(text: String, dir: String?): Boolean {
        if (text.isBlank()) return false
        return when (normalize(dir)) {
            EN2RU -> !ScriptDetect.isMostlyCyrillic(text)
            RU2EN -> ScriptDetect.isMostlyCyrillic(text)
            else -> true
        }
    }
}