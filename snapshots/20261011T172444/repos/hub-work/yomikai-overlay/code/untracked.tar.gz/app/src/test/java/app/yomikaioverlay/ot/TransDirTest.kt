package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TransDirTest {

    private val latin = "The hero opened the door"
    private val cyrillic = "Герой открыл дверь"

    @Test
    fun defaultIsAuto() {
        assertEquals(TransDir.AUTO, TransDir.normalize(null))
        assertEquals(TransDir.AUTO, TransDir.normalize("nonsense"))
    }

    @Test
    fun cycleWraps() {
        assertEquals(TransDir.EN2RU, TransDir.next(TransDir.AUTO))
        assertEquals(TransDir.RU2EN, TransDir.next(TransDir.EN2RU))
        assertEquals(TransDir.AUTO, TransDir.next(TransDir.RU2EN))
    }

    @Test
    fun autoTranslatesBothDirections() {
        assertTrue(TransDir.shouldTranslate(latin, TransDir.AUTO))
        assertTrue(TransDir.shouldTranslate(cyrillic, TransDir.AUTO))
    }

    @Test
    fun en2ruSkipsCyrillic() {
        assertTrue(TransDir.shouldTranslate(latin, TransDir.EN2RU))
        assertFalse(TransDir.shouldTranslate(cyrillic, TransDir.EN2RU))
    }

    @Test
    fun ru2enOnlyCyrillic() {
        assertTrue(TransDir.shouldTranslate(cyrillic, TransDir.RU2EN))
        assertFalse(TransDir.shouldTranslate(latin, TransDir.RU2EN))
    }

    @Test
    fun blankTextNeverTranslates() {
        assertFalse(TransDir.shouldTranslate("", TransDir.AUTO))
        assertFalse(TransDir.shouldTranslate("   ", TransDir.EN2RU))
    }

    @Test
    fun autoSubtitlesModeTapsAndTranslates() {
        assertTrue(ReadMode.autoTap(ReadMode.AUTO_SUB))
        assertFalse(ReadMode.autoTap(ReadMode.NORMAL))
        assertFalse(ReadMode.autoTap(ReadMode.GAME_SUB))
        assertEquals(TransDir.AUTO, ReadMode.translateDir(ReadMode.AUTO_SUB))
        assertEquals(null, ReadMode.translateDir(ReadMode.MANGA))
    }
}