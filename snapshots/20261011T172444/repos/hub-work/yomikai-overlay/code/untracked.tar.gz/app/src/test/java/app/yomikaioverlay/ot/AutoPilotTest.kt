package app.yomikaioverlay.ot

import org.junit.Assert.assertEquals
import org.junit.Test

class AutoPilotTest {

    /** Типичный экран телефона: 1080x2400. */
    private val h = 2400

    private fun b(w: Int, bh: Int) = AutoPilot.Block(w, bh)

    @Test
    fun noBlocksMeansWait() {
        assertEquals(AutoPilot.WAIT, AutoPilot.decision(emptyList(), h))
    }

    @Test
    fun singleNarrativeBlockMeansTap() {
        assertEquals(AutoPilot.TAP, AutoPilot.decision(listOf(b(1080, 1800)), h))
        assertEquals(AutoPilot.TAP, AutoPilot.decision(listOf(b(1080, 1800), b(300, 90)), h))
    }

    @Test
    fun threeWideShortRowsLooksLikeChoiceList() {
        val blocks = listOf(b(1080, 110), b(1080, 110), b(1080, 110))
        assertEquals(AutoPilot.WAIT, AutoPilot.decision(blocks, h))
    }

    @Test
    fun fourChoicesAlsoWait() {
        val blocks = listOf(b(1080, 110), b(1080, 110), b(1080, 110), b(1080, 110))
        assertEquals(AutoPilot.WAIT, AutoPilot.decision(blocks, h))
    }

    @Test
    fun tallParagraphBlocksAreNotMenu() {
        // Три блока во всю ширину, но высокие — это абзацы, а не реплики.
        val blocks = listOf(b(1080, 900), b(1080, 900), b(1080, 900))
        assertEquals(AutoPilot.TAP, AutoPilot.decision(blocks, h))
    }

    @Test
    fun narrowDifferentWidthsAreNotMenu() {
        val blocks = listOf(b(1080, 110), b(540, 110), b(270, 110))
        assertEquals(AutoPilot.TAP, AutoPilot.decision(blocks, h))
    }

    @Test
    fun twoMenuRowsAreNotEnoughToWait() {
        assertEquals(AutoPilot.TAP, AutoPilot.decision(listOf(b(1080, 110), b(1080, 110)), h))
    }

    @Test
    fun choiceThresholdScalesWithScreenHeight() {
        // Блоки 400px: на экране 2400 это 16.7% высоты — крупный текст (абзац).
        val blocks = listOf(b(1080, 400), b(1080, 400), b(1080, 400))
        assertEquals(AutoPilot.TAP, AutoPilot.decision(blocks, 2400))
        // На экране 4000 те же блоки — всего 10% высоты, низкие строки-реплики.
        assertEquals(AutoPilot.WAIT, AutoPilot.decision(blocks, 4000))
    }
}