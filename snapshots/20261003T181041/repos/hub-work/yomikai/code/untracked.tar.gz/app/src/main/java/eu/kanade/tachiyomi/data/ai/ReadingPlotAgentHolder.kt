package eu.kanade.tachiyomi.data.ai

import mihon.domain.ocr.service.OcrPreferences
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Единственный экземпляр суб-агента сюжета на процесс.
 *
 * Движок озвучки живёт дольше экранов и не должен знать, где показывается
 * пересказ, поэтому агент вынесен в отдельный держатель: его состояние
 * (накопленные реплики, идущий запрос) обязано быть общим для движка и вкладки.
 */
object ReadingPlotAgentHolder {
    val agent: ReadingPlotAgent by lazy { ReadingPlotAgent(Injekt.get<OcrPreferences>()) }
}
