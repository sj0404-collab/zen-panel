(function () {
  'use strict';

  var query = new URLSearchParams(window.location.search);
  var DEFAULT_MODEL = query.get('model') || 'whalegirl';

  var bridge = window.VtuberAvatar || null;

  var MOODS = {
    idle:      { angleX: 0,   angleY: 0,    angleZ: 0,   eyeX: 0,    eyeY: 0,    browL: 0,   browR: 0,   mouthForm: 0.35, smile: 0,   mouth: 0.55, hue: 0 },
    listening: { angleX: 0,   angleY: -5,   angleZ: 2,   eyeX: 0,    eyeY: 0.35, browL: 0.7, browR: 0.7, mouthForm: 0.55, smile: 0,   mouth: 0.70, hue: 0.04 },
    thinking:  { angleX: -9,  angleY: -9,   angleZ: -6,  eyeX: -0.6, eyeY: -0.45,browL: -0.2,browR: 0.5, mouthForm: 0.0,  smile: 0,   mouth: 0.42, hue: -0.05 },
    speaking:  { angleX: 0,   angleY: 0,    angleZ: 0,   eyeX: 0,    eyeY: 0,    browL: 0.3, browR: 0.3, mouthForm: 0.65, smile: 0,   mouth: 0.85, hue: 0.02 },
    sleep:     { angleX: 0,   angleY: 11,   angleZ: -8,  eyeX: 0,    eyeY: 0.3,  browL: -0.3,browR: -0.3,mouthForm: 0.1,  smile: 0,   mouth: 0.22, hue: -0.10 },
    happy:     { angleX: 0,   angleY: -6,   angleZ: 7,   eyeX: 0,    eyeY: 0,    browL: 1,   browR: 1,   mouthForm: 1.0,  smile: 1,   mouth: 0.95, hue: 0.08 },
    surprised: { angleX: -4,  angleY: -13,  angleZ: 5,   eyeX: 0,    eyeY: -0.1, browL: 1,   browR: 1,   mouthForm: -0.2, smile: 0,   mouth: 0.5,  hue: 0.12 },
    concerned: { angleX: 3,   angleY: 4,    angleZ: -5,  eyeX: 0.2,  eyeY: 0.25, browL: -0.8,browR: 0.9, mouthForm: -0.6, smile: 0,   mouth: 0.45, hue: -0.08 }
  };

  var state = {
    app: null,
    model: null,
    modelName: DEFAULT_MODEL,
    modelDir: 'models/' + DEFAULT_MODEL + '/',
    ready: false,
    mood: 'idle',
    moodFrom: MOODS.idle,
    moodTo: MOODS.idle,
    moodT: 1,
    moodFromAt: 0,
    groups: { eyeBlink: ['ParamEyeLOpen', 'ParamEyeROpen'], lipSync: ['ParamMouthOpenY'] },
    motions: [],
    speaking: false,
    level: 0,
    levelSmooth: 0,
    env: 0,
    breath: 0,
    time: 0,
    blink: { next: 2.4, closing: 0, state: 'wait' },
    eyesClosed: 0,
    gaze: { x: 0, y: 0, tx: 0, ty: 0 },
    tilt: 0,
    tiltTarget: 0,
    caption: '',
    captionAlpha: 0,
    statusText: '',
    statusAlpha: 0,
    flash: 0,
    seed: 20260927
  };

  var els = {
    gradient: null,
    beams: null,
    stars: [],
    hearts: [],
    city: null,
    horizon: null,
    model: null,
    bars: [],
    frame: null,
    caption: null,
    status: null,
    statusBg: null,
    flashOverlay: null
  };

  function rand() {
    state.seed = (state.seed * 1664525 + 1013904223) % 4294967296;
    return state.seed / 4294967296;
  }

  function range(a, b) {
    return a + rand() * (b - a);
  }

  function clamp(v, a, b) {
    return v < a ? a : v > b ? b : v;
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function hsl(h, s, l, a) {
    var c = new PIXI.Color(0xffffff);
    var hslColor = new PIXI.Color();
    hslColor.setHSL(((h % 1) + 1) % 1, s, l, a === undefined ? 1 : a);
    return hslColor;
  }

  function native(name) {
    if (bridge && typeof bridge[name] === 'function') {
      try {
        bridge[name]();
      } catch (e) {}
    }
  }

  function nativeArgs(name, args) {
    if (bridge && typeof bridge[name] === 'function') {
      try {
        bridge[name].apply(null, args);
      } catch (e) {}
    }
  }

  function core() {
    return state.model && state.model.internalModel ? state.model.internalModel.coreModel : null;
  }

  function hasParam(id) {
    var c = core();
    if (!c) return false;
    try {
      return c.getParameterIndex(id) < c.getParameterCount();
    } catch (e) {
      return false;
    }
  }

  function setParam(candidates, value) {
    var c = core();
    if (!c) return;
    var id = Array.isArray(candidates) ? candidates : [candidates];
    for (var i = 0; i < id.length; i++) {
      if (hasParam(id[i])) {
        try {
          c.setParameterValueById(id[i], value);
          return true;
        } catch (e) {
          return false;
        }
      }
    }
    return false;
  }

  function lockParams() {
    var c = core();
    if (c && c.saveParameters) {
      try {
        c.saveParameters();
      } catch (e) {}
    }
  }

  function makeGlowTexture(size, inner, outer) {
    var canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    var ctx = canvas.getContext('2d');
    var g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    g.addColorStop(0, inner);
    g.addColorStop(0.35, outer);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    return PIXI.Texture.from(canvas);
  }

  function makeHeartTexture(size) {
    var canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    var s = size / 32;
    ctx.moveTo(16 * s, 28 * s);
    ctx.bezierCurveTo(4 * s, 19 * s, 2 * s, 10 * s, 8 * s, 6 * s);
    ctx.bezierCurveTo(13 * s, 3 * s, 16 * s, 8 * s, 16 * s, 10 * s);
    ctx.bezierCurveTo(16 * s, 8 * s, 19 * s, 3 * s, 24 * s, 6 * s);
    ctx.bezierCurveTo(30 * s, 10 * s, 28 * s, 19 * s, 16 * s, 28 * s);
    ctx.closePath();
    ctx.fill();
    ctx.lineWidth = 1.6 * s;
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.stroke();
    return PIXI.Texture.from(canvas);
  }

  function buildBackground() {
    var w = state.app.renderer.width / state.app.renderer.resolution;
    var h = state.app.renderer.height / state.app.renderer.resolution;

    els.gradient = new PIXI.Sprite(makeGlowTexture(512, 'rgba(255,64,190,0.95)', 'rgba(120,20,140,0.55)'));
    els.gradient.anchor.set(0.5);
    els.gradient.x = w * 0.5;
    els.gradient.y = h * 0.42;
    els.gradient.scale.set(Math.max(w, h) / 340);
    els.gradient.alpha = 0.9;
    state.app.stage.addChild(els.gradient);

    els.horizon = new PIXI.Graphics();
    els.horizon.beginFill(0xff2fb0, 0.16);
    els.horizon.drawRoundedRect(0, 0, w, h);
    els.horizon.endFill();
    state.app.stage.addChild(els.horizon);

    els.beams = new PIXI.Container();
    var colors = [0xff3ec8, 0x9b5cff, 0x2fe6ff, 0xff7ae0, 0x7c4dff];
    for (var i = 0; i < 7; i++) {
      var beam = new PIXI.Graphics();
      var color = colors[i % colors.length];
      beam.beginFill(color, 0.11);
      beam.moveTo(0, 0);
      beam.lineTo(range(-w, w) * 0.5, h * 2.4);
      beam.lineTo(range(-w, w) * 0.5 + range(20, 90), h * 2.4);
      beam.endFill();
      beam.x = w * 0.5 + range(-w * 0.3, w * 0.3);
      beam.y = -h * 0.15;
      beam.rotation = range(-0.35, 0.35);
      beam.pivot.set(0, 0);
      beam.speed = range(0.05, 0.16) * (rand() > 0.5 ? 1 : -1);
      beam.baseX = beam.x;
      beam.baseRot = beam.rotation;
      els.beams.addChild(beam);
    }
    state.app.stage.addChild(els.beams);

    var starTex = makeGlowTexture(64, 'rgba(255,255,255,1)', 'rgba(255,190,240,0.55)');
    for (var s = 0; s < 46; s++) {
      var star = new PIXI.Sprite(starTex);
      star.anchor.set(0.5);
      star.x = range(0, w);
      star.y = range(0, h * 0.92);
      star.baseSize = range(4, 18);
      star.scale.set(star.baseSize / 32);
      star.blendMode = PIXI.BLEND_MODES.ADD;
      star.phase = range(0, Math.PI * 2);
      star.speed = range(0.6, 2.2);
      star.baseAlpha = range(0.25, 0.95);
      star.alpha = star.baseAlpha;
      state.app.stage.addChild(star);
      els.stars.push(star);
    }

    var heartTex = makeHeartTexture(64);
    for (var hh = 0; hh < 7; hh++) {
      var heart = new PIXI.Sprite(heartTex);
      heart.anchor.set(0.5);
      heart.x = range(w * 0.08, w * 0.92);
      heart.y = range(h * 0.15, h * 0.95);
      heart.baseSize = range(10, 26);
      heart.scale.set(heart.baseSize / 32);
      heart.blendMode = PIXI.BLEND_MODES.ADD;
      heart.tint = rand() > 0.5 ? 0xff7ad4 : 0xffb3ec;
      heart.phase = range(0, Math.PI * 2);
      heart.speed = range(6, 16);
      heart.sway = range(6, 20);
      heart.baseAlpha = range(0.25, 0.7);
      state.app.stage.addChild(heart);
      els.hearts.push(heart);
    }

    els.city = new PIXI.Graphics();
    var baseY = h * 0.99;
    var x = -20;
    while (x < w + 20) {
      var bw = range(18, 46);
      var bh = range(h * 0.05, h * 0.19);
      els.city.beginFill(0x12041f, 0.72);
      els.city.drawRect(x, baseY - bh, bw, bh);
      els.city.endFill();
      var lights = Math.floor(bh / 12);
      for (var l = 0; l < lights; l++) {
        if (rand() > 0.55) {
          els.city.beginFill(rand() > 0.5 ? 0xff6ad5 : 0x66e0ff, range(0.25, 0.8));
          els.city.drawRect(x + 4 + rand() * (bw - 9), baseY - bh + 6 + l * 12, 3, 4);
          els.city.endFill();
        }
      }
      x += bw + range(3, 12);
    }
    state.app.stage.addChild(els.city);

    els.model = new PIXI.Container();
    state.app.stage.addChild(els.model);

    buildEqualizer(w, h);
    buildOverlay(w, h);
  }

  function buildEqualizer(w, h) {
    var count = Math.max(14, Math.round(w / 14));
    var width = w / count;
    var barWidth = Math.max(2, width * 0.55);
    var baseY = h - 3;
    var colors = [0x2fe6ff, 0x5ac8ff, 0x9b5cff, 0xe14bff, 0xff3ec8, 0xff6ad5];
    for (var i = 0; i < count; i++) {
      var holder = new PIXI.Container();
      holder.x = i * width;
      var bar = new PIXI.Graphics();
      var color = colors[Math.floor((i / count) * colors.length)];
      bar.beginFill(color, 0.95);
      bar.drawRoundedRect(0, 0, barWidth, 4, barWidth / 2);
      bar.endFill();
      bar.blendMode = PIXI.BLEND_MODES.ADD;
      bar.x = (width - barWidth) / 2;
      bar.y = baseY;
      bar.pivot.set(0, bar.height);
      bar.seed = range(0, Math.PI * 2);
      bar.speed = range(6, 15);
      holder.addChild(bar);
      state.app.stage.addChild(holder);
      els.bars.push({ bar: bar, seed: bar.seed, speed: bar.speed, baseY: baseY });
    }
  }

  function buildOverlay(w, h) {
    els.flashOverlay = new PIXI.Graphics();
    els.flashOverlay.beginFill(0xffffff, 1);
    els.flashOverlay.drawRect(0, 0, w, h);
    els.flashOverlay.endFill();
    els.flashOverlay.alpha = 0;
    els.flashOverlay.blendMode = PIXI.BLEND_MODES.ADD;
    state.app.stage.addChild(els.flashOverlay);

    var captionStyle = new PIXI.TextStyle({
      fontFamily: 'sans-serif',
      fontSize: Math.max(12, Math.round(w * 0.045)),
      fontWeight: '600',
      fill: 0xffffff,
      stroke: 0x2a0418,
      strokeThickness: Math.max(3, w * 0.012),
      dropShadow: true,
      dropShadowColor: 0xff2fb0,
      dropShadowBlur: 10,
      dropShadowDistance: 0,
      align: 'center',
      wordWrap: true,
      wordWrapWidth: w * 0.78,
      lineHeight: Math.max(14, Math.round(w * 0.055))
    });
    els.caption = new PIXI.Text('', captionStyle);
    els.caption.anchor.set(0.5, 1);
    els.caption.x = w / 2;
    els.caption.y = h - Math.max(18, h * 0.075);
    els.caption.alpha = 0;
    state.app.stage.addChild(els.caption);

    var statusStyle = new PIXI.TextStyle({
      fontFamily: 'sans-serif',
      fontSize: Math.max(10, Math.round(w * 0.032)),
      fontWeight: '700',
      fill: 0xffffff
    });
    els.status = new PIXI.Text('', statusStyle);
    els.status.anchor.set(0, 0.5);
    els.status.x = Math.max(8, w * 0.03);
    els.status.y = Math.max(12, h * 0.05);
    els.status.alpha = 0;
    state.app.stage.addChild(els.status);

    els.frame = new PIXI.Graphics();
    state.app.stage.addChild(els.frame);

    var mask = new PIXI.Graphics();
    mask.beginFill(0xffffff, 1);
    mask.drawRoundedRect(0, 0, w, h, Math.min(w, h) * 0.09);
    mask.endFill();
    state.app.stage.addChild(mask);
    state.app.stage.mask = mask;
  }

  function drawFrame(w, h, radius, glow) {
    els.frame.clear();
    els.frame.lineStyle({ width: Math.max(6, w * 0.022), color: 0xff2fb0, alpha: 0.16 * glow, alignment: PIXI.LINE_JOIN_ROUND });
    els.frame.drawRoundedRect(0, 0, w, h, radius);
    els.frame.lineStyle({ width: Math.max(1.5, w * 0.006), color: 0xffb3ec, alpha: 0.55 * glow, alignment: PIXI.LINE_JOIN_ROUND });
    els.frame.drawRoundedRect(0, 0, w, h, radius);
    els.frame.lineStyle(0);
  }

  function layout() {
    var w = state.app.renderer.width / state.app.renderer.resolution;
    var h = state.app.renderer.height / state.app.renderer.resolution;
    var radius = Math.min(w, h) * 0.09;

    els.gradient.x = w * 0.5;
    els.gradient.y = h * 0.42;
    els.gradient.scale.set(Math.max(w, h) / 340);

    els.beams.children.forEach(function (beam) {
      beam.height = h;
    });
    els.beams.pivot.set(w / 2, 0);
    els.beams.position.set(0, -h * 0.15);

    var starIdx = 0;
    var total = els.stars.length;
    els.stars.forEach(function (star) {
      star.x = (star.x / (star._w || w)) * w;
      star._w = w;
      star.y = star.y / (star._h || h) * h;
      star._h = h;
    });

    els.hearts.forEach(function (heart) {
      heart.x = heart.x / (heart._w || w) * w;
      heart._w = w;
      heart.y = heart.y / (heart._h || h) * h;
      heart._h = h;
    });

    els.caption.style.fontSize = Math.max(12, Math.round(w * 0.045));
    els.caption.style.wordWrapWidth = w * 0.78;
    els.caption.x = w / 2;
    els.caption.y = h - Math.max(18, h * 0.075);
    els.status.x = Math.max(8, w * 0.03);
    els.status.y = Math.max(12, h * 0.05);
    els.status.style.fontSize = Math.max(10, Math.round(w * 0.032));

    els.bars.forEach(function (item, i) {
      item.bar.x = (i * (w / els.bars.length) + (w / els.bars.length - item.bar.width) / 2);
      item.bar.y = h - 3;
    });

    els.city.clear();
    var savedSeed = state.seed;
    state.seed = 20260927;
    var baseY = h * 0.99;
    var x = -20;
    while (x < w + 20) {
      var bw = range(18, 46);
      var bh = range(h * 0.05, h * 0.19);
      els.city.beginFill(0x12041f, 0.72);
      els.city.drawRect(x, baseY - bh, bw, bh);
      els.city.endFill();
      x += bw + range(3, 12);
    }
    state.seed = savedSeed;

    drawFrame(w, h, radius, 1);
    fitModel(w, h);
  }

  function fitModel(w, h) {
    var model = state.model;
    if (!model) return;
    model.scale.set(1);
    model.position.set(0, 0);
    var nw = model.width;
    var nh = model.height;
    if (!nw || !nh) return;
    var s = Math.min((w * 0.96) / nw, (h * 0.9) / nh);
    model.scale.set(s);
    model.x = (w - nw * s) / 2;
    model.y = (h - nh * s) / 2 - h * 0.02;
  }

  function readGroups(modelJson) {
    var groups = (modelJson.Groups || []).reduce(function (acc, group) {
      acc[group.Name] = group.Ids || [];
      return acc;
    }, {});
    if (groups.EyeBlink && groups.EyeBlink.length) state.groups.eyeBlink = groups.EyeBlink;
    if (groups.LipSync && groups.LipSync.length) state.groups.lipSync = groups.LipSync;
    state.motions = Object.keys((modelJson.FileReferences || {}).Motions || {});
    if (modelJson.FileReferences && modelJson.FileReferences.Physics) state.hasPhysics = true;
  }

  function loadModel(name) {
    state.modelName = name;
    state.modelDir = 'models/' + name + '/';
    var url = '../' + state.modelDir + name + '.model3.json';
    return fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error('model3.json ' + r.status);
        return r.json();
      })
      .then(function (json) {
        readGroups(json);
        return PIXI.live2d.Live2DModel.from(url, { autoInteract: false });
      })
      .then(function (model) {
        if (state.model) {
          els.model.removeChild(state.model);
          state.model.destroy();
        }
        state.model = model;
        els.model.addChild(model);
        model.anchor.set(0, 0);
        var im = model.internalModel;
        im.autoUpdate = true;
        if (im.motionManager && im.motionManager.groups && state.motions.indexOf('Idle') >= 0) {
          im.motionManager.groups.idle = 'Idle';
        }
        if (state.motions.indexOf('Idle') >= 0) model.motion('Idle');
        var w = state.app.renderer.width / state.app.renderer.resolution;
        var h = state.app.renderer.height / state.app.renderer.resolution;
        fitModel(w, h);
        state.ready = true;
        nativeArgs('onReady', [name]);
      })
      .catch(function (e) {
        state.ready = false;
        nativeArgs('onError', [String((e && e.message) || e)]);
      });
  }

  function playMotion(name) {
    if (!state.model || state.motions.indexOf(name) < 0) return;
    try {
      state.model.motion(name);
    } catch (e) {}
  }

  function setMood(mood) {
    if (!MOODS[mood]) mood = 'idle';
    if (state.mood === mood) return;
    state.moodFrom = currentMood();
    state.moodTo = MOODS[mood];
    state.mood = mood;
    state.moodFromAt = state.time;
    state.moodT = 0;
    var status = {
      idle: '',
      listening: '🎤 слушаю…',
      thinking: '💭 думаю…',
      speaking: '💬 говорю',
      sleep: '😴 тишина',
      happy: '✨ радость',
      surprised: '😮 ой!',
      concerned: '😟 тревога'
    }[mood] || '';
    state.statusText = status;
    state.statusAlpha = status ? 1 : 0;
    els.status.text = status;
    if (mood === 'happy') playMotion('Nod');
    if (mood === 'surprised') playMotion('Shake');
  }

  function currentMood() {
    var t = clamp((state.time - state.moodFromAt) / 0.45, 0, 1);
    var e = t * t * (3 - 2 * t);
    var a = state.moodFrom;
    var b = state.moodTo;
    return {
      angleX: lerp(a.angleX, b.angleX, e),
      angleY: lerp(a.angleY, b.angleY, e),
      angleZ: lerp(a.angleZ, b.angleZ, e),
      eyeX: lerp(a.eyeX, b.eyeX, e),
      eyeY: lerp(a.eyeY, b.eyeY, e),
      browL: lerp(a.browL, b.browL, e),
      browR: lerp(a.browR, b.browR, e),
      mouthForm: lerp(a.mouthForm, b.mouthForm, e),
      smile: lerp(a.smile, b.smile, e),
      mouth: lerp(a.mouth, b.mouth, e),
      hue: lerp(a.hue, b.hue, e)
    };
  }

  function updateBlink(dt) {
    var b = state.blink;
    if (b.state === 'wait') {
      b.next -= dt;
      if (b.next <= 0) {
        b.state = 'closing';
        b.t = 0;
        if (rand() > 0.75) b.double = true;
      }
    } else if (b.state === 'closing') {
      b.t += dt;
      if (b.t >= 0.09) {
        b.state = 'closed';
        b.t = 0;
      }
    } else if (b.state === 'closed') {
      b.t += dt;
      if (b.t >= 0.07) {
        b.state = 'opening';
        b.t = 0;
      }
    } else if (b.state === 'opening') {
      b.t += dt;
      if (b.t >= 0.13) {
        if (b.double) {
          b.double = false;
          b.state = 'wait';
          b.next = 0.12;
        } else {
          b.state = 'wait';
          b.next = range(2.2, 5.4);
        }
      }
    }
    var value = 1;
    if (b.state === 'closing') value = 1 - clamp(b.t / 0.09, 0, 1);
    else if (b.state === 'closed') value = 0;
    else if (b.state === 'opening') value = clamp(b.t / 0.13, 0, 1);
    state.eyesClosed = 1 - value;
  }

  function updateEnvelope(dt) {
    state.time += dt;
    state.breath = (Math.sin(state.time * 1.15) + 1) / 2;
    var wobble =
      Math.sin(state.time * 13.7) * 0.34 +
      Math.sin(state.time * 7.1 + 1.3) * 0.28 +
      Math.sin(state.time * 21.3 + 0.7) * 0.16;
    var target = state.speaking ? clamp(0.55 + wobble * 0.9, 0, 1) : 0;
    target = clamp(target * (1 - state.eyesClosed * 0.6) + state.levelSmooth * (1 - state.eyesClosed * 0.6), 0, 1);
    state.env = lerp(state.env, target, clamp(dt * 18, 0, 1));
    state.levelSmooth = lerp(state.levelSmooth, clamp(state.level, 0, 1), clamp(dt * 10, 0, 1));

    state.gaze.x = lerp(state.gaze.x, state.gaze.tx, clamp(dt * 6, 0, 1));
    state.gaze.y = lerp(state.gaze.y, state.gaze.ty, clamp(dt * 6, 0, 1));
    state.tilt = lerp(state.tilt, state.tiltTarget, clamp(dt * 8, 0, 1));
  }

  function applyParams() {
    var m = currentMood();
    var talking = state.env;
    setParam(['ParamAngleX', 'ParamHeadAngleX'], m.angleX + state.gaze.x * 6);
    setParam(['ParamAngleY', 'ParamHeadAngleY'], m.angleY + state.gaze.y * 4);
    setParam(['ParamAngleZ', 'ParamHeadAngleZ'], m.angleZ);
    setParam(['ParamBodyAngleX'], m.angleX * 0.4);
    setParam(['ParamBodyAngleZ'], m.angleZ * 0.4);
    setParam(['ParamEyeBallX'], clamp(m.eyeX + state.gaze.x * 0.6, -1, 1));
    setParam(['ParamEyeBallY'], clamp(m.eyeY + state.gaze.y * 0.5, -1, 1));
    setParam(['ParamBrowLY'], m.browL);
    setParam(['ParamBrowRY'], m.browR);
    setParam(['ParamBrowLForm'], m.concerned || 0);
    setParam(['ParamBrowRForm'], m.concerned || 0);
    setParam(['ParamMouthForm'], m.mouthForm);
    setParam(['ParamCheek'], talking * 0.4);

    var open = 1 - state.eyesClosed;
    if (state.mood === 'sleep') open = 0;
    state.groups.eyeBlink.forEach(function (id) {
      setParam(id, open);
    });
    if (hasParam('ParamEyeLSmile')) setParam('ParamEyeLSmile', m.smile);
    if (hasParam('ParamEyeRSmile')) setParam('ParamEyeRSmile', m.smile);

    var mouth = m.mouth * (1 - talking * 0.35) + talking * 0.95;
    mouth = clamp(mouth, 0, 1.25);
    state.groups.lipSync.forEach(function (id) {
      setParam(id, mouth);
    });

    if (hasParam('ParamBreath')) setParam('ParamBreath', 1 + state.breath * 0.5);
    lockParams();
  }

  function updateVisuals(dt) {
    var w = state.app.renderer.width / state.app.renderer.resolution;
    var h = state.app.renderer.height / state.app.renderer.resolution;
    var m = currentMood();

    els.gradient.tint = hsl(0.88 + m.hue, 0.9, 0.55);
    els.gradient.alpha = 0.75 + state.env * 0.25;

    els.beams.rotation = Math.sin(state.time * 0.12) * 0.08;
    els.beams.children.forEach(function (beam, i) {
      beam.rotation = beam.baseRot + Math.sin(state.time * beam.speed + i) * 0.05;
      beam.x = beam.baseX + Math.sin(state.time * beam.speed * 0.7 + i * 1.7) * w * 0.03;
    });

    els.stars.forEach(function (star) {
      var tw = 0.55 + 0.45 * Math.sin(state.time * star.speed + star.phase);
      star.alpha = star.baseAlpha * tw;
      var size = star.baseSize * (0.85 + tw * 0.3) / 32;
      star.scale.set(size);
      star.tint = 0xffffff;
    });

    els.hearts.forEach(function (heart, i) {
      heart.y -= heart.speed * dt;
      heart.x += Math.sin(state.time * 1.3 + heart.phase) * heart.sway * dt;
      if (heart.y < -20) {
        heart.y = h + 20;
        heart.x = range(w * 0.08, w * 0.92);
      }
      var tw = 0.6 + 0.4 * Math.sin(state.time * 2 + heart.phase);
      heart.alpha = heart.baseAlpha * tw;
      heart.scale.set((heart.baseSize / 32) * (0.9 + tw * 0.2));
    });

    els.bars.forEach(function (item, i) {
      var wave = 0.5 + 0.5 * Math.sin(state.time * item.speed + item.seed + i * 0.4);
      var idle = 0.12 + wave * 0.1;
      var amp = 0.35 + wave * 0.65;
      var height = (h * 0.16) * (idle + state.env * amp);
      var grow = state.flash > 0 ? 1 + state.flash * 0.5 : 1;
      item.bar.scale.y = Math.max(0.06, height * grow);
      item.bar.alpha = 0.55 + state.env * 0.45;
    });

    if (state.model) {
      var bounce = state.speaking ? Math.sin(state.time * 9) * 0.004 * state.env : 0;
      var breathe = 1 + Math.sin(state.time * 1.15) * 0.004;
      state.model.scale.set(state.model.scale.x * 1);
      var base = state.model.scale.x / breathe;
      state.model.scale.set(base * breathe + bounce);
      state.model.rotation = state.tilt * 0.02;
      state.model.pivot.x = state.model.width / 2 / (state.model.scale.x || 1) * 0;
    }

    if (els.caption.text !== state.caption) els.caption.text = state.caption;
    state.captionAlpha = state.caption ? Math.min(1, state.captionAlpha + dt * 3) : Math.max(0, state.captionAlpha - dt * 2.5);
    els.caption.alpha = state.captionAlpha;
    els.caption.scale.set(1 + (1 - state.captionAlpha) * 0.04);

    els.status.alpha = state.statusAlpha;
    els.flashOverlay.alpha = Math.max(0, state.flash - dt * 2.2);

    drawFrame(w, h, Math.min(w, h) * 0.09, 0.6 + state.env * 0.6 + state.flash);
  }

  function tick(ticker) {
    var dt = Math.min(0.05, ticker.deltaMS / 1000);
    updateEnvelope(dt);
    updateBlink(dt);
    applyParams();
    updateVisuals(dt);
  }

  function onPointer(x, y) {
    var w = state.app.renderer.width / state.app.renderer.resolution;
    var h = state.app.renderer.height / state.app.renderer.resolution;
    state.gaze.tx = clamp((x / w - 0.5) * 2, -1, 1);
    state.gaze.ty = clamp((y / h - 0.5) * 2, -1, 1);
    state.flash = Math.max(state.flash, 0.35);
    if (state.model && state.model.internalModel) {
      var group = null;
      try {
        group = state.model.internalModel.hitTest(x, y);
      } catch (e) {}
      if (group && state.motions.indexOf(group) >= 0) {
        playMotion(group);
      } else if (state.motions.indexOf('Nod') >= 0) {
        playMotion('Nod');
      }
    }
    nativeArgs('onTap', [x, y]);
  }

  function bindInput() {
    var surface = state.app.view;
    surface.style.touchAction = 'none';
    var send = function (e) {
      var rect = surface.getBoundingClientRect();
      var touch = e.touches && e.touches[0] ? e.touches[0] : e;
      onPointer((touch.clientX - rect.left), (touch.clientY - rect.top));
    };
    surface.addEventListener('touchstart', send, { passive: true });
    surface.addEventListener('touchmove', send, { passive: true });
    surface.addEventListener('mousedown', send);
  }

  function boot() {
    if (typeof PIXI === 'undefined' || !PIXI.live2d) {
      nativeArgs('onError', ['PIXI/live2d runtime not loaded']);
      return;
    }

    state.app = new PIXI.Application({
      width: window.innerWidth,
      height: window.innerHeight,
      backgroundAlpha: 0,
      transparent: true,
      antialias: true,
      resolution: Math.min(2, window.devicePixelRatio || 1),
      autoDensity: true,
      powerPreference: 'high-performance'
    });
    document.body.appendChild(state.app.view);

    buildBackground();
    bindInput();
    state.app.ticker.add(tick);

    var refit = function () {
      var w = window.innerWidth;
      var h = window.innerHeight;
      if (w < 8 || h < 8) return;
      state.app.renderer.resize(w, h);
      layout();
    };
    window.addEventListener('resize', refit);
    window.addEventListener('orientationchange', function () {
      setTimeout(refit, 120);
    });
    [60, 200, 500, 1000, 2000].forEach(function (ms) {
      setTimeout(refit, ms);
    });
    refit();

    loadModel(DEFAULT_MODEL);
  }

  window.vtuberApi = {
    mood: function (mood) { setMood(mood); },
    speak: function (on) { state.speaking = !!on; if (!on) state.level = 0; },
    level: function (v) { state.level = clamp(parseFloat(v) || 0, 0, 1); },
    caption: function (text) { state.caption = text ? String(text) : ''; },
    status: function (text) { state.statusText = text ? String(text) : ''; state.statusAlpha = text ? 1 : 0; els.status.text = state.statusText; },
    gaze: function (x, y) {
      state.gaze.tx = clamp(parseFloat(x) || 0, -1, 1);
      state.gaze.ty = clamp(parseFloat(y) || 0, -1, 1);
    },
    tilt: function (deg) { state.tiltTarget = clamp(parseFloat(deg) || 0, -30, 30); },
    pulse: function () { state.flash = 0.6; },
    model: function (name) {
      if (!name || name === state.modelName) return;
      state.ready = false;
      loadModel(name);
    },
    isReady: function () { return state.ready; }
  };

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(boot, 0);
  } else {
    window.addEventListener('DOMContentLoaded', boot);
  }
})();
