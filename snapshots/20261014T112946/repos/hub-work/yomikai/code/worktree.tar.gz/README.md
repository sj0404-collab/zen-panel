<div align="center">

<img src="./.github/assets/logo.png" alt="Yomikai logo" width="128" height="128" />

# Yomikai
### Full-Featured Reader for Android
Discover and read manga, webtoons, comics, and more – easier than ever on your Android device.


[![Discord server](https://img.shields.io/discord/1464063546257182876.svg?label=&labelColor=6A7EC2&color=7389D8&logo=discord&logoColor=FFFFFF)](https://discord.com/invite/TXvTZdBuQa)
[![GitHub downloads](https://img.shields.io/github/downloads/sj0404-collab/yomikai/total?label=downloads&labelColor=27303D&color=0D1117&logo=github&logoColor=FFFFFF&style=flat)](https://github.com/sj0404-collab/yomikai/releases)

[![CI](https://img.shields.io/github/actions/workflow/status/sj0404-collab/yomikai/build.yml?labelColor=27303D)](https://github.com/sj0404-collab/yomikai/actions/workflows/build.yml)
[![License: Apache-2.0](https://img.shields.io/github/license/mihonapp/mihon?labelColor=27303D&color=0877d2)](/LICENSE)
<!--
[![Translation status](https://img.shields.io/weblate/progress/mihon?labelColor=27303D&color=946300)](https://hosted.weblate.org/engage/mihon/)
-->

## Download


[![Yomikai Stable](https://img.shields.io/github/release/sj0404-collab/yomikai.svg?maxAge=3600&label=Stable&labelColor=06599d&color=043b69)](https://github.com/sj0404-collab/yomikai/releases)
<!--
[![Mihon Beta](https://img.shields.io/github/v/release/mihonapp/mihon-preview.svg?maxAge=3600&label=Beta&labelColor=2c2c47&color=1c1c39)](https://mihon.app/download)
-->

*Requires Android 8.0 or higher.*

New to Yomikai? Check out our [**Getting Started Guide**](https://github.com/sj0404-collab/yomikai#readme) to set up your library.

---
</div>

## Features

Yomikai takes the features of Mihon and enhances them with advanced tools for language learners.

| Feature | Description |
| :--- | :--- |
| 🔍 **Built-in Text Recognition** | Fast, on-device OCR to extract text from images in real-time. Online models are also available for more languages. |
| 📖 **Yomitan Dictionary Support** | Seamless dictionary lookups for language learners across multiple languages. |
| **One-click Anki Cards** | Instantly create flashcards while reading and looking up new words. |

Core Reader Features:

* Experimental offline panel-by-panel reading.
* Local reading of content.
* A configurable reader with multiple viewers, reading directions and other settings.
* Tracker support: [MyAnimeList](https://myanimelist.net/), [AniList](https://anilist.co/), [Kitsu](https://kitsu.app/), [MangaUpdates](https://mangaupdates.com), [Shikimori](https://shikimori.one), [Bangumi](https://bgm.tv/) and [Hikka](https://hikka.io/) support.
* Categories to organize your library.
* Light and dark themes.
* Schedule updating your library for new chapters.
* Create backups locally to read offline or to your desired cloud service.
* Plus much more...

## 🤝 Contributing

Feature requests, bug reports, and pull requests are welcome. For major changes, please open an issue or join our [discord](https://discord.com/invite/TXvTZdBuQa) to discuss what you would like to change.

Before opening an issue, please check the [FAQ](https://github.com/sj0404-collab/yomikai#readme) and search [existing issues](https://github.com/sj0404-collab/yomikai/issues).

[Code of conduct](./CODE_OF_CONDUCT.md) · [Contributing guide](./CONTRIBUTING.md)

Model and dataset attribution for externally fetched ML assets is documented in [MODEL_ATTRIBUTION.md](./MODEL_ATTRIBUTION.md).

## Credits

Yomikai is a community-driven fork of the [Mihon](https://github.com/mihonapp/mihon) project. Thank you to all the people who have contributed.

> Note: this project is unaffiliated with the official Mihon Organization.

---

### Disclaimer
The developer(s) of this application have no affiliation with the content providers available. This application hosts zero content. Users are responsible for the content they bring or access.

### License
Copyright © 2015 Javier Tomás  
Copyright © 2024 Mihon Open Source Project  
Copyright © 2025 Yomikai  

Licensed under the Apache License, Version 2.0. See the [LICENSE](/LICENSE) file for more details.

