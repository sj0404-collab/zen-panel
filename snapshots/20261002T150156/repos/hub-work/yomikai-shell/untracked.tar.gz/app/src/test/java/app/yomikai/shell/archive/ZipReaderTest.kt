package app.yomikai.shell.archive

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Чтение ZIP без нативной библиотеки проверяется на JVM: от `ZipReader`
 * зависит только [FileChannel], то есть подделать дескриптор SAF не нужно.
 * Смысл тестов — ловить тихую порчу страниц: неверное смещение из локального
 * заголовка даёт не ошибку, а картинку чужой страницы.
 */
class ZipReaderTest {

    @Test
    fun `читает записи без сжатия`() {
        val file = stored("001.jpg" to page(1, 4096), "002.jpg" to page(2, 8192))
        file.channel().use { channel ->
            openZip(channel, file.length()).use { zip ->
                val entries = zip.imageEntries(setOf("jpg"))
                assertEquals(listOf("001.jpg", "002.jpg"), entries.map { it.name })
                assertTrue(page(1, 4096).contentEquals(zip.read(entries[0])), "байты первой страницы не совпали")
                assertTrue(page(2, 8192).contentEquals(zip.read(entries[1])), "байты второй страницы не совпали")
            }
        }
    }

    @Test
    fun `читает записи со сжатием`() {
        val file = deflated("p/001.png" to page(7, 200_000))
        file.channel().use { channel ->
            openZip(channel, file.length()).use { zip ->
                val entry = zip.find("p/001.png")
                assertNotNull(entry, "запись в подпапке не нашлась")
                assertTrue(page(7, 200_000).contentEquals(zip.read(entry!!)), "распакованная страница не совпала")
            }
        }
    }

    @Test
    fun `страницы идут в естественном порядке`() {
        val names = listOf("10.jpg", "2.jpg", "1.jpg", "20.jpg", "003.jpg")
        val file = stored(*names.map { it to page(1, 16) }.toTypedArray())
        file.channel().use { channel ->
            openZip(channel, file.length()).use { zip ->
                assertEquals(
                    listOf("1.jpg", "003.jpg", "2.jpg", "10.jpg", "20.jpg"),
                    zip.imageEntries(setOf("jpg")).map { it.name },
                )
            }
        }
    }

    @Test
    fun `главы тайтла сортируются как числа`() {
        assertEquals(
            listOf("Том 1", "том 2", "Том 10"),
            listOf("Том 10", "том 2", "Том 1").sortedWith { a, b -> naturalOrder(a, b) },
        )
    }

    @Test
    fun `страница больше прежнего лимита читается`() {
        // 64 МБ на запись были причиной, по которой тяжёлый CBR не открывался.
        val big = page(3, 70 * 1024 * 1024)
        val file = deflated("001.jpg" to big)
        file.channel().use { channel ->
            openZip(channel, file.length()).use { zip ->
                val entry = zip.find("001.jpg")
                assertNotNull(entry)
                assertTrue(big.contentEquals(zip.read(entry!!)), "большая страница прочиталась не целиком")
            }
        }
    }

    @Test
    fun `не zip читается как ошибка`() {
        val file = Files.createTempFile("shell", ".cbr").toFile()
        file.writeBytes(ByteArray(5000) { 7 })
        assertThrows(IOException::class.java) {
            file.channel().use { channel -> openZip(channel, file.length()).use { it.entries() } }
        }
    }

    private fun page(seed: Int, size: Int): ByteArray = ByteArray(size) { (it + seed).toByte() }

    private fun stored(vararg files: Pair<String, ByteArray>): File = zip(false, *files)

    private fun deflated(vararg files: Pair<String, ByteArray>): File = zip(true, *files)

    private fun zip(deflate: Boolean, vararg files: Pair<String, ByteArray>): File {
        val file = Files.createTempFile("shell", ".cbz").toFile()
        ZipOutputStream(file.outputStream().buffered()).use { out ->
            out.setMethod(if (deflate) ZipEntry.DEFLATED else ZipEntry.STORED)
            files.forEach { (name, bytes) ->
                // Запись без сжатия обязана знать размер и контрольную сумму
                // заранее, иначе ZipOutputStream её не пишет.
                val entry = ZipEntry(name)
                if (!deflate) {
                    entry.method = ZipEntry.STORED
                    entry.size = bytes.size.toLong()
                    entry.compressedSize = bytes.size.toLong()
                    entry.crc = java.util.zip.CRC32().apply { update(bytes) }.value
                }
                out.putNextEntry(entry)
                out.write(bytes)
                out.closeEntry()
            }
        }
        return file
    }

    private fun File.channel(): FileChannel = RandomAccessFile(this, "r").channel
}
