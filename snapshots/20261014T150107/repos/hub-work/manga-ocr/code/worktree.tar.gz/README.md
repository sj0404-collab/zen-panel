# manga-ocr

Сырой (verbatim) OCR русскоязычной главы манхвы разными движками, плюс скрипты
и workflow, которыми это получено. Никакой коррекции и «додумывания» — только
то, что реально вернул движок.

Фикстура: `Том 1 Глава 74` (63 страницы JPG, внутри `fixtures/vol1-ch74.cbz`).

## Что внутри

- `scripts/normcap_ocr.py` — ансамбль через OCR-слой NormCap (Tesseract):
  конфиги `resize_factor × psm`, победа по средней уверенности. Основной движок.
- `scripts/easyocr_ocr.py` — EasyOCR.
- `scripts/florence_ocr.py` — крошечный VLM `microsoft/Florence-2-base-ft` (463 МБ) с задачей `<OCR>`.
- `scripts/mobile_vlm_ocr.py` — маленькие VLM (`SmolVLM-256M-Instruct` 513 МБ и др.).
- `scripts/eslav_ocr.py` — PaddleOCR `eslav_PP-OCRv5_mobile_rec` (восточнославянский распознаватель).
- `scripts/rapidocr_ocr.py` — RapidOCR, ONNX-порт того же PP-OCRv5 `eslav` (без PaddlePaddle).
- `scripts/occular_ocr.py` — Occular-OCR: DBNet + SVTR + русская n-gram LM (ONNX, CPU); страницы обрабатываются параллельно (пул процессов), детектор ужат до 1152 px.
- `scripts/surya_ocr.py` — Surya (Segformer-детектор + распознаватель, 90+ языков).
- `.github/workflows/ocr-win.yml` — прогон NormCap/EasyOCR на Windows-раннере.
- `results/*.txt` — полученные сырые транскрипты.

## Результаты (63 страницы)

| Движок | Размер | Скорость | Качество на этом тексте |
|---|---|---|---|
| NormCap / Tesseract-`rus` | ~15 МБ (tessdata) | ~9 с/стр | **лучший**, читаемый русский текст |
| EasyOCR | ~100 МБ | ~30–90 с/стр | плохо: системно `Л→/`, `Н→H`, `Д→А/4`, `Ж→AI` |
| Florence-2-base-ft (VLM) | 463 МБ | ~170–200 с/стр (CPU) | частично: кириллицу узнаёт, но с ошибками и клеит строки без пробелов |
| SmolVLM-256M-Instruct (VLM) | 513 МБ | ~10–250 с/стр (CPU) | не OCR: описывает картинку, галлюцинирует |
| PaddleOCR `eslav_PP-OCRv5_mobile_rec` | ~14 МБ | ~20–31 с/стр (CPU) | хорошо: кириллица, но тянет арт-шум и клеит строки |
| RapidOCR (ONNX, PP-OCRv5 `eslav`) | ~14 МБ | **~1.3 с/стр** (CPU) | как PaddleOCR `eslav`, но без PaddlePaddle — самый быстрый |
| Occular-OCR (DBNet+SVTR+RU LM) | ~300 МБ (LM) | ~4 с/стр (4 процесса, CPU) | приемлемо: русская LM, но путает регистр и теряет буквы |

Вывод: среди моделей ≤600 МБ Florence-2-base-ft — единственная, что реально
читает текст, но по точности уступает Tesseract/NormCap; SmolVLM-256M для OCR
непригодна. Ближайший к Tesseract по качеству и при этом очень быстрый —
RapidOCR с восточнославянским распознавателем PP-OCRv5 (ONNX). Occular-OCR
заточен под русский, но на художественном тексте манхвы его LM портит регистр.
Surya (Segformer + распознаватель, 90+ языков) на CPU даёт ~90–190 с/стр, полный
прогон фикстуры не снят.

## Воспроизведение

```bash
# NormCap (нужен tesseract с языком rus)
python scripts/normcap_ocr.py <pages_dir> <out_dir>

# EasyOCR
python scripts/easyocr_ocr.py <pages_dir> <out_dir>

# PaddleOCR PP-OCRv5 eslav (нужен paddleocr)
python scripts/eslav_ocr.py <pages_dir> <out.txt> 63

# RapidOCR ONNX, тот же eslav-распознаватель (быстрее, без PaddlePaddle)
pip install rapidocr
python scripts/rapidocr_ocr.py <pages_dir> <out.txt> 63
# смена языка распознавателя: RAPIDOCR_LANG=cyrillic|eslav|...

# Occular-OCR (pip, ONNX, CPU; при первом запуске тянет веса и LM ~300 МБ)
pip install occular-ocr
python scripts/occular_ocr.py <pages_dir> <out.txt> 63
#   страницы идут параллельно (пул процессов); узкое место — детектор 1280x1280,
#   его длинная сторона ужата до 1152 px (OCCULAR_DET_VAL). Крутилки:
#   OCCULAR_WORKERS, OCCULAR_THREADS, OCCULAR_LM=0, OCCULAR_DEVICE=cuda.

# Surya (нужен torch; на CPU ~90–190 с/стр)
pip install surya-ocr
python scripts/surya_ocr.py <pages_dir> <out.txt> 63

# Florence-2 (transformers, trust_remote_code; CPU ок)
pip install torch transformers timm
python scripts/florence_ocr.py microsoft/Florence-2-base-ft <pages_dir> <out.txt> 63

# SmolVLM-256M
pip install torch transformers accelerate einops
python scripts/mobile_vlm_ocr.py HuggingFaceTB/SmolVLM-256M-Instruct <pages_dir> <out.txt> 63
```
